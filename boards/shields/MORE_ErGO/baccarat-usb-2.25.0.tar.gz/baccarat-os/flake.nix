{
  description = "Baccarat bot on a USB stick: boots straight into the game and the dashboard";

  inputs = {
    # the stable release: the browser and everything else get their security updates
    # here every day, without Hyprland or the rest changing under the bot
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-26.05";
    disko = {
      url = "github:nix-community/disko/v1.13.0";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs = { self, nixpkgs, disko, ... }:
    let
      system = "x86_64-linux";
      settings = import ./settings.nix;
    in {
      nixosConfigurations.usb = nixpkgs.lib.nixosSystem {
        inherit system;
        specialArgs = { inherit self settings; };
        modules = [
          disko.nixosModules.disko
          ./modules/disk.nix
          ./modules/hardware.nix
          ./modules/lockdown.nix
          ./modules/bot.nix
          ./modules/kiosk.nix
          ./modules/updates.nix
          ./modules/logs.nix
        ];
      };

      packages.${system} = let pkgs = nixpkgs.legacyPackages.${system}; in {
        # the bot itself, as a package (also what the service runs)
        bot = pkgs.callPackage ./modules/bot-package.nix { };
        # make-usb.sh: builds the stick as an image file, in a small VM
        image-script = self.nixosConfigurations.usb.config.system.build.diskoImagesScript;
        # … and writes only its used blocks to the stick, then fixes up the partition table
        inherit (pkgs) bmaptool gptfdisk;
        # make-usb.sh update: the system alone, and the tool that puts it on a stick
        system = self.nixosConfigurations.usb.config.system.build.toplevel;
        inherit (pkgs) nixos-install;
        # make-usb.sh publish: what it needs to upload an update
        inherit (pkgs) jq curl;
      };
    };
}
