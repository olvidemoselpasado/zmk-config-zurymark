# Baccarat bot on a USB stick

Start a computer from the stick: the screen comes up with the dashboard on the left
third and the game on the rest. Press **New session**. Power off, and nothing of the
session is left: **the stick boots clean every time.**

## Make it

On your NixOS computer, in this folder:

```sh
lsblk                                    # find the stick: e.g. /dev/sdb (the whole disk, not sdb1)
sudo ./make-usb.sh /dev/sdb              # build it and write it (asks ERASE only for a new stick)
```

**Every stick updates itself from the server.** Once set up, a new version is one
command on this computer, and nothing to unplug:

```sh
sudo ./make-usb.sh publish               # builds it, signs it, puts it on the server
```

Every stick hears of it within ~30 s and starts fetching at once — 20 at a time, the
rest wait their turn a minute or so — fetches only what changed (a new bot: a few MB),
and checks it was signed with your key. An idle stick installs it straight away. A
stick in a session downloads beside it, plays out the run in progress, **stops at the
next base bet**, installs, and **carries on with the session by itself** (same set-up,
the balance it stopped on). On the stick, a bar under the header shows the download;
while it is about to install, Start waits. The server's page shows how many sticks
have it (UPDATE) and each stick's progress in its VERSION column. `--newest` takes the newest
packages first — the newest browser — so publish with it now and then.

*The first time:* `publish` makes the signing key (kept on this computer, root only, in
`/var/lib/baccarat-usb-publish/`; its public half is `update-key.pub` in this folder) and
uploads the whole system once (a few GB). Sticks made before that don't know the key yet:
update each of them by hand **one last time** with `sudo ./make-usb.sh update /dev/sdX`.
Keep the key safe: whoever has it can update every stick.

**Changed something since, by hand?** (a new version of the bot, `settings.nix`, the screen…)
Don't make the stick again — update it:

```sh
sudo ./make-usb.sh update /dev/sdb       # only what changed is written: seconds to a minute
```

The new system is built here and copied into the stick's own system the way NixOS
installs itself: whatever the stick already has is skipped, so a new bot is a few MB.
It becomes a new entry in the boot menu (started by default); the one before stays
there. The Wi-Fi, the logs and the stick's id are left alone. `--data DIR` replaces the
data the bot starts from; `--newest` takes the newest packages first (otherwise the
stick does that by itself every day).

How: the whole stick is first built as one image file **here**, on this computer's fast
disk, in a small VM (a few minutes once the packages are downloaded). Then only the used
part of it — a few GB — is written to the stick in one long sequential write, which is
what flash sticks are fast at. If nothing changed since the last stick, the same image is
written again without rebuilding it. The image is kept in `/var/tmp/baccarat-usb-0` (delete
it whenever) — never in this folder, which is the system's recipe and is copied whole.

Options:

| | |
|---|---|
| `--data ~/path/to/bot/data` | the bot starts from this data folder at every boot: your coordinates, regions, patterns, tables, run history, window size. Changes made while it runs are lost at power-off (on purpose). The casino login is left out (the stick isn't encrypted); `--keep-login` puts it on. |
| `--wifi` | asks for the Wi-Fi it should join, and writes it on the stick once it is made. Ethernet needs nothing. |
| `wifi` | **only** changes the Wi-Fi on a stick already made: `sudo ./make-usb.sh wifi /dev/sdb` — seconds, nothing is rebuilt or rewritten. The Wi-Fi is never part of the image, so the same image works in every house. |
| `--no-update` | use the packages already pinned in `flake.lock` (faster, repeatable). Without it, every run takes the newest NixOS 26.05 packages — the newest browser. |
| `publish` | puts this folder's version on the server, for every stick to take (above) |
| `update` | puts this folder's changes on a stick already made, by hand (above) |
| `logs` | copies the stick's logs to `~/baccarat-usb-logs`: `sudo ./make-usb.sh logs /dev/sdb` (see below) |
| `--check` | only build the system, no stick, no sudo |

`imageSize` in `settings.nix` (26G) fits a "32 GB" stick; for a smaller one, lower it.

## What is on the stick

| Partition | |
|---|---|
| boot (1 GB) | systemd-boot, no editing at boot |
| system (`/nix`, the rest) | NixOS, Hyprland, Firefox, the bot. The only thing ever written to the stick. |
| **everything else** | **RAM**: the bot's data, the browser's profile and cookies, logs. Gone at power-off. |

## Who can do what

| | |
|---|---|
| **kiosk** (the screen) | Logs in by itself into Hyprland with two Firefox windows. No password, no shell, no terminal, no other program, no text consoles (Ctrl+Alt+F… does nothing). |
| **baccarat** (the bot) | A system service under its own user, its data folder readable by it alone. It may take pictures of kiosk's screen and click on it — that is its job. No internet: only the dashboard on the stick itself, and the report server. |
| **Firefox** | No developer tools, add-ons, `about:config` or `file://`; downloads go to one folder. The game's stream and the alarm play without a click; video is decoded by the graphics chip. |
| **Nobody** | is administrator: no root password, no sudo, no SSH. The stick is changed only from another computer, with `make-usb.sh`. |

## Updates

- **From the server** (`updates = "server"`, the default once you have published): what
  you `publish`, every stick takes by itself within a minute or so — a session in play
  first plays out its run and stops at the base bet, then carries on after. The boot menu
  keeps the last 5 systems, to go back to if one ever goes wrong.
- **From the internet** (`updates = "internet"`, or before the first publish): every day
  at 04:30 each stick fetches the newest NixOS packages itself and builds them, for its
  next start. The bot itself only changes with `update` by hand.

## Booting it

- Any 64-bit PC with UEFI, or an **Intel** Mac (hold ⌥ at power-on). Apple Silicon Macs
  can't. Intel/AMD graphics are best; NVIDIA is less reliable with Hyprland.
- Turn **Secure Boot off** in that computer's firmware settings.
- The computer's boot menu: usually F12, F11, F8 or Esc at power-on.
- A **USB 3 SSD** (Samsung T7, a USB NVMe enclosure…) boots and runs much better than
  a cheap stick.

**Two keys** (Super is the Windows key):
- **Super + right mouse button, dragged:** the line between the two windows moves. Then
  press **Save its width** on the dashboard (Game window), so **Fit window** can put it
  back later.
- **Super + C:** closes the window. The dashboard or the game comes back by itself,
  fresh, in its own place, a few seconds later; anything else (a casino pop-up) just
  goes.

The coordinates are points on the screen: on the same monitor, with the data copied
in (`--data`), they are right as they are, and **Fit window** (or the start of a
session) puts the game window back to its saved width. On another monitor, record
them again from the Interface tab — and set `monitorMode` in `settings.nix` so every
computer shows the same screen.

## When something goes wrong

There is no shell on the stick, so it keeps its own logs (while `keepLogs = true` in
`settings.nix`): every 2 minutes and at power-off, the log of that boot is written to
the stick — the last 5 boots. Back on your computer:

```sh
sudo ./make-usb.sh logs /dev/sdb
```

copies them to `~/baccarat-usb-logs/`. `<boot time>.short.log` is the one to paste: the
computer, its graphics chip, every warning and error, and everything the browser said.

**If the browser keeps crashing**, it fixes what it can by itself: after two crashes in
two minutes it starts again with one more thing turned off — first the graphics chip
(drawing in software), then Firefox's sandboxes, then Wayland (XWayland instead). The
log says which step it ended on. No "Firefox crashed" box is ever shown.

Turn `keepLogs` off once everything works: the logs have no passwords in them, but
whoever holds the stick could read them.

## The server: where each stick's set-up lives

The stick runs the **locked** bot: nothing of its set-up is on the stick. Its
coordinates, regions, patterns, settings, the game's page, its recorded tables and its
casino login are all kept on the server (`server` in `settings.nix`:
**http://192.168.0.2:4444** — see the `baccarat-server` folder).

- **First start of a stick:** it makes itself an id and a secret key (kept on the stick,
  readable by root only) and shows **WAITING FOR APPROVAL** with a code. Approve it on
  the server's page (same code). It then starts with nothing set up: set it up on the
  dashboard as usual, and every change goes to the server by itself a few seconds later
  (the header says **set-up saved hh:mm**). Put **the game's page** on the Interface
  tab: that is the page the stick opens beside the dashboard.
- **Every start after that:** it downloads its set-up and login from the server, then
  opens the dashboard and the game's page. Power off at any time: what changed was
  already sent (and is sent once more when it shuts down).
- The bot may reach the server's address on the network and nothing else. Every call is
  signed with the stick's key; the server gives the set-up and the login only to an
  approved stick.
- **No server**, or not approved: the stick waits, saying so on its screen.
- **HTTPS:** see the server's README (`serverCa` in `settings.nix`).

`--data DIR` still works: a set-up to start from on a stick the server has nothing for
yet.

## The files

| | |
|---|---|
| `make-usb.sh` | builds and writes the stick; `publish` puts a version on the server |
| `publish-update.sh` | uploads what is new of a version to the server (called by `publish`) |
| `update-key.pub` | the public half of the key updates are signed with (made by the first `publish`) |
| `settings.nix` | the casino's page, the screen, the keyboard, the time zone, the update hour |
| `flake.nix` | the system: NixOS 26.05 + the modules below |
| `modules/disk.nix` | boot + system partitions, `/` in RAM |
| `modules/hardware.nix` | boots anywhere: drivers, firmware, Wi-Fi, sound; kept light |
| `modules/lockdown.nix` | no root, no sudo, no consoles, no SSH, firewall |
| `modules/kiosk.nix` | the screen user, Hyprland, Firefox and its rules |
| `modules/bot.nix`, `bot-package.nix` | the locked bot as a confined service: its id, its key, its server |
| `modules/updates.nix` | the daily update, applied at the next boot |
| `modules/logs.nix` | while testing: each boot's log kept on the stick |
| `hyprland.lua`, `kiosk-session.sh` | the screen's config, and what opens the two windows |
| `bot/` | the bot itself |
