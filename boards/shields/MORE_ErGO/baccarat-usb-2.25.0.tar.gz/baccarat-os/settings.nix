# Everything you are likely to change, in one place. After a change: sudo ./make-usb.sh /dev/sdX
{
  # the game's page is set on each bot's dashboard (Interface tab) and kept on the
  # server with the rest of its set-up. This is only what opens before one is set
  # ("" = a blank window).
  gameUrl = "";

  # one fixed screen setup, so recorded coordinates stay right on every computer the
  # stick boots on. "preferred" = whatever the screen says it likes best; or e.g.
  # "1920x1080@60" -- then record the coordinates with that same setting.
  monitorMode = "preferred";
  monitorScale = "1";

  keyboardLayout = "us";
  timeZone = "UTC";                 # e.g. "America/New_York": the log times follow it

  # the stick is built as an image this big, then only its used part is written
  # (a "32 GB" stick holds about 29.8 GiB: 26G leaves room to spare)
  imageSize = "26G";

  # where the sticks' updates come from:
  #   "server"   -- what you publish (sudo ./make-usb.sh publish): every stick takes it
  #                 within ~15 minutes, while no session runs. Nothing to unplug.
  #   "internet" -- each stick fetches the newest NixOS packages itself, daily, at
  #                 updateTime, for its next start (the bot itself never changes).
  updates = "server";
  updateTime = "04:30";

  # the server: every bot's set-up and casino login are kept there (not on the stick),
  # and it reports to it. http:// or https://, an IP address (not a name) and the port.
  server = "http://192.168.0.2:4444";
  # HTTPS with a certificate you made yourself: the certificate file to trust, put in
  # this folder, e.g. ./server-ca.pem (a certificate is public: no secret in it).
  serverCa = null;

  # while testing: each boot's log is kept on the stick (the last 5 boots), and
  # `sudo ./make-usb.sh logs /dev/sdX` copies them to this computer. Turn it off once
  # everything works: whoever holds the stick could read them.
  keepLogs = true;
}
