#!/usr/bin/env bash
# Make the stick, from your NixOS computer. Run it from this folder.
#
#   sudo ./make-usb.sh /dev/sdX                 make the stick (the whole of it: minutes)
#   sudo ./make-usb.sh publish                  put this folder's version on the server: every stick
#                                               takes it by itself within ~15 min (no unplugging).
#                                               --newest: the newest packages (browser) first.
#   sudo ./make-usb.sh update /dev/sdX          put this folder's changes on a stick already made:
#                                               only what changed is written (seconds to a minute).
#                                               --data DIR too: its start-up data is replaced.
#                                               --newest: and take the newest packages first.
#   sudo ./make-usb.sh /dev/sdX --data DIR      … and the bot starts from this data folder at every boot
#                                               (without the casino login: --keep-login adds it)
#   sudo ./make-usb.sh /dev/sdX --wifi          … and asks for the Wi-Fi it should join
#   sudo ./make-usb.sh wifi /dev/sdX            only change the Wi-Fi on a stick already made
#                                               (seconds: nothing is rebuilt or rewritten)
#   sudo ./make-usb.sh logs /dev/sdX            copy the stick's logs (last 5 boots) into ~/baccarat-usb-logs
#   ./make-usb.sh --check                       only build the system (no stick, no sudo)
#
#   --no-update   keep the packages pinned in flake.lock (faster, repeatable). Without it,
#                 every full make takes the newest NixOS 26.05 packages -- the newest browser.
#                 (`update` keeps them unless --newest: the stick updates itself daily anyway.)
#
# How: the whole stick is built as one image file here, on this computer's fast disk,
# in a small VM (a few minutes). Then only the used part of it (a few GB) is written
# to the stick in one long sequential write -- what flash sticks are good at. If
# nothing changed since the last run, the image is reused and only written. It is kept
# in /var/tmp/baccarat-usb-0 (delete it whenever).
#
# /dev/sdX is the WHOLE stick (not sdX1); `lsblk` shows which one. Nothing of yours is
# kept on the stick: it boots clean every time.
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"

NIX=(nix --extra-experimental-features "nix-command flakes")
# The image and what it was built from live OUTSIDE this folder: everything in this
# folder is the system's recipe, copied whole into the system (and onto the stick).
BUILD="/var/tmp/baccarat-usb-$(id -u)"
START=$(date +%s)

say()  { printf '\n\033[1m%s\033[0m\n' "$*"; }
die()  { printf '\n\033[31m%s\033[0m\n' "$*" >&2; exit 1; }
took() { local s=$(( $(date +%s) - START )); printf '%dm%02ds' $((s / 60)) $((s % 60)); }
usage() { sed -n '2,31p' "$0" | sed 's/^# \{0,1\}//'; exit 1; }

if [ -d .build ]; then                        # where older versions kept it: 26 GB in the recipe
  rm -rf .build 2>/dev/null || die "Delete the old .build folder first: sudo rm -rf $PWD/.build"
fi

dev=""; data=""; wifi=0; check=0; refresh=""; keep_login=0; wifi_only=0; logs_only=0; update_only=0
publish=0
while [ $# -gt 0 ]; do
  case "$1" in
    --check)      check=1 ;;
    wifi)         wifi_only=1; wifi=1 ;;
    logs)         logs_only=1 ;;
    update)       update_only=1 ;;
    publish)      publish=1 ;;
    --newest)     refresh=1 ;;
    --data)       data="${2:?--data needs the folder}"; shift ;;
    --wifi)       wifi=1 ;;
    --keep-login) keep_login=1 ;;
    --no-update)  refresh=0 ;;
    -h|--help)    usage ;;
    /dev/*)       dev="$1" ;;
    *)            die "Don't know '$1'. ./make-usb.sh --help" ;;
  esac
  shift
done
# the newest packages: on every full make (unless --no-update); on `update` only if asked
[ -n "$refresh" ] || refresh=$(( update_only || publish ? 0 : 1 ))

refresh_packages() {
  if [ "$refresh" = 1 ]; then
    say "Taking the newest NixOS 26.05 packages (the newest browser)…"
    "${NIX[@]}" flake update
  fi
}

build_tools() {   # the image builder (which builds the whole system) and the writers
  say "Building the system…"
  mkdir -p "$BUILD"
  "${NIX[@]}" build --print-build-logs -o "$BUILD/image-script" .#image-script
  "${NIX[@]}" build -o "$BUILD/bmaptool" .#bmaptool
  "${NIX[@]}" build -o "$BUILD/gptfdisk" .#gptfdisk
}

# --- publish: the server hands this version to every stick ------------------------------
# The key updates are signed with is made here the first time and stays on this computer
# (root only). Its public half, update-key.pub, is part of this folder and so of every
# stick: a stick takes only what this key signed.
KEYDIR=/var/lib/baccarat-usb-publish
setting() { sed -n "s/^ *$1 = \"\{0,1\}\([^\";]*\)\"\{0,1\};.*/\1/p" settings.nix | head -n 1; }
if [ "$publish" = 1 ]; then
  [ "$(id -u)" = 0 ] || die "Run it with sudo: sudo ./make-usb.sh publish"
  sec="$KEYDIR/update-key.sec"
  if [ ! -s "$sec" ]; then
    install -d -m 0700 "$KEYDIR"
    ( umask 077; "${NIX[@]}" key generate-secret --key-name "baccarat-updates-$(date +%Y%m%d)" > "$sec" )
    say "Made the key updates are signed with: $sec (keep it — it never leaves this computer)."
  fi
  pub=$("${NIX[@]}" key convert-secret-to-public < "$sec")
  if [ "$(cat update-key.pub 2>/dev/null)" != "$pub" ]; then
    printf '%s\n' "$pub" > update-key.pub
    say "update-key.pub written. Sticks made before it don't know this key yet: update each of"
    echo "   them by hand ONE last time (sudo ./make-usb.sh update /dev/sdX). After that they"
    echo "   take every publish by themselves."
  fi
  server=$(setting server)
  [ -n "$server" ] || die "No server in settings.nix."
  case "$server" in *://*) ;; *) server="http://$server" ;; esac
  ca=$(setting serverCa)
  if [ -n "$ca" ] && [ "$ca" != null ]; then export BACCARAT_SERVER_CA="$PWD/${ca#./}"; fi
  refresh_packages
  say "Building the system…"
  mkdir -p "$BUILD"
  "${NIX[@]}" build --print-build-logs -o "$BUILD/system" .#system
  "${NIX[@]}" build -o "$BUILD/jq" .#jq
  "${NIX[@]}" build -o "$BUILD/curl" .#curl
  system=$(readlink -f "$BUILD/system")
  version=$(sed -n 's/^__version__ = "\(.*\)"/\1/p' bot/baccarat/__init__.py)
  say "Signing it and packing what is new (the first time: all of it, a few GB, once)…"
  "${NIX[@]}" copy --to "file://$BUILD/cache?compression=zstd&parallel-compression=true&secret-key=$sec" "$system"
  say "Sending what the server doesn't have to $server…"
  PATH="$BUILD/jq/bin:$(dirname "$(readlink -f "$BUILD/curl/bin/curl")"):$PATH" \
    ./publish-update.sh "$server" "$BUILD/cache" "$system" "${version:-?}"
  say "Published $version in $(took). Every stick starts fetching it within a minute (a session in play: at its next base bet)."
  echo "   The server's page shows how many have it (UPDATE)."
  exit 0
fi

if [ "$check" = 1 ]; then
  refresh_packages
  build_tools
  say "It builds ($(took)). Next: sudo ./make-usb.sh /dev/sdX"
  exit 0
fi

# The Wi-Fi is not part of the image -- so the image is the same in every house, and
# changing it is a few seconds: the stick's system partition is mounted, one small file
# written (readable by root only), and unmounted.
ask_wifi() {
  read -r -p "Wi-Fi name (SSID): " ssid
  read -r -s -p "Wi-Fi password: " psk; echo
}
nix_part() {      # the stick's system partition
  local p
  partprobe "$dev" 2>/dev/null || true
  p=$(lsblk -nrpo NAME,PARTLABEL "$dev" | awk '$2=="disk-main-nix" {print $1}')
  [ -n "$p" ] || die "$dev wasn't made by make-usb.sh (no system partition on it)."
  echo "$p"
}
write_wifi() {
  local nixp mnt
  nixp=$(nix_part)
  mnt=$(mktemp -d)
  mount "$nixp" "$mnt"
  install -d -m 0700 "$mnt/var/baccarat-os"
  ( umask 077; printf 'WIFI_SSID=%s\nWIFI_PSK=%s\n' "$ssid" "$psk" > "$mnt/var/baccarat-os/wifi.env" )
  sync; umount "$mnt"; rmdir "$mnt"
  say "Wi-Fi set to \"$ssid\". It joins at the next boot."
}

# --- the stick ----------------------------------------------------------------------
[ -n "$dev" ] || usage
[ "$(id -u)" = 0 ] || die "Run it with sudo: sudo ./make-usb.sh $*"
[ -b "$dev" ] || die "$dev is not a disk. 'lsblk' lists them; give the whole stick, e.g. /dev/sdb."
[ "$(lsblk -ndo TYPE "$dev")" = disk ] || die "$dev is a partition — give the whole stick, e.g. /dev/sdb."
if lsblk -nrpo MOUNTPOINT "$dev" | grep -qxE '/|/boot|/nix|/home|/nix/store'; then
  die "$dev holds this computer's own system. That is not the stick."
fi
if [ -n "$data" ]; then
  [ -d "$data/sites" ] || [ -f "$data/site.json" ] || die "$data doesn't look like the bot's data folder (no sites/ or site.json)."
fi
lsblk -o NAME,SIZE,MODEL,TRAN "$dev"

# the data the bot starts from, ready to go on the stick (in $extras/seed)
extras=$(mktemp -d); chmod 700 "$extras"
trap 'rm -rf "$extras"' EXIT
stage_seed() {
  [ -n "$data" ] || return 0
  mkdir -p "$extras/seed"
  cp -a "$data/." "$extras/seed/"
  rm -rf "$extras/seed/logs" "$extras/seed/debug"   # old logs and screenshots: not needed
  rm -f "$extras/seed/bot_id" "$extras/seed/bot_key" # each stick is its own bot
  if [ "$keep_login" = 0 ]; then
    # the stick isn't encrypted: whoever holds it could read the casino password
    find "$extras/seed" -name login.json -delete
    say "(the casino login is left out — --keep-login puts it on the stick)"
  fi
  chmod -R go-rwx "$extras/seed"
}

unmount_all() { for p in $(lsblk -nrpo NAME "$dev" | tail -n +2); do umount "$p" 2>/dev/null || true; done; }

if [ "$logs_only" = 1 ]; then
  unmount_all
  nixp=$(nix_part)
  mnt=$(mktemp -d)
  mount -o ro "$nixp" "$mnt"
  home=$(getent passwd "${SUDO_USER:-root}" | cut -d: -f6)
  out="${home:-$PWD/..}/baccarat-usb-logs"
  mkdir -p "$out"
  if [ -d "$mnt/var/baccarat-os/logs" ]; then cp -a "$mnt/var/baccarat-os/logs/." "$out/"; fi
  umount "$mnt"; rmdir "$mnt"
  chown -R "${SUDO_USER:-root}": "$out"; chmod -R u+rwX,go-rwx "$out"
  newest=$(find "$out" -name '*.short.log' -printf '%T@ %p\n' | sort -rn | head -n 1 | cut -d' ' -f2-)
  [ -n "$newest" ] || die "No logs on the stick yet (keepLogs = true in settings.nix, and the stick started at least once, for a minute)."
  ls -lt "$out"
  say "The last boot, short: $newest"
  echo "Paste it to Claude, or: less $newest"
  exit 0
fi

# --- update: only what changed --------------------------------------------------------
# The new system is built here, then copied into the stick's own store the way NixOS
# installs itself (nixos-install): store paths the stick already has are skipped, so a
# change to the bot or the screen writes a few MB, not the whole image. It becomes a new
# entry in the boot menu, started by default; the one before stays there to go back to.
# The Wi-Fi, the logs, the stick's id: untouched.
if [ "$update_only" = 1 ]; then
  refresh_packages
  say "Building the new system…"
  mkdir -p "$BUILD"
  "${NIX[@]}" build --print-build-logs -o "$BUILD/system" .#system
  "${NIX[@]}" build -o "$BUILD/nixos-install" .#nixos-install
  stage_seed
  unmount_all
  nixp=$(nix_part)
  espp=$(lsblk -nrpo NAME,PARTLABEL "$dev" | awk '$2=="disk-main-ESP" {print $1}')
  [ -n "$espp" ] || die "$dev has no boot partition made by this script."
  mnt=$(mktemp -d); chmod 755 "$mnt"
  trap 'umount -R "$mnt" 2>/dev/null; rmdir "$mnt" 2>/dev/null; rm -rf "$extras"' EXIT
  mkdir -p "$mnt/nix" "$mnt/boot"
  mount "$nixp" "$mnt/nix"
  mount -o umask=0077 "$espp" "$mnt/boot"
  before=$(df --output=used -B1M "$mnt/nix" | tail -n 1)
  say "Putting the changes on the stick…"
  "$BUILD/nixos-install/bin/nixos-install" --root "$mnt" --system "$(readlink -f "$BUILD/system")" \
    --no-root-passwd --no-channel-copy
  if [ -n "$data" ]; then
    rm -rf "$mnt/nix/var/baccarat-os/seed"
    install -d -m 0700 "$mnt/nix/var/baccarat-os"
    cp -a "$extras/seed" "$mnt/nix/var/baccarat-os/seed"
    chown -R root:root "$mnt/nix/var/baccarat-os/seed"
    say "The bot's start-up data replaced."
  fi
  after=$(df --output=used -B1M "$mnt/nix" | tail -n 1)
  sync
  umount "$mnt/boot" "$mnt/nix"
  rm -rf --one-file-system "$mnt"        # what the installer left beside the stick (/etc …): not on it
  trap 'rm -rf "$extras"' EXIT
  say "Updated in $(took) ($((after - before)) MB more on the stick). Unplug it: it starts the new system."
  exit 0
fi

if [ "$wifi_only" = 1 ]; then
  unmount_all
  ask_wifi
  write_wifi
  exit 0
fi
[ "$wifi" = 1 ] && ask_wifi            # asked now, written once the stick is made
[ -e /dev/kvm ] || say "Note: this computer has no /dev/kvm — building the image will be slow."

# A stick this script made before is simply made again. Any other disk is asked about
# once: a typo in /dev/sdX must never wipe the wrong one.
if lsblk -nrpo PARTLABEL "$dev" | grep -qx disk-main-nix; then
  say "$dev is a baccarat stick: making it again."
else
  say "$dev was not made by this script. EVERYTHING on it will be erased. Type ERASE to go on:"
  read -r answer; [ "$answer" = ERASE ] || die "Left alone."
fi

# what goes on the stick besides the system: the data to start from
stage_seed
args=()
if [ -n "$data" ]; then
  args+=(--post-format-files "$extras/seed" /nix/var/baccarat-os/seed)
fi

refresh_packages
build_tools

# the same system and the same extras as last time? then the image is already right
stamp="$(readlink -f "$BUILD/image-script") $( (cd "$extras" && find . -type f -exec sha256sum {} + | sort) | sha256sum)"
if [ -f "$BUILD/main.raw" ] && [ -f "$BUILD/main.bmap" ] && [ "$(cat "$BUILD/stamp" 2>/dev/null)" = "$stamp" ]; then
  say "Nothing changed since the last stick: using the same image."
else
  say "Building the stick's image here, in a small VM (a few minutes)…"
  rm -f "$BUILD/main.raw" "$BUILD/main.bmap" "$BUILD/stamp"
  ( cd "$BUILD" && "$BUILD/image-script" --build-memory 4096 "${args[@]}" )
  [ -f "$BUILD/main.raw" ] || die "The image wasn't made (see above)."
  "$BUILD/bmaptool/bin/bmaptool" create -o "$BUILD/main.bmap" "$BUILD/main.raw"
  printf '%s' "$stamp" > "$BUILD/stamp"
  chmod 600 "$BUILD/main.raw"                      # it may hold your data and Wi-Fi password
fi

need=$(stat -c %s "$BUILD/main.raw"); have=$(blockdev --getsize64 "$dev")
[ "$have" -ge "$need" ] || die "The stick holds $((have / 1000000000)) GB; the image is $((need / 1000000000)) GB. Lower imageSize in settings.nix."

say "Writing to $dev (only the used part: $(du -h "$BUILD/main.raw" | cut -f1))…"
unmount_all
"$BUILD/bmaptool/bin/bmaptool" copy --bmap "$BUILD/main.bmap" "$BUILD/main.raw" "$dev"
# the image was smaller than the stick: move the partition table's backup copy to the
# real end of the stick, where it belongs
"$BUILD/gptfdisk/bin/sgdisk" -e "$dev" >/dev/null
partprobe "$dev" 2>/dev/null || true
sync
udevadm settle 2>/dev/null || true
[ "$wifi" = 1 ] && write_wifi
say "Done in $(took). Unplug it, start a computer from it."
