"""strategies.py — kept so existing imports keep working.

The game logic moved into baccarat/core/: game, strategy, rules, staking,
session, road, screening. `import strategies` hands back that package itself,
so patching a name through this file reaches the real one.

Nothing new should import this:

    from baccarat.core.session import Session
    from baccarat.core.road import find_pattern
"""

import sys

import baccarat.core

sys.modules[__name__] = baccarat.core
