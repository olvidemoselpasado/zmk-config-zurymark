#!/bin/bash
# Set the bot up on a Mac: a private Python environment (.venv) with everything it
# needs, then the tests, then what to do next. Safe to run again at any time.
#
#   sh setup_mac.sh
#
set -e
cd "$(dirname "$0")"

say() { printf '\n== %s\n' "$*"; }

# A Python of 3.10 or newer, with Tk. The one from python.org has both; the one macOS
# ships (/usr/bin/python3) is too old.
PY=""
for c in "$PYTHON" \
         /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.11/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.10/bin/python3 \
         python3.13 python3.12 python3.11 python3.10 python3; do
    [ -n "$c" ] || continue
    command -v "$c" >/dev/null 2>&1 || continue
    if "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
        PY="$c"; break
    fi
done
if [ -z "$PY" ]; then
    echo "No Python 3.10 or newer found."
    echo "Install the latest Python from https://www.python.org/downloads/macos/"
    echo "(it includes Tk, which 'Select the box' needs), then run this again."
    exit 1
fi
say "Using $("$PY" -c 'import sys; print(sys.version.split()[0], "at", sys.executable)')"

if ! "$PY" -c 'import tkinter' 2>/dev/null; then
    echo "   Note: this Python has no Tk, so 'Select the box' won't work."
    echo "   Python from python.org has it; with Homebrew: brew install python-tk"
fi

say "Making the environment (.venv)"
"$PY" -m venv .venv
.venv/bin/python -m pip install --quiet --upgrade pip
say "Installing what the bot needs (a few minutes the first time)"
.venv/bin/python -m pip install --quiet -r requirements-mac.txt

say "Running the tests"
.venv/bin/python -m pytest tests -q -p no:cacheprovider | tail -1

chmod +x "Start bot.command" "Check this Mac.command" 2>/dev/null || true
# files from a download are marked as such, and macOS then refuses to open the
# double-click launchers; this folder is yours, so the mark comes off
xattr -dr com.apple.quarantine . 2>/dev/null || true

cat <<'MSG'

== Done. Next:

 1. Double-click "Check this Mac.command". The first time, macOS asks for two
    permissions for Terminal: Screen Recording and Accessibility. Allow both
    (System Settings › Privacy & Security), quit Terminal completely (⌘Q),
    and double-click it again until it says everything is working.

 2. Double-click "Start bot.command" to open the dashboard.

 3. On the Interface tab, record the coordinates and select the regions for this
    screen — the ones from another computer don't carry over.

MSG
