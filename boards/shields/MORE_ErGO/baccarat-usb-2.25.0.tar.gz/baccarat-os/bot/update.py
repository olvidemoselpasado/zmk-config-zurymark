#!/usr/bin/env python3
"""Apply a code update to the bot without touching your data.

    python3 update.py --dry-run         say exactly what it would do
    python3 update.py                   do it
    python3 update.py --undo            put the code back as it was before the last update
    python3 update.py some/other.tar.gz use that archive instead of the newest one here
    python3 update.py --folder ~/bot    if this script is not sitting in the bot folder

Put the bot-update-*.tar.gz you were sent next to this script and run it. That is all.

What it does, in this order:

    1. checks the archive: nothing outside the folder, nothing in data/, every file
       the size and checksum its own list says
    2. writes down the checksum of every file in data/
    3. sorts every file the update changes into: new, already up to date, safe to
       replace, or edited by you -- and stops before changing anything if any are
       edited by you, unless you say --force (your copy is kept either way)
    4. saves every file it is about to replace in data/attic/updates/<when>/
    5. writes the new files, each one in a single step so a crash can't leave half a file
    6. proves it: every written file has the checksum the update says, every file in
       data/ is byte for byte what it was, the package imports and finds your data,
       and the tests pass

Only the files this update changes are touched. A file you have edited that the
update does not change is left exactly as it is, and named so you know.

data/ is never written to, except for the saved copies in data/attic/updates/.
Nothing is deleted: a file the update removes is moved into that same folder.

Safe to run twice: the second time everything is already up to date.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from pathlib import Path

ARCHIVE_GLOB = "bot-update*.tar.gz"
MANIFEST = "UPDATE.json"
UPDATES = Path("data") / "attic" / "updates"     # where replaced files are kept


# --- saying what is happening ----------------------------------------------

class Log:
    def __init__(self, dry):
        self.dry, self.steps = dry, 0

    def step(self, text):
        self.steps += 1
        print(f"\n{self.steps}. {text}")

    def do(self, text):
        print(f"   {'would ' if self.dry else ''}{text}")

    def note(self, text):
        print(f"   - {text}")

    def warn(self, text):
        print(f"   ! {text}")


def sha(path, blocks=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(blocks):
            h.update(chunk)
    return h.hexdigest()


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(folder):
    """Every file under `folder`, by path: its checksum. The saved updates are left
    out -- they are the one thing this script adds to data/ -- and so are the logs,
    which a bot left running keeps writing to."""
    out = {}
    if not folder.is_dir():
        return out
    for p in sorted(folder.rglob("*")):
        rel = p.relative_to(folder.parent)
        if p.is_file() and "__pycache__" not in p.parts \
                and not str(rel).startswith(str(UPDATES)) \
                and not str(rel).startswith(str(Path("data") / "logs")):
            out[str(rel)] = sha(p)
    return out


def installed_version(folder):
    init = folder / "baccarat" / "__init__.py"
    if not init.is_file():
        return None
    m = re.search(r'^__version__\s*=\s*"([^"]+)"', init.read_text(errors="replace"), re.M)
    return m.group(1) if m else None


# --- the archive -------------------------------------------------------------

def find_archive(given, here, folder):
    if given:
        p = Path(given).expanduser().resolve()
        if not p.is_file():
            sys.exit(f"There is no archive at {p}.")
        return p
    found = {p.resolve() for d in (here, folder) for p in d.glob(ARCHIVE_GLOB)}
    if not found:
        sys.exit(f"No {ARCHIVE_GLOB} next to this script (looked in {here}"
                 + (f" and {folder}" if folder != here else "") + ").\n"
                 "Put the archive you were sent beside it, or name it: "
                 "python3 update.py path/to/bot-update.tar.gz")
    return max(found, key=lambda p: p.stat().st_mtime)


def read_archive(path):
    """The update's list and the bytes of every file in it, after checking that
    it only writes where it should."""
    files, manifest = {}, None
    with tarfile.open(path) as t:
        for m in t.getmembers():
            parts = Path(m.name).parts
            if m.name.startswith("/") or ".." in parts:
                sys.exit(f"{path.name} wants to write outside the folder ({m.name}). "
                         "Not using it.")
            if m.isdir():
                continue
            if not m.isfile():
                sys.exit(f"{path.name} contains a link or a device ({m.name}). Not using it.")
            rel = Path(*parts[1:]) if parts and parts[0] == "bot" else Path(*parts)
            if rel.parts and rel.parts[0] == "data":
                sys.exit(f"{path.name} contains {rel} -- an update never writes to data/. "
                         "Not using it.")
            data = t.extractfile(m).read()
            if str(rel) == MANIFEST:
                manifest = json.loads(data)
            else:
                files[str(rel)] = data
    if manifest is None:
        sys.exit(f"{path.name} has no {MANIFEST}: it isn't an update archive.")
    listed = manifest.get("files", {})
    bad = [r for r, h in listed.items() if r not in files or sha_bytes(files[r]) != h]
    extra = [r for r in files if r not in listed]
    if bad or extra:
        sys.exit(f"{path.name} is damaged or incomplete: "
                 + ", ".join((bad + extra)[:4]) + ". Download it again.")
    return manifest, files


# --- deciding ----------------------------------------------------------------

def plan(folder, manifest, force):
    """Sort every file the update cares about. Nothing is touched here."""
    base = manifest.get("base", {})          # each file as it was in the version updated from
    known = manifest.get("known", {})        # other versions of a file already handed over
    out = {"new": [], "same": [], "replace": [], "yours": [], "untouched_edits": [],
           "remove": [], "remove_yours": []}
    for rel, new in manifest["files"].items():
        dest = folder / rel
        old = base.get(rel)                  # None: the file is new in this update
        if not dest.is_file():
            out["new"].append(rel)
            continue
        have = sha(dest)
        if have == new:
            out["same"].append(rel)
        elif (old is not None and have == old) or have in known.get(rel, ()):
            out["replace"].append(rel)       # a version of ours, not an edit of yours
        elif old == new:
            out["untouched_edits"].append(rel)   # edited by you, and the update doesn't change it
        else:
            out["yours"].append(rel)         # changed by you (or a different version)
    for rel in manifest.get("removed", []):
        dest = folder / rel
        if dest.is_file():
            (out["remove"] if sha(dest) == base.get(rel) else out["remove_yours"]).append(rel)
    if force:
        out["replace"] += out["yours"]
        out["remove"] += out["remove_yours"]
    return out


# --- doing -------------------------------------------------------------------

def save_copies(folder, rels, moving, store, log):
    """Copy (or for removed files, move) each file into the update's folder."""
    for rel in rels:
        src, dest = folder / rel, store / "files" / rel
        if log.dry:
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        if rel in moving:
            shutil.move(str(src), str(dest))
        else:
            shutil.copy2(src, dest)


def write_file(dest, data):
    """In one step: written beside it first, then swapped in. A crash part way leaves
    the old file, never half of the new one."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=dest.parent, prefix=f".{dest.name}.")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        if dest.exists():
            shutil.copymode(dest, tmp)
        else:                                   # new: runnable if it is a script to run
            os.chmod(tmp, 0o755 if dest.suffix in (".sh", ".command") else 0o644)
        os.replace(tmp, dest)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def drop_caches(folder):
    for d in folder.rglob("__pycache__"):
        if "data" not in d.relative_to(folder).parts:
            shutil.rmtree(d, ignore_errors=True)


# --- proving it worked ------------------------------------------------------

def self_test(folder, log):
    """Ask the program itself which version it is and which data it can see."""
    probe = (
        "import sys; sys.path.insert(0, %r)\n"
        "from baccarat.store import paths\n"
        "import baccarat, bet\n"
        "d = paths.data_dir()\n"
        "print('version', baccarat.__version__)\n"
        "print('data', d, '(' + paths.layout() + ')')\n"
        "print('sites', sorted(p.name for p in (d / 'sites').iterdir()) "
        "if (d / 'sites').is_dir() else [])\n"
        "print('tables', len(list((d / 'tables').glob('table_*.json'))) "
        "if (d / 'tables').is_dir() else 0)\n"
        "print('site-in-use', bet.site_name() or '-')\n"
    ) % str(folder)
    r = subprocess.run([sys.executable, "-c", probe], cwd=folder,
                       capture_output=True, text=True)
    if r.returncode:
        log.warn("the package did not import:")
        for line in (r.stderr or "").strip().split("\n")[-12:]:
            log.warn("    " + line)
        return False
    for line in r.stdout.strip().split("\n"):
        key, _, value = line.partition(" ")
        log.note(f"{key.replace('-', ' ')}: {value}")
    return True


def run_tests(folder, log):
    if not (folder / "tests").is_dir():
        return None
    r = subprocess.run([sys.executable, "-m", "pytest", "tests", "-q", "-o", "addopts=",
                        "--tb=line", "-p", "no:cacheprovider"],
                       cwd=folder, capture_output=True, text=True)
    if "No module named pytest" in (r.stderr or ""):
        log.note("tests: skipped (pytest is not installed)")
        return None
    last = (r.stdout.strip().split("\n") or [""])[-1]
    if r.returncode == 0:
        log.note(f"tests: {last}")
        return True
    for line in [x for x in r.stdout.split("\n") if "FAILED" in x or "ERROR" in x][:8]:
        log.warn("    " + line.strip()[:100])
    log.warn(f"tests: {last}")
    log.warn("Run `python3 -m pytest tests -q` for the detail. Your data is untouched "
             "either way, and `python3 update.py --undo` puts the code back.")
    return False


# --- the way back -------------------------------------------------------------

def undo(folder, log):
    root = folder / UPDATES
    done = sorted(d for d in root.iterdir() if (d / "record.json").is_file()
                  and not (d / "undone").exists()) if root.is_dir() else []
    if not done:
        sys.exit("There is no update to undo.")
    store = done[-1]
    rec = json.loads((store / "record.json").read_text())
    log.step(f"Putting back the code from before the update to {rec['to']} "
             f"({rec['when']})")
    gone = []
    for rel in rec["added"]:
        dest = folder / rel
        if dest.is_file() and sha(dest) == rec["wrote"].get(rel):
            log.do(f"set aside {rel} (new in that update)")
            gone.append(rel)
    for rel in rec["replaced"] + rec["removed"]:
        log.do(f"restore {rel}")
    changed_since = [rel for rel in rec["replaced"] if (folder / rel).is_file()
                     and sha(folder / rel) != rec["wrote"].get(rel)]
    if changed_since:
        log.warn("these were changed after the update and will be replaced too "
                 "(copies are kept in the undo folder):")
        for rel in changed_since:
            log.warn(f"    {rel}")
    if log.dry:
        return 0
    aside = store / "undo"
    for rel in gone + changed_since:
        dest = aside / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(folder / rel, dest)
    for rel in gone:
        (folder / rel).unlink()
    for rel in rec["replaced"] + rec["removed"]:
        write_file(folder / rel, (store / "files" / rel).read_bytes())
    drop_caches(folder)
    (store / "undone").write_text(time.strftime("%Y-%m-%d %H:%M:%S") + "\n")
    log.note(f"back to {rec['from'] or 'the previous version'}")
    self_test(folder, log)
    return 0


# --- putting it together ----------------------------------------------------

def main():
    ap = argparse.ArgumentParser(prog="update.py",
                                 description="Apply a code update without touching your data.")
    ap.add_argument("archive", nargs="?", help=f"the update (default: the newest {ARCHIVE_GLOB} here)")
    ap.add_argument("--folder", type=Path, help="the bot folder (default: the one this script is in)")
    ap.add_argument("--dry-run", action="store_true", help="say what it would do and change nothing")
    ap.add_argument("--force", action="store_true",
                    help="also replace files you have edited (your copies are kept)")
    ap.add_argument("--undo", action="store_true", help="put back the code from before the last update")
    ap.add_argument("--no-tests", action="store_true", help="skip running the tests at the end")
    ap.add_argument("-y", "--yes", action="store_true", help="do not ask")
    args = ap.parse_args()

    here = Path(__file__).resolve().parent
    folder = (args.folder or here).expanduser().resolve()
    log = Log(args.dry_run)
    if sys.version_info < (3, 10):
        sys.exit(f"This needs Python 3.10 or newer. You have {sys.version.split()[0]}.")
    if not (folder / "baccarat").is_dir():
        sys.exit(f"{folder} does not look like the bot: there is no baccarat/ in it. "
                 "Pass the right folder with --folder.")

    print("=" * 72)
    print("  Updating the bot" + ("  (dry run: nothing will change)" if args.dry_run else ""))
    print("=" * 72)
    if args.undo:
        return undo(folder, log)

    log.step("Checking the update")
    archive = find_archive(args.archive, here, folder)
    manifest, files = read_archive(archive)
    have = installed_version(folder)
    log.note(f"archive: {archive.name}")
    log.note(f"installed: {have or 'unknown'}   →   update: {manifest['version']} "
             f"(made from {manifest.get('from') or '?'})")
    for line in manifest.get("changes", []):
        log.note(f"in this update: {line}")

    log.step("Writing down your data")
    data_before = fingerprint(folder / "data")
    log.note(f"{len(data_before)} files in data/ — they will be checked again at the end")

    log.step("Working out what changes")
    p = plan(folder, manifest, args.force)
    for rel in p["new"]:
        log.do(f"add      {rel}")
    for rel in p["replace"]:
        log.do(f"replace  {rel}" + ("   (edited by you — your copy is kept)"
                                    if rel in p["yours"] else ""))
    for rel in p["remove"]:
        log.do(f"set aside {rel}   (no longer part of the bot)")
    if p["same"]:
        log.note(f"{len(p['same'])} file(s) already up to date")
    for rel in p["untouched_edits"]:
        log.note(f"{rel} is edited by you; this update doesn't change it, so it is left alone")
    if p["untouched_edits"] and have and have != manifest.get("from"):
        log.warn(f"(you have {have}, and this update was made from {manifest.get('from')}: "
                 "the files above may be your old version's rather than edits — if the tests "
                 "fail at the end, `python3 update.py --undo` and ask for an update made "
                 f"from {have})")
    if (p["yours"] or p["remove_yours"]) and not args.force:
        if have and have != manifest.get("from"):
            log.warn(f"(this update was made from {manifest.get('from')}, and you have "
                     f"{have} — so these may be older versions rather than your edits)")
        log.warn("These are different from every version of them this update knows, so "
                 "replacing them could lose a change of yours:")
        for rel in p["yours"] + p["remove_yours"]:
            log.warn(f"    {rel}")
        log.warn("Nothing has been changed. Run again with --force to replace them; "
                 "your copies are kept in data/attic/updates/.")
        return 2
    work = p["new"] + p["replace"] + p["remove"]
    if not work:
        print("\n  Already up to date. Nothing to do.")
        return 0

    if args.dry_run:
        print("\n" + "=" * 72)
        print("  Dry run only. Nothing was changed. Run it again without --dry-run.")
        print("=" * 72)
        return 0
    if not args.yes:
        print("\n" + "-" * 72)
        print(f"  Ready: {len(work)} file(s). Your data is not touched, and every replaced")
        print("  file is kept, so `python3 update.py --undo` puts it all back.")
        print("-" * 72)
        if input("  Type yes to go ahead: ").strip().lower() != "yes":
            print("\nLeft alone. Nothing changed.")
            return 1

    log.step("Keeping the files it replaces")
    stamp = time.strftime("%Y%m%d_%H%M%S")
    store = folder / UPDATES / f"{stamp}_{have or 'unknown'}-to-{manifest['version']}"
    save_copies(folder, p["replace"], set(), store, log)
    save_copies(folder, p["remove"], set(p["remove"]), store, log)
    log.note(f"in {store.relative_to(folder)}")

    log.step("Writing the new code")
    wrote = {}
    for rel in p["new"] + p["replace"]:
        write_file(folder / rel, files[rel])
        wrote[rel] = manifest["files"][rel]
    (store / "record.json").parent.mkdir(parents=True, exist_ok=True)
    (store / "record.json").write_text(json.dumps({
        "when": time.strftime("%Y-%m-%d %H:%M:%S"), "from": have, "to": manifest["version"],
        "archive": archive.name, "added": p["new"], "replaced": p["replace"],
        "removed": p["remove"], "wrote": wrote}, indent=1))
    drop_caches(folder)
    log.note(f"{len(wrote)} file(s) written, {len(p['remove'])} set aside")

    log.step("Checking")
    wrong = [rel for rel, h in wrote.items() if sha(folder / rel) != h]
    for rel in wrong:
        log.warn(f"{rel} doesn't have the checksum the update says")
    if not wrong:
        log.note(f"the {len(wrote)} file(s) written are exactly the update's")
    works = self_test(folder, log)
    passed = None if args.no_tests else run_tests(folder, log)
    # last, so it covers the tests and the import as well as the update itself
    data_after = fingerprint(folder / "data")
    changed = sorted(k for k in set(data_before) | set(data_after)
                     if data_before.get(k) != data_after.get(k))
    if changed:
        log.warn(f"{len(changed)} file(s) in data/ are different — this should never happen:")
        for rel in changed[:10]:
            log.warn(f"    {rel}")
    else:
        log.note(f"data/: all {len(data_after)} files byte for byte as they were")

    ok = works and not wrong and not changed and passed is not False
    print("\n" + "=" * 72)
    print(f"  {'Done' if ok else 'Finished, but not cleanly — read the ! lines above'}: "
          f"{have or '?'} → {manifest['version']}.")
    print("  Undo:  python3 update.py --undo")
    print("=" * 72)
    return 0 if ok else 2


if __name__ == "__main__":
    sys.exit(main())
