# The bot, by folder

Three files used to hold almost all of this: `bet.py` (3,268 lines), `main.py`
(3,364) and `strategies.py` (1,121). They are now a package of 75 modules, and
the point of the arrangement is one rule:

> **Nothing lower imports anything higher.**

That is what stops it collapsing back. The import graph is checked to be a DAG —
if a change needs a cycle, something is in the wrong layer.

```
baccarat/
├── store/        where things are kept
│   ├── paths.py      ← the ONLY module that works out where the data folder is
│   ├── settings.py   per-site session settings; the road-pattern library
│   ├── history.py    recorded tables (one file per shoe), run history
│   └── tablecalls.py every table called good or bad, and what it turned out to be
│
├── core/         the game. Pure: no screen, no mouse, no files
│   ├── game.py       the three sides, their letters, what a win pays
│   ├── strategy.py   which side to bet on, from the road
│   ├── rules.py      taking over from the strategy for a while
│   ├── staking.py    how much; how many losses this balance survives
│   ├── session.py    the balance, the road, the statistics — one sitting
│   ├── road.py       runs, letters, the big road, finding a shape in it
│   ├── screening.py  deciding a table is not worth sitting at
│   ├── tablekind.py  a table's pattern, its four numbers, what a table was worth
│   └── bets.py       chips, and planning the clicks that place them
│
├── screen/       the screen, mouse and keyboard
│   ├── sites.py      which site is being played, and where its recordings are
│   ├── desktop.py    ← the ONLY door to the OS; picks one of the two below
│   ├── linux.py      Hyprland: hyprctl, grim, slurp, ydotool, wtype, /proc
│   ├── macos.py      Quartz, Accessibility, psutil; and --doctor
│   ├── select_box.py drag a box on a Mac (slurp's stand-in)
│   ├── procnames.py  process names, for the CPU meter on either
│   ├── pointer.py    moving and clicking like a hand
│   ├── capture.py    screenshots, and the rectangles we read
│   ├── numbers.py    how a table writes money
│   ├── glyphs.py     reading text by matching characters
│   ├── board.py      the scoreboard bar: game number and P/B/T
│   ├── road.py       the big road
│   ├── colors.py     telling one look of a region from another
│   ├── regions.py    every region the bot reads, and what each needs
│   ├── coords.py     the recorded points, regions and patterns
│   ├── window.py     the game window's width: saved per site, put back with one button
│   ├── wizards.py    teaching it all, with a person at the terminal
│   └── cli.py        python -m baccarat.screen
│
├── play/         playing a table
│   ├── tuning.py     ← every behaviour knob, with the reason for its value
│   ├── stop.py       Stop and Pause, and the exception that unwinds a session
│   ├── reading.py    turning what the screen says into what happened
│   ├── pace.py       how often to look at the screen
│   ├── actions.py    open a table, close it, reload, scroll the lobby
│   ├── player.py     the loop. __init__, record, wait, run
│   ├── pacing.py     measuring the table's speed            ┐
│   ├── money.py      the score, the stake, the alarm        │ mixed into
│   ├── confirming.py did the bet go on; a break if refused  │
│   ├── loadmeter.py  CPU and screen grabs, hand by hand     │
│   ├── login.py      logging back in when the site drops you │
│   ├── navigate.py   finding, opening and leaving tables    │ Player
│   ├── screening.py  turning a table down                   │
│   ├── tablekind.py  judging the table's kind; was it right │
│   ├── placing.py    getting the bet in inside the window   │
│   └── reporting.py  what the dashboard is shown            ┘
│
├── study/        what happened, what would have happened, what a target really takes,
│                 and what kind of table this is (tablekinds.py)
├── web/          the dashboard, its API, the page itself, the Copy report text, and
│                 the server: uplink.py (reports), remote.py (its id, its key, signed
│                 calls), configsync.py (the locked bot's set-up, kept on the server)
├── setup.py      reading the Setup form
├── consistency.py checking every part came from the same version
└── cli.py        python -m baccarat

data/             YOUR data. Never contains code.
├── sites/  tables/  debug/  logs/ (one log file a day)
├── site.json  runs.json  road_patterns.json  table_calls.json  bot_id  bot_key  resume.json
└── attic/        files nothing reads, kept anyway. old-code/ is the old modules.

tests/            481 tests. The source of truth.
```

## Running it

```sh
python -m baccarat              # the dashboard
python -m baccarat --play       # play the table (places real bets)
python -m baccarat --stats      # every strategy against every stored table
python -m baccarat.screen       # set up and check the screen reading
```

`bet.py`, `main.py`, `strategies.py` and the rest are still in the folder as
two-line forwarding shims, so `python bet.py --coords` and `import main` keep
working. They hand back the real module rather than re-exporting its names — a
shim that copied the names would look identical until something replaced one
and then the replacement would land on the copy.

## Locked and unlocked

The same program, two ways of running it:

- **unlocked** (the default, on your own computer): its data folder is its own, as it
  always was. It reports to the server (BACCARAT_SERVER, default
  http://192.168.0.2:4444; `off` turns it off).
- **locked** (`--locked`, or BACCARAT_LOCKED=1 — the USB stick): its set-up and its
  casino login live on the server. At start it gives the server its key, shows a code
  until it is approved on the server's page, downloads its set-up and login, and then
  sends back whatever is changed on its dashboard (the recorded tables at the end of
  each session). Nothing of it has to stay on the computer it runs on. If the server
  gives it a template, the game set-up (strategy, budget, rules…) is the template's.

Every bet is also sent with the table's pattern before it (core/patterns.py): the server
adds up every bot's, and each bot judges its table by what all of them have seen.

## Working on it

```sh
python3 -m pytest tests -q      # 481 tests. A failure means the change is wrong.
ruff check .                    # must be clean
```

`ruff check .` is not cosmetic here. **F401** (imported and not used) and
**F821** (used and not defined) together prove every module names exactly what
it needs, which is what keeps the layers from quietly merging through imports
nobody reads.

### Two rules worth keeping

**Ask for a path, do not hold one.** Only `store/paths.py` works out where the
data is. The old code did it in three modules with `Path(__file__).parent`, and
a module that does that and then calls `mkdir(exist_ok=True)` does not fail when
it moves — it makes an empty folder in its new home and starts up with no sites
and no settings, which looks exactly like losing everything. Same reason the
per-site folders are `snaps_dir()` and not `SNAPS_DIR`: a constant rebound by
`use_site()` is captured at import time by whoever imported it, and then one
site's templates get written into another site's folder.

**Read a tunable through its module.** `tuning.SCORE_RECHECK`, not
`from ... import SCORE_RECHECK`. Copying the value into each module means there
is no single place to override it, which breaks every test that needs to.

## On a Mac

```sh
sh setup_mac.sh                 # once: a private Python (.venv) with everything
```

Then double-click **Check this Mac.command** and give Terminal the two permissions
it asks for (Screen Recording, Accessibility — quit Terminal with ⌘Q after), and
**Start bot.command** to open the dashboard. Coordinates and regions belong to a
screen, so they are recorded again on the Mac; tables and run history can be
copied across from `data/`.

Any Mac with Python 3.10 or newer from python.org — Intel or Apple silicon. A
Retina screen is handled: clicks are in screen units, and every picture is read at
one pixel per unit, so the reading behaves as on any other screen. Reload is ⌘R.

## Where the port goes

`screen/desktop.py` is the only door to the machine: about twenty functions — take
a picture of a box, let you drag one, move the pointer, press a button or a key,
type, bring a window forward, say how busy the machine is. Behind it, one backend
per system: `linux.py` (Hyprland) and `macos.py`. A Windows port is a third file
with the same functions; the reading, the strategy and the betting never learn
which machine they are on. `python -m baccarat.screen --doctor` checks a machine.
