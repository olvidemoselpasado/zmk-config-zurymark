#!/bin/bash
# Double-click to start the bot and open its dashboard.
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
    echo "The bot isn't set up yet: run  sh setup_mac.sh  in this folder first."
    read -r -p "Press Return to close."
    exit 1
fi
exec .venv/bin/python -m baccarat
