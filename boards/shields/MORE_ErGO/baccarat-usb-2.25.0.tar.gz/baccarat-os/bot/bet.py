"""bet.py — kept so the commands you already know keep working.

The code moved into baccarat/screen/, which is now twelve modules instead of
one 3,300-line file. `python -m baccarat.screen --help` is the same CLI.

This file does not re-export the names, it hands back the real module. A shim
that merely re-imported them would look identical right up until something
replaced one -- a test stubbing a read, your own script patching a function --
and then the replacement would land on this copy while the program went on
calling the original. That is a bug you would find at a table.

Nothing new should import this. Import what it needs:

    from baccarat.screen import board           # reading the scoreboard bar
    from baccarat.screen.pointer import click   # pressing a button
"""

import sys

import baccarat.screen
from baccarat.screen.cli import main as _main

if __name__ == "__main__":
    sys.exit(_main())

sys.modules[__name__] = baccarat.screen
