"""betting.py — kept so existing imports keep working. Now baccarat/core/bets.py."""

import sys

import baccarat.core.bets

sys.modules[__name__] = baccarat.core.bets
