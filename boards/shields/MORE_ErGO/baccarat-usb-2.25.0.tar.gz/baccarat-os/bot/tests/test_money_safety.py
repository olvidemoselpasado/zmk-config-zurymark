"""The checks that stand between a misread screen and a wrong bet.

Every test here is a bug that reached a live table. They are the reason the
suite exists: none of them were caught before the money moved.
"""
import time
import pytest
import analysis
import bet
from baccarat.screen import board as board_mod
import main
from baccarat.play import tuning


BOARD = {"game": 14, "player": 2, "banker": 9, "tie": 0,
         "player_pair": 0, "banker_pair": 0}


@pytest.fixture
def player(site, monkeypatch):
    """A session mid-hand, with the screen under our control."""
    # Every tunable is read through the tuning module rather than copied
    # into each one, so there is one place to override it -- here.
    monkeypatch.setattr(tuning, "SCORE_RECHECK", 0.0)
    p = main.Player(analysis.new_session(strategy="streak_or_chop_2",
                                         budget=11842.96, base=20, table_hands=40),
                    road=None, bet_window=6.0, click_speed=(0.1, 0.1),
                    hard_score=True, bet_start_on="game")
    p.table = None
    p.score = p.s.balance = 11841.96
    p.game_seen = time.monotonic()
    return p


def screen_shows(monkeypatch, value):
    monkeypatch.setattr(bet, "read_number", lambda name: value[0])
    monkeypatch.setattr(bet, "read_number_stable", lambda name, **kw: value[0])


def look(p, times=4):
    for _ in range(times):
        p.on_read(BOARD, 1.0)


# --- a settlement that is simply late ---------------------------------------

def test_a_slow_settlement_is_waited_for_not_complained_about(player, monkeypatch):
    """The bug: the check ran 2 s after the result, this table pays out later
    than that, and every hand produced a false alarm — then a second, opposite
    one, because the stale reading became the new baseline."""
    value = [11841.96]                       # not settled yet
    screen_shows(monkeypatch, value)
    player.current_bet = ("banker", 20.0)
    player.result_after("player")            # lost 20 -> expects 11,821.96
    assert player.score_check is not None, "it must wait rather than cry wolf"

    value[0] = 11821.96                      # the money lands during the gap
    look(player)
    assert player.score_check is None
    assert player.score == 11821.96
    assert player.s.corrections == [], "nothing was wrong, so nothing is corrected"


def test_the_check_never_delays_the_next_bet(player, monkeypatch):
    """The bug: waiting for a score that could never match ate three seconds of
    the next hand's betting window, and the hand was skipped as too late."""
    screen_shows(monkeypatch, [11841.96])
    player.current_bet = ("banker", 20.0)
    t0 = time.monotonic()
    player.result_after("player")
    assert time.monotonic() - t0 < 0.5, "it must defer, not block"


# --- a table that takes the stake when the bet is placed --------------------

def test_the_stake_on_the_table_is_learnt_and_accounted_for(player, monkeypatch):
    """This table shows the balance less whatever is riding on the hand. Seeing
    that figure is proof the stake went on at the size we meant."""
    value = [11841.96]
    screen_shows(monkeypatch, value)
    player.current_bet = ("banker", 20.0)
    player.result_after("player")            # expects 11,821.96
    player.stake_down = 40.0                 # the next bet goes on
    value[0] = 11821.96 - 40.0               # and the table takes it
    look(player)
    assert player.deducts is True
    assert player.score_check is None
    assert player.score == 11821.96, "the settled figure, worked back from the stake"
    assert player.s.corrections == []


def test_a_stake_that_never_reached_the_table_cancels_the_bet(player, monkeypatch):
    """Once we know this table deducts, a balance that has not moved means our
    money is not down. The hand is not ours: no win, no loss, no doubling."""
    value = [11841.96]
    screen_shows(monkeypatch, value)
    player.deducts = True
    player.current_bet = ("banker", 20.0)
    player.result_after("player")
    player.current_bet = ("banker", 40.0)
    player.stake_down = 40.0
    value[0] = 11821.96                      # settled, but nothing taken
    look(player)
    assert player.current_bet is None, "the bet must be called off"
    assert player.mismatch is not None, "and said out loud"
    assert player.stake_down == 0.0


def test_nothing_is_corrected_from_a_reading_it_cannot_interpret(player, monkeypatch):
    """The bug: three 'corrections' from readings taken while money was on the
    table turned a correct balance into one that was 20 short."""
    value = [11841.96]
    screen_shows(monkeypatch, value)
    assert player.deducts is None            # never seen this table deduct
    player.current_bet = ("banker", 20.0)
    player.result_after("player")
    player.stake_down = 40.0
    value[0] = 11821.96
    look(player)
    before = player.s.balance
    player.current_bet = None
    player.result_after("banker")
    assert player.s.corrections == []
    assert player.s.balance == before, "a guess here makes a right balance wrong"


# --- the stake on the table, as the site shows it ---------------------------

class Dash:
    """Keeps the last thing the dashboard was sent."""
    def __init__(self):
        self.state = {}

    def update(self, **values):
        self.state.update(values)

    def route(self, path, fn):
        pass


def test_the_balance_shown_drops_by_the_stake_the_moment_it_is_placed(player):
    """The bug: the site took the 20 off the balance as soon as the bet went on,
    and the dashboard kept showing the old figure until the hand settled."""
    player.dash = Dash()
    player.current_bet, player.stake_down = ("banker", 20.0), 20.0
    player.push()
    shown = player.dash.state
    assert shown["balance"] == 11821.96, "what the site shows: the stake is gone"
    assert shown["score"] == 11821.96
    assert shown["settled"] == 11841.96 and shown["on_table"] == 20.0

    player.current_bet, player.stake_down = None, 0.0       # the hand is over
    player.push()
    assert player.dash.state["balance"] == 11841.96
    assert player.dash.state["on_table"] == 0.0


# --- confirming the bet went on (the site can refuse it) ---------------------

BEFORE = 11841.96
ON = BEFORE - 20.0


@pytest.fixture
def betting(player, monkeypatch):
    """A 20 bet on banker, clicks just done, on a table at game 14."""
    monkeypatch.setattr(tuning, "STAKE_LOOK", 0.0)
    monkeypatch.setattr(player, "snapshot", lambda *a, **k: None)
    player.board, player.bet_game = dict(BOARD), 14
    player.current_bet, player.stake_down = ("banker", 20.0), 20.0
    player.start_bet_watch("banker", 20.0, time.monotonic())
    return player


def reads(p, monkeypatch, *values, board=BOARD):
    """The score reads each of `values` in turn, one per read of the bar."""
    for v in values:
        monkeypatch.setattr(bet, "read_number", lambda name, v=v: v)
        p.on_read(board, 1.0)


def test_a_bet_the_site_takes_and_gives_back_is_called_off(betting, monkeypatch):
    """The 'not confirmed' notice: the stake comes off, then comes back. The hand
    is not ours -- no win, no loss, no doubling."""
    betting.placer.last = object()
    reads(betting, monkeypatch, ON, ON, BEFORE, BEFORE)
    assert betting.current_bet is None, "the bet must be called off"
    assert betting.stake_down == 0.0
    assert betting.score == BEFORE
    assert betting.rejected_bets == 1
    assert betting.placer.last is None, "the repeat button can't be trusted after this"
    assert betting.deducts is True
    assert betting.bet_watch is None


def test_a_refused_bet_does_not_move_the_doubling(betting, monkeypatch):
    step = betting.s.staking.step
    reads(betting, monkeypatch, ON, BEFORE, BEFORE)
    betting.s.record("player", betting.current_bet)     # banker would have lost
    assert betting.s.staking.step == step
    assert betting.s.balance == BEFORE


def test_a_bet_that_stays_on_is_left_alone(betting, monkeypatch):
    reads(betting, monkeypatch, ON, ON, ON)
    assert betting.current_bet == ("banker", 20.0)
    assert betting.rejected_bets == 0


def test_one_odd_frame_is_not_a_refusal(betting, monkeypatch):
    """A single reading of the old figure -- a redraw, a digit mid-animation -- is
    not enough. It has to show the stake back STAKE_CONFIRM times in a row."""
    reads(betting, monkeypatch, ON, BEFORE, ON, BEFORE, ON)
    assert betting.current_bet == ("banker", 20.0)


def test_a_tie_handing_the_stake_back_is_not_a_refusal(betting, monkeypatch):
    """Once the result is in, the score is settling: a tie gives a banker stake
    back and reads exactly like a refusal. The watch ends the moment the bar moves."""
    reads(betting, monkeypatch, ON)
    after = dict(BOARD, game=15, tie=1)
    reads(betting, monkeypatch, BEFORE, BEFORE, BEFORE, board=after)
    assert betting.bet_watch is None
    assert betting.current_bet == ("banker", 20.0)


def test_the_result_ends_the_watch(betting, monkeypatch):
    reads(betting, monkeypatch, ON)
    monkeypatch.setattr(bet, "read_number_stable", lambda name, **kw: ON + 39.0)
    betting.result_after("banker")
    assert betting.bet_watch is None
    assert betting.rejected_bets == 0


def test_a_stake_that_never_left_is_called_off_on_a_table_known_to_deduct(betting, monkeypatch):
    """Judged from readings taken after the window closed: two of them showing the
    balance with our stake still in it."""
    betting.deducts = True
    betting.bet_watch["closes"] = time.monotonic() - 1
    reads(betting, monkeypatch, BEFORE)
    assert betting.current_bet == ("banker", 20.0), "one reading is not enough"
    reads(betting, monkeypatch, BEFORE)
    assert betting.current_bet is None
    assert betting.rejected_bets == 1


def test_the_first_bet_of_a_session_that_never_went_on_is_caught(betting, monkeypatch):
    """The bug, from a live session: the clicks were interrupted on the very first
    bet, the score never moved, and it was booked as a win. The 'never left' check
    needed its FIRST reading of the old balance to come after the window closed --
    but with the stake never leaving, that reading came straight after the clicks,
    so the check could never fire. And it waited to see this table take a stake
    once before trusting itself, which a session whose first bet fails never does."""
    betting.deducts = True                      # Setup: the site takes the stake on placing
    reads(betting, monkeypatch, BEFORE, BEFORE, BEFORE)      # inside the window
    assert betting.current_bet == ("banker", 20.0)
    betting.bet_watch["closes"] = time.monotonic() - 1        # the window shuts
    reads(betting, monkeypatch, BEFORE, BEFORE)
    assert betting.current_bet is None, "a bet that never went on is not settled"
    assert betting.bet_notice and betting.bet_notice["kind"] == "never"


def test_the_stake_is_looked_for_in_what_the_screen_read_not_in_our_books(player, monkeypatch):
    """The bug, from the same session: after a bet that never went on, our books
    expected 11,033.96 and the screen still read 11,014.96. The next bet's stake was
    looked for coming off 11,033.96, matched nothing, and no verdict was ever given.
    What comes off is whatever the screen showed just before the clicks."""
    monkeypatch.setattr(tuning, "STAKE_LOOK", 0.0)
    monkeypatch.setattr(player, "snapshot", lambda *a, **k: None)
    player.deducts = True
    player.board, player.bet_game = dict(BOARD), 14
    player.game_seen = time.monotonic() - 3
    player.score = 11014.96
    player.score_check = {"expected": 11033.96, "saw": 11014.96, "game": 13, "since": 0}
    player._score_read = (11014.96, time.monotonic() - 1)   # read in the wait before the clicks
    player.current_bet, player.stake_down = ("player", 20.0), 20.0
    player.start_bet_watch("player", 20.0, time.monotonic() - 7)   # window already shut
    assert player.bet_watch["before"] == 11014.96
    reads(player, monkeypatch, 11014.96, 11014.96)
    assert player.current_bet is None


def test_a_wrong_size_bet_is_never_settled_on_a_guessed_side(player, monkeypatch):
    """Game 18 of a live session, replayed: 160 on banker planned, the chip click
    missed, the repeat button put 320 on PLAYER. The bot called it '320 on banker' and
    booked a loss when player won. Now: no side is guessed, the hand is no bet for
    the strategy and the doubling, and the balance becomes what the table paid."""
    monkeypatch.setattr(tuning, "STAKE_LOOK", 0.0)
    monkeypatch.setattr(player, "snapshot", lambda *a, **k: None)
    player.deducts = True
    player.board, player.bet_game = dict(BOARD), 18
    player.score = player.s.balance = 10558.96
    player.s.staking.step = 3                          # 160 is the fourth stake of the run
    player.current_bet, player.stake_down = ("banker", 160.0), 160.0
    player.start_bet_watch("banker", 160.0, time.monotonic() - 7)   # the window has closed
    reads(player, monkeypatch, 10238.96, 10238.96)     # 320 came off, not 160
    assert player.current_bet is None, "not settled on a side the score can't show"
    assert player.stake_down == 320.0
    assert player.bet_notice["kind"] == "extra"

    player.s.record("player", player.current_bet)      # player wins the hand
    assert player.s.staking.step == 3, "the doubling doesn't move"
    screen_shows(monkeypatch, [10878.96])              # the 320 on player was paid 640
    player.result_after("player")
    assert player.score_check is not None
    player.finish_score_check()
    assert player.s.balance == 10878.96, "the balance is what the table paid"
    assert player.mismatch is not None, "and the page says so"


def test_a_hand_settled_wrongly_is_corrected_not_hidden(player, monkeypatch):
    """Games 12 and 13 of the same session: the books said 10,699.96 after game 12,
    the screen said 10,660.96. On game 13 the check that the new stake went on
    adopted the screen's figure as the score and closed the old check without a word,
    and the balance stayed 39 out for the rest of the session."""
    monkeypatch.setattr(tuning, "STAKE_LOOK", 0.0)
    player.deducts = True
    player.board, player.bet_game = dict(BOARD), 13
    player.game_seen = time.monotonic() - 3
    player.score = 10680.96
    player.s.balance = 10699.96
    player.score_check = {"expected": 10699.96, "saw": 10660.96, "game": 12, "since": 0}
    player._score_read = (10660.96, time.monotonic() - 1)
    player.current_bet, player.stake_down = ("banker", 20.0), 20.0
    player.start_bet_watch("banker", 20.0, time.monotonic())
    reads(player, monkeypatch, 10640.96)               # the new 20 went on
    assert player.bet_watch["on"]
    assert player.s.balance == 10660.96, "the books follow the screen"
    assert player.mismatch is not None and player.mismatch["by"] == -39.0
    assert player.score_check is None


def test_a_refusal_does_not_hide_an_open_difference_either(betting, monkeypatch):
    betting.s.balance = BEFORE + 19.0
    betting.score_check = {"expected": BEFORE + 19.0, "saw": BEFORE, "game": 13, "since": 0}
    reads(betting, monkeypatch, ON, BEFORE, BEFORE)    # taken, then handed back
    assert betting.current_bet is None
    assert betting.s.balance == BEFORE
    assert betting.mismatch is not None


def test_the_same_figure_closes_an_open_check_quietly(player, monkeypatch):
    player.score_check = {"expected": 1000.0, "saw": None, "game": 3, "since": 0}
    player.settle_open_check(1000.0)
    assert player.score_check is None and player.mismatch is None and player.score == 1000.0


# --- the chip before the repeat button ----------------------------------------------

def test_the_chip_is_seen_on_the_balance_before_the_repeats(player, monkeypatch):
    monkeypatch.setattr(tuning, "CHIP_CONFIRM_WAIT", 0.05)
    player.game_seen = time.monotonic() - 3
    player._score_read = (1000.0, time.monotonic())
    monkeypatch.setattr(bet, "read_number", lambda name: 980.0)
    assert player.chip_landed(20.0) is True
    monkeypatch.setattr(bet, "read_number", lambda name: 1000.0)
    assert player.chip_landed(20.0) is False


def test_with_no_reading_from_before_the_clicks_it_does_not_block(player, monkeypatch):
    player._score_read = None
    assert player.chip_landed(20.0) is True


def test_a_bet_stopped_before_the_repeats_is_no_bet_and_the_table_decides(player, monkeypatch):
    monkeypatch.setattr(player, "snapshot", lambda *a, **k: None)
    player.bet_game = 18
    player.score = player.s.balance = 10558.96
    player.current_bet = ("banker", 160.0)
    player._chip_check = {"before": 10558.96, "staked": 20.0, "trace": [(0.1, 10558.96)]}
    player.bet_cut_short("banker", 160.0, 20.0)
    assert player.current_bet is None and player.bet_notice["kind"] == "stopped"
    assert player.placer.last is None and player.placer.chip is None
    screen_shows(monkeypatch, [10558.96])              # nothing went on after all
    player.result_after("player")
    player.finish_score_check()
    assert player.s.balance == 10558.96 and player.mismatch is None


def test_a_win_paid_before_the_bar_moves_is_not_a_wrong_size(betting, monkeypatch):
    betting.bet_watch["closes"] = time.monotonic() - 1
    reads(betting, monkeypatch, ON, BEFORE + 19.0, BEFORE + 19.0)
    assert betting.current_bet == ("banker", 20.0)
    assert betting.bet_notice is None


def test_a_bet_that_did_not_go_on_forgets_the_selected_chip(betting, monkeypatch):
    """The press that selected the chip may be the one that missed, so the next bet
    clicks the chip again rather than trusting it is still selected."""
    betting.placer.chip = 20
    reads(betting, monkeypatch, ON, BEFORE, BEFORE)
    assert betting.placer.chip is None


def test_the_notice_can_stop_the_session(betting, monkeypatch):
    from baccarat.play.stop import STOP
    reads(betting, monkeypatch, ON, BEFORE, BEFORE)
    assert betting.bet_notice["kind"] == "refused"
    try:
        betting.bet_notice_seen({"do": "stop"})
        assert STOP.is_set()
    finally:
        STOP.clear()
    assert betting.bet_notice is None


def test_every_bet_says_in_the_log_what_the_score_did(betting, monkeypatch, caplog):
    import logging
    caplog.set_level(logging.INFO, logger="bet")
    reads(betting, monkeypatch, BEFORE, ON, ON)
    betting.end_bet_watch()
    line = [r.getMessage() for r in caplog.records if "confirmed" in r.getMessage()][-1]
    assert "11,841.96" in line and "11,821.96" in line, line


def test_the_score_trace_is_short_enough_to_read():
    from baccarat.play.confirming import fmt_trace
    s = fmt_trace([(5.3, 100.0), (6.1, 100.0), (6.8, 80.0), (7.6, 80.0), (8.4, None)])
    assert s == "100.00 ×2 (5.3–6.1 s) → 80.00 ×2 (6.8–7.6 s) → unreadable (8.4 s)"


def test_setup_says_the_site_takes_the_stake_by_default(site):
    from baccarat.setup import timing_params
    from baccarat.store.settings import DEFAULTS
    assert DEFAULTS["stake_on_place"] is True
    assert timing_params({"bet_window": 6, "click_min": 0.1, "click_max": 0.3}
                         )["stake_on_place"] is True
    p = main.Player(analysis.new_session(strategy="streak_or_chop_2", budget=100, base=20),
                    road=None, stake_on_place=True)
    assert p.deducts is True


def test_a_stake_slow_to_show_is_not_called_off(betting, monkeypatch):
    """The site is slow: the first looks still show the old balance, then the
    stake appears. Calling off a bet that is on would book a real result as no bet."""
    betting.deducts = True
    reads(betting, monkeypatch, BEFORE, BEFORE, BEFORE)    # inside the window
    reads(betting, monkeypatch, BEFORE, board=dict(BOARD, game=15, banker=10))
    assert betting.current_bet == ("banker", 20.0)

    betting.current_bet = ("banker", 20.0)
    betting.board = dict(BOARD)
    betting.start_bet_watch("banker", 20.0, time.monotonic())
    reads(betting, monkeypatch, BEFORE, BEFORE, ON, ON)
    assert betting.current_bet == ("banker", 20.0)
    assert betting.bet_watch["on"]


def test_a_stake_that_never_left_stands_until_the_table_is_known_to_deduct(betting, monkeypatch):
    """A table that has never been seen taking a stake may simply not do it."""
    assert betting.deducts is None
    reads(betting, monkeypatch, BEFORE, BEFORE, BEFORE)
    assert betting.current_bet == ("banker", 20.0)


def test_the_watch_stops_after_the_window(betting, monkeypatch):
    betting.bet_watch["until"] = time.monotonic() - 1
    reads(betting, monkeypatch, BEFORE, BEFORE)
    assert betting.bet_watch is None
    assert betting.current_bet == ("banker", 20.0)


def test_one_look_serves_the_stake_and_the_last_result(player, monkeypatch):
    """The last result's money not on screen yet, then the next bet goes on: seeing
    the settled figure less the stake confirms both, with one read per look."""
    monkeypatch.setattr(tuning, "STAKE_LOOK", 0.0)
    player.board, player.bet_game = dict(BOARD), 14
    player.score_check = {"expected": BEFORE + 20.0, "saw": None, "game": 13, "since": 0}
    player.current_bet, player.stake_down = ("banker", 40.0), 40.0
    player.start_bet_watch("banker", 40.0, time.monotonic())
    n = []
    monkeypatch.setattr(bet, "read_number", lambda name: n.append(1) or BEFORE - 20.0)
    player.on_read(BOARD, 1.0)
    assert len(n) == 1
    assert player.score_check is None and player.score == BEFORE + 20.0


def test_with_the_score_off_nothing_is_watched(player, monkeypatch):
    player.hard_score = False
    player.start_bet_watch("banker", 20.0, time.monotonic())
    assert player.bet_watch is None
    monkeypatch.setattr(bet, "read_number", lambda name: pytest.fail("no reads"))
    player.on_read(BOARD, 1.0)


# --- two refusals close together: a break -----------------------------------

def test_one_refusal_carries_on(player):
    player.note_refusal()
    assert not player.cooloff_due


def test_two_close_together_take_a_break(player):
    player.note_refusal()
    player.note_refusal()
    assert player.cooloff_due


def test_two_far_apart_do_not(player):
    player.rejections = [time.monotonic() - tuning.REJECT_WINDOW - 1]
    player.note_refusal()
    assert not player.cooloff_due


def test_a_break_closes_and_reopens_the_same_table(player, monkeypatch):
    """Sitting at an open table risks the inactivity logout, and the hands missed
    while away would leave a hole in the road. Closing and reopening avoids both:
    the road is read again on the way back. Balance and stake carry over."""
    asked = []
    monkeypatch.setattr(player, "next_table", lambda **kw: asked.append(kw) or True)
    player.open_patterns = ["open_table"]
    player.cooloff_due = True
    assert player.cool_off()
    assert asked == [{"target_reached": False, "same_table": True,
                      "wait_seconds": tuning.REJECT_COOLOFF}]
    assert not player.cooloff_due and player.rejections == []


def test_with_nowhere_to_come_back_to_it_watches_without_betting(player, monkeypatch):
    monkeypatch.setattr(player, "next_table", lambda **kw: pytest.fail("can't reopen"))
    assert player.cool_off()
    assert player.sitting_out(15)
    player.s.balance = player.s.budget                 # nothing in the way of a bet
    monkeypatch.setattr(player.s, "next_bet", lambda hand=None: ("banker", 20.0))
    clicked = []
    monkeypatch.setattr(player, "wait_for_chips", lambda g: clicked.append(g) or False)
    player.board = dict(BOARD)
    assert player.decide(15)
    assert player.current_bet is None and clicked == [], "no bet during the break"

    player.sit_out_until = time.monotonic() - 1        # the break is over
    assert not player.sitting_out(16)
    assert player.cooloff_ended is not None


def test_breaks_get_longer_and_then_it_stops(player, monkeypatch):
    waits = []
    monkeypatch.setattr(player, "next_table", lambda **kw: waits.append(kw["wait_seconds"]) or True)
    player.open_patterns = ["open_table"]
    for _ in range(tuning.REJECT_MAX_COOLOFFS):
        assert player.cool_off()
    assert waits[1] > waits[0] and waits[2] > waits[1]
    assert not player.cool_off(), "still refused after every break: stop"


def test_a_calm_spell_after_a_break_starts_the_count_again(player):
    player.cooloffs = 2
    player.cooloff_ended = time.monotonic() - tuning.REJECT_WINDOW - 1
    player.note_refusal()
    assert player.cooloffs == 0


# --- the road and the counters ----------------------------------------------

def test_the_road_is_read_with_the_counters_it_agrees_with(site, monkeypatch):
    """The bug: a result landed while the road was being read, the road came
    back one ahead of the counters the session joined on, and that result went
    into the road twice."""
    from helpers import road as R
    twelve = R("BBBPBBBBBPBB")
    monkeypatch.setattr(tuning, "ROAD_GAP", 0.0)
    monkeypatch.setattr(bet, "read_road", lambda: twelve)
    monkeypatch.setattr(bet, "read_board_stable", lambda *a, **k: dict(
        game=12, player=2, banker=10, tie=0, player_pair=0, banker_pair=0))
    walked_up_with = dict(game=11, player=2, banker=9, tie=0,
                          player_pair=0, banker_pair=0)
    seen, board = main.road_and_board(walked_up_with)
    assert len(seen) == 12
    assert board["game"] == 12, "join on the counters the road agrees with"


def test_a_road_that_does_not_match_the_counters_is_not_used(site, monkeypatch):
    from helpers import road as R
    monkeypatch.setattr(tuning, "ROAD_GAP", 0.0)
    monkeypatch.setattr(bet, "read_road", lambda: R("BBBP"))      # 4 results
    board = dict(game=11, player=2, banker=9, tie=0, player_pair=0, banker_pair=0)
    monkeypatch.setattr(bet, "read_board_stable", lambda *a, **k: board)
    seen, got = main.road_and_board(board, tries=2)
    assert seen is None, "a road short of the counters is a misread, not history"


def test_no_road_region_is_not_an_error(site, monkeypatch):
    monkeypatch.setattr(bet, "read_road", lambda: None)
    board = dict(game=11, player=2, banker=9, tie=0, player_pair=0, banker_pair=0)
    seen, got = main.road_and_board(board)
    assert seen is None and got is board


# --- the board memo ---------------------------------------------------------

def test_an_unchanged_board_is_not_read_twice(site, monkeypatch):
    """Every read is a screenshot. A frame repeating the value we already trust
    is not asking us to act on anything."""
    reads = []
    board = dict(game=11, player=2, banker=9, tie=0, player_pair=0, banker_pair=0)
    # read_board_stable calls read_board in its own module, so that is where
    # the stub goes -- patching the facade would not be seen.
    monkeypatch.setattr(board_mod, "read_board",
                        lambda name="board": (reads.append(1), dict(board))[1])
    bet._LAST_BOARD.clear()
    bet.read_board_stable()
    first = len(reads)
    reads.clear()
    bet.read_board_stable()
    assert first == 2, "a value we have not seen before is confirmed"
    assert len(reads) == 1, "the same value again is taken as read"


def test_leaving_a_table_forgets_what_the_bar_said(site):
    bet._LAST_BOARD["board"] = {"game": 11}
    bet.forget_board()
    assert "board" not in bet._LAST_BOARD
