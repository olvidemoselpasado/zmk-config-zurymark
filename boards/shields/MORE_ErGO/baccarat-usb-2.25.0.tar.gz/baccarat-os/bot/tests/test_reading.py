"""Reading the screen — the parts of bet.py that are pure enough to pin down.

The images here are drawn in the test, so nothing depends on a screenshot
someone has to keep. What is being checked is the arithmetic and the decisions,
not the exact pixels of any one casino's font.
"""
import shutil
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

import bet
from baccarat.store import paths
from baccarat.screen import board as board_mod


def text_image(text, colour=(40, 165, 255), background=(16, 14, 12),
               w=240, h=46, scale=1.0, thickness=2):
    """A line of text, drawn the way a score is: coloured on a dark bar."""
    img = np.zeros((h, w, 3), np.uint8)
    img[:] = background
    cv2.putText(img, text, (6, int(h * 0.72)), cv2.FONT_HERSHEY_SIMPLEX,
                scale, colour, thickness, cv2.LINE_AA)
    return img


class NumberFormats(unittest.TestCase):
    """How a table writes money, worked out from one example of it."""

    def test_comma_thousands_and_dot_decimals(self):
        f = bet.format_from_example("$12,633.96")
        self.assertEqual((f["thousands"], f["decimal"], f["decimals"]), (",", ".", 2))
        self.assertEqual((f["symbol"], f["symbol_at"]), ("$", "start"))

    def test_comma_decimals_and_a_trailing_symbol(self):
        f = bet.format_from_example("1000,10 $")
        self.assertEqual((f["decimal"], f["decimals"]), (",", 2))
        self.assertEqual((f["symbol"], f["symbol_at"]), ("$", "end"))
        self.assertEqual(f["thousands"], "")

    def test_an_example_that_is_not_a_number_is_refused(self):
        for bad in ("", "abc", ",50"):
            with self.assertRaises(bet.BetError, msg=bad):
                bet.format_from_example(bad)


class Separators(unittest.TestCase):
    """A full stop and a comma are a couple of pixels apart in a small font, so
    which is which is decided by where they sit, not by how they look.
    12,633.96 can only be grouped one way."""

    def setUp(self):
        self.money = bet.format_from_example("$12,633.96")   # , thousands . decimals
        self.plain = bet.format_from_example("1000,10 $")    # , decimals, no grouping

    def read(self, text, fmt=None):
        fmt = fmt or self.money
        return bet._parse_number(bet._resolve_separators(text, fmt), fmt)

    def test_a_decimal_point_read_as_a_comma_still_parses(self):
        self.assertEqual(self.read("12,633,96"), 12633.96)

    def test_every_separator_read_as_a_dot_still_parses(self):
        self.assertEqual(self.read("12.633.96"), 12633.96)

    def test_a_correct_reading_is_untouched(self):
        self.assertEqual(self.read("12,633.96"), 12633.96)

    def test_no_grouping_needed(self):
        self.assertEqual(self.read("633,96"), 633.96)

    def test_a_genuinely_broken_reading_is_still_refused(self):
        self.assertIsNone(self.read("12,633,9"))     # the tail is not two digits

    def test_a_single_separator_format_takes_whichever_glyph_was_read(self):
        self.assertEqual(self.read("1000.10", self.plain), 1000.10)
        self.assertEqual(self.read("1000,10", self.plain), 1000.10)

    def test_grouping_that_does_not_add_up_is_refused(self):
        self.assertIsNone(self.read("12,34.96"))     # a group of two is not a group


class ParsingNumbers(unittest.TestCase):
    def setUp(self):
        self.fmt = bet.format_from_example("$12,633.96")

    def test_digits_at_both_ends_are_required(self):
        self.assertIsNone(bet._parse_number(".96", self.fmt))
        self.assertIsNone(bet._parse_number("12,", self.fmt))

    def test_two_decimal_points_are_refused(self):
        self.assertIsNone(bet._parse_number("1.2.3", self.fmt))

    def test_the_decimal_count_has_to_match(self):
        self.assertIsNone(bet._parse_number("12,633.9", self.fmt))


class FailedReadBackoff(unittest.TestCase):
    """A read that fails is retried quickly a few times — a bar mid-animation is
    unreadable for a moment and has to be caught — then backed off, because a bar
    that is not there will not appear in forty milliseconds and every attempt is
    a screenshot."""

    def test_the_first_few_retries_stay_quick(self):
        for fails in range(1, bet.FAIL_GRACE + 1):
            self.assertEqual(bet._retry_gap(0.04, fails), 0.04)

    def test_then_it_backs_off(self):
        self.assertGreater(bet._retry_gap(0.04, bet.FAIL_GRACE + 2), 0.04)

    def test_it_never_waits_longer_than_the_cap(self):
        self.assertLessEqual(bet._retry_gap(0.04, 99), bet.FAIL_BACKOFF)

    def test_a_read_that_worked_is_not_delayed(self):
        self.assertEqual(bet._retry_gap(0.04, 0), 0.04)

    def test_a_bar_that_is_really_gone_costs_few_screenshots(self):
        spent, shots = 0.0, 0
        while spent < 3.0:
            shots += 1
            spent += bet._retry_gap(0.04, shots)
        self.assertLess(shots, 20)      # it used to be 75


class ColourGatedReading(unittest.TestCase):
    """A score drawn in its own colour is found by that colour, not by
    brightness. Then the box can be drawn with room to spare — which it has to
    be, because the score grows a digit — and whatever else is in the box is
    ignored."""

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        paths.use_data_dir(self.dir)
        bet.use_site("test")

    def tearDown(self):
        paths.use_data_dir(None)
        shutil.rmtree(self.dir, ignore_errors=True)

    def roomy(self, img, clutter):
        out = cv2.copyMakeBorder(img, 8, 10, 6, 70, cv2.BORDER_CONSTANT, value=(16, 14, 12))
        if clutter:                                  # grey chrome and a white label
            cv2.rectangle(out, (out.shape[1] - 64, 3), (out.shape[1] - 8, 15), (90, 90, 90), -1)
            cv2.putText(out, "BET", (out.shape[1] - 62, out.shape[0] - 6),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.42, (225, 225, 225), 1)
        return out

    def test_it_learns_the_colour_of_the_text(self):
        ink = bet.save_ink("score", text_image("12,633.96"))
        self.assertTrue(bet._ink_file("score").exists())
        self.assertGreater(ink["background_at"], ink["text_to"])

    def test_a_colourless_number_is_refused_and_says_so(self):
        grey = text_image("1,250.50", colour=(235, 235, 235))
        with self.assertRaises(bet.BetError):
            bet.save_ink("plain", grey)

    def test_other_things_in_the_box_are_ignored(self):
        """The guarantee is that the number reads the same whether or not the
        box catches other chrome — not that the brightness path trips over any
        particular clutter, which depends on how OpenCV renders it."""
        img = text_image("12,633.96")
        bet.save_ink("score", img)
        clean = len(bet._segment(bet._binarize(self.roomy(img, False), "score")))
        cluttered = len(bet._segment(bet._binarize(self.roomy(img, True), "score")))
        self.assertEqual(clean, 9)                   # 1 2 , 6 3 3 . 9 6
        self.assertEqual(cluttered, clean)

    def test_nothing_outside_the_number_survives_the_colour_gate(self):
        """Directly: the mask has to be empty everywhere the number is not."""
        img = text_image("12,633.96")
        bet.save_ink("score", img)
        mask = bet._binarize(self.roomy(img, clutter=True), "score")
        scale = mask.shape[1] / (img.shape[1] + 76)  # the gate upscales the box
        right_edge = int((img.shape[1] + 6) * scale)  # everything past the number
        self.assertEqual(int((mask[:, right_edge:] > 0).sum()), 0)

    def test_room_to_spare_does_not_shrink_the_glyphs(self):
        """The upscale is worked out from the height of the TEXT, not of the
        box, so the glyphs reach the matcher at the same size however much spare
        room the box has. Counting glyphs is not enough to catch this: a box
        twice as tall still yields the same nine, just at half the resolution,
        and the matching quietly gets worse."""
        img = text_image("12,633.96")
        bet.save_ink("score", img)
        tight = bet._binarize(img, "score")
        roomy = bet._binarize(self.roomy(img, clutter=False), "score")
        self.assertEqual(len(bet._segment(tight)), len(bet._segment(roomy)))
        self.assertAlmostEqual(bet._text_rows(tight), bet._text_rows(roomy), delta=6)

    def test_the_glyphs_reach_the_matcher_big_enough_to_match(self):
        """Whatever the box, the text is scaled towards the height the templates
        were taught at. Too small and every reading is a guess."""
        img = text_image("12,633.96")
        bet.save_ink("score", img)
        for box in (img, self.roomy(img, clutter=False), self.roomy(img, clutter=True)):
            self.assertGreater(bet._text_rows(bet._binarize(box, "score")), 80)

    def test_without_a_learnt_colour_it_falls_back_to_brightness(self):
        img = text_image("12,633.96")
        self.assertIsNone(bet.ink_of("score"))
        self.assertTrue(len(bet._segment(bet._binarize(img, "score"))) > 0)

    def test_forgetting_puts_it_back_to_brightness(self):
        img = text_image("12,633.96")
        bet.save_ink("score", img)
        bet.forget_ink("score")
        self.assertIsNone(bet.ink_of("score"))

    def test_colour_is_matched_regardless_of_brightness(self):
        """Lab without L: grey and white sit far from gold whatever their
        brightness, which is the whole reason this works."""
        ink = {"lab": list(cv2.cvtColor(np.uint8([[[40, 165, 255]]]),
                                        cv2.COLOR_BGR2LAB)[0, 0].astype(float))}
        for neutral in ((235, 235, 235), (90, 90, 90), (16, 14, 12)):
            patch = np.full((4, 4, 3), neutral, np.uint8)
            self.assertGreater(float(bet._ink_distance(patch, ink).mean()), 40)
        gold = np.full((4, 4, 3), (40, 165, 255), np.uint8)
        self.assertLess(float(bet._ink_distance(gold, ink).mean()), 5)


class BoardMemo(unittest.TestCase):
    """A read that repeats the value we are already working from is taken at
    once; only a changed value is confirmed with a second screenshot."""

    def setUp(self):
        self._read = board_mod.read_board
        bet._LAST_BOARD.clear()

    def tearDown(self):
        board_mod.read_board = self._read
        bet._LAST_BOARD.clear()

    def board(self, game=10):
        return {"game": game, "player": 5, "banker": 4, "tie": 1,
                "player_pair": 0, "banker_pair": 0}

    def count_reads(self, values):
        seen = []

        def fake(name="board"):
            seen.append(1)
            return values[min(len(seen) - 1, len(values) - 1)]

        board_mod.read_board = fake
        got = bet.read_board_stable(timeout=1.0)
        return got, len(seen)

    def test_a_new_value_is_confirmed_twice(self):
        got, reads = self.count_reads([self.board(), self.board()])
        self.assertIsNotNone(got)
        self.assertEqual(reads, 2)

    def test_the_same_value_again_costs_one_read(self):
        self.count_reads([self.board(), self.board()])
        _, reads = self.count_reads([self.board()])
        self.assertEqual(reads, 1)

    def test_forgetting_makes_it_confirm_again(self):
        self.count_reads([self.board(), self.board()])
        bet.forget_board()
        _, reads = self.count_reads([self.board(), self.board()])
        self.assertEqual(reads, 2)


if __name__ == "__main__":
    unittest.main()
