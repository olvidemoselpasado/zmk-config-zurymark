# Tests

The source of truth. If a change breaks one of these, the change is wrong until
proven otherwise — most of these tests exist because the thing they check went
wrong once in a live session with real money on the table.

## Running them

```
python3 tests/run.py            all of them
python3 tests/run.py money      only the ones whose name matches 'money'
python3 -m pytest tests -q      the same thing directly
```

They need `pytest` (`pip install pytest`), and they run from anywhere — the
project folder, inside `tests/`, or with an absolute path from somewhere else
entirely. If one ever stops working from a particular folder or under a
particular pytest version, that is a bug in the test, not in how you ran it:
`test_session.py :: TestTheSuiteItself` guards the two ways it has happened.

Nothing here touches a screen, a mouse, a network or a casino. The screen
functions are replaced with ones that answer from a script, and the images are
drawn by the tests themselves, so the suite runs anywhere Python and OpenCV do
— including on a machine with no Wayland, which is what makes it useful for the
macOS and Windows ports.

## What is covered

| File | Covers |
| --- | --- |
| `test_money_safety.py` | The score-check state machine, the stake shown on the dashboard, confirming each bet went on, the break after refused bets, road/counter agreement, the board memo |
| `test_timing.py` | Poll pacing, screen grabs saved on unchanged values, the load meter, the quickest-hand floor, the click budget, the double-click hold-off |
| `test_screens.py` | Road patterns, whole-run matching, the big road, table screening |
| `test_setup.py` | Everything the Setup form refuses, that its sections fold, that paper mode is gone, and the screen regions: every one listed, each with only its own steps |
| `test_betting.py` | Chip breakdown, click planning, the worst bet a setup can reach, repeat accounting, the placer |
| `test_strategies.py` | Strategies, the majority rule and its window, doubling and lives, session accounting |
| `test_reading.py` | Number formats, separator resolution, failed-read backoff, colour-gated reading |
| `test_login.py` | Logging back in: when it acts, the order of the clicks and keys, reloads and retries, giving up, that it is checked once at the start and never during play, and that the email and password never reach the log, the settings or Copy report |
| `test_macos.py` | The Mac backend against stand-ins for Quartz, Accessibility and AppKit: Retina pictures read at one pixel per unit in any byte order, ⌘R in the right order, text typed as characters and never logged, the game's window brought forward rather than the dashboard's, permissions named, the doctor |
| `test_expect.py` | What a win is really worth: the banker's 0.95 and the run before it, the wins a target takes, the doubling limit, the chance of a run the balance can't pay for, the same answer every time, and the figures in Setup and on the running target |
| `test_tablekinds.py` | A table's kind: the pattern (majority window or the whole table), its four numbers, what a table was worth, finding and proving a real pattern, proving nothing on random tables, judged when the window fills and again as it moves, which way an ORDINARY call leans, a table turned bad the moment a run is down to two lives (and still counted when stopped), every call checked when the table ends, wrong calls explained, the Copy report |
| `test_extra_life.py` | The extra life: off by default; always on at one in 3 once ticked, bought first; strict one in 2 when a run reaches life 6 (the 640 bet), kept strict by reaching it again, back to one in 3 after 20 losses without it; one run not two; what counts as a save; the bets to come until a win (extra life, doubling limit, money running out); resetting a configuration's run history (kept in the attic) |
| `test_window.py` | The game window's width: saved from the window the game is in, put back (rounding corrected) on either side of the split — Hyprland moves the split line, so a window on the right shrinks when told to grow — never left worse than it was found, a changed page title still found, the wrong side refused, fitted before a session, not touched during one, and what is said to Hyprland |
| `test_report.py` | The Copy report: the checks come first and say what is wrong (the money, lives against the configuration's history, the target's risk, the screen score, stuck or unreadable screens, refused bets, CPU, the extra life) — or that nothing is; every warning of the whole session grouped, not just the tail; the tables and the session in lines; the settings changed from the defaults; a broken part never stops it |
| `test_stop.py` | The Stop button: no question first, no more clicks after it even mid-bet, a pause never holds up the clicks, waits cut short, the page says Stopping at once |
| `test_analysis.py` | Replay from any hand, entry scan and detail, and that the replay agrees with live play |
| `test_session.py` | Answering a mismatch, reading a typed road, that the modules match each other, the Copy report text, and that the suite itself runs anywhere and never touches your real data/ |

Shared helpers live in `helpers.py` — `road()`, `board()`, `table_coords()`.
Import them from there, never from `conftest.py`: conftest is pytest's plugin
file and importing it only works under some of pytest's import modes.

Each file owns its area. Before adding a test, check whether the area already
has a home — coverage in two places drifts apart and then disagrees.

## The ones that matter most

These guard faults that cost real money or real hands. Read the docstring
before changing the code they cover:

- `test_money_safety.py` — the whole score-check state machine. A score read
  that held up the betting window, a slow settlement reported as a dropped bet,
  a balance "corrected" from a reading that could not be interpreted, and a
  road a hand out of step with the counters.
- `test_money_safety.py :: confirming the bet went on` — a bet the site refuses
  after taking the stake must be called off before the result is recorded, or the
  doubling carries on from a hand that was never ours. A tie handing the stake
  back looks exactly like a refusal, which is why the watch ends when the bar moves.
- `test_betting.py :: TheRepeatButtonWaitsForTheChip` and the wrong-size, hidden-mismatch
  tests in `test_money_safety.py` — game 18 of a live session: a missed chip click, the
  repeat button on an empty table, 320 on the other side, settled as if it were ours, and
  the difference hidden. Each of the three steps has its own test.
- `test_timing.py :: the double-click hold-off` — two presses on one point get
  swallowed, and a doubled bet goes on at half size.
- `test_betting.py :: RepeatedClicks` and `Placing` — repeats are dealt round
  the recorded points so no two presses in a row land on the same one.
- `test_screens.py` — a pattern counts on whole runs only. `BPPBB` is not
  inside `BPPBBB`, and the plain substring count is not what is used.
- `test_analysis.py :: ReplayMatchesLivePlay` — the replay and a live session
  share one engine. If they ever disagree, every conclusion drawn from the
  analysis tab is worthless.

## Writing new ones

Name the test after the behaviour, not the function: `test_a_late_settlement_
settles_quietly` says what is true, and the failure output then reads like a
sentence. When a bug is fixed, add the test that would have caught it and say
in its docstring what went wrong — several of these would have saved a live
debugging session.
