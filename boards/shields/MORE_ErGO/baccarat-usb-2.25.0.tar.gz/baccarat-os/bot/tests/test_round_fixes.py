"""From the 2.24.0 report: the report mixed in yesterday; Stop with a bet on the table
left its result unknown; table end from the shoes really watched."""
import logging
import threading
from types import SimpleNamespace

from baccarat.play.stop import STOP
from baccarat.store import history
from baccarat.web.server import LogBuffer


# -- A: the report is this session's ---------------------------------------------------
def test_the_report_covers_only_the_session_in_play():
    buf = LogBuffer()
    lg = logging.getLogger("round-fixes")
    lg.addHandler(buf)
    lg.setLevel(logging.INFO)
    try:
        lg.warning("yesterday: the table didn't load")
        buf.mark_session()
        lg.info("today: Game 1")
        lg.warning("today: something")
    finally:
        lg.removeHandler(buf)
    texts = [x["text"] for x in buf.session_lines()]
    assert len(texts) == 2 and all("today" in t for t in texts)
    from baccarat.web import report
    out = report.build({}, buf.session_lines(), since="2026-11-05")
    assert "yesterday" not in out and "this session (since 2026-11-05)" in out


# -- B: stopping --------------------------------------------------------------------------
class Ctl:
    from baccarat.web.routes_session import SessionRoutes
    stop = SessionRoutes.stop
    AFTER_RESULT_MAX = SessionRoutes.AFTER_RESULT_MAX

    def __init__(self, player):
        self.running, self.player = True, player
        self.answered = threading.Event()
        self.said = {}
        self.dash = SimpleNamespace(update=lambda **kv: self.said.update(kv))


def a_player(current_bet=None, stake_down=0.0, in_run=False):
    return SimpleNamespace(current_bet=current_bet, stake_down=stake_down,
                           stop_after_result=False,
                           s=SimpleNamespace(in_run=in_run, halt_for=None, halt_resume=False))


def test_stop_with_a_bet_on_the_table_waits_for_its_result_and_again_stops_at_once():
    STOP.clear()
    p = a_player(("banker", 20), 20.0)
    c = Ctl(p)
    c.AFTER_RESULT_MAX = 0.2
    assert "result" in c.stop({})["message"]
    assert p.stop_after_result and not STOP.is_set()
    c.stop({"now": True})
    assert STOP.is_set()
    STOP.clear()


def test_the_result_that_never_comes_doesnt_keep_it_waiting():
    import time
    STOP.clear()
    p = a_player(("banker", 20), 20.0)
    c = Ctl(p)
    c.AFTER_RESULT_MAX = 0.1
    c.stop({})
    time.sleep(0.3)
    assert STOP.is_set()
    STOP.clear()


def test_stop_with_nothing_on_the_table_is_at_once():
    STOP.clear()
    c = Ctl(a_player())
    c.stop({})
    assert STOP.is_set()
    STOP.clear()


def test_stop_after_this_run_plays_it_out_and_isnt_started_again():
    STOP.clear()
    p = a_player(("player", 80), 80.0, in_run=True)
    c = Ctl(p)
    assert "run" in c.stop({"after_run": True})["message"]
    assert p.s.halt_for and p.s.halt_resume is False and not STOP.is_set()
    assert c.said.get("stop_after_run")


def test_the_session_ends_at_the_base_bet_when_asked():
    from baccarat.study.replay import new_session
    s = new_session("streak_or_chop_2", 10000, 20)
    s.new_table(["player", "player"])
    b = s.next_bet()
    s.record("banker" if b[0] == "player" else "player", b)   # a loss: in a run
    s.halt_for = "you asked to stop after this run"
    b = s.next_bet()
    assert b and b[1] == 40                                       # played out
    s.record(b[0], b)
    assert s.next_bet() is None and s.finished


# -- G: where a table ends ----------------------------------------------------------------
def shoe(n, reason="counters reset — new table", site="default"):
    return {"end_reason": reason, "site": site,
            "rounds": [{"counts": {"player": n // 2, "banker": n - n // 2 - 1, "tie": 1}}]}


def test_shoe_lengths_come_only_from_shoes_watched_to_the_end():
    tables = [shoe(44), shoe(46), shoe(33, "no room left for a new run"), shoe(45, site="other")]
    assert history.shoe_lengths(tables, site="default") == [44, 46]


def test_the_table_end_follows_the_shoes_watched(monkeypatch):
    from baccarat.play import player as pl
    monkeypatch.setattr(pl, "shoe_lengths", lambda site=None: [43, 44, 44, 45, 46, 47, 52])
    me = SimpleNamespace(s=SimpleNamespace(table_hands=40), SHOES_NEEDED=5)
    pl.Player.fit_table_end(me)
    assert me.s.table_hands == 44                  # 4 in 5 shoes lasted at least 44
    monkeypatch.setattr(pl, "shoe_lengths", lambda site=None: [44, 46])
    me.s.table_hands = 40
    pl.Player.fit_table_end(me)
    assert me.s.table_hands == 40                  # too few shoes: the setting stands


def test_once_the_waited_for_result_is_in_no_next_bet_is_made():
    import pytest
    from baccarat.play.placing import Placing
    from baccarat.play.stop import Stopped
    me = SimpleNamespace(stop_after_result=True, current_bet=("banker", 20),
                         s=SimpleNamespace(next_bet=lambda **k: pytest.fail("chose a next bet")))
    with pytest.raises(Stopped):
        Placing.decide(me, 21)
    assert me.current_bet is None          # nothing reported as left on the table
