#!/usr/bin/env python3
"""Run the tests and print a summary.

    python3 tests/run.py            all of them
    python3 tests/run.py money      only the files whose name matches 'money'
    python3 tests/run.py -v         show every test name

Run it from the folder that holds main.py.
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    if not (ROOT / "main.py").exists():
        print("Run this from the folder that holds main.py.")
        return 2
    try:
        import pytest                                    # noqa: F401
    except ImportError:
        print("The tests need pytest (the shared fixtures in tests/conftest.py use it):")
        print("    pip install pytest")
        return 2

    args, verbose = [], False
    for a in sys.argv[1:]:
        if a in ("-v", "--verbose"):
            verbose = True
        else:
            args.append(a)

    target = str(ROOT / "tests")
    cmd = [sys.executable, "-m", "pytest", target, "-v" if verbose else "-q"]
    for a in args:                                        # a name fragment to filter by
        cmd += ["-k", a]
    print("$ " + " ".join(cmd[1:]) + "\n")
    code = subprocess.run(cmd, cwd=ROOT).returncode
    if code:
        print("\nA failure here means the change is wrong until proven otherwise.")
        print("Read the test's docstring: it says what went wrong the last time.")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
