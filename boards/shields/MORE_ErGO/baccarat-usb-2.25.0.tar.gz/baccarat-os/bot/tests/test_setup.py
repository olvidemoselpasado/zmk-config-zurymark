"""The Setup form: what it accepts, and what it refuses before a session runs."""
import inspect
import pytest
import main


BASE = {"strategy": "streak_or_chop_2", "budget": "1000", "base": "20", "rules": [],
        "target": "", "max_steps": "", "table_hands": "40", "at_cutoff": "wait",
        "cutoff_margin": "20"}
TIMING = {"bet_window": "6", "click_min": "0.1", "click_max": "0.3", "move_speed": "0.26",
          "quiet_poll": "0.8", "bet_start_on": "game", "leave": "close"}


def session(**over):
    return main.session_params({**BASE, **over})


def timing(**over):
    return main.timing_params({**TIMING, **over})


# --- the money ---------------------------------------------------------------

def test_a_sensible_session_is_accepted():
    p = session()
    assert p["budget"] == 1000 and p["base"] == 20


def test_a_base_bet_bigger_than_the_budget_is_refused():
    with pytest.raises(ValueError, match="base bet"):
        session(base="2000")


@pytest.mark.parametrize("field", ["budget", "base"])
def test_money_that_is_not_a_number_is_refused(field):
    with pytest.raises(ValueError):
        session(**{field: "lots"})


def test_an_unknown_strategy_is_refused():
    with pytest.raises(ValueError, match="unknown strategy"):
        session(strategy="hunches")


def test_an_unknown_rule_is_refused():
    with pytest.raises(ValueError):
        session(rules=["telepathy=3"])


def test_keeping_more_hands_than_the_table_has_is_refused():
    with pytest.raises(ValueError):
        session(table_hands="20", cutoff_margin="20")


# --- the clock ---------------------------------------------------------------

def test_a_window_too_small_for_even_one_click_is_refused():
    """A crude floor. The real test is click_budget_problem, which checks the
    biggest bet the ladder can reach against the window."""
    with pytest.raises(ValueError, match="one click"):
        timing(bet_window="0.1", click_min="0.2", click_max="0.3")


def test_a_click_that_could_never_fit_any_window_is_refused():
    with pytest.raises(ValueError, match="2 s"):
        timing(click_min="0.1", click_max="3")


def test_a_slowest_click_quicker_than_the_fastest_is_refused():
    with pytest.raises(ValueError):
        timing(click_min="0.5", click_max="0.1")


@pytest.mark.parametrize("value", ["0.05", "5"])
def test_a_screen_read_gap_outside_the_sane_range_is_refused(value):
    with pytest.raises(ValueError):
        timing(quiet_poll=value)


@pytest.mark.parametrize("value", ["0.02", "2"])
def test_a_pointer_speed_outside_the_sane_range_is_refused(value):
    with pytest.raises(ValueError):
        timing(move_speed=value)


def test_the_pointer_speed_defaults_when_left_empty():
    assert timing(move_speed="")["move_speed"] == pytest.approx(0.26)


# --- what to do when the screen disagrees ------------------------------------

@pytest.mark.parametrize("choice", ["carry_on", "pause", "stop"])
def test_every_mismatch_choice_is_accepted(choice):
    assert timing(on_mismatch=choice)["on_mismatch"] == choice


def test_the_default_is_to_keep_playing():
    assert timing()["on_mismatch"] == "carry_on"


def test_a_mismatch_choice_that_is_not_one_of_the_three_is_refused():
    with pytest.raises(ValueError):
        timing(on_mismatch="panic")


# --- table screening ---------------------------------------------------------

def test_screens_need_somewhere_to_go_when_a_table_is_turned_down():
    with pytest.raises(ValueError, match="open_table"):
        main.screen_params({"screens": [{"name": "x", "pattern": "BBPP"}],
                            "open_patterns": []}, session())


def test_screens_need_to_know_how_long_a_shoe_lasts():
    with pytest.raises(ValueError, match="hands a table usually lasts"):
        main.screen_params({"screens": [{"name": "x", "pattern": "BBPP"}],
                            "open_patterns": ["open_table_1"]}, {})


def test_judging_a_table_cannot_need_more_results_than_it_has_hands():
    with pytest.raises(ValueError):
        main.screen_params({"screens": [{"name": "x", "pattern": "BBPP"}],
                            "open_patterns": ["open_table_1"], "screen_min": "40",
                            "wait_hands": "44"}, {"table_hands": 40})


def test_with_no_screens_none_of_that_applies():
    assert main.screen_params({"screens": [], "open_patterns": []}, session())["screens"] == []


# --- paper mode is gone ------------------------------------------------------

def test_starting_needs_no_real_money_tick_box():
    """It only ever plays for real: a box to tick every time said nothing."""
    src = inspect.getsource(main.Controller.start)
    assert "confirm_live" not in src


def test_the_player_has_no_mode_flag_left():
    assert "live" not in inspect.signature(main.Player.__init__).parameters
    assert main.Player.__init__.__doc__ is None or "paper" not in main.Player.__init__.__doc__


def test_no_module_still_talks_about_paper_mode():
    """Found from this file, not from wherever pytest happened to be started:
    a test that only passes in one folder is a test you stop trusting."""
    import pathlib
    root = pathlib.Path(__file__).resolve().parent.parent
    for name in ("main.py", "strategies.py", "betting.py", "analysis.py"):
        text = (root / name).read_text().lower()
        assert "paper mode" not in text, f"{name} still mentions paper mode"


# --- the screen regions: every one listed, each with only its own steps ----------

def _save_region(name, picture=True):
    import bet
    import cv2
    import numpy as np
    d = bet.snaps_dir()
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{name}.geo").write_text("10,10 40x20")
    if picture:
        cv2.imwrite(str(d / f"{name}.png"), np.full((20, 40, 3), 30, np.uint8))


def _slots(**settings):
    import bet
    return {s["slot"] or s["name"]: s for s in bet.region_slots(settings, bet.region_list())}


def test_every_region_is_listed_before_any_is_set_up(site):
    s = _slots()
    assert list(s)[:1] == ["board"], "what is needed comes first"
    assert set(s) == {"board", "score", "road", "bets_open", "success_login"}
    assert all(x["status"] == "select" and x["region"] is None for x in s.values())


def test_what_is_needed_follows_the_settings(site):
    s = _slots(hard_score=False, bet_start_on="game")
    assert s["board"]["need"] == "needed"
    assert s["score"]["need"] == "optional" and s["bets_open"]["need"] == "unused"
    s = _slots(hard_score=True, bet_start_on="chips")
    assert s["score"]["need"] == "needed" and s["bets_open"]["need"] == "needed"


def test_each_kind_asks_for_its_own_next_step(site):
    _save_region("board")
    _save_region("score")
    _save_region("road")
    _save_region("bets_open")
    s = _slots()
    assert s["board"]["todo"] == "teach its digits" and s["score"]["todo"] == "teach its digits"
    assert s["road"]["status"] == "ready", "the road is read by colour: nothing to teach"
    assert s["bets_open"]["todo"] == "show it chips up and chips gone"


def test_the_logged_in_box_has_nothing_to_teach(site):
    """The bug: a region the bot didn't know was taken for a number, so the box
    around 'Bienvenido … / Mi Cuenta' was offered 'Teach digits'."""
    import bet
    _save_region("success_login")
    s = _slots()["success_login"]
    assert s["kind"] == "picture" and s["status"] == "ready"
    assert bet.region_kind("success_login") == "picture"


def test_a_box_saved_as_login_success_is_the_login_region(site):
    import bet
    from baccarat.play.login import login_missing, success_region
    _save_region("login_success")
    s = _slots()
    assert s["success_login"]["name"] == "login_success" and s["success_login"]["status"] == "ready"
    assert "login_success" not in s, "listed once, in its slot"
    assert success_region() == "login_success"
    assert not any("success_login" in m for m in login_missing())
    assert bet.region_kind("succes_login") == "picture"


def test_a_region_nothing_reads_is_listed_as_such(site):
    import bet
    _save_region("winner")
    s = _slots()["winner"]
    assert s["slot"] is None and s["kind"] == "unused"
    assert bet.region_kind("winner") == "unused"


def test_the_chips_are_ready_with_one_look_of_each(site):
    import bet
    import numpy as np
    _save_region("bets_open")
    bet.teach_color_sample("bets_open", "open", np.full((20, 40, 3), (0, 200, 0), np.uint8))
    assert _slots()["bets_open"]["todo"] == "show it chips gone"
    bet.teach_color_sample("bets_open", "shut", np.full((20, 40, 3), (40, 40, 40), np.uint8))
    assert _slots()["bets_open"]["status"] == "ready"


def test_teaching_digits_is_refused_where_there_are_none(site):
    from baccarat.web.routes_setup import SetupRoutes

    class Routes(SetupRoutes):
        running, frames = False, {}

        def _hands_off(self, action):
            pass
    _save_region("success_login")
    with pytest.raises(ValueError, match="nothing to teach"):
        Routes().regions({"action": "shot", "name": "success_login"})
    _save_region("winner")
    with pytest.raises(ValueError, match="nothing in the bot reads"):
        Routes().regions({"action": "shot", "name": "winner"})
    out = Routes().regions({"action": "list"})
    assert {s["slot"] for s in out["slots"] if s["slot"]} == \
        {"board", "score", "road", "bets_open", "success_login"}


def test_the_setup_sections_fold_and_the_start_never_does():
    """Every titled section of Setup folds (the page does it from the titles); the
    one that starts the session is marked never to."""
    import pathlib
    page = (pathlib.Path(__file__).parent.parent / "baccarat/web/static/dashboard.html").read_text()
    assert "function setupFolds()" in page and "setupFolds();" in page
    assert '<div class="field" data-nofold><span class="flabel">Start</span>' in page
    assert '<span class="flabel">Strategy and money</span>' in page
    for title in ("Shadow bet", "Extra life", "Login", "Rules", "Skip bad tables"):
        assert f'"{title}": () =>' in page, f"{title} says what it is set to when folded"


def test_hover_help_answers_only_the_words():
    """The help shows over a field's label or a line of text, never over the box you
    type in or the empty space beside a short line."""
    import pathlib
    page = (pathlib.Path(__file__).parent.parent / "baccarat/web/static/dashboard.html").read_text()
    assert ".field[data-tip]:has(> label:hover)::after" in page
    assert "[data-tip]:hover::after" not in page and "[data-tip]:focus-within::after" not in page
    assert "[data-tip]:not(.field){width:fit-content" in page


@pytest.mark.parametrize("bad", ["10500", "21"])
def test_a_doubling_limit_that_is_not_a_number_of_losses_is_refused(bad):
    """The 2.24.0 report: 10500 typed there (the budget, in the wrong field)."""
    with pytest.raises(ValueError, match="isn't a number of losses"):
        session(max_steps=bad)


def test_a_sensible_doubling_limit_or_none():
    assert session(max_steps="8")["max_steps"] == 8
    assert session(max_steps="")["max_steps"] is None
