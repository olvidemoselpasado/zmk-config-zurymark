"""How many wins a target really takes.

'1,000 at a base of 20 = 50 wins' only holds if every win nets one base bet.
A banker win pays 0.95, and the longer the doubled run before it the more that
costs, so the value of a win is measured by replaying the setup -- and the wins
needed come out higher than the plain division.
"""
import time

import pytest

import analysis
import main
from baccarat.study import expect
from baccarat.web.routes_study import StudyRoutes

SETUP = dict(strategy="streak_or_chop_2", budget=10524.96, base=20, table_hands=40)


# --- the arithmetic of one run -------------------------------------------------

def test_a_banker_win_nets_less_the_longer_the_run_before_it():
    assert [expect.run_net(20, k, "banker") for k in range(1, 7)] == [19, 18, 16, 12, 4, -12]


def test_a_player_win_always_nets_one_base_bet():
    assert {expect.run_net(20, k, "player") for k in range(1, 10)} == {20}


def test_how_many_bets_in_a_row_the_balance_pays_for():
    # 20 + 40 + … doubling: nine bets cost 10,220, a tenth would need 20,460
    assert expect.affordable(10524.96, 20) == 9
    assert expect.affordable(10524.96, 20, max_steps=5) == 5


# --- from a value to a number of wins ----------------------------------------------

def test_wins_needed_divide_by_what_a_win_is_really_worth():
    assert expect.wins_for(1000, {"per_win": 17.6}, 20) == 57
    assert expect.wins_for(1000, None, 20) == 50, "no measurement: one base bet a win"
    assert expect.wins_for(1000, {"per_win": -3.0}, 20) is None, "a win that loses money"
    assert expect.wins_for(0, {"per_win": 17.6}, 20) == 0


def test_the_chance_of_being_cut_short_grows_with_the_wins():
    v = {"beyond_per_run": 0.002}
    few, many = expect.cut_short_chance(10, v), expect.cut_short_chance(100, v)
    assert 0 < few < many < 1
    assert many == pytest.approx(1 - 0.998 ** 100)
    assert expect.cut_short_chance(0, v) is None


# --- measuring it ------------------------------------------------------------------

def test_with_no_tables_recorded_it_replays_tables_dealt_from_the_odds():
    v = expect.win_value(**SETUP, tables=[])
    assert v["source"] == "dealt" and v["wins"] >= expect.MIN_WINS
    assert 15 < v["per_win"] < 20, "below a base bet: banker pays 0.95"
    assert v["hands_per_win"] > 2, "runs lose first, and ties cost hands"
    assert v["cover"] == 9
    assert expect.wins_for(1000, v, 20) > 50


def test_the_same_setup_gives_the_same_estimate_every_time():
    assert expect.win_value(**SETUP, tables=[]) == expect.win_value(**SETUP, tables=[])


def test_a_few_recorded_tables_are_reported_but_not_relied_on():
    road = ["banker", "player"] * 20
    v = expect.win_value(**SETUP, tables=[{"name": "t1", "road": road}])
    assert v["source"] == "dealt"
    assert v["recorded"]["tables"] == 1


def test_enough_recorded_tables_are_used_as_they_are():
    tables = expect.deal_tables(40, n=300)
    v = expect.win_value(**SETUP, tables=tables)
    assert v["source"] == "replay" and v["tables"] == 300


def test_with_a_doubling_limit_the_long_runs_are_losses_not_the_end():
    """At the limit the loss is taken and it starts over at base: that costs every
    win a little, and it can't cut the session short the way an unpaid run would."""
    free = expect.win_value(**SETUP, tables=[])
    capped = expect.win_value(**SETUP, max_steps=4, tables=[])
    assert capped["cover"] == 4 and capped["capped"]
    assert capped["per_win"] < free["per_win"]
    assert capped["beyond_per_run"] is None and expect.cut_short_chance(60, capped) is None


# --- the session and the dashboard -----------------------------------------------------

def test_the_session_counts_wins_at_the_measured_value():
    s = analysis.new_session(strategy="streak_or_chop_2", budget=1000, base=20, ceiling=2000)
    assert s.wins_needed == 50
    s.per_win = 17.6
    assert s.wins_needed == 57
    s.per_win = -1.0
    assert s.wins_needed is None


def test_setup_says_what_the_target_takes_before_starting(site):
    e = StudyRoutes.estimate(None, {**{k: str(v) for k, v in SETUP.items()},
                                    "target": "1000"})["estimate"]
    assert e["remaining"] == 1000 and e["naive"] == 50
    assert e["wins"] > 50 and e["hands"] > e["wins"]
    assert 0 <= e["cut_short"] < 1
    assert StudyRoutes.estimate(None, {"strategy": "streak_or_chop_2", "budget": "1000",
                                       "base": "20"})["estimate"] is None, "no target set"


def test_a_running_session_measures_once_and_shows_it(site):
    s = analysis.new_session(strategy="streak_or_chop_2", budget=10524.96, base=20,
                             ceiling=11524.96)
    p = main.Player(s, road=None, estimator=lambda: expect.win_value(**SETUP, tables=[]))
    p.snapshot = lambda *a, **k: None
    p.push = lambda: None
    p.refresh_estimate("test")
    for _ in range(200):
        if p.estimate:
            break
        time.sleep(0.02)
    assert p.estimate and s.per_win == p.estimate["per_win"]
    r = p.estimate_report()
    assert r["source"] == "dealt" and r["base"] == 20
    assert s.wins_needed > 50


def test_an_estimator_that_fails_changes_nothing(site):
    s = analysis.new_session(strategy="streak_or_chop_2", budget=1000, base=20, ceiling=2000)

    def broken():
        raise RuntimeError("no tables")
    p = main.Player(s, road=None, estimator=broken)
    p.push = lambda: None
    p.refresh_estimate("test")
    for _ in range(50):
        if not p._estimating:
            break
        time.sleep(0.02)
    assert p.estimate is None and s.wins_needed == 50
