"""Judging a table by its pattern, with what every bot has seen after it."""
import random

from baccarat.core import patterns as pt
from baccarat.web import template

B, P, T = "banker", "player", "tie"


def road(s):
    return [{"B": B, "P": P, "T": T}[c] for c in s]


def test_the_road_is_read_in_its_exact_colours_without_ties():
    assert pt.bp(road("BBTPPB")) == "BBPPB"


def test_observations_keep_the_last_sixteen_and_come_back_if_unsent():
    pt.take()
    pt.observe("cfg", road("BBBPPPBBBPBBPPBBPPBB"), "LOSS", "banker", "leaning bad")
    pt.observe("cfg", road("BBP"), "WIN")            # too short to be a pattern
    pt.observe("cfg", road("BBPPBB"), "PUSH")        # not a win or a loss
    got = pt.take()
    assert [(o["road"], o["out"], o["side"], o["v"]) for o in got] == [
        ("PPBBBPBBPPBBPPBB", "L", "B", "leaning bad")]
    pt.put_back(got)
    assert pt.take() == got and pt.take() == []


def stats(base_w, base_l, **pats):
    return {"base": [base_w, base_l], "patterns": {k: list(v) for k, v in pats.items()}}


def test_no_data_and_learning():
    assert pt.judge("nothing", road("BBPPBB"))["verdict"] == "no data"
    pt.set_stats("c1", stats(500, 500, BBPPBB=(5, 9)))
    v = pt.judge("c1", road("BBPPBB"))
    assert v["verdict"] == "learning" and v["n"] == 14


def test_bad_only_on_strong_evidence():
    # baseline 50%: 40 of 100 is z = -2 — leaning, not bad; 30 of 100 is z = -4 — bad
    pt.set_stats("c2", stats(5000, 5000, BBPPBB=(40, 60)))
    assert pt.judge("c2", road("PBBPPBB"))["verdict"] == "leaning bad"
    pt.set_stats("c2", stats(5000, 5000, BBPPBB=(30, 70)))
    v = pt.judge("c2", road("PBBPPBB"))
    assert v["verdict"] == "bad" and v["pattern"] == "BBPPBB" and v["z"] <= -3
    assert "bad" in pt.describe(v)


def test_the_strongest_length_is_the_one_shown():
    pt.set_stats("c3", stats(5000, 5000, PPBB=(52, 48), BPPBB=(20, 80), PBPPBB=(45, 55)))
    v = pt.judge("c3", road("PBPPBB"))
    assert v["pattern"] == "BPPBB" and v["verdict"] == "bad"
    assert {r["pattern"] for r in v["lengths"]} == {"PPBB", "BPPBB", "PBPPBB"}


def test_luck_alone_rarely_makes_a_pattern_bad():
    """A fair game: 500 patterns with 200 bets each at the baseline. At z <= -3 about one
    in 700 looks bad by luck — at the usual 1.65 it would be dozens."""
    rnd = random.Random(1)
    pats = {}
    for i in range(500):
        w = sum(rnd.random() < 0.5 for _ in range(200))
        pats[format(i, "09b").replace("0", "B").replace("1", "P")] = (w, 200 - w)
    pt.set_stats("fair", stats(50000, 50000, **pats))
    bad = sum(pt.judge("fair", road(p))["verdict"] == "bad" for p in pats)
    lean = sum(pt.judge("fair", road(p))["verdict"] == "leaning bad" for p in pats)
    assert bad <= 3 and lean > 10


def sided(sides, **pats):
    """The 2.24 server's answer: per side, only patterns with 30+ bets, and their count."""
    return {"sides": sides, "by_side": pats, "m": len(pats)}


def test_banker_bets_are_compared_with_banker_bets():
    """After BBBB the strategy bets banker, which wins ~50.7% anywhere: 53 of 100 there is
    nothing special. Against an overall 50% it would have looked like a better pattern."""
    pt.set_stats("c4", sided({"B": [5068, 4932], "P": [4932, 5068]}, BBBB={"B": [53, 47]}))
    v = pt.judge("c4", road("BBBB"))
    assert v["base"] == 0.507 and v["verdict"] == "nothing special"


def test_the_line_rises_with_the_number_of_patterns_compared():
    assert pt.line_for(1) == 3.0
    assert 3.4 < pt.line_for(100) < 3.6 and 4.4 < pt.line_for(10_000) < 4.7
    # z = -4 is BAD among 10 patterns, not among 10,000
    pats = {"BBPPBB": {"P": [30, 70]}}
    pt.set_stats("c5", {**sided({"B": [500, 500], "P": [500, 500]}, **pats), "m": 10})
    assert pt.judge("c5", road("BBPPBB"))["verdict"] == "bad"
    pt.set_stats("c5", {**sided({"B": [500, 500], "P": [500, 500]}, **pats), "m": 10_000})
    v = pt.judge("c5", road("BBPPBB"))
    assert v["verdict"] == "leaning bad" and v["line"] > 4.4
    assert "not proven" in pt.describe(v)


def test_long_patterns_are_judged_too():
    p16 = "BBPPBBPPBBBPPBPB"
    pt.set_stats("c6", sided({"B": [500, 500], "P": [500, 500]}, **{p16: {"B": [2, 98]}}))
    v = pt.judge("c6", road(p16))
    assert v["pattern"] == p16 and v["verdict"] == "bad" and len(v["lengths"]) == 13


def test_the_track_record_is_against_what_those_bets_should_win():
    pt.set_stats("c7", {**sided({"B": [507, 493], "P": [493, 507]}),
                        "track": {"bad": {"B": [40, 60]}, "neutral": {"B": [500, 500], "P": [500, 500]}}})
    rows = {r["group"]: r for r in pt.track("c7")}
    assert rows["bad"]["n"] == 100 and rows["bad"]["exp"] == 0.507 and rows["bad"]["z"] < -2
    assert "after BAD: 100 bets, won 40.0%" in pt.describe_track(pt.track("c7"))


def test_a_template_sets_the_game_and_nothing_else():
    template.set_current(None, None)
    assert template.apply({"budget": "1000"}) == {"budget": "1000"}
    assert template.set_current("steady", {"budget": "5000", "strategy": "streak_or_chop_2",
                                           "click_min": "9"})
    out = template.apply({"budget": "1000", "click_min": "0.1", "base": "20"})
    assert out == {"budget": "5000", "click_min": "0.1", "base": "20", "strategy": "streak_or_chop_2"}
    assert not template.set_current("steady", {"budget": "5000", "strategy": "streak_or_chop_2"})
    template.set_current(None, None)
