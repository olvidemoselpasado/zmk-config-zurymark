"""The game window's width: saved per site, put back with one button, and fitted
before a session. Hyprland is a stand-in here: two windows tiled side by side, the
game and the terminal, where making one wider makes the other narrower -- and where
the split rounds, the way a real one does."""
import pytest

import bet
from baccarat.errors import BetError
from baccarat.screen import desktop, window

SCREEN, GAP = 2560, 10


class Hypr:
    """Two tiled windows and the split line between them, the way Hyprland's dwindle
    with smart_resizing moves it: a resize of +d moves the LINE d to the right,
    whichever window was asked. So the window on the left of the line grows and the
    one on the right shrinks -- and the split is a ratio, so it rounds a little."""

    def __init__(self, monkeypatch, game_w=1400, game_left=True, title="Casino — Baccarat",
                 rounding=3):
        self.line = game_w if game_left else SCREEN - game_w - GAP   # where the split is
        self.game_left, self.title, self.rounding = game_left, title, rounding
        self.calls = []
        monkeypatch.setattr(desktop, "list_windows", self.list)
        monkeypatch.setattr(desktop, "set_window_width", self.resize)
        monkeypatch.setattr(window, "SETTLE", 0.0)

    @property
    def game_w(self):
        return self.line if self.game_left else SCREEN - self.line - GAP

    @game_w.setter
    def game_w(self, w):
        self.line = w if self.game_left else SCREEN - w - GAP

    def list(self):
        left_w, right_w = self.line, SCREEN - self.line - GAP
        game = (0, left_w) if self.game_left else (self.line + GAP, right_w)
        term = (self.line + GAP, right_w) if self.game_left else (0, left_w)
        return [
            {"id": "0xgame", "class": "firefox", "title": self.title, "x": game[0], "y": 0,
             "w": game[1], "h": 1400, "floating": False, "fullscreen": False, "visible": True},
            {"id": "0xterm", "class": "kitty", "title": "python3 dashboard", "x": term[0], "y": 0,
             "w": term[1], "h": 1400, "floating": False, "fullscreen": False, "visible": True},
            {"id": "0xdash", "class": "firefox", "title": "Baccarat control — Mozilla Firefox",
             "x": 0, "y": 0, "w": 900, "h": 1400, "floating": False, "fullscreen": False,
             "visible": False},
        ]

    def resize(self, win_id, width, height, exact=True):
        self.calls.append((win_id, width, exact))
        assert win_id == "0xgame"
        delta = width - self.game_w if exact else width
        self.line += delta - (self.rounding if delta > 0 else -self.rounding)
        self.rounding = 0


@pytest.fixture
def board(site):
    d = bet.snaps_dir()
    d.mkdir(parents=True, exist_ok=True)
    (d / "board.geo").write_text("200,100 600x40")       # the scoreboard: in the game


def test_save_remembers_the_window_the_game_is_in(board, monkeypatch):
    Hypr(monkeypatch, game_w=1280)
    saved = window.save_game_window()
    assert (saved["w"], saved["x"], saved["class"]) == (1280, 0, "firefox")
    assert window.saved_window()["w"] == 1280


def test_with_nothing_recorded_it_can_t_tell_which_window(site, monkeypatch):
    Hypr(monkeypatch)
    with pytest.raises(BetError, match="which window is the game"):
        window.save_game_window()


def test_fit_puts_the_width_back_and_corrects_the_rounding(board, monkeypatch):
    h = Hypr(monkeypatch, game_w=1280)
    window.save_game_window()
    h.game_w, h.rounding = 1500, 3                    # the browser was closed and reopened
    r = window.fit_game_window()
    assert r == {**r, "before": 1500, "after": 1280, "fits": True, "same_place": True,
                 "changed": True, "side": "left"}
    assert all(not exact for _, _, exact in h.calls), "only nudges, each one measured"
    assert window.window_status()["fits"] is True


def test_a_game_on_the_right_of_the_split_is_steered_the_other_way(monkeypatch, site):
    """What went wrong in the field: the terminal on the left (713 px), the game on the
    right from x=723. '+d' moves the split right, so the game got NARROWER each time it
    was asked to grow, and ended up at x=1822. Measured, it is steered the right way."""
    d = bet.snaps_dir()
    d.mkdir(parents=True, exist_ok=True)
    (d / "board.geo").write_text("1500,100 600x40")  # the scoreboard: in the right window
    h = Hypr(monkeypatch, game_w=SCREEN - 723, game_left=False)
    saved = window.save_game_window()
    assert (saved["x"], saved["w"]) == (723, SCREEN - 723)
    h.game_w, h.rounding = 1300, 3                    # reopened: the game is narrower now
    r = window.fit_game_window()
    assert r["fits"] and r["same_place"] and r["side"] == "right"
    assert (r["after"], r["x"]) == (SCREEN - 723, 723)
    assert len(h.calls) <= 4


def test_it_never_leaves_the_window_worse_than_it_found_it(board, monkeypatch):
    """A layout that answers each nudge the opposite way to the one before: it can't be
    steered, so it is put back where it was."""
    h = Hypr(monkeypatch, game_w=1280)
    window.save_game_window()
    h.game_w, h.rounding = 1400, 0
    flips = [1]

    def contrary(win_id, width, height, exact=True):
        h.calls.append((win_id, width, exact))
        h.line += width * flips[0]
        flips[0] = -flips[0]
    monkeypatch.setattr(desktop, "set_window_width", contrary)
    r = window.fit_game_window()
    assert abs(r["after"] - 1280) <= abs(1400 - 1280) + window.CLOSE_ENOUGH


def test_already_right_nothing_is_touched(board, monkeypatch):
    h = Hypr(monkeypatch, game_w=1280)
    window.save_game_window()
    r = window.fit_game_window()
    assert not r["changed"] and h.calls == []


def test_a_page_title_that_changed_still_finds_the_game(board, monkeypatch):
    h = Hypr(monkeypatch, game_w=1280, title="Casino — Baccarat lobby")
    window.save_game_window()
    h.title, h.game_w = "Casino — Baccarat table 4", 1400
    assert window.fit_game_window()["after"] == 1280


def test_on_the_other_side_it_says_so_and_a_session_won_t_start(board, monkeypatch):
    h = Hypr(monkeypatch, game_w=1280)
    window.save_game_window()
    h.game_left = False
    r = window.fit_game_window()
    assert r["fits"] and not r["same_place"]
    with pytest.raises(BetError, match="same side"):
        window.ensure_game_window()


def test_before_a_session_it_is_fitted_by_itself(board, monkeypatch):
    h = Hypr(monkeypatch, game_w=1280)
    window.save_game_window()
    h.game_w = 1180
    window.ensure_game_window()
    assert h.game_w == 1280


def test_nothing_saved_a_session_starts_as_before(site, monkeypatch):
    h = Hypr(monkeypatch)
    window.ensure_game_window()
    assert h.calls == []
    with pytest.raises(BetError, match="no width saved"):
        window.fit_game_window()


def test_the_page_can_t_change_it_during_a_session(board, monkeypatch):
    import types
    from baccarat.web.routes_setup import SetupRoutes
    Hypr(monkeypatch, game_w=1280)
    me = types.SimpleNamespace(running=True)
    with pytest.raises(ValueError, match="session is running"):
        SetupRoutes.window(me, {"action": "fit"})
    assert SetupRoutes.window(me, {"action": "status"})["saved"] is None


def test_the_hyprland_side_asks_the_right_things(monkeypatch):
    """What is said to Hyprland, and how its answer is read -- without a Hyprland.
    Hyprland >= 0.55 (Lua) gets hl.dsp.window.resize; older ones resizewindowpixel."""
    import json
    from baccarat.screen import linux
    sent = []
    clients = [{"address": "0xabc", "class": "firefox", "title": "Casino", "at": [0, 0],
                "size": [1280, 1400], "workspace": {"id": 1}, "mapped": True, "hidden": False,
                "floating": False, "fullscreen": 0},
               {"address": "0xdef", "class": "kitty", "title": "term", "at": [0, 0],
                "size": [800, 1400], "workspace": {"id": 4}, "mapped": True, "hidden": False}]
    speaks = {"lua"}

    def req(cmd):
        sent.append(cmd)
        if cmd.startswith("j/"):
            return {"j/clients": json.dumps(clients),
                    "j/monitors": json.dumps([{"activeWorkspace": {"id": 1}}])}[cmd]
        lua = "hl.dsp" in cmd
        return "ok" if ("lua" if lua else "legacy") in speaks else "error: unknown"
    monkeypatch.setattr(linux, "_HYPR_SOCK", "/tmp/fake.sock")
    monkeypatch.setattr(linux, "hypr_request", req)
    wins = linux.list_windows()
    assert [(w["id"], w["w"], w["visible"]) for w in wins] == [("0xabc", 1280, True),
                                                                ("0xdef", 800, False)]
    # a Lua Hyprland (what the error in the field came from)
    monkeypatch.setattr(linux, "_MOVE_SYNTAX", None)
    linux.set_window_width("0xabc", 1300, 1400)
    linux.set_window_width("0xabc", -4, 0, exact=False)
    assert sent[-2:] == [
        'dispatch hl.dsp.window.resize({ x = 1300, y = 1400, relative = false, window = "address:0xabc" })',
        'dispatch hl.dsp.window.resize({ x = -4, y = 0, relative = true, window = "address:0xabc" })']
    # an older one
    speaks.clear(); speaks.add("legacy")
    monkeypatch.setattr(linux, "_MOVE_SYNTAX", None)
    linux.set_window_width("0xabc", 1300, 1400)
    assert sent[-1] == "dispatch resizewindowpixel exact 1300 1400,address:0xabc"
    assert linux._MOVE_SYNTAX == "legacy"
    # neither: it says what each one answered
    speaks.clear()
    monkeypatch.setattr(linux, "_MOVE_SYNTAX", None)
    with pytest.raises(BetError, match="lua: error: unknown"):
        linux.set_window_width("0xabc", 1300, 1400)
