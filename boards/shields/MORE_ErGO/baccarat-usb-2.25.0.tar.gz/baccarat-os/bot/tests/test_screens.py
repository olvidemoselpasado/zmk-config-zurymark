"""Table screening: the road shapes you write down to walk away from."""
import pytest
import strategies as S


# --- writing a pattern down -------------------------------------------------

@pytest.mark.parametrize("typed, want", [
    ("BBPPBB", "BBPPBB"),
    ("bb pp bb", "BBPPBB"),
    ("  p b  ", "PB"),
])
def test_a_pattern_is_cleaned_up_as_you_type_it(typed, want):
    assert S.clean_pattern(typed) == want


@pytest.mark.parametrize("bad", ["", "B", "PBX", "PBT", "P" * 61])
def test_a_pattern_that_cannot_be_used_is_refused(bad):
    with pytest.raises(Exception):
        S.clean_pattern(bad)


def test_a_pattern_reads_back_in_words():
    assert S.describe_pattern("BBPPBB") == "two banker, two player, two banker"


def test_the_big_road_starts_a_column_at_every_change():
    assert S.big_road("BBPPB") == [["B", "B"], ["P", "P"], ["B"]]


def test_a_long_run_turns_the_corner_rather_than_growing_forever():
    assert S.big_road("B" * 8, rows=6) == [["B"] * 6, ["B", "B"]]


# --- finding a pattern: whole runs only -------------------------------------

@pytest.mark.parametrize("road, hits, why", [
    ("PBPPBBP",  1, "clean: the side changes on both sides of it"),
    ("BPPBBB",   0, "the last run is three, not two"),
    ("BBPPBBP",  0, "the run in front is two, not one"),
    ("BPPBBP",   1, "it may start the road"),
    ("PBPPBB",   0, "it reaches the newest result, which may still grow"),
])
def test_a_pattern_only_counts_on_whole_runs(road, hits, why):
    assert len(S.find_pattern(road, "BPPBB")) == hits, why


def test_the_plain_substring_count_is_not_what_is_used():
    """BPPBB appears three times as text in this road and not once as a shape.
    Counting the text is what blocked a perfectly good table."""
    road = "PBPPBBBPPBBPPPBBPPBBP"
    loose = sum(1 for i in range(len(road)) if road.startswith("BPPBB", i))
    assert loose == 3
    assert S.find_pattern(road, "BPPBB") == []


def test_overlapping_shapes_are_each_counted_once():
    assert len(S.find_pattern("PBBPPBBPPBBP", "BBPPBB")) == 2


# --- judging a table --------------------------------------------------------

def patterns(*specs):
    return S.build_patterns([{"name": n, "pattern": p, "times": t} for n, p, t in specs])


ROAD = "BBPPBBPPBPPBBPPBBPBBPP"        # 22 results, four 2-2 ladders


def test_a_table_showing_the_shape_enough_times_is_turned_down():
    v = S.screen_table(ROAD, patterns(("two by two", "BBPPBB", 2)), min_history=20)
    assert v["bad"] and "two by two" in v["why"]


def test_once_is_not_enough_when_you_asked_for_twice():
    v = S.screen_table("PBBPPBBP", patterns(("two by two", "BBPPBB", 2)), min_history=4)
    assert not v["bad"]


def test_every_pattern_is_reported_not_just_the_one_that_failed():
    v = S.screen_table(ROAD, patterns(("two by two", "BBPPBB", 2),
                                      ("ping-pong", "PBPBPB", 1)), min_history=20)
    assert [c["bad"] for c in v["checks"]] == [True, False]


def test_a_table_with_too_little_history_is_not_judged_but_is_skipped():
    v = S.screen_table("BBPP", patterns(("two by two", "BBPPBB", 1)), min_history=20)
    assert v["bad"] and v["short"] and "20 are needed" in v["why"]


def test_with_no_patterns_ticked_every_table_passes():
    v = S.screen_table(ROAD, [], min_history=20)
    assert not v["bad"] and v["checks"] == []


def test_ties_do_not_break_a_shape():
    """A tie is not a result for this purpose, so a shape straddling one still
    counts as the same shape."""
    assert len(S.find_pattern(S.road_letters("P B B P P B B P"), "BBPPBB")) == 1
    assert len(S.find_pattern(S.road_letters("P B B T P P B B P"), "BBPPBB")) == 1


def test_a_pattern_with_a_bad_number_is_refused():
    with pytest.raises(Exception):
        S.build_patterns([{"name": "x", "pattern": "BBPP", "times": 0}])
    with pytest.raises(Exception):
        S.build_patterns([{"name": "x", "pattern": "BBPP", "times": "many"}])


def test_a_pattern_is_named_after_itself_when_you_do_not_name_it():
    assert S.build_patterns([{"pattern": "BBPP"}])[0]["name"] == "BBPP"
