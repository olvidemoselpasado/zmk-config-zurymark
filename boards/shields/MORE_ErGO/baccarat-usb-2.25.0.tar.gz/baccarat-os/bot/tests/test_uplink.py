"""The report server's side of the bot: what it notices, what it sends, and that a
server that can't be reached changes nothing for the bot."""
import gzip
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

from baccarat.web import uplink as up
from baccarat.web.server import LogBuffer


class FakeDash:
    def __init__(self, state=None):
        self.state = state or {}
        self.logs = LogBuffer()
        self.updates = {}

    def snapshot(self):
        return dict(self.state)

    def update(self, **kv):
        self.updates.update(kv)

    def log(self, level, text):
        self.logs.seq += 1
        self.logs.lines.append({"n": self.logs.seq, "level": level, "text": text})


@pytest.fixture
def server():
    """A stand-in report server: keeps what it receives, answers like the real one."""
    got, answer = [], {"ok": True, "next": 30, "report": False}

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_POST(self):
            body = self.rfile.read(int(self.headers["Content-Length"]))
            assert self.headers["Content-Encoding"] == "gzip"
            msg = json.loads(gzip.decompress(body))
            got.append(msg)
            out = dict(answer, ack=max([e["n"] for e in msg["events"]], default=0))
            data = json.dumps(out).encode()
            self.send_response(200)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{srv.server_address[1]}", got, answer
    srv.shutdown()


def playing(**kv):
    return {"running": True, "status": "Playing", "base": 20, "budget": 10000, "balance": 10120,
            "net": 120, "strategy": {"name": "streak_or_chop"}, "options": {"site": "casino"},
            "stats": {"W": 6, "L": 3}, "session": {"lives_now": 2, "hands": 40},
            "table": {"name": "table_7"}, "played": [], **kv}


def test_off_by_default_in_tests_and_with_off():
    assert up.server_url() is None
    assert up.Uplink(FakeDash(), url=None).start().thread is None


def test_server_address_forms(monkeypatch):
    monkeypatch.setenv("BACCARAT_SERVER", "192.168.0.2:4444")
    assert up.server_url() == "http://192.168.0.2:4444"
    monkeypatch.setenv("BACCARAT_SERVER", "http://10.0.0.1:4444/")
    assert up.server_url() == "http://10.0.0.1:4444"


def test_bot_id_is_kept(monkeypatch):
    monkeypatch.delenv("BACCARAT_BOT_ID", raising=False)
    a = up.bot_id()
    assert a == up.bot_id() and len(a) == 32
    monkeypatch.setenv("BACCARAT_BOT_ID", "stick-1234abcd")
    assert up.bot_id() == "stick-1234abcd"


def test_status_is_small_and_has_no_login():
    st = up.compact(playing(login={"email": "x@y.z", "password": "secret"}))
    assert st["balance"] == 10120 and st["W"] == 6 and st["table"] == "table_7"
    assert "secret" not in json.dumps(st) and "login" not in st
    assert len(json.dumps(st)) < 800


def test_session_tables_warnings_and_report(server):
    url, got, _ = server
    dash = FakeDash({"running": False})
    u = up.Uplink(dash, url=url, report=lambda s, lines: f"REPORT {len(lines)} lines")
    dash.state = playing()
    u.observe(dash.snapshot())
    dash.log("INFO", "just information")
    dash.log("WARNING", "the bet bar is late")
    dash.state = playing(played=[{"name": "table_7", "started": "10:00", "ended": "10:20",
                                  "won": 9, "lost": 4, "net": 180, "deepest": 3, "reason": "cutoff"}])
    u.observe(dash.snapshot())
    u.send(dash.snapshot())
    kinds = [e["kind"] for e in got[0]["events"]]
    assert kinds == ["session_start", "table", "warning"]
    assert got[0]["info"]["version"] and got[0]["status"]["running"] is True
    assert "report" not in got[0]
    assert not u.events                          # acknowledged: not sent again

    dash.state = dict(playing(), running=False, status="Target reached")
    assert u.observe(dash.snapshot()) is True     # a session end is sent at once …
    u.send(dash.snapshot())
    assert got[1]["events"][0]["kind"] == "session_end"
    assert got[1]["report"]["why"] == "session ended"   # … with its report
    assert got[1]["report"]["text"].startswith("REPORT")
    assert u.want_report is None
    assert dash.updates["uplink"]["ok"] is True


def test_report_asked_from_the_server(server):
    url, got, answer = server
    u = up.Uplink(FakeDash(playing()), url=url, report=lambda s, lines: "R")
    answer["report"] = True
    assert u.send(u.dash.snapshot()) == 1         # call back at once, with it
    answer["report"] = False
    u.send(u.dash.snapshot())
    assert got[1]["report"] == {"why": "asked from the server", "text": "R"}


def test_unreachable_server_keeps_events_and_backs_off():
    dash = FakeDash(playing())
    u = up.Uplink(dash, url="http://127.0.0.1:9", every=30)   # nothing listens there
    u.observe(dash.snapshot())
    assert u.send(dash.snapshot()) == 30
    assert u.send(dash.snapshot()) == 60
    assert len(u.events) == 1                     # the session start, still waiting
    assert dash.updates["uplink"]["ok"] is False and dash.updates["uplink"]["waiting"] == 1


def test_a_release_mentioned_by_the_server_wakes_the_updater(server, tmp_path, monkeypatch):
    """The server says which system is out: a stick not on it starts fetching at once."""
    import os
    from baccarat.web import updatestatus as us
    url, got, answer = server
    (tmp_path / "poke").mkdir()
    os.symlink("/nix/store/" + "a" * 32 + "-nixos-system-usb", tmp_path / "current")
    monkeypatch.setattr(us, "POKE", tmp_path / "poke" / "now")
    monkeypatch.setattr(us, "CURRENT", tmp_path / "current")
    monkeypatch.setattr(us, "FILE", tmp_path / "status.json")
    us._poked.update(system=None, at=0.0)
    u = up.Uplink(FakeDash(playing()), url=url, report=lambda s, lines: "R")
    u.send(u.dash.snapshot())
    assert not (tmp_path / "poke" / "now").exists()      # nothing out yet
    new = "/nix/store/" + "b" * 32 + "-nixos-system-usb"
    from baccarat import __version__
    answer["release"] = {"system": new, "version": __version__}
    u.send(u.dash.snapshot())
    assert (tmp_path / "poke" / "now").read_text().strip() == new
