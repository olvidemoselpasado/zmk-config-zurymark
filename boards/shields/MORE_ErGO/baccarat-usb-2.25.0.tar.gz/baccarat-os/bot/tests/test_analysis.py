"""Replay and what-if — analysis.py.

These answer "how would this table have gone if I had joined at hand N", which
is the only tool in the project that lets a strategy change be judged against a
real table rather than an opinion. If the replay drifts from what the live
session does, every conclusion drawn from it is wrong, so the thing most worth
pinning down is that the two agree.
"""
import unittest

import analysis
from helpers import road

SETTINGS = dict(strategy="streak_or_chop_2", budget=1000, base=20, rules=[])


class PlayingFromAHand(unittest.TestCase):
    def test_joining_at_one_plays_the_table_out(self):
        r = road("BPBPBPBPBP")                  # a chop it follows happily
        s = analysis._play_from(r, 1, **SETTINGS)
        self.assertEqual(len(s.results), len(r))
        self.assertFalse(s.busted)

    def test_it_stops_the_moment_the_money_runs_out(self):
        """A replay that kept playing past a bust would report hands that could
        never have happened."""
        r = road("BBPPBBPPBP")                  # two-by-two: it busts on 1000
        s = analysis._play_from(r, 1, **SETTINGS)
        self.assertTrue(s.busted)
        self.assertLess(len(s.results), len(r))

    def test_joining_later_plays_only_what_is_left(self):
        r = road("BBPPBBPPBP")
        s = analysis._play_from(r, 5, **SETTINGS)
        self.assertEqual(len(s.results), len(r) - 4)

    def test_what_came_before_is_handed_over_as_history(self):
        """Joining at hand 5 means the first four results are known, exactly as
        a road region would give them — not that the table started at five."""
        r = road("BBPPBBPPBP")
        early = analysis._play_from(r, 5, **SETTINGS)
        self.assertEqual(early.results[0].side is None, False)   # it can bet at once

    def test_the_same_road_always_gives_the_same_answer(self):
        r = road("BBPPBBPPBPPBBPPBBPBB")
        a = analysis._play_from(r, 3, **SETTINGS)
        b = analysis._play_from(r, 3, **SETTINGS)
        self.assertEqual(a.balance, b.balance)
        self.assertEqual([x.outcome for x in a.results], [x.outcome for x in b.results])


class EntryScan(unittest.TestCase):
    def scan(self, letters, first=1, last=None, **kw):
        return analysis.entry_scan(road(letters), first, last, **{**SETTINGS, **kw})

    def test_one_row_per_entry_point(self):
        got = self.scan("BBPPBBPPBP", 1, 5)
        self.assertEqual(len(got["entries"]), 5)
        self.assertEqual([e["at"] for e in got["entries"]], [1, 2, 3, 4, 5])

    def test_a_strategy_that_needs_two_results_cannot_bet_before_hand_three(self):
        """So joining at 1, 2 and 3 come out identical — which is why the first
        bet is reported, not just the entry."""
        got = self.scan("BBPPBBPPBP", 1, 3)
        firsts = {e["first_bet"] for e in got["entries"]}
        self.assertEqual(firsts, {3})

    def test_every_row_carries_what_the_table_did_to_it(self):
        for e in self.scan("BBPPBBPPBP", 1, 3)["entries"]:
            for key in ("at", "first_bet", "hands", "bets", "wins", "losses",
                        "net", "max_bet", "worst_run", "busted", "balance"):
                self.assertIn(key, e)

    def test_a_backwards_range_is_refused(self):
        with self.assertRaises(ValueError):
            self.scan("BBPPBB", 5, 2)

    def test_an_empty_road_is_refused(self):
        with self.assertRaises(ValueError):
            analysis.entry_scan([], 1, 3, **SETTINGS)

    def test_the_range_is_clipped_to_the_table(self):
        got = self.scan("BBPP", 1, 99)
        self.assertEqual(got["entries"][-1]["at"], 4)

    def test_wins_and_losses_add_up_to_the_bets(self):
        for e in self.scan("BBPPBBPPBPPBBPPB", 1, 6)["entries"]:
            self.assertEqual(e["wins"] + e["losses"] + e["pushes"], e["bets"])


class EntryDetail(unittest.TestCase):
    def test_one_row_per_hand_from_the_join(self):
        r = road("BPBPBPBPBP")
        got = analysis.entry_detail(r, 4, **SETTINGS)
        self.assertEqual(len(got["rows"]), len(r) - 3)

    def test_each_row_says_what_really_came_and_what_was_predicted(self):
        got = analysis.entry_detail(road("BBPPBBPPBP"), 3, **SETTINGS)
        for row in got["rows"]:
            self.assertIn("winner", row)
            self.assertIn("side", row)             # what it bet, or nothing
            self.assertIn("outcome", row)

    def test_the_detail_agrees_with_the_scan(self):
        """Two different code paths over the same table have to come out the
        same, or the panel contradicts itself on screen."""
        r = road("BBPPBBPPBPPBBPPBBPBB")
        scanned = next(e for e in analysis.entry_scan(r, 4, 4, **SETTINGS)["entries"])
        detail = analysis.entry_detail(r, 4, **SETTINGS)
        self.assertAlmostEqual(scanned["net"], detail["net"], places=2)


class ReplayMatchesLivePlay(unittest.TestCase):
    """The replay and a live session share one engine. This is the test that
    says so: play a road by hand through a Session, and through the replay, and
    insist the money comes out the same."""

    def test_by_hand_and_by_replay_agree(self):
        r = road("BBPPBBPPBPPBBPPBBPBB")
        by_hand = analysis.new_session(**SETTINGS)
        by_hand.new_table()
        for i, winner in enumerate(r, start=1):
            by_hand.record(winner, by_hand.next_bet(hand=i), i)
            if by_hand.busted:                  # a live session stops here too
                break
        replayed = analysis._play_from(r, 1, **SETTINGS)
        self.assertAlmostEqual(by_hand.balance, replayed.balance, places=2)
        self.assertEqual(len(by_hand.results), len(replayed.results))
        self.assertEqual([x.outcome for x in by_hand.results],
                         [x.outcome for x in replayed.results])

    def test_a_rule_behaves_the_same_in_both(self):
        r = road("BBPPBBPPBPPBBPPBBPBBPPBB")
        settings = {**SETTINGS, "rules": [{"name": "majority", "n": 3, "window": 11}]}
        by_hand = analysis.new_session(**settings)
        by_hand.new_table()
        for i, winner in enumerate(r, start=1):
            by_hand.record(winner, by_hand.next_bet(hand=i), i)
            if by_hand.busted:
                break
        replayed = analysis._play_from(r, 1, **settings)
        self.assertAlmostEqual(by_hand.balance, replayed.balance, places=2)
        self.assertEqual([x.outcome for x in by_hand.results],
                         [x.outcome for x in replayed.results])


class CountingOutcomes(unittest.TestCase):
    """`Session.count` reports the last eleven results, not the whole session.
    That is deliberate — it feeds the recent-form figures — but it means it can
    never be used as a session total, and anything that needs one has to count
    `results` itself. Pinned here because the two readings look identical at a
    glance and are not."""

    def test_it_only_looks_at_the_recent_results(self):
        r = road("BPBPBPBPBPBPBPBPBPBP")
        s = analysis._play_from(r, 1, **SETTINGS)
        self.assertGreater(len(s.results), 11)
        windowed = s.count("WIN") + s.count("LOSS") + s.count("PUSH") + s.count("NO BET")
        self.assertEqual(windowed, 11)

    def test_a_session_total_has_to_be_counted_from_results(self):
        r = road("BPBPBPBPBPBPBPBPBPBP")
        s = analysis._play_from(r, 1, **SETTINGS)
        whole = sum(1 for x in s.results if x.outcome == "WIN")
        self.assertGreaterEqual(whole, s.count("WIN"))


class Busting(unittest.TestCase):
    def test_a_table_that_runs_the_money_out_is_reported_as_bust(self):
        """Perfect two-by-two is what takes streak_or_chop_2 apart: every bet
        lands on the hand the run ends."""
        r = road("BBPP" * 6)
        got = analysis.entry_scan(r, 1, 1, strategy="streak_or_chop_2",
                                  budget=500, base=20, rules=[])
        self.assertTrue(got["entries"][0]["busted"])

    def test_capping_the_ladder_survives_the_same_table(self):
        """Doubling without a limit is what runs the money out, not the table."""
        r = road("BBPP" * 6)
        got = analysis.entry_scan(r, 1, 1, strategy="streak_or_chop_2",
                                  budget=100000, base=20, max_steps=3, rules=[])
        self.assertFalse(got["entries"][0]["busted"])


if __name__ == "__main__":
    unittest.main()
