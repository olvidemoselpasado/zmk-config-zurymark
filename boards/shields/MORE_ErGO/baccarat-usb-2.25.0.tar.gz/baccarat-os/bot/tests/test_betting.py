"""Chip maths and click planning — betting.py.

Everything here is a pure function over plain data, so these are the cheapest
tests in the project and the ones most worth keeping right: a wrong plan means
the wrong amount of money goes on the table.
"""
import random
import unittest

import betting


def coords(chips=(20, 100, 500), spots_each=3, redos=3, step=30):
    """A recorded table. `step` is how far apart the variants of one button sit:
    30 px is a normal recording, 2 px is everything on one spot."""
    c = {f"chip_{v}": {"x": 100 + i * 40, "y": 900, "action": "click"}
         for i, v in enumerate(chips)}
    for i in range(1, spots_each + 1):
        c[f"spot_player_{i}"] = {"x": 400 + i * step, "y": 800, "action": "click"}
        c[f"spot_banker_{i}"] = {"x": 600 + i * step, "y": 800, "action": "click"}
    for i in range(1, redos + 1):
        c[f"redo_bet_{i}"] = {"x": 800 + i * step, "y": 900, "action": "click"}
    return c


class ChipBreakdown(unittest.TestCase):
    def test_exact_change_uses_fewest_chips(self):
        self.assertEqual(betting.chips_for(140, [100, 20]), {100: 1, 20: 2})

    def test_not_greedy(self):
        """Taking the biggest chip each time strands 10 and fails. The docstring
        in chips_for calls this out; it is the reason the function is a DP."""
        got = betting.chips_for(1160, [500, 200, 100, 50, 20])
        self.assertIsNotNone(got)
        self.assertEqual(sum(v * n for v, n in got.items()), 1160)

    def test_impossible_amount_is_none(self):
        self.assertIsNone(betting.chips_for(30, [20]))

    def test_zero_is_no_chips(self):
        self.assertEqual(betting.chips_for(0, [20]), {})


class Planning(unittest.TestCase):
    def test_repeat_and_double_is_two_redos(self):
        last = betting.Placed("player", 80.0, 5, "t")
        plan = betting.plan_bet("player", 160.0, 20.0, [20], last, 6, "t", True)
        self.assertEqual(plan, [("redo",), ("redo",)])

    def test_repeat_after_a_tie_is_one_redo(self):
        last = betting.Placed("player", 80.0, 5, "t")
        plan = betting.plan_bet("player", 80.0, 20.0, [20], last, 6, "t", True)
        self.assertEqual(plan, [("redo",)])

    def test_different_side_cannot_repeat(self):
        last = betting.Placed("player", 80.0, 5, "t")
        plan = betting.plan_bet("banker", 160.0, 20.0, [20], last, 6, "t", True)
        self.assertNotIn(("redo",), plan[:1])

    def test_another_table_cannot_repeat(self):
        last = betting.Placed("player", 80.0, 5, "other")
        plan = betting.plan_bet("player", 160.0, 20.0, [20], last, 6, "t", True)
        self.assertNotEqual(plan, [("redo",), ("redo",)])

    def test_ladder_from_base_when_there_is_nothing_to_repeat(self):
        plan = betting.plan_bet("player", 160.0, 20.0, [20], None, None, None, True)
        self.assertEqual(plan, [("chip", 20), ("spot",)] + [("redo",)] * 3)

    def test_chips_only_when_no_redo_button(self):
        plan = betting.plan_bet("player", 140.0, 20.0, [100, 20], None, None, None, False)
        self.assertNotIn(("redo",), plan)
        self.assertEqual(sum(1 for a in plan if a[0] == "spot"), 3)   # 100 + 20 + 20

    def test_amount_the_chips_cannot_make_is_refused(self):
        with self.assertRaises(ValueError):
            betting.plan_bet("player", 30.0, 20.0, [20], None, None, None, False)

    def test_only_player_or_banker(self):
        with self.assertRaises(ValueError):
            betting.plan_bet("tie", 20.0, 20.0, [20], None, None, None, False)


class WorstBet(unittest.TestCase):
    """The biggest bet a configuration can reach. Setup refuses a session whose
    worst bet cannot be clicked inside the betting window, so this number decides
    whether a session is allowed to start at all."""

    def test_every_doubling_adds_a_click(self):
        n, stake, _ = betting.worst_bet([20], 20, 6, 7600, True)
        self.assertEqual(stake, 20 * 2 ** 6)
        self.assertEqual(n, 2 + 6)             # chip + spot, then six doublings

    def test_the_worst_bet_is_the_top_of_the_ladder_not_the_first(self):
        """The bug this guards: checking only the opening bet passed a setup whose
        biggest bet needed eleven clicks and could never be placed."""
        n, stake, _ = betting.worst_bet([20], 20, 9, 100000, True)
        self.assertEqual(stake, 20 * 2 ** 9)
        self.assertGreater(n, len(betting.plan_bet("player", 20.0, 20.0, [20],
                                                   None, None, None, True)))

    def test_budget_caps_the_ladder(self):
        _, stake, _ = betting.worst_bet([20], 20, None, 100, True)
        self.assertLessEqual(stake, 100)

    def test_no_chips_recorded_means_nothing_to_measure(self):
        self.assertEqual(betting.worst_bet([], 20, 6, 7600, True), (0, 0.0, []))


class RepeatedClicks(unittest.TestCase):
    """Two presses on one spot inside the double-click window can be swallowed,
    which is how a doubled bet silently goes on at half size. They are either
    dealt round several recorded points, or held apart — and the betting window
    has to pay for the ones that are held."""

    def test_counts_back_to_back_identical_actions(self):
        plan = [("chip", 20), ("spot",), ("redo",), ("redo",), ("redo",)]
        self.assertEqual(betting.repeat_clicks(plan), 2)

    def test_nothing_is_held_when_the_variants_are_spread_out(self):
        plan = [("chip", 20), ("spot",)] + [("redo",)] * 5
        self.assertEqual(betting.repeat_clicks(plan, coords(step=30), "player", 14), 0)

    def test_everything_is_held_when_they_sit_on_one_point(self):
        plan = [("chip", 20), ("spot",)] + [("redo",)] * 5
        self.assertEqual(betting.repeat_clicks(plan, coords(step=2), "player", 14), 4)

    def test_one_recorded_point_cannot_be_spread(self):
        plan = [("chip", 20), ("spot",), ("redo",), ("redo",)]
        self.assertEqual(betting.repeat_clicks(plan, coords(redos=1), "player", 14), 1)

    def test_spread_out_needs_two_points_far_enough_apart(self):
        self.assertTrue(betting.spread_out(coords(step=30), ["redo_bet_1", "redo_bet_2"], 14))
        self.assertFalse(betting.spread_out(coords(step=2), ["redo_bet_1", "redo_bet_2"], 14))
        self.assertFalse(betting.spread_out(coords(), ["redo_bet_1"], 14))


class Placing(unittest.TestCase):
    """The placer turns a plan into named coordinates. The rule that matters:
    never two presses in a row on the same recorded point when there is a choice."""

    def place(self, side, amount, seed, last=None, co=None):
        clicked = []
        p = betting.BetPlacer(clicked.append, lambda: co or coords(), random.Random(seed))
        p.last = last
        p.place(side, amount, 20.0, 6, "t")
        return clicked

    def test_never_the_same_point_twice_running(self):
        bad = 0
        for seed in range(50):
            last = betting.Placed("player", 80.0, 5, "t")
            hits = self.place("player", 160.0, seed, last)
            bad += any(hits[i] == hits[i - 1] for i in range(1, len(hits)))
        self.assertEqual(bad, 0)

    def test_holds_for_a_long_chip_only_bet(self):
        hits = self.place("player", 1240.0, 3, None, coords(redos=0))
        self.assertFalse(any(hits[i] == hits[i - 1] for i in range(1, len(hits))))

    def test_one_spot_per_side_is_still_fine(self):
        hits = self.place("player", 60.0, 1, None, coords(spots_each=1, redos=0))
        self.assertTrue(hits)                  # it just repeats; the click layer holds them apart

    def test_the_chip_is_not_reselected_when_it_is_already_up(self):
        clicked = []
        p = betting.BetPlacer(clicked.append, coords, random.Random(1))
        p.place("player", 40.0, 20.0, 1, "t")
        clicked.clear()
        p.place("banker", 40.0, 20.0, 3, "t")  # same chip still selected
        self.assertFalse([c for c in clicked if c.startswith("chip_")])


class TheRepeatButtonWaitsForTheChip(unittest.TestCase):
    """The bug, from a live table: 160 on banker was planned as a 20 chip on banker and
    three presses of the repeat button. The chip click missed. Pressed on an empty
    table the repeat button repeats LAST round's bet -- 80 on player -- and the two
    presses after it doubled that: 320 on player. Now the chip has to show on the
    balance before the repeat button is touched."""

    def place(self, answer, side="banker", amount=160.0, last=None):
        clicked, asked = [], []
        p = betting.BetPlacer(clicked.append, coords, random.Random(4))
        p.last = last if last is not None else betting.Placed("player", 80.0, 5, "t")

        def confirm(staked):
            asked.append(staked)
            return answer
        how = p.place(side, amount, 20.0, 6, "t", confirm=confirm)
        return p, clicked, asked, how

    def test_no_chip_on_the_balance_no_repeat_presses(self):
        p, clicked, asked, how = self.place(False)
        self.assertEqual(asked, [20.0])
        self.assertFalse([c for c in clicked if c.startswith("redo_")])
        self.assertTrue([c for c in clicked if c.startswith("spot_banker")])
        self.assertEqual(p.cut_short, 20.0)
        self.assertIsNone(p.last, "the repeat button's memory can't be trusted now")
        self.assertIn("STOPPED", how)

    def test_the_chip_seen_the_repeats_follow(self):
        p, clicked, asked, _ = self.place(True)
        self.assertEqual(asked, [20.0], "asked once, before the first repeat")
        self.assertEqual(len([c for c in clicked if c.startswith("redo_")]), 3)
        self.assertIsNone(p.cut_short)

    def test_a_bet_that_is_only_repeats_is_not_asked(self):
        """Same side as last hand: repeat + double, no chip down first. That one is
        meant to repeat last round's bet, and placer.last is cleared whenever a bet
        didn't go on as clicked, so it is only used when that bet really is there."""
        _, clicked, asked, _ = self.place(False, "player", 160.0)
        self.assertEqual(asked, [])
        self.assertEqual(len([c for c in clicked if c.startswith("redo_")]), 2)

    def test_the_window_sets_time_aside_only_for_bets_that_check(self):
        from baccarat.play.placing import checks_chips_first
        self.assertTrue(checks_chips_first([("chip", 20), ("spot",), ("redo",)]))
        self.assertFalse(checks_chips_first([("redo",), ("redo",)]))
        self.assertFalse(checks_chips_first([("chip", 20), ("spot",), ("spot",)]))


class SetupProblems(unittest.TestCase):
    def test_missing_spots_block_play(self):
        errors, _ = betting.setup_problems({"chip_20": {"x": 1, "y": 1}})
        self.assertEqual(len(errors), 2)       # one per side

    def test_missing_redo_is_only_a_warning(self):
        errors, warnings = betting.setup_problems(coords(redos=0))
        self.assertEqual(errors, [])
        self.assertTrue(warnings)

    def test_a_complete_table_is_clean(self):
        errors, warnings = betting.setup_problems(coords())
        self.assertEqual((errors, warnings), ([], []))


if __name__ == "__main__":
    unittest.main()
