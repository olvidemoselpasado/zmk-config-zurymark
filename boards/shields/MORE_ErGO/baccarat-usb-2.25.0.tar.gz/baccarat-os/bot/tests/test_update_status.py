"""The stick's own update, as the dashboard sees it: Start held back while it is about to
install, never by a status the updater stopped refreshing."""
import json
import time

import pytest

from baccarat.web import updatestatus as us


@pytest.fixture
def status(tmp_path, monkeypatch):
    f = tmp_path / "status.json"
    monkeypatch.setattr(us, "FILE", f)

    def write(**kv):
        f.write_text(json.dumps({"version": "2.23.0", "done": 0, "total": 0, "at": time.time(), **kv}))
    return write


def test_no_file_no_update():
    assert us.read() is None or not us.holding(us.read())


def test_downloading_holds_and_says_how_far(status):
    status(state="downloading", done=15 * 2**20, total=60 * 2**20)
    st = us.read()
    assert st["pct"] == 25 and us.holding(st)
    assert "downloading (25%)" in us.why(st)


@pytest.mark.parametrize("state,held", [("waiting", True), ("installing", True), ("done", False),
                                        ("current", False), ("failed", False)])
def test_which_states_hold_a_session_back(status, state, held):
    status(state=state)
    assert us.holding(us.read()) is held


def test_a_stale_status_holds_nothing(status):
    status(state="installing", at=time.time() - 120)
    assert us.read()["stale"] and not us.holding(us.read())


def test_start_is_refused_while_it_installs(status, monkeypatch):
    from types import SimpleNamespace
    from baccarat.web.routes_session import SessionRoutes
    status(state="installing")
    me = SimpleNamespace(running=False, lock=None)
    with pytest.raises(ValueError, match="installing"):
        SessionRoutes.start(me, {"strategy": "streak_or_chop_2", "budget": "1000", "base": "20"})
