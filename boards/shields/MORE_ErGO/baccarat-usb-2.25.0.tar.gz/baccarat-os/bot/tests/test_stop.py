"""The Stop button: no question first, and it takes effect at once -- in the middle
of the clicks too, where the rest of the bet is simply not made."""
import pathlib
import random
import threading
import time
import types

import pytest

from baccarat.core import bets as betting
from baccarat.play import stop
from baccarat.web.routes_session import SessionRoutes
from helpers import table_coords

DASHBOARD = pathlib.Path(__file__).parent.parent / "baccarat/web/static/dashboard.html"


@pytest.fixture(autouse=True)
def clear():
    stop.STOP.clear()
    stop.PAUSE.clear()
    yield
    stop.STOP.clear()
    stop.PAUSE.clear()


def test_stop_in_the_middle_of_the_clicks_makes_no_more_of_them():
    clicked = []
    p = betting.BetPlacer(clicked.append, table_coords, random.Random(4))
    p.last = betting.Placed("banker", 640.0, 5, "t")

    def click(name):
        clicked.append(name)
        if len(clicked) == 2:
            stop.STOP.set()                     # you press Stop after the second click
    p.click = click
    with pytest.raises(stop.Stopped):
        p.place("player", 1280.0, 20.0, 9, "t", check=stop.stop_now)
    assert len(clicked) == 2, "nothing clicked after Stop"
    assert p.interrupted["clicks"] == 2 and p.interrupted["of"] > 2
    assert p.last is None, "what the repeat button remembers is unknown now"


def test_without_stop_the_check_changes_nothing():
    clicked = []
    p = betting.BetPlacer(clicked.append, table_coords, random.Random(4))
    p.place("player", 160.0, 20.0, 1, "t", check=stop.stop_now)
    assert clicked and p.interrupted is None and p.last is not None


def test_a_pause_never_holds_up_the_clicks():
    stop.PAUSE.set()
    t0 = time.monotonic()
    stop.stop_now()                             # returns at once: a pause isn't a stop
    assert time.monotonic() - t0 < 0.05


def test_a_wait_is_cut_short_by_stop():
    threading.Timer(0.15, stop.STOP.set).start()
    t0 = time.monotonic()
    with pytest.raises(stop.Stopped):
        stop.nap(5.0)
    assert time.monotonic() - t0 < 0.5


def test_the_page_says_stopping_at_once():
    seen = {}
    dash = types.SimpleNamespace(update=lambda **kw: seen.update(kw))
    me = types.SimpleNamespace(running=True, answered=threading.Event(), dash=dash)
    assert SessionRoutes.stop(me, {}) == {"message": "Stopping…"}
    assert stop.STOP.is_set() and seen == {"status": "Stopping…", "stopping": True}


def test_the_stop_button_asks_nothing():
    page = DASHBOARD.read_text()
    handler = page[page.index('$("btn-run").onclick'):]
    handler = handler[:handler.index("\n};") + 3]
    assert "confirm(" not in handler and "alert(" not in handler
    assert '"/api/stop"' in handler


def test_a_bet_cut_off_by_stop_is_reported_plainly(site, caplog):
    import logging
    import main
    from baccarat.study.replay import new_session
    caplog.set_level(logging.INFO)
    p = main.Player(new_session(strategy="streak_or_chop_2", budget=1000, base=20), road=None)
    p.current_bet = ("player", 320.0)
    p.placer.interrupted = {"clicks": 3, "of": 6, "chips": 20.0}
    p.stopped_mid_bet(14, "player", 320.0)
    assert p.current_bet is None
    text = "\n".join(r.getMessage() for r in caplog.records)
    assert "STOPPED in the middle of the bet — 3 of the 6 clicks" in text
    p.placer.interrupted = {"clicks": 0, "of": 6, "chips": 0.0}
    p.stopped_mid_bet(15, "player", 320.0)
    assert "nothing was put on the table" in "\n".join(r.getMessage() for r in caplog.records)
