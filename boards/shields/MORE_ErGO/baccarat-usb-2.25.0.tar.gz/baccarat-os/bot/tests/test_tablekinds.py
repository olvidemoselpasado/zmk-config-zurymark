"""What kind of table this is: its pattern, the four numbers that describe it, the
tables like it and what they turned out to be worth, the call, and whether the call
was right.

Two made-up worlds keep the detector honest. In one, choppy and streaky tables
really do play differently for this configuration, and it has to find that and
prove it. In the other, every table is dealt from the game's odds -- the shape of
the road means nothing -- and it has to say so rather than invent a pattern.
"""
import functools
import logging
import random
import time

import pytest

import main
from baccarat.core import tablekind as tk
from baccarat.core.rules import build_rules
from baccarat.setup import kind_params
from baccarat.store import tablecalls
from baccarat.study import tablekinds as kinds
from baccarat.study.expect import deal_tables
from baccarat.study.replay import new_session
from baccarat.web import report
from helpers import road

CONFIG = dict(strategy="streak_or_chop_2", budget=10524.96, base=20, table_hands=60,
              rules=["majority=3,12"])


def shaped(kind: str, rng: random.Random, n: int = 60) -> list[str]:
    """A table that keeps changing sides (chop) or keeps repeating (streak)."""
    out, last = [], "player"
    for _ in range(n):
        change = rng.random() < (0.85 if kind == "chop" else 0.2)
        last = ("banker" if last == "player" else "player") if change else last
        out.append(last)
    return out


@pytest.fixture(scope="module")
def signal_world():
    rng = random.Random(5)
    return [{"name": f"t{i}", "road": shaped("chop" if i % 2 else "streak", rng)}
            for i in range(1000)]


@pytest.fixture(scope="module")
def random_world():
    return deal_tables(60, n=600)


# --- the pattern -------------------------------------------------------------------

def test_the_pattern_is_the_majority_window_or_the_whole_table():
    assert tk.window_of(build_rules(["majority=3,12"])) == 12
    assert tk.window_of(build_rules(["majority=3,0"])) == 0, "window 0 = the whole table"
    assert tk.window_of(build_rules(["loss_streak=3"])) == 0, "no majority rule"
    r = road("PPTB" + "PB" * 10)
    assert tk.pattern_of(r, 12) == ("PB" * 10)[-12:], "the last 12 results, ties left out"
    assert tk.pattern_of(r, 0) == "PPB" + "PB" * 10
    assert not tk.ready(road("PB" * 5), 12) and tk.ready(road("PB" * 6), 12)
    assert not tk.ready(road("PB" * 5), 0, whole_after=12)


def test_four_numbers_describe_a_pattern():
    assert tk.shape("PBPB") == {"chop": 1.0, "banker": 0.5, "longest": 1, "doubles": 0.0}
    assert tk.shape("PPPP") == {"chop": 0.0, "banker": 0.0, "longest": 4, "doubles": 0.0}
    assert tk.shape("PPBBPPBB")["doubles"] == 1.0
    assert "chop 1.00" in tk.describe("PBPB")


def test_what_a_table_was_worth():
    cover = 9                                    # the next-to-last life is bet 8
    assert tk.tier(450, 3, cover) == "exceptional"
    assert tk.tier(200, 3, cover) == "good"
    assert tk.tier(100, 3, cover) == "regular"
    assert tk.tier(0, 1, cover) == "regular"
    assert tk.tier(-20, 2, cover) == "bad", "lost money"
    assert tk.tier(500, 8, cover) == "bad", "a run reached the next-to-last life"
    assert tk.tier(500, 7, cover) == "exceptional"
    assert tk.tier(160, 2, cover, exceptional_at=1000, regular_below=200) == "regular"
    assert tablecalls.TIERS == tk.TIERS, "the store keeps its own copy: they must agree"


# --- the examples -------------------------------------------------------------------

def test_every_table_is_taken_back_to_the_same_hand():
    t = {"name": "a", "start_counts": {"player": 3, "banker": 2, "tie": 0},
         "prior_road": road("PBPBP"), "road": road("BBBPPPBBBPPP")}
    assert kinds.known_road(t) == (1, road("PBPBP" + "BBBPPPBBBPPP"))
    rows, cover = kinds.examples(**CONFIG, hand=12, window=12, tables=[t])
    assert rows and rows[0]["pattern"] == "PBPBPBBBPPPB" and rows[0]["hands"] == 5
    assert cover == 9
    late = {"name": "b", "start_counts": {"player": 10, "banker": 10, "tie": 0},
            "road": road("PB" * 20)}
    assert kinds.known_road(late)[0] == 21
    assert kinds.examples(**CONFIG, hand=12, window=0, tables=[late])[0] == [], \
        "the whole table is the pattern, and its start wasn't seen"
    assert kinds.examples(**CONFIG, hand=12, window=12, tables=[t], exclude=("a",))[0] == []


def test_too_few_tables_say_how_many_are_needed():
    r = kinds.judge(road("PB" * 6), 12, 12, **CONFIG, tables=deal_tables(60, n=5))
    assert r["ready"] is False and "30 are needed" in r["why"]


# --- the call --------------------------------------------------------------------------

def test_where_the_shape_matters_it_finds_it_and_proves_it(signal_world):
    rng = random.Random(9)
    chop = kinds.judge(shaped("chop", rng)[:20], 20, 12, **CONFIG, tables=signal_world)
    streak = kinds.judge(shaped("streak", rng)[:20], 20, 12, **CONFIG, tables=signal_world)
    assert chop["call"] == "bad" and streak["call"] == "good"
    assert chop["spectrum"]["bad"] > 2 * chop["general"]["bad"]
    assert abs(sum(chop["spectrum"].values()) - 1) < 0.01
    assert chop["record"]["proven"] == {"bad": True, "good": True}
    assert "chop" in chop["uses"]


def test_where_the_shape_means_nothing_it_proves_nothing(random_world):
    rng = random.Random(3)
    for kind in ("chop", "streak"):
        r = kinds.judge(shaped(kind, rng)[:20], 20, 12, **CONFIG, tables=random_world)
        assert r["ready"] and r["record"]["proven"] == {"bad": False, "good": False}
        assert r["call"] in ("good", "ordinary", "bad")
    calls = r["record"]["calls"]
    assert calls["ordinary"]["n"] > calls["good"]["n"] + calls["bad"]["n"], \
        "on noise it should mostly decline to call"


def test_the_same_tables_give_the_same_call(random_world):
    a = kinds.judge(road("PBBPBPPBBPPB"), 20, 12, **CONFIG, tables=random_world[:200])
    b = kinds.judge(road("PBBPBPPBBPPB"), 20, 12, **CONFIG, tables=random_world[:200])
    assert a == b


# --- the settings --------------------------------------------------------------------------

def test_the_thresholds_come_from_setup_within_reason():
    assert kind_params({}) == {"on": True, "exceptional_at": 400.0, "regular_below": 150.0,
                               "whole_after": 12}
    assert kind_params({"kind_on": False, "kind_exceptional": "600", "kind_regular": "200",
                        "kind_after": "20"})["regular_below"] == 200.0
    for bad in ({"kind_exceptional": "100", "kind_regular": "150"}, {"kind_regular": "0"},
                {"kind_after": "2"}):
        with pytest.raises(ValueError):
            kind_params(bad)
    off = kinds.player_args([], {"strategy": "streak_or_chop_2"}, kind_params({"kind_on": False}))
    assert off["kind_judge"] is None


# --- live: judged once, followed, and checked when the table is over ---------------------

def bd(counts, game):
    return {"game": game, "player": counts["player"], "banker": counts["banker"],
            "tie": counts["tie"], "player_pair": 0, "banker_pair": 0}


def play(p, results, start_game=1, counts=None):
    counts = counts or {"player": 0, "banker": 0, "tie": 0}
    for i, w in enumerate(results):
        hand = sum(counts.values()) + 1
        p.current_bet = p.s.next_bet(hand=hand)
        counts[w] += 1
        p.record(start_game + i, w, [], bd(counts, start_game + i))
    return counts


def wait_for(cond, secs=10.0):
    end = time.monotonic() + secs
    while time.monotonic() < end and not cond():
        time.sleep(0.02)
    return cond()


def live_player(tables, rules=("majority=3,12",), **kw):
    params = dict(CONFIG, rules=list(rules))
    s = new_session(**params)
    judge = functools.partial(kinds.judge, **{**kinds.player_args(
        s.rules, params, kind_params(kw))["kind_judge"].keywords, "tables": tables})
    p = main.Player(s, road=None, kind_judge=judge, kind_after=12)
    p.snapshot = lambda *a, **k: None
    p.push = lambda: None
    return p


def settle_down(p):
    """Let a judgement that is under way finish before the next result lands."""
    assert wait_for(lambda: not p._kind_busy)


def play_one_by_one(p, results, start_game, counts):
    for i, w in enumerate(results):
        counts = play(p, [w], start_game=start_game + i, counts=counts)
        settle_down(p)
    return counts


def test_a_table_is_judged_when_its_window_fills_and_again_as_it_moves(site, signal_world, caplog):
    caplog.set_level(logging.INFO)
    p = live_player(signal_world)
    assert p.kind_every == 6, "half the window"
    p.open_table(bd({"player": 0, "banker": 0, "tie": 0}, 1))
    table = shaped("chop", random.Random(11))
    counts = play(p, table[:11])
    assert p.kind is None and p.kind_open == [], "11 results: no pattern yet"
    counts = play_one_by_one(p, table[11:30], 12, counts)
    hands = [c["k"]["hand"] for c in p.kind_open]
    assert hands == [12, 18, 24, 30], "judged at 12, then every 6 results"
    assert p.kind["hand"] == 30
    first = p.kind_open[0]["track"]
    assert first["results"] == 18 and p.kind_open[-1]["track"]["results"] == 0
    rep = p.kind_report()
    assert rep["now"]["hand"] == 30 and [h["hand"] for h in rep["history"]] == hands
    assert rep["track"] is first, "the card shows the table since the first call"
    counts = play(p, table[30:32], start_game=31, counts=counts)
    p.close_table("counters reset — new table")
    calls = tablecalls.load_calls()
    assert [c["hand"] for c in calls] == [12, 18, 24, 30], "every call checked"
    assert all(c["outcome"]["tier"] in tk.TIERS and not c["outcome"]["partial"] for c in calls)
    assert p.kind_calls["n"] == 4
    text = "\n".join(r.getMessage() for r in caplog.records)
    assert "Table kind at hand 12: " in text and "tables like it:" in text
    assert "Table kind: called" in text and "Calls so far" in text
    assert p.kind is None and p.kind_report()["now"] is None and p.kind_open == []


def test_an_ordinary_call_says_which_way_it_leans(signal_world):
    rng = random.Random(9)
    r = kinds.judge(shaped("chop", rng)[:20], 20, 12, **CONFIG, tables=signal_world[:200])
    assert r["lean"] in (None, "bad", "good")
    assert kinds.lean_of(
        [0.0, 0.4, 0.43, 0.17], [0.0, 0.44, 0.44, 0.12]) == "bad", "17% bad against 12%"
    assert kinds.lean_of([0.0, 0.44, 0.44, 0.12], [0.0, 0.44, 0.44, 0.12]) is None
    from baccarat.play.tablekind import call_text
    assert call_text({"call": "ordinary", "lean": "bad"}) == "ORDINARY, leaning bad"
    assert call_text({"call": "bad", "lean": "bad"}) == "BAD"


def lose_until(p, cond, start_game, counts, limit=20):
    """Every result goes against the bet: a losing run, as deep as it takes."""
    for i in range(limit):
        bet = p.s.next_bet(hand=sum(counts.values()) + 1)
        w = ("banker" if bet[0] == "player" else "player") if bet else "player"
        counts = play(p, [w], start_game=start_game + i, counts=counts)
        if cond():
            return counts, start_game + i + 1
    raise AssertionError("never got there")


def test_a_run_down_to_its_last_two_lives_makes_the_table_bad_at_once(site, signal_world, caplog):
    caplog.set_level(logging.INFO)
    p = live_player(signal_world)
    p.open_table(bd({"player": 0, "banker": 0, "tie": 0}, 1))
    counts = play(p, shaped("streak", random.Random(2))[:12])
    settle_down(p)
    assert p.kind_open
    counts, g = lose_until(p, lambda: (p.kind_table or {}).get("bad_at"), 13, counts)
    tb = p.kind_report()["table"]
    assert tb["bad_at"] and tb["lives_left"] <= 2
    assert p.kind_open[0]["track"]["bad_at"] == tb["bad_at"]
    assert "this table has turned BAD at hand" in "\n".join(r.getMessage() for r in caplog.records)
    p.close_table("stopped")                     # you stop it there …
    call = tablecalls.load_calls()[0]
    assert call["outcome"]["tier"] == "bad" and not call["outcome"]["partial"], \
        "… and it still counts: stopping can't undo a table that already went bad"
    assert tablecalls.calibration()["n"] == 1


def test_a_wrong_call_says_what_it_saw(site, signal_world, caplog):
    caplog.set_level(logging.INFO)
    p = live_player(signal_world)
    p.open_table(bd({"player": 0, "banker": 0, "tie": 0}, 1))
    counts = play(p, shaped("chop", random.Random(11))[:12])
    settle_down(p)
    c = p.kind_open[0]
    c["k"] = {**c["k"], "call": "good"}          # pretend it called it good …
    c["track"].update(profit=-500.0, deepest=8)  # … and the table went badly
    play(p, road("PB"), start_game=13, counts=counts)
    p.close_table("counters reset — new table")
    text = "\n".join(r.getMessage() for r in caplog.records)
    assert "it was BAD" in text and "the call was WRONG" in text
    assert "It was BAD:" in text and "closest:" in text
    assert tablecalls.calibration()["calls"]["good"] == {
        "n": 1, "right": 0, "tiers": {"exceptional": 0, "good": 0, "regular": 0, "bad": 1}}


def test_a_table_stopped_before_it_went_bad_is_kept_but_not_counted(site, signal_world):
    p = live_player(signal_world)
    p.open_table(bd({"player": 0, "banker": 0, "tie": 0}, 1))
    counts = play(p, shaped("streak", random.Random(2))[:12])
    settle_down(p)
    play(p, road("PPB"), start_game=13, counts=counts)
    p.close_table("stopped")
    out = tablecalls.load_calls()[0]["outcome"]
    assert out["partial"] is True or out["tier"] == "bad"
    if out["partial"]:
        assert tablecalls.calibration()["n"] == 0


def test_with_no_window_a_table_joined_late_is_not_judged(site, signal_world, caplog):
    caplog.set_level(logging.INFO)
    p = live_player(signal_world, rules=())
    assert p._kind_window == 0
    start = {"player": 10, "banker": 8, "tie": 2}
    p.open_table(bd(start, 21))
    play(p, road("PB" * 7), start_game=21, counts=dict(start))
    assert p.kind is None and not p._kind_busy
    assert "first 20 of its 32 results weren't seen" in \
        "\n".join(r.getMessage() for r in caplog.records)


def test_switched_off_it_does_nothing(site):
    s = new_session(**CONFIG)
    p = main.Player(s, road=None, kind_judge=None)
    p.push = lambda: None
    p.open_table(bd({"player": 0, "banker": 0, "tie": 0}, 1))
    play(p, road("PB" * 10))
    assert p.kind is None and p.kind_report() is None


def test_the_calls_are_in_the_copy_report(site, signal_world):
    p = live_player(signal_world)
    p.open_table(bd({"player": 0, "banker": 0, "tie": 0}, 1))
    counts = play(p, shaped("chop", random.Random(4))[:12])
    settle_down(p)
    play(p, road("PBPB"), start_game=13, counts=counts)
    state = {"kind": p.kind_report()}
    p.close_table("counters reset — new table")
    text = report.build(state, [], None)
    assert "--- table kinds ---" in text and "this table:" in text
    assert "→ called" in text and "→ was" in text


def test_no_new_judgement_past_the_last_hand_a_run_may_start(site, signal_world):
    """Late in a table every kind is 'regular' -- too few hands are left to be anything
    else -- so a call there says nothing. Past the cutoff it isn't made."""
    p = live_player(signal_world)
    p.s.table_hands, p.s.cutoff_margin = 30, 8
    p.s.cutoff_jitter = 0
    p.open_table(bd({"player": 0, "banker": 0, "tie": 0}, 1))
    p.s.cutoff_jitter = 0
    table = shaped("chop", random.Random(11))
    play_one_by_one(p, table[:30], 1, None)
    hands = [c["k"]["hand"] for c in p.kind_open]
    assert hands and max(hands) <= 22, hands
