"""The Copy report: pasted into a conversation, it has to say what is wrong (or that
nothing is) before anyone reads a log line -- and the evidence after."""
import time

from baccarat.store.settings import save_settings
from baccarat.web import report


def log(*rows):
    return [{"n": i, "level": lvl, "text": f"23:{i // 60:02d}:{i % 60:02d}  {lvl:<8}  {msg}"}
            for i, (lvl, msg) in enumerate(rows)]


BUST = {
    "status": "Lost everything — the watch couldn't finish", "budget": 10500.0, "base": 20,
    "settled": 751.0, "net": -9749.0, "timing": {"hard_score": False},
    "watch": {"text": "still losing"},
    "stats": {"max_drawdown": 10120, "max_bet": 5120, "max_losing_streak": 9},
    "session": {"started": time.time() - 3600, "hands": 240, "bets": 200, "peak": 10871},
    "runs": {"config": "streak_or_chop_2 + majority=3,11", "count": 3,
             "lives": {"1": 2, "9": 1}, "not_won": 1,
             "history": {"runs": 1699, "max_lives": 15,
                         "lives": {"1": 1690, "9": 3, "10": 2, "12": 1, "15": 1}}},
    "extra": {"bought": 4, "cost": 80, "saved": 0},
    "played": [{"name": "table_x", "started": "23:37", "ended": "23:48", "joined": 21,
                "rounds": 21, "bets": 20, "won": 6, "lost": 14, "net": -10165, "deepest": 9,
                "biggest": 5120, "reason": "stopped"}],
}


def section(text, title):
    part = text.split(f"--- {title}")[1]
    return part.split("\n--- ")[0]


def test_the_checks_come_first_and_say_what_is_wrong(site):
    text = report.build(BUST, log(("INFO", "Game 41 → bet 5,120 on BANKER")), 10)
    assert text.index("--- checks") < text.index("--- session") < text.index("--- log")
    c = section(text, "checks")
    assert "! The money ran out" in c
    assert "covers 9 lives (20 … 5,120)" in c and "needed up to 15 over 1,699 runs" in c
    assert "4 of them needed more than 9" in c
    assert "Trust the screen score is OFF" in c
    assert "bought 4 × 20 = 80, saves 0" in c


def test_a_quiet_session_says_so(site):
    calm = {"budget": 1000, "base": 20, "timing": {"hard_score": True}, "settled": 1040,
            "runs": {"config": "x", "history": {"runs": 50, "max_lives": 4, "lives": {"1": 49, "4": 1}}}}
    c = section(report.build(calm, [], 10), "checks")
    assert "!" not in c
    assert "ok the budget covers 5 lives" in c and "ok no refused bets" in c


def test_every_warning_of_the_session_is_there_not_just_the_tail(site):
    rows = [("WARNING", "Still on game 12 after 30 s — the table looks stuck")]
    rows += [("INFO", f"Game {i}: PLAYER") for i in range(400)]
    rows += [("WARNING", "Still on game 340 after 30 s — the table looks stuck"),
             ("ERROR", "the bar couldn't be read")]
    text = report.build({}, log(*rows), 50)
    w = section(text, "warnings and errors")
    assert "2× WARNING" in w and "Still on game 12 after 30 s" in w, "grouped, the first kept"
    assert "1× ERROR" in w
    assert "the last 50 of this session's 403 lines" in text
    assert "! The table looked stuck or slow 2 time(s)" in section(text, "checks")


def test_the_tables_and_the_session_in_lines(site):
    text = report.build(BUST, [], 10)
    assert "23:37–23:48 table_x · joined at #21 · 21 rounds · 20 bets (6W 14L) · net -10,165.00 · " \
           "deepest run 9" in section(text, "tables this session")
    s = section(text, "session")
    assert "budget 10,500.00 → balance 751.00" in s and "lives needed:count → 1:2 9:1" in s
    assert "all runs ever for 'streak_or_chop_2 + majority=3,11': 1,699, worst 15" in s


def test_the_settings_that_were_changed_are_picked_out(site):
    save_settings({"strategy": "streak_or_chop_2", "budget": "10,500", "base": 20, "hard_score": False})
    s = section(report.build({}, [], 10), "setup")
    changed = s.split("changed from the defaults: ")[1].split("\n")[0]
    assert '"budget":"10,500"' in changed and '"strategy":"streak_or_chop_2"' in changed
    assert '"base"' not in changed, "20 is the default"


def test_a_broken_part_never_stops_the_report(site, monkeypatch):
    monkeypatch.setattr(report, "session_lines", lambda s: 1 / 0)
    text = report.build(BUST, log(("INFO", "the last line")), 10)
    assert "couldn't put this part together" in text and "the last line" in text


def test_before_any_session_there_is_no_empty_session_block(site):
    text = report.build({"control": {}, "options": {}}, [], 10)
    assert "--- session ---" not in text and "--- checks" in text


def test_a_stop_in_the_middle_of_a_run_is_flagged():
    from baccarat.web import report
    s = {"stopped_with": {"side": "player", "amount": 80, "lost": 2, "lost_total": 60},
         "timing": {}, "runs": {}}
    out = report.checks(s, {}, [])
    assert any("Stopped in the middle of a run" in x and "80 on player" in x and "60" in x for x in out)


def test_a_table_is_closed_once():
    """A table opened and turned away used to close the previous table a second time."""
    from types import SimpleNamespace
    from baccarat.play.navigate import Navigating

    class T:
        name, path = "table_1", SimpleNamespace(name="table_1.json")

        def __init__(self):
            self.data, self.closed = {"rounds": []}, []

        def close(self, reason):
            self.data.update(ended="x", end_reason=reason)
            self.closed.append(reason)

    me = SimpleNamespace(table=T(), tables_played=[], settle_kind=lambda r: None,
                         refresh_estimate=lambda why: None)
    Navigating.close_table(me, "no room left for a new run")
    Navigating.close_table(me, "opened too late — no room")
    assert me.table.closed == ["no room left for a new run"] and len(me.tables_played) == 1
