"""Wiring that nothing else owns — main.py.

The score-check state machine and the road/counter agreement live in
`test_money_safety.py`; the pacing and the click budget live in
`test_timing.py`; the Setup form lives in `test_setup.py`. What is here is what
those do not cover: how the session answers a mismatch once it has found one,
how a typed road is read, and whether the modules beside main.py are the
versions it expects.
"""
import time

import pytest

import bet
import betting
import main
from baccarat.play import tuning
from analysis import new_session
from helpers import board, road as R


@pytest.fixture
def player(monkeypatch):
    """A session whose score is whatever the test says it is."""
    screen = [1000.0]
    monkeypatch.setattr(bet, "read_number_stable", lambda n, **k: screen[0])
    monkeypatch.setattr(bet, "read_number", lambda n: screen[0])
    # Every tunable is read through the tuning module rather than copied
    # into each one, so there is one place to override it -- here.
    monkeypatch.setattr(tuning, "SCORE_RECHECK", 0.0)
    main.STOP.clear()
    main.PAUSE.clear()

    def make(on_mismatch="carry_on", hard_score=True):
        p = main.Player(new_session(strategy="streak_or_chop_2", budget=1000.0,
                                    base=20, table_hands=40),
                        road=None, bet_window=6.0, click_speed=(0.1, 0.1),
                        bet_start_on="game", hard_score=hard_score,
                        on_mismatch=on_mismatch)
        p.score, p.table = 1000.0, None
        p.s.balance = 1000.0
        p.game_seen = time.monotonic()
        p.screen = screen
        return p

    yield make
    main.STOP.clear()
    main.PAUSE.clear()


def idle(p, ticks=4):
    """The gap between hands, where a slow settlement is seen arriving."""
    for _ in range(ticks):
        p.on_read(board(), 1.0)


def missing_stake(p):
    """Walk a session into the state where its stake never reached the table."""
    p.deducts = True
    p.score = 1000.0                  # whatever happened before, start from here
    p.current_bet = ("player", 20.0)
    p.screen[0] = 1000.0
    p.result_after("banker")          # -20, so it expects 980
    p.current_bet = ("banker", 40.0)  # this hand's bet
    p.stake_down = 40.0
    p.screen[0] = 980.0               # settled, but nothing of ours was taken
    idle(p)


class TestAnsweringAMismatch:
    """Finding money unaccounted for is covered elsewhere. What happens next is
    a choice the person made in Setup, and all three have to work."""

    def test_by_default_it_keeps_playing(self, player):
        p = player(on_mismatch="carry_on")
        missing_stake(p)
        assert p.mismatch is not None
        assert not main.STOP.is_set()
        assert not main.PAUSE.is_set()

    def test_it_can_be_asked_to_hold(self, player):
        p = player(on_mismatch="pause")
        missing_stake(p)
        assert main.PAUSE.is_set()
        assert not main.STOP.is_set()

    def test_it_can_be_asked_to_stop(self, player):
        p = player(on_mismatch="stop")
        missing_stake(p)
        assert main.STOP.is_set()

    def test_the_notice_carries_what_the_person_needs_to_decide(self, player):
        p = player()
        missing_stake(p)
        for key in ("id", "at", "doing", "count", "total"):
            assert key in p.mismatch

    def test_each_one_is_a_new_notice(self, player):
        p = player()
        missing_stake(p)
        first = p.mismatch["id"]
        missing_stake(p)
        assert p.mismatch["id"] != first


class TestTheCheckStaysOutOfTheWay:
    def test_a_score_that_already_agrees_closes_at_once(self, player):
        p = player()
        p.current_bet = ("player", 40.0)
        p.screen[0] = 960.0                      # 1000 - 40
        p.result_after("banker")
        assert p.score_check is None
        assert p.score == 960.0

    def test_the_stake_is_cleared_when_the_hand_ends(self, player):
        p = player()
        p.stake_down = 40.0
        p.current_bet = None
        p.result_after("player")
        assert p.stake_down == 0.0

    def test_with_the_score_turned_off_it_does_nothing_at_all(self, player):
        p = player(hard_score=False)
        p.current_bet = ("player", 40.0)
        assert p.result_after("banker") is None
        assert p.score_check is None
        assert p.stake_down == 0.0


class TestReadingATypedRoad:
    def test_letters_in_any_shape(self):
        assert main.parse_road("B P B") == R("BPB")
        assert main.parse_road("bpb") == R("BPB")
        assert main.parse_road("B,P,T") == R("BPT")

    def test_nothing_is_an_empty_road(self):
        assert main.parse_road("") == []

    def test_a_letter_that_is_not_a_result_is_refused(self):
        """Better than quietly dropping it: a typed road with a stray letter in
        it is a road the person got wrong, and silently playing a different one
        is worse than making them look."""
        with pytest.raises(ValueError):
            main.parse_road("B x P")


class TestTheFilesMatchEachOther:
    """Every module has to come from the same version. Copying one file and not
    its neighbour has cost two live debugging sessions.

    A package makes that much harder to do by accident, but not impossible --
    one module dragged across on its own still does it -- so the check stays,
    now naming the part of the package that is behind."""

    def test_a_complete_set_is_quiet(self):
        assert main.stale_files() == []

    def test_a_module_missing_what_main_needs_is_named(self, monkeypatch):
        monkeypatch.delattr(betting, "worst_bet")
        stale = main.stale_files()
        assert any("bets.py" in s and "worst_bet" in s for s in stale)

    def test_it_names_the_file_to_copy_not_just_the_symbol(self, monkeypatch):
        monkeypatch.delattr(betting, "worst_bet")
        assert stale_mentions_a_filename(main.stale_files())


def stale_mentions_a_filename(lines):
    """The message has to say WHERE, not just which name went missing: "it has no
    worst_bet" sends you looking through the whole program."""
    return all(line.startswith("baccarat/") for line in lines)


class TestTheSuiteItself:
    """A suite that only runs on the machine it was written on is not a source
    of truth. These guard the two ways that happened: importing helpers out of
    conftest, which only works under some of pytest's import modes, and reading
    a file by a path relative to wherever pytest was started."""

    def test_the_helpers_are_a_real_module(self):
        import helpers
        assert helpers.road("BP") == ["banker", "player"]

    def test_no_test_imports_its_helpers_from_conftest(self):
        """conftest is pytest's plugin file, not a library. Importing it works
        under --import-mode=prepend and fails under importlib."""
        import pathlib
        here = pathlib.Path(__file__).resolve().parent
        needle = "from " + "conftest" + " import"     # built so this file isn't a hit
        for f in sorted(here.glob("test_*.py")):
            assert needle not in f.read_text(), \
                f"{f.name} imports from conftest; import from helpers instead"

    def test_no_test_reads_a_source_file_by_a_bare_name(self):
        import pathlib
        import re
        here = pathlib.Path(__file__).resolve().parent
        bare = re.compile(r'Path\(\s*["\'](?:main|bet|betting|strategies|analysis)\.py')
        for f in sorted(here.glob("test_*.py")):
            assert not bare.search(f.read_text()), \
                f"{f.name} opens a source file relative to the current folder"

    def test_the_suite_never_touches_your_real_data_folder(self):
        """The bug: importing the package picked a site and wrote data/site.json,
        and a Player built without the `site` fixture read your runs.json -- both in
        the real data folder. So running the tests rewrote your site file, and a
        run history the tests didn't expect failed them. conftest points the whole
        suite at a scratch folder before anything is imported."""
        from baccarat.store import paths
        here = paths.data_dir().resolve()
        assert paths.PROJECT.resolve() not in (here, *here.parents), \
            f"the tests are using {here}, inside the project"


class TestTheReport:
    """What the Copy report buttons put on the clipboard: enough to look into a
    problem from the paste alone, readable anywhere."""

    def test_it_carries_the_version_the_state_and_the_log_without_colour_codes(self, site):
        from baccarat.web import report
        import baccarat
        state = {"status": "Watching game 14", "balance": 980.0, "settled": 1000.0,
                 "on_table": 20.0, "bet_notice": {"kind": "never", "trace": "1,000.00 ×3"}}
        lines = [{"text": f"\x1b[34mline {i}\x1b[0m"} for i in range(500)]
        text = report.build(state, lines, 300)
        assert baccarat.__version__ in text
        assert "Watching game 14" in text and "on the table 20.0" in text
        assert '"kind": "never"' in text and "×3" in text
        assert "line 499" in text and "line 199" not in text, "the last 300 lines only"
        assert "\x1b" not in text
        assert "STAKE_WATCH=" in text

    def test_it_can_carry_the_whole_log(self, site):
        from baccarat.web import report
        text = report.build({}, [{"text": f"line {i}"} for i in range(500)], None)
        assert "line 0\n" in text and "the last 500 of this session's 500" in text

    def test_starting_up_does_not_write_the_site_file(self, site):
        """The bug: picking the site on import wrote data/site.json every time the
        program was imported -- by the tests, by update.py checking its work -- so
        importing the bot was enough to change your data."""
        from baccarat.screen import sites
        from baccarat.store import paths
        sites.use_site("mine")
        f = paths.site_file()
        f.unlink()
        sites._start_site()
        assert not f.exists()
        assert sites.site_name() == "mine", "still picks the one that is there"
