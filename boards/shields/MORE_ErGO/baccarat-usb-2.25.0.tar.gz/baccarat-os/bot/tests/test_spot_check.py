"""'Trust the screen score' off: the screen is still looked at every 10 bets, to notice
bets that don't go on. It never corrects anything, and one odd read says nothing."""
import logging
from types import SimpleNamespace

from baccarat.play import money
from baccarat.play.money import MoneyWatch


class Me(MoneyWatch):
    def __init__(self, balance):
        self.s = SimpleNamespace(balance=balance)
        self.spot = {"looks": 0, "agreed": 0, "apart": 0, "base": None, "suspect": None,
                     "bets": 0, "last": None}
        self.hard_score = False
        self.pushed = 0
        self.bet_reason = ""

    def push(self):
        self.pushed += 1


def run(me, monkeypatch, screens, books_after_each):
    """One bet each: the screen reads screens[i] just before it; the books move by the step."""
    seq = iter(screens)
    monkeypatch.setattr(money.bet, "read_number", lambda name: next(seq))
    for step in books_after_each:
        me.look_at_score()
        me.s.balance += step


def test_the_screen_moving_with_the_books_is_quiet(monkeypatch, caplog):
    me = Me(1000)           # the budget typed may differ from the casino's balance (5,000)
    screens = [5000, 5020, 5040, 5060]
    run(me, monkeypatch, screens, [2] * 31)              # +20 every 10 bets, both sides
    assert me.spot["looks"] == 3 and me.spot["agreed"] == 3 and me.spot["apart"] == 0
    assert not [r for r in caplog.records if r.levelno >= logging.WARNING]


def test_bets_that_do_not_go_on_are_noticed_after_two_looks(monkeypatch, caplog):
    me = Me(1000)
    # the books win 20 every 10 bets; the screen never moves: nothing goes on
    run(me, monkeypatch, [5000, 5000, 5000], [2] * 10 + [0, 0])
    assert me.spot["apart"] == 1 and me.spot["last"] == -20
    assert any("check the casino's balance" in r.getMessage().lower() for r in caplog.records
               if r.levelno == logging.WARNING)
    assert me.s.balance == 1020                          # nothing corrected


def test_one_odd_read_is_not_a_warning(monkeypatch, caplog):
    me = Me(1000)
    run(me, monkeypatch, [5000, 5300, 5020], [2] * 10 + [0, 0])   # a misread, then right again
    assert me.spot["apart"] == 0 and me.spot["agreed"] == 1
    assert not [r for r in caplog.records if r.levelno >= logging.WARNING]


def test_an_unreadable_score_costs_nothing(monkeypatch):
    me = Me(1000)
    run(me, monkeypatch, [None] * 20, [2] * 20)
    assert me.spot["looks"] == 0 and me.spot["base"] is None
