"""The locked bot's configuration: what goes to the server, what comes back, and that
nothing else is touched or sent (the login, the bot's key, logs, screenshots)."""
import io
import json
import os
import tarfile

import pytest

from baccarat.web import configsync as cs
from baccarat.web import remote


@pytest.fixture
def data(tmp_path, monkeypatch):
    root = tmp_path / "data"
    for rel, text in {"site.json": '{"site": "winpot"}',
                      "sites/winpot/coords.json": '{"chip_20": {"x": 1, "y": 2}}',
                      "sites/winpot/settings.json": '{"base": 20}',
                      "sites/winpot/game.json": '{"url": "https://casino.example/live"}',
                      "sites/winpot/login.json": '{"email": "me@x.com", "password": "secret"}',
                      "tables/t1.json": "{}", "runs.json": "[]",
                      "logs/2026-11-03.log": "log", "debug/shot.png": "png",
                      "bot_id": "usb-123", "bot_key": "ab" * 32}.items():
        f = root / rel
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(text)
    monkeypatch.setattr(cs, "data_dir", lambda: root)
    return root


def names(blob):
    with tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz") as t:
        return sorted(t.getnames())


def test_what_is_sent_never_has_the_login_the_key_or_logs(data):
    got = names(cs.pack(data))
    assert got == ["runs.json", "site.json", "sites/winpot/coords.json", "sites/winpot/game.json",
                   "sites/winpot/settings.json", "tables/t1.json"]
    assert b"secret" not in cs.pack(data)


def test_unpack_replaces_the_configuration_and_keeps_this_bots_own(data, tmp_path):
    blob = cs.pack(data)
    (data / "sites/winpot/coords.json").write_text("{}")
    (data / "sites/old").mkdir()
    (data / "sites/old/coords.json").write_text("{}")
    assert cs.unpack(blob, data) == 6
    assert json.loads((data / "sites/winpot/coords.json").read_text())["chip_20"]["x"] == 1
    assert not (data / "sites/old").exists()              # the server's set-up, exactly
    assert (data / "bot_key").read_text() == "ab" * 32       # never replaced
    assert (data / "logs/2026-11-03.log").exists() and (data / "debug/shot.png").exists()
    assert oct(os.stat(data / "site.json").st_mode)[-3:] == "600"


def test_unpack_refuses_anything_outside_the_folder(data, tmp_path):
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as t:
        for name in ("../evil.txt", "/etc/evil", "sites/x/coords.json"):
            info = tarfile.TarInfo(name)
            info.size = 2
            t.addfile(info, io.BytesIO(b"{}"))
        link = tarfile.TarInfo("sites/x/link")
        link.type, link.linkname = tarfile.SYMTYPE, "/etc/passwd"
        t.addfile(link)
    assert cs.unpack(buf.getvalue(), data) == 1
    assert not (tmp_path / "evil.txt").exists()
    assert not (data / "sites/x/link").exists()


def test_fingerprints_split_setup_learnt_and_login(data):
    a = cs.fingerprints(data)
    (data / "tables/t2.json").write_text("{}")
    b = cs.fingerprints(data)
    assert a[0] == b[0] and a[1] != b[1] and a[2] == b[2]
    (data / "sites/winpot/login.json").write_text('{"email": "me@x.com", "password": "new"}')
    c = cs.fingerprints(data)
    assert c[0] == b[0] and c[2] != b[2]
    (data / "logs/2026-11-03.log").write_text("more log")      # never counts
    assert cs.fingerprints(data) == c


def test_logins_go_and_come_as_their_own_thing(data):
    assert cs.collect_logins(data) == {"winpot": {"email": "me@x.com", "password": "secret"}}
    (data / "sites/winpot/login.json").unlink()
    assert cs.write_logins(data, {"winpot": {"email": "me@x.com", "password": "secret"},
                                  "../evil": {"email": "x"}}) == 1
    f = data / "sites/winpot/login.json"
    assert json.loads(f.read_text())["password"] == "secret"
    assert oct(os.stat(f).st_mode)[-3:] == "600"


def test_signature_is_what_the_server_checks():
    key = "11" * 32
    sig = remote.signature(key, "GET", "/v1/login", "1700000000.000", b"")
    import hashlib
    import hmac
    msg = b"GET\n/v1/login\n1700000000.000\n" + hashlib.sha256(b"").hexdigest().encode()
    assert sig == hmac.new(bytes.fromhex(key), msg, hashlib.sha256).hexdigest()
    assert remote.code_of(key) == remote.code_of(key) and len(remote.code_of(key)) == 9


def test_a_key_file_of_any_content_becomes_a_key(tmp_path, monkeypatch):
    f = tmp_path / "bot-key"
    f.write_bytes(os.urandom(32))
    monkeypatch.setenv("BACCARAT_BOT_KEY_FILE", str(f))
    monkeypatch.delenv("CREDENTIALS_DIRECTORY", raising=False)
    k = remote.bot_key()
    assert len(k) == 64 and int(k, 16) >= 0
    f.write_text("cd" * 32)
    assert remote.bot_key() == "cd" * 32


def test_locked_comes_from_the_environment(monkeypatch):
    monkeypatch.delenv("BACCARAT_LOCKED", raising=False)
    assert not remote.locked()
    monkeypatch.setenv("BACCARAT_LOCKED", "1")
    assert remote.locked()
