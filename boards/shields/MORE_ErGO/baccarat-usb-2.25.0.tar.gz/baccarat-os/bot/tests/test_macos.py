"""The macOS backend, run against stand-ins for Quartz, Accessibility and AppKit.

The real frameworks only exist on a Mac. These stand-ins record every event the
backend posts and answer the way macOS does, so what is checked is the backend's own
logic: Retina pictures brought back to one pixel per unit, whatever byte order they
come in; ⌘R pressed and released in the right order; text typed as characters;
permissions asked for before they are needed; the game's window, not the
dashboard's, brought forward. Nothing here touches a real screen, on any system.
"""
import logging
import types

import numpy as np
import pytest

from baccarat.errors import BetError
from baccarat.screen import macos


class Pt:
    def __init__(self, x, y):
        self.x, self.y = x, y


class Rect:
    def __init__(self, x, y, w, h):
        self.origin, self.size = Pt(x, y), types.SimpleNamespace(width=w, height=h)


class FakeMac:
    """Quartz, ApplicationServices and AppKit, as far as the backend uses them."""

    def __init__(self, scale=2, screen_ok=True, input_ok=True, order="BGRA"):
        self.scale, self.screen_ok, self.input_ok, self.order = scale, screen_ok, input_ok, order
        self.pos = [500.0, 400.0]
        self.posted, self.asked, self.raised, self.activated = [], [], [], []
        self.windows = []
        self.colour = (10, 20, 30)               # B, G, R of every captured pixel
        self.quartz_works = True
        Q = types.ModuleType("Quartz")
        for k, v in dict(kCGEventMouseMoved=5, kCGEventLeftMouseDown=1, kCGEventLeftMouseUp=2,
                         kCGEventRightMouseDown=3, kCGEventRightMouseUp=4, kCGMouseButtonLeft=0,
                         kCGMouseButtonRight=1, kCGHIDEventTap=0, kCGMouseEventClickState=1,
                         kCGEventFlagMaskCommand=1 << 20, kCGEventFlagMaskShift=1 << 17,
                         kCGEventFlagMaskAlternate=1 << 19, kCGEventFlagMaskControl=1 << 18,
                         kCGWindowListOptionOnScreenOnly=1, kCGWindowListExcludeDesktopElements=16,
                         kCGNullWindowID=0, kCGWindowImageDefault=0, kCGBitmapByteOrderMask=0x7000,
                         kCGBitmapByteOrder32Little=0x2000, kCGBitmapByteOrder32Big=0x4000,
                         kCGImageAlphaPremultipliedFirst=2, kCGImageAlphaFirst=4,
                         kCGImageAlphaNoneSkipFirst=6, kCGImageAlphaPremultipliedLast=1,
                         CGRectInfinite="infinite").items():
            setattr(Q, k, v)
        Q.CGEventCreate = lambda src: "now"
        Q.CGEventGetLocation = lambda ev: Pt(*self.pos)
        Q.CGEventCreateMouseEvent = lambda src, kind, pos, btn: {"kind": kind, "pos": tuple(pos), "btn": btn}
        Q.CGEventSetIntegerValueField = lambda ev, f, v: ev.__setitem__("clicks", v)
        Q.CGEventCreateKeyboardEvent = lambda src, code, down: {"key": code, "down": down}
        Q.CGEventSetFlags = lambda ev, flags: ev.__setitem__("flags", flags)
        Q.CGEventKeyboardSetUnicodeString = lambda ev, n, s: ev.update(text=s, units=n)
        Q.CGEventPost = self.post
        Q.CGRectMake = lambda x, y, w, h: (x, y, w, h)
        Q.CGWindowListCreateImage = self.image
        Q.CGImageGetWidth = lambda r: r["w"]
        Q.CGImageGetHeight = lambda r: r["h"]
        Q.CGImageGetBytesPerRow = lambda r: r["bpr"]
        Q.CGImageGetBitsPerPixel = lambda r: 32
        Q.CGImageGetBitmapInfo = lambda r: r["info"]
        Q.CGImageGetAlphaInfo = lambda r: r["alpha"]
        Q.CGImageGetDataProvider = lambda r: r
        Q.CGDataProviderCopyData = lambda r: r["data"]
        Q.CGPreflightScreenCaptureAccess = lambda: self.screen_ok
        Q.CGRequestScreenCaptureAccess = lambda: self.asked.append("screen")
        Q.CGWindowListCopyWindowInfo = lambda opts, wid: list(self.windows)
        Q.CGMainDisplayID = lambda: 1
        Q.CGGetActiveDisplayList = lambda n, a, b: (0, [1], 1)
        Q.CGDisplayBounds = lambda d: Rect(0, 0, 2560, 1440)
        Q.CGDisplayCopyDisplayMode = lambda d: "mode"
        Q.CGDisplayModeGetPixelWidth = lambda m: int(2560 * self.scale)
        AX = types.ModuleType("ApplicationServices")
        for k in ("kAXWindowsAttribute", "kAXTitleAttribute", "kAXPositionAttribute",
                  "kAXSizeAttribute", "kAXMainAttribute", "kAXRaiseAction",
                  "kAXTrustedCheckOptionPrompt"):
            setattr(AX, k, k)
        AX.AXIsProcessTrusted = lambda: self.input_ok
        AX.AXIsProcessTrustedWithOptions = lambda o: self.asked.append("input")
        AX.AXUIElementCreateApplication = lambda pid: {"pid": pid}
        AX.AXUIElementCopyAttributeValue = self.ax_get
        AX.AXUIElementPerformAction = lambda el, act: self.raised.append(el["title"])
        AX.AXUIElementSetAttributeValue = lambda el, a, v: None
        AK = types.ModuleType("AppKit")
        AK.NSApplicationActivateIgnoringOtherApps = 2
        fake = self

        class App:
            def __init__(self, pid):
                self.pid = pid

            def activateWithOptions_(self, opts):
                fake.activated.append(self.pid)

        AK.NSRunningApplication = types.SimpleNamespace(
            runningApplicationWithProcessIdentifier_=lambda pid: App(pid))
        self.modules = {"Quartz": Q, "ApplicationServices": AX, "AppKit": AK}

    def post(self, tap, ev):
        self.posted.append(dict(ev))
        if ev.get("kind") == 5:
            self.pos = list(ev["pos"])

    def ax_get(self, el, attr, _):
        if attr == "kAXWindowsAttribute":
            return 0, [{"title": w["kCGWindowName"]} for w in self.windows
                       if w["kCGWindowOwnerPID"] == el["pid"]]
        if attr == "kAXTitleAttribute":
            return 0, el["title"]
        return 1, None

    def image(self, rect, *a):
        if not self.quartz_works:
            return None
        x, y, w, h = rect
        W, H = int(w * self.scale), int(h * self.scale)
        b, g, r = self.colour
        px = {"BGRA": (b, g, r, 255), "RGBA": (r, g, b, 255)}[self.order]
        bpr = W * 4 + 16                         # rows are padded, as on a real Mac
        rows = (bytes(px) * W + bytes(16)) * H
        info = 0x2000 if self.order == "BGRA" else 0x4000
        alpha = 2 if self.order == "BGRA" else 1
        return {"w": W, "h": H, "bpr": bpr, "info": info, "alpha": alpha, "data": rows}


@pytest.fixture
def mac(monkeypatch):
    m = FakeMac()
    monkeypatch.setattr(macos, "_MODULES", dict(m.modules))
    for flag in ("_SCREEN_OK", "_INPUT_OK", "_SAID_SCALE", "_USE_SCREENCAPTURE"):
        monkeypatch.setattr(macos, flag, False)
    monkeypatch.setattr(macos.time, "sleep", lambda s: None)
    return m


# --- pictures -----------------------------------------------------------------------

def test_a_retina_picture_comes_back_at_one_pixel_per_unit(mac):
    img = macos.capture_region(100, 200, 40, 10)
    assert img.shape == (10, 40, 3), "the 80×20 Retina picture, read at 40×10"
    assert tuple(img[5, 20]) == (10, 20, 30)


def test_the_byte_order_is_read_from_the_picture_not_assumed(mac):
    mac.order = "RGBA"
    assert tuple(macos.capture_region(0, 0, 8, 4)[2, 3]) == (10, 20, 30)


def test_a_normal_screen_is_left_as_it_is(mac):
    mac.scale = 1
    assert macos.capture_region(0, 0, 30, 6).shape == (6, 30, 3)


def test_without_screen_recording_it_says_what_to_turn_on(mac):
    mac.screen_ok = False
    with pytest.raises(BetError, match="Screen Recording"):
        macos.capture_region(0, 0, 10, 10)
    assert mac.asked == ["screen"], "and the system's own prompt is shown"


def test_where_quartz_gives_no_pictures_screencapture_takes_over(mac, monkeypatch):
    mac.quartz_works = False
    calls = []
    monkeypatch.setattr(macos, "_screencapture",
                        lambda x, y, w, h: calls.append((x, y, w, h)) or np.zeros((h * 2, w * 2, 3), np.uint8))
    assert macos.capture_region(5, 6, 20, 10).shape == (10, 20, 3)
    macos.capture_region(5, 6, 20, 10)
    assert len(calls) == 2 and macos._USE_SCREENCAPTURE, "and Quartz isn't asked again"


def test_the_whole_screen_is_every_display_together(mac):
    assert macos.capture_screen().shape == (1440, 2560, 3)


# --- the pointer ---------------------------------------------------------------------

def test_the_pointer_moves_by_posting_a_move(mac):
    macos.move_cursor(321, 123)
    assert mac.posted[-1] == {"kind": 5, "pos": (321.0, 123.0), "btn": 0}
    assert macos.get_cursor_pos() == (321, 123)


def test_a_click_is_pressed_and_released_where_the_pointer_is(mac):
    mac.pos = [700.0, 300.0]
    assert macos.mouse_button(True) and macos.mouse_button(False)
    down, up = mac.posted
    assert (down["kind"], up["kind"]) == (1, 2)
    assert down["pos"] == (700.0, 300.0) and down["clicks"] == 1
    macos.mouse_button(True, "right")
    assert mac.posted[-1]["kind"] == 3 and mac.posted[-1]["btn"] == 1


def test_without_accessibility_it_says_what_to_turn_on(mac):
    mac.input_ok = False
    with pytest.raises(BetError, match="Accessibility"):
        macos.ensure_input()
    assert mac.asked == ["input"]


# --- the keyboard --------------------------------------------------------------------

def test_reload_is_command_r_held_and_released_in_order(mac):
    assert macos.RELOAD_KEY == "cmd+r"
    assert macos.press_key("cmd+r")
    cmd = 1 << 20
    assert [(e["key"], e["down"], e["flags"]) for e in mac.posted] == \
        [(55, True, cmd), (15, True, cmd), (15, False, cmd), (55, False, 0)]


def test_the_keys_the_bot_uses_are_all_known(mac):
    for k in ("Return", "Tab", "Down", "Up", "F5", "cmd+r"):
        assert macos.press_key(k), k
    assert not macos.press_key("hyper+q"), "an unknown key is refused, not guessed"


def test_text_is_typed_as_characters_and_never_logged(mac, caplog):
    caplog.set_level(logging.DEBUG)
    secret = "añ@é🙂"
    assert macos.type_private(secret, "typing the password")
    typed = [e for e in mac.posted if e["down"]]
    assert "".join(e["text"] for e in typed) == secret
    assert typed[-1]["units"] == 2, "an emoji is two UTF-16 units"
    assert all(e["flags"] == 0 for e in mac.posted), "no stuck modifier changes the text"
    assert secret not in caplog.text and "añ" not in caplog.text


# --- focus ---------------------------------------------------------------------------

def test_the_window_under_the_point_is_brought_forward_not_the_dashboard(mac):
    """The dashboard and the game in the same browser: activating the browser alone
    could leave the dashboard in front and send ⌘R to it."""
    mac.windows = [
        {"kCGWindowLayer": 25, "kCGWindowBounds": {"X": 0, "Y": 0, "Width": 3000, "Height": 30},
         "kCGWindowOwnerPID": 9, "kCGWindowOwnerName": "Menu", "kCGWindowName": "menu bar"},
        {"kCGWindowLayer": 0, "kCGWindowBounds": {"X": 0, "Y": 0, "Width": 800, "Height": 900},
         "kCGWindowOwnerPID": 100, "kCGWindowOwnerName": "Firefox", "kCGWindowName": "Baccarat control"},
        {"kCGWindowLayer": 0, "kCGWindowBounds": {"X": 800, "Y": 0, "Width": 1700, "Height": 1400},
         "kCGWindowOwnerPID": 100, "kCGWindowOwnerName": "Firefox", "kCGWindowName": "Casino — Live"},
    ]
    macos.focus_point(1200, 20)
    assert mac.activated == [100]
    assert mac.raised == ["Casino — Live"]


def test_nothing_under_the_point_nothing_is_focused(mac):
    macos.focus_point(10, 10)
    assert mac.activated == [] and mac.raised == []


# --- choosing a box --------------------------------------------------------------------

def test_a_box_comes_back_from_the_overlay(mac, monkeypatch):
    replies = iter([types.SimpleNamespace(returncode=0, stdout="100,200 300x40\n", stderr=""),
                    types.SimpleNamespace(returncode=1, stdout="", stderr=""),
                    types.SimpleNamespace(returncode=2, stdout="", stderr="no tk")])
    monkeypatch.setattr(macos.subprocess, "run", lambda *a, **k: next(replies))
    assert macos.select_region() == "100,200 300x40"
    with pytest.raises(BetError, match="nothing was selected"):
        macos.select_region()
    with pytest.raises(BetError, match="Tk"):
        macos.select_region()


# --- the CPU meter -----------------------------------------------------------------------

def test_the_meter_knows_mac_browsers_and_the_window_server(monkeypatch):
    from baccarat.play.loadmeter import GROUPS
    procs = [(1, "WindowServer"), (2, "Google Chrome"), (3, "Google Chrome Helper (Renderer)"),
             (4, "com.apple.WebKit.WebContent"), (5, "Safari"), (6, "Finder")]
    fake = types.SimpleNamespace(process_iter=lambda attrs: [
        types.SimpleNamespace(info={"pid": p, "name": n}) for p, n in procs])
    monkeypatch.setattr(macos, "_psutil", lambda: fake)
    assert macos.find_pids(GROUPS) == {"compositor": [1], "browser": [2, 3, 4, 5]}


# --- through the doorway -----------------------------------------------------------------

def test_the_rest_of_the_bot_reaches_the_mac_only_through_desktop(mac, monkeypatch):
    from baccarat.screen import desktop
    monkeypatch.setattr(desktop, "backend", macos)
    assert desktop.capture_region("10,20 40x10").shape == (10, 40, 3)
    with pytest.raises(BetError, match="doesn't look like a region"):
        desktop.capture_region("forty by ten")


# --- the doctor ---------------------------------------------------------------------------

def _doctor(mac, monkeypatch, capsys):
    import sys
    for name, mod in mac.modules.items():
        monkeypatch.setitem(sys.modules, name, mod)
    monkeypatch.setattr(macos.platform, "mac_ver", lambda: ("12.6.6", ("", "", ""), "x86_64"))
    macos.doctor()
    return capsys.readouterr().out


def test_the_doctor_checks_everything_and_says_it_works(mac, monkeypatch, capsys, site):
    out = _doctor(mac, monkeypatch, capsys)
    assert "macOS                    12.6.6" in out
    assert "scale 2" in out, "a Retina screen is recognised"
    assert "Screen Recording         allowed" in out and "Accessibility            allowed" in out
    assert "a 300×120 box            600×240 px → read at 300×120" in out
    assert "moved 40 to the right" in out and "ok" in out
    assert "looks real               NO" in out, "the stand-in's picture is one flat colour"


def test_the_doctor_names_each_missing_permission(mac, monkeypatch, capsys, site):
    mac.screen_ok, mac.input_ok = False, False
    out = _doctor(mac, monkeypatch, capsys)
    assert "Screen Recording         NOT ALLOWED" in out and "Accessibility            NOT ALLOWED" in out
    assert "To fix:" in out
    assert "System Preferences › Security & Privacy › Privacy › Screen Recording" in out, \
        "Monterey's menus, not Ventura's"
