"""The Budget read off the casino's balance; a wrong reading teaches the score's digits."""
from types import SimpleNamespace

import pytest

from baccarat import screen as bet
from baccarat.web.routes_setup import SetupRoutes


@pytest.fixture
def me(monkeypatch):
    taught = []
    monkeypatch.setattr(bet, "region_list", lambda: [{"name": "score"}])
    monkeypatch.setattr(bet, "number_frame", lambda name: {
        "frame": "PIXELS", "shot": SimpleNamespace(name="score_1.png"),
        "texts": {"number": "10,560.00"}, "note": "", "format": {"example": "1,250.50"}})
    monkeypatch.setattr(bet, "teach_number_from",
                        lambda name, img, typed: taught.append((name, img, typed)) or {"kept": 3, "problems": []})
    return SimpleNamespace(running=False, frames={}, taught=taught)


def test_read_then_use_as_read_teaches_nothing(me):
    d = SetupRoutes.budget_from_screen(me, {"action": "read"})
    assert d["text"] == "10,560.00" and d["value"] == 10560 and d["shot"] == "score_1.png"
    u = SetupRoutes.budget_from_screen(me, {"action": "use", "text": "10,560.00"})
    assert u["value"] == 10560 and u["taught"] == 0 and me.taught == []


def test_a_corrected_reading_teaches_from_the_same_picture(me):
    SetupRoutes.budget_from_screen(me, {"action": "read"})
    u = SetupRoutes.budget_from_screen(me, {"action": "use", "text": "10,500.00"})
    assert u["value"] == 10500 and u["taught"] == 3
    assert me.taught == [("score", "PIXELS", "10,500.00")]


def test_not_during_a_session_and_not_without_the_region(me, monkeypatch):
    me.running = True
    with pytest.raises(ValueError):
        SetupRoutes.budget_from_screen(me, {"action": "read"})
    me.running = False
    monkeypatch.setattr(bet, "region_list", lambda: [])
    with pytest.raises(ValueError, match="score"):
        SetupRoutes.budget_from_screen(me, {"action": "read"})


@pytest.mark.parametrize("shown,value", [("$10,752.96", 10752.96), ("10,752.96 $", 10752.96),
                                         (" $ 10,752.96 ", 10752.96), ("#1,250.50", 1250.5),
                                         ("10,752.96", 10752.96), ("$", None), ("", None)])
def test_the_currency_sign_does_not_count(shown, value):
    from baccarat.screen.numbers import parse_shown
    fmt = {"decimal": ".", "thousands": ",", "decimals": 2}
    assert parse_shown(shown, fmt) == value


def test_a_balance_shown_with_a_dollar_sign(me, monkeypatch):
    """It read '$10,752.96': Use it takes it as it is (2.23.1 refused it: 'isn't a number')."""
    monkeypatch.setattr(bet, "number_frame", lambda name: {
        "frame": "PIXELS", "shot": None, "texts": {"number": "$10,752.96"}, "note": "",
        "format": {"example": "$1,250.50"}})
    d = SetupRoutes.budget_from_screen(me, {"action": "read"})
    assert d["value"] == 10752.96
    assert SetupRoutes.budget_from_screen(me, {"action": "use", "text": "$10,752.96"})["value"] == 10752.96
    assert SetupRoutes.budget_from_screen(me, {"action": "use", "text": "10,752.96"})["taught"] == 0
    assert me.taught == []                                     # same number: nothing to learn
    u = SetupRoutes.budget_from_screen(me, {"action": "use", "text": "10,762.96"})
    assert u["value"] == 10762.96
    assert me.taught == [("score", "PIXELS", "$10,762.96")]   # the $ is in the picture too
