"""Extra life, the way it was asked for. With base 20:

    always on: one first loss bought (20 goes on again instead of 40), then the next
    two double as usual, then one bought … -- one in 3;
    once a run reaches life 6 (the 640 bet) it goes STRICT: one in 2;
    every run that reaches life 6 again keeps it strict and starts the count over;
    20 losses with none put it back to one in 3.
"""
import pytest

from baccarat.setup import session_params
from baccarat.study.replay import new_session


def session(every=3, strict=2, after=3, losses=6, budget=10000):
    s = new_session("streak_or_chop_2", budget, 20, extra_every=every, extra_strict=strict,
                    extra_after=after, extra_for=losses)
    s.new_table(["player", "player"])
    return s


def bet(s, win: bool):
    """Play one hand the strategy bets on, won or lost as asked."""
    b = s.next_bet()
    assert b, "the strategy should bet here"
    side, amount = b
    w = side if win else ("banker" if side == "player" else "player")
    r = s.record(w, b)
    return amount, r


def deep_run(s, life):
    """A run that loses until it has placed life `life`, then wins: → the stakes."""
    out = []
    while True:
        a, _ = bet(s, s.staking.step == life - 1 and not s.extra_held)
        out.append(a)
        if s.run_bets == 0:
            return out


def first_losses(s, n):
    """n runs of: the first bet loses, the next wins. → the second stake of each."""
    seconds = []
    for _ in range(n):
        bet(s, False)
        seconds.append(bet(s, True)[0])
    return seconds


def test_off_by_default_nothing_changes():
    s = new_session("streak_or_chop_2", 10000, 20)
    s.new_table(["player", "player"])
    assert [bet(s, False)[0] for _ in range(4)] == [20, 40, 80, 160]
    assert s.extra_rhythm == 0


def test_always_on_one_in_three():
    s = session(every=3, after=8, losses=100)
    assert first_losses(s, 7) == [40, 40, 20, 40, 40, 20, 40], "normal, normal, bought …"
    assert s.extra_bought == 2 and not s.extra_active


def test_it_waits_for_its_turn_before_buying_anything():
    """1 in 3: a session doesn't buy a life on its first loss -- the first two first
    losses double as usual, the third is bought."""
    s = session(every=3)
    assert s.extra_until == 3 and not s.extra_buy_next
    assert first_losses(s, 2) == [40, 40] and s.extra_bought == 0
    assert s.extra_until == 1 and s.extra_buy_next
    assert first_losses(s, 1) == [20] and s.extra_bought == 1


def test_a_bought_first_loss_puts_the_base_bet_on_again_then_it_doubles():
    s = session(every=1)
    a, r = bet(s, False)                         # 1 in 1: every first loss is bought
    assert (a, r.outcome) == (20, "LOSS")
    assert s.extra_held and s.in_run and s.extra_bought == 1 and s.extra_cost == 20
    assert [bet(s, False)[0] for _ in range(3)] == [20, 40, 80]
    assert not s.extra_held


def test_life_6_is_the_640_bet_and_that_makes_it_strict():
    s = session(every=3, strict=2, after=6, losses=20, budget=100000)
    first_losses(s, 1)                           # use up the first bought one: 1 of 3 seen
    stakes = deep_run(s, 6)
    assert stakes[-1] == 640 and s.extra_active and s.extra_rhythm == 2
    assert any("reached life 6 (the 640 bet)" in e for e in s.events)
    assert first_losses(s, 4) == [20, 40, 20, 40], "strict: bought, normal, bought, normal"


def test_reaching_the_life_again_keeps_it_strict_and_starts_the_count_over():
    s = session(after=3, losses=10)
    deep_run(s, 3)
    assert s.extra_active
    first_losses(s, 3)
    assert s.extra_quiet == 3
    deep_run(s, 3)
    assert s.extra_active and s.extra_quiet == 0
    assert any("starts over" in e for e in s.events)


def test_losses_without_reaching_the_life_put_it_back_to_the_usual_rhythm():
    s = session(every=3, strict=2, after=3, losses=4)
    deep_run(s, 3)
    assert s.extra_active
    first_losses(s, 4)                           # four losses, none of them deep
    assert not s.extra_active and s.extra_rhythm == 3
    assert first_losses(s, 3) == [40, 40, 20], "the usual rhythm again: two as usual, then bought"


def test_a_deep_runs_own_losses_don_t_count():
    s = session(after=3, losses=2)
    deep_run(s, 3)
    deep_run(s, 6)                               # past life 3: its losses don't count
    assert s.extra_active and s.extra_quiet == 0


def test_the_run_it_buys_for_is_one_run_not_two():
    s = session()
    n = len(s.runs)
    bet(s, False)                                # bought
    bet(s, False)                                # 20 → now 40
    bet(s, True)
    assert len(s.runs) == n + 1 and s.runs[-1] == {**s.runs[-1], "lives": 3, "won": True}


def test_setup_turns_it_on_and_checks_it():
    base = {"strategy": "streak_or_chop_2", "budget": "10000", "base": "20"}
    assert session_params(base)["extra_every"] == 0, "unticked: off"
    p = session_params({**base, "extra_on": True})
    assert (p["extra_every"], p["extra_strict"], p["extra_after"], p["extra_for"]) == (3, 2, 6, 20)
    for bad in ({"extra_every": "0"}, {"extra_strict": "4"}, {"extra_after": "1"},
                {"extra_for": "0"}, {"extra_after": "6", "max_steps": "5"}):
        with pytest.raises(ValueError):
            session_params({**base, "extra_on": True, **bad})


# --- the bets to come, until a win ---------------------------------------------------

def test_the_bets_to_come_until_the_money_runs_out():
    s = new_session("streak_or_chop_2", 1000, 20)
    s.new_table(["player", "player"])
    a = s.ladder_ahead()
    assert a == {"stakes": [20, 40, 80, 160, 320], "bought": None, "then": "out"}
    bet(s, False), bet(s, False)                 # 20, 40 lost
    assert s.ladder_ahead(80)["stakes"] == [80, 160, 320], "from the bet on the table"


def test_the_bets_to_come_show_the_extra_life_it_would_buy():
    s = session(every=1, budget=1000)
    a = s.ladder_ahead()
    assert a["stakes"][:4] == [20, 20, 40, 80] and a["bought"] == 1
    bet(s, False)                                # bought: 20 again …
    a = s.ladder_ahead()
    assert a["stakes"][:3] == [20, 40, 80] and a["bought"] is None


def test_the_bets_to_come_stop_at_the_doubling_limit():
    s = new_session("streak_or_chop_2", 100000, 20, max_steps=3)
    s.new_table(["player", "player"])
    assert s.ladder_ahead() == {"stakes": [20, 40, 80], "bought": None, "then": "limit"}


def test_a_run_that_wins_only_because_of_it_is_a_save():
    """The balance pays for 3 bets (20, 40, 80). With the first loss bought, a run of
    four -- 20 lost, then 20, 40, 80 -- still wins; without it, the fourth bet would
    have needed 160 that wasn't there. (The four bets cost 160: the budget is that.)"""
    s = session(every=1, budget=160)
    for _ in range(3):
        bet(s, False)                            # 20 (bought), 20, 40 lost …
    a, r = bet(s, True)                          # … and 80 wins
    assert a == 80 and r.outcome == "WIN"
    assert len(s.extra_saves) == 1 and s.extra_finished == 1
    save = s.extra_saves[0]
    assert (save["lives"], save["cover"], save["at_risk"]) == (4, 3, 140)
    assert any("SAVED" in e for e in s.events)


def test_a_bought_run_that_wins_early_is_not_a_save():
    s = session(every=1, budget=150)
    bet(s, False)                                # bought
    bet(s, True)                                 # won straight after: no save, it cost 20
    assert s.extra_saves == [] and s.extra_finished == 1 and s.extra_cost == 20


# --- resetting what a configuration has needed ------------------------------------------

def test_the_run_history_of_one_configuration_can_be_reset(site):
    from baccarat.store import history, paths
    history.note_run("streak_or_chop_2 + majority=3,11", 15, True, mode="live")
    history.note_run("all_downs", 4, True, mode="live")
    assert history.run_history("streak_or_chop_2 + majority=3,11")["max_lives"] == 15
    gone = history.reset_runs("streak_or_chop_2 + majority=3,11")
    assert gone["max_lives"] == 15
    assert history.run_history("streak_or_chop_2 + majority=3,11")["runs"] == 0
    assert history.run_history("all_downs")["runs"] == 1, "the others are left alone"
    kept = list(paths.attic_dir().glob("runs-reset-*.json"))
    assert len(kept) == 1 and '"max_lives": 15' in kept[0].read_text()
    assert history.reset_runs("nothing like it") == {}


def test_the_page_resets_it_and_the_running_session_forgets_too(site):
    import types
    from baccarat.store import history
    from baccarat.web.routes_study import StudyRoutes
    history.note_run("streak_or_chop_2", 12, True, mode="live")
    pushed = []
    player = types.SimpleNamespace(s=types.SimpleNamespace(config="streak_or_chop_2"),
                                   run_stats={"max_lives": 12}, push=lambda: pushed.append(1))
    me = types.SimpleNamespace(player=player)
    r = StudyRoutes.history(me, {"strategy": "streak_or_chop_2", "rules": [], "action": "reset"})
    assert r["result"]["runs"] == 0 and player.run_stats["max_lives"] == 0 and pushed


def test_a_bought_run_that_reaches_the_set_life_and_wins_is_a_save():
    """Set for life 6: a bought run that goes 20 (bought), 20, 40, 80, 160 and wins on 320
    reached life 6 betting 320 where it would have bet 640 — that is a save."""
    s = session(every=1, after=6, budget=10000)
    for _ in range(5):
        bet(s, False)
    a, r = bet(s, True)
    assert a == 320 and r.outcome == "WIN"
    save = s.extra_saves[-1]
    assert (save["lives"], save["biggest"], save["instead"], save["busted_without"]) == (6, 320, 640, False)
    assert save["at_risk"] == 620                 # 20 + 40 + 80 + 160 + 320 not doubled
    assert any("extra life saved" in e for e in s.events)


def test_a_bought_run_that_wins_before_the_set_life_is_not_a_save():
    s = session(every=1, after=6, budget=10000)
    for _ in range(4):
        bet(s, False)
    bet(s, True)                                  # won on bet 5: not deep enough
    assert s.extra_saves == []


def test_a_run_won_only_while_watching_after_the_money_ran_out_is_no_save():
    """The 2.23.2 report: the money ran out on bet 10; the run "won" on bet 11 while the
    bot only watched (nothing staked). That was no save -- the session was lost."""
    s = session(every=1, budget=140)             # pays for 20 (bought), 20, 40 -- then out
    s.watch_after_bust = True                    # as the live bot does
    for _ in range(3):
        bet(s, False)
    assert s.next_bet() is None and s.busted and s.watching
    side = s.virtual_bet[0]
    s.record(side, None)                          # the watched bet "wins": nothing staked
    assert s.watch_over and s.extra_finished == 1
    assert s.extra_saves == []
    assert not any("SAVED" in e for e in s.events)
