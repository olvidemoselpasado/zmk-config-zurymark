"""The score's digits: a digit never taught must not come out as some other digit, and
the bot learns the missing ones from balances it knows for certain."""
import shutil
import tempfile
import unittest
from pathlib import Path

import bet
from baccarat.store import paths
from baccarat.screen.glyphs import read_number_detailed
from baccarat.screen.numbers import format_number
from test_reading import text_image


class ScoreLessons(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        paths.use_data_dir(self.dir)
        bet.use_site("test")
        got = bet.teach_number_from("score", text_image("10,522.96"), "10,522.96")
        assert got["kept"], got

    def tearDown(self):
        paths.use_data_dir(None)
        shutil.rmtree(self.dir, ignore_errors=True)

    def read(self, text):
        return read_number_detailed("score", text_image(text))["value"]

    def test_the_digits_never_taught(self):
        self.assertEqual(bet.missing_digits("score"), "3478")

    def test_an_untaught_digit_reads_as_nothing_never_as_another(self):
        # (with the old rule 10,533.96 came out as 10,555.96: a 3 it had never seen, read as a 5)
        for text, right in (("10,558.96", 10558.96), ("10,493.96", 10493.96), ("17,522.96", 17522.96),
                            ("10,533.96", 10533.96)):
            v = self.read(text)
            self.assertIn(v, (None, right), f"{text} read as {v}")

    def test_it_learns_a_missing_digit_from_a_balance_it_knows(self):
        img = text_image("10,558.96")
        self.assertEqual(bet.learn_from_known("score", "10,558.96", img), "8")
        self.assertEqual(self.read("10,558.96"), 10558.96)
        self.assertEqual(bet.missing_digits("score"), "347")

    def test_it_learns_nothing_when_the_known_digits_disagree(self):
        # the books say 10,558.96 but the screen shows 10,552.96: the 2 is a digit it
        # knows, plainly not an 8 -- the books are off, so nothing is learnt
        self.assertEqual(bet.learn_from_known("score", "10,558.96", text_image("10,552.96")), "")
        # … and when a known digit is somewhere else than the books say
        self.assertEqual(bet.learn_from_known("score", "10,558.96", text_image("19,558.96")), "")
        self.assertEqual(bet.missing_digits("score"), "3478")

    def test_nothing_to_learn_when_all_are_known(self):
        self.assertEqual(bet.learn_from_known("score", "10,522.96", text_image("10,522.96")), "")

    def test_a_balance_written_the_way_the_table_does(self):
        fmt = {"decimal": ".", "thousands": ",", "decimals": 2, "symbol": "$", "symbol_at": "start"}
        self.assertEqual(format_number(10558.96, fmt), "$10,558.96")
        fmt = {"decimal": ",", "thousands": ".", "decimals": 2, "symbol": "€", "symbol_at": "end"}
        self.assertEqual(format_number(1250.5, fmt), "1.250,50€")
        self.assertIsNone(format_number(10.5, {"decimal": ".", "thousands": ",", "decimals": None}))
        self.assertEqual(format_number(1200, {"decimal": ".", "thousands": "", "decimals": None}), "1200")
