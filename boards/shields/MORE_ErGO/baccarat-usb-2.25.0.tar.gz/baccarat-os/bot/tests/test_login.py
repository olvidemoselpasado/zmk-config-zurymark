"""Logging back in when the site has dropped the session.

The site here is a script: 'success_login' shows once the form has been sent
(or after a chosen number of tries), and every click, key and piece of typed
text is written down so the order can be checked. Nothing touches a screen.
"""
import logging
import os
import stat
import time
import pytest
import analysis
import bet
import main
from baccarat.play import login as login_mod
from baccarat.play import tuning

EMAIL, PASSWORD = "me@example.com", "s3cr3t-Pa55!"


class Site:
    """Logged out until the form has been sent `works_on` times (0 = never)."""

    def __init__(self, monkeypatch, logged_in=False, works_on=1, enter_submits=True):
        self.logged_in, self.works_on, self.sent = logged_in, works_on, 0
        self.enter_submits = enter_submits
        self.did: list[str] = []
        monkeypatch.setattr(bet, "region_difference", lambda name: 3.0 if self.logged_in else 80.0)
        monkeypatch.setattr(login_mod, "run_action", lambda name: self.did.append(f"click {name}"))
        monkeypatch.setattr(bet, "type_private", self.type)
        monkeypatch.setattr(bet, "press_key", self.key)

    def type(self, text, label=""):
        self.did.append("type email" if text == EMAIL else
                        "type password" if text == PASSWORD else f"type {text!r}")
        if text == PASSWORD and not self.enter_submits:
            self.send()
        return True

    def key(self, key, over=None, label=""):
        self.did.append(f"key {key}")
        if key == "Return" and self.enter_submits:
            self.send()

    def send(self):
        self.sent += 1
        if self.works_on and self.sent >= self.works_on:
            self.logged_in = True


@pytest.fixture
def ready(site, monkeypatch):
    """A site with everything a login needs set up."""
    from baccarat.screen.sites import save_coords
    save_coords({"login": {"x": 10, "y": 20, "action": "click"}})
    snaps = bet.snaps_dir()
    snaps.mkdir(parents=True, exist_ok=True)
    (snaps / "success_login.geo").write_text("0,0 10x10")
    (snaps / "success_login.png").write_bytes(b"png")
    bet.save_login(EMAIL, PASSWORD)
    for k in ("LOGIN_FORM_WAIT", "LOGIN_POLL", "LOGIN_RELOAD_WAIT"):
        monkeypatch.setattr(tuning, k, 0.0)
    monkeypatch.setattr(login_mod.time, "sleep", lambda s: None)


def player(**kw):
    p = main.Player(analysis.new_session(strategy="streak_or_chop_2", budget=1000, base=20),
                    road=None, login_wait=kw.pop("login_wait", 0.02), **kw)
    p.snapshot = lambda *a, **k: None
    return p


# --- whether it does anything at all -----------------------------------------

def test_not_set_up_it_does_nothing(site, monkeypatch):
    s = Site(monkeypatch)
    assert player().ensure_logged_in() is True
    assert s.did == []


def test_already_logged_in_nothing_is_clicked(ready, monkeypatch):
    s = Site(monkeypatch, logged_in=True)
    assert player().ensure_logged_in() is True
    assert s.did == []


def test_the_old_spelling_of_the_region_still_counts(ready, monkeypatch):
    d = bet.snaps_dir()
    for ext in (".geo", ".png"):
        (d / f"success_login{ext}").rename(d / f"succes_login{ext}")
    assert login_mod.success_region() == "succes_login"
    assert login_mod.login_missing() == []


# --- logging in ----------------------------------------------------------------

def test_it_logs_in_click_email_tab_password_enter(ready, monkeypatch):
    s = Site(monkeypatch)
    assert player().ensure_logged_in() is True
    assert s.did == ["click login", "type email", "key Tab", "type password", "key Return"]


def test_without_enter_the_form_is_left_to_submit_itself(ready, monkeypatch):
    s = Site(monkeypatch, enter_submits=False)
    assert player(login_enter=False).ensure_logged_in() is True
    assert "key Return" not in s.did


def test_a_failed_try_reloads_the_page_and_tries_again(ready, monkeypatch):
    s = Site(monkeypatch, works_on=2)
    assert player().ensure_logged_in() is True
    assert s.did.count("click login") == 2
    assert s.did.count(f"key {bet.RELOAD_KEY}") == 1
    assert s.did.index(f"key {bet.RELOAD_KEY}") < len(s.did) - s.did[::-1].index("click login") - 1


def test_it_gives_up_after_the_tries_set_and_says_so(ready, monkeypatch):
    s = Site(monkeypatch, works_on=0)
    p = player(login_tries=4)
    assert p.ensure_logged_in() is False
    assert s.did.count("click login") == 4
    assert s.did.count(f"key {bet.RELOAD_KEY}") == 3, "a reload before every try but the first"
    assert "couldn't log in after 4 tries" in p.status


def test_a_slow_login_that_lands_during_the_reload_is_not_typed_again(ready, monkeypatch):
    s = Site(monkeypatch, works_on=0)
    reload = s.key

    def key(k, over=None, label=""):
        reload(k, over, label)
        if k == bet.RELOAD_KEY:
            s.logged_in = True                 # the first try's login arrived late
    monkeypatch.setattr(bet, "press_key", key)
    assert player().ensure_logged_in() is True
    assert s.did.count("click login") == 1


def test_a_table_is_never_opened_on_a_login_page(ready, monkeypatch):
    """hunt_for_table asks before every open, and stops when the login fails."""
    Site(monkeypatch, works_on=0)
    p = player(login_tries=1, open_patterns=["open_table_1"])
    monkeypatch.setattr(p, "open_until_loaded", lambda *a, **k: pytest.fail("opened a table"))
    assert p.hunt_for_table() is None


# --- the details stay private ----------------------------------------------------

def test_the_password_is_never_written_to_the_log(ready, monkeypatch, caplog):
    caplog.set_level(logging.DEBUG)
    Site(monkeypatch, works_on=0)
    player(login_tries=2).ensure_logged_in()
    Site(monkeypatch, works_on=1)
    player().ensure_logged_in()
    text = "\n".join(r.getMessage() for r in caplog.records)
    assert "Logging in" in text
    assert PASSWORD not in text and EMAIL not in text


def test_typing_puts_the_secret_on_stdin_and_logs_nothing_even_when_it_fails(monkeypatch, caplog):
    """The Linux backend, called directly: on a Mac the tests must never type for real."""
    from baccarat.screen import linux
    seen = {}

    class Failed:
        returncode, stdout, stderr = 1, "", "wtype: something about " + PASSWORD

    def run(cmd, **kw):
        seen.update(cmd=cmd, input=kw.get("input"))
        return Failed()
    monkeypatch.setattr(linux.subprocess, "run", run)
    caplog.set_level(logging.DEBUG)
    monkeypatch.setattr(linux, "DEBUG", True)
    assert linux.type_private(PASSWORD, "typing the password") is False
    assert PASSWORD not in " ".join(seen["cmd"]) and seen["input"] == PASSWORD
    assert seen["cmd"][-1] == "-", "wtype reads the text from stdin"
    assert PASSWORD not in "\n".join(r.getMessage() for r in caplog.records)


def test_the_file_is_readable_only_by_you_and_an_empty_password_keeps_the_saved_one(site):
    bet.save_login(EMAIL, PASSWORD)
    from baccarat.screen.sites import login_file
    f = login_file()
    assert stat.S_IMODE(os.stat(f).st_mode) == 0o600
    bet.save_login("new@example.com", "")
    assert bet.load_login() == {"email": "new@example.com", "password": PASSWORD}
    assert PASSWORD not in str(bet.login_summary())
    assert bet.forget_login() == {"email": "", "has_password": False}


def test_the_password_is_not_in_the_settings_or_copy_report(site):
    from baccarat.store.settings import DEFAULTS
    from baccarat.web import report
    bet.save_login(EMAIL, PASSWORD)
    assert not any("pass" in k or "email" in k for k in DEFAULTS)
    text = report.build({}, [{"text": "a line"}], None)
    assert PASSWORD not in text and EMAIL not in text


# --- the settings ----------------------------------------------------------------

def test_tries_and_wait_come_from_setup_within_limits():
    from baccarat.setup import login_params
    assert login_params({}) == {"login_tries": 3, "login_wait": 60.0, "login_enter": True}
    assert login_params({"login_tries": "5", "login_wait": "120", "login_enter": False}) == \
        {"login_tries": 5, "login_wait": 120.0, "login_enter": False}
    for bad in ({"login_tries": "0"}, {"login_tries": "11"}, {"login_wait": "5"},
                {"login_tries": "2.5"}):
        with pytest.raises(ValueError):
            login_params(bad)


def test_the_wait_is_long_enough_to_count(ready, monkeypatch):
    """The site gets the whole wait before a reload."""
    s = Site(monkeypatch, works_on=0)
    t0 = time.monotonic()
    player(login_tries=1, login_wait=0.2).ensure_logged_in()
    assert time.monotonic() - t0 >= 0.2
    assert s.did.count("click login") == 1


def test_it_is_checked_at_the_start_only_never_during_play(ready, monkeypatch):
    """The first table needs a login; the tables after it are opened without a look."""
    Site(monkeypatch, logged_in=True)
    p = player(open_patterns=["open_table_1"])
    looks = []
    real = p.ensure_logged_in
    monkeypatch.setattr(p, "ensure_logged_in", lambda why="": looks.append(why) or real(why))
    monkeypatch.setattr(p, "open_until_loaded", lambda *a, **k: (None, "open_table_1"))
    for _ in range(3):
        p.hunt_for_table()
    assert looks == ["before the first table"]


def test_a_stuck_table_is_reopened_by_its_own_name_after_a_login_check(ready, monkeypatch):
    """The 2.24.0 report: open_table_1 got stuck; "reopening the same table" opened
    open_table_2 (busy, no room) five times and stopped. And the login -- the likely
    reason a table stops moving -- was never looked at again."""
    Site(monkeypatch, logged_in=True)
    p = player(open_patterns=["open_table_1", "open_table_2", "open_table_3"])
    p.login_checked = True
    p.current_open, p.open_index = "open_table_1", 1
    looks, opened = [], []
    real = p.ensure_logged_in
    monkeypatch.setattr(p, "ensure_logged_in", lambda why="": looks.append(why) or real(why))
    monkeypatch.setattr(p, "open_until_loaded",
                        lambda name, *a, **k: opened.append(name) or (None, name))
    p.hunt_for_table(same_table=True)
    assert opened == ["open_table_1"] and looks == ["the table got stuck"]


def test_a_table_that_wont_load_makes_it_look_for_a_logout_and_try_another_one(ready, monkeypatch):
    Site(monkeypatch, logged_in=False, works_on=1)          # the casino has logged us out
    p = player(open_patterns=["open_table_1", "open_table_2", "open_table_3"])
    clicked, looks = [], []
    real = p.ensure_logged_in
    monkeypatch.setattr(p, "ensure_logged_in", lambda why="": looks.append(why) or real(why))
    from baccarat.play import navigate
    monkeypatch.setattr(navigate, "run_action", lambda name: clicked.append(name))
    monkeypatch.setattr(p, "ensure_lobby", lambda *a: None)
    monkeypatch.setattr(p, "scroll_to", lambda *a: None)
    monkeypatch.setattr(p, "leave_table", lambda *a: None)
    monkeypatch.setattr(p, "refresh_lobby", lambda *a: True)
    monkeypatch.setattr(p, "wait", lambda *a, **k: None)
    boards = iter([None, {"game": 3, "player": 1, "banker": 2, "tie": 0}])
    monkeypatch.setattr(p, "wait_for_board", lambda avoid=None: next(boards))
    board, name = p.open_until_loaded("open_table_2")
    assert board and looks == ["the table didn't load"]         # logged back in
    assert clicked[0] == "open_table_2" and clicked[-1] != "open_table_2" and name == clicked[-1]
