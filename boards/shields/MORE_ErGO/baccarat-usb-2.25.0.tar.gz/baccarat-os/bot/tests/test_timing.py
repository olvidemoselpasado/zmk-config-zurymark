"""Pacing and the betting window: when to look, and whether a bet can fit."""
import pytest
import bet
from baccarat.screen import pointer
import main


# --- how often the screen is read -------------------------------------------

def test_a_score_that_has_not_changed_costs_one_grab(monkeypatch):
    """The bug behind CPU peaks: every look at the score was two screen grabs, even
    though it sits unchanged for most of every hand. The bar already took an
    unchanged value at once; the score now does the same."""
    from baccarat.screen import glyphs
    monkeypatch.setattr(glyphs, "_LAST_NUMBER", {})
    grabs = []
    monkeypatch.setattr(glyphs, "read_number", lambda name: grabs.append(1) or 1000.0)
    monkeypatch.setattr(glyphs.time, "sleep", lambda s: None)
    assert glyphs.read_number_stable("score") == 1000.0
    assert len(grabs) == 2, "a value not seen before is confirmed with a second look"
    grabs.clear()
    assert glyphs.read_number_stable("score") == 1000.0
    assert len(grabs) == 1, "the same value again is taken at once"


def test_a_changing_value_is_confirmed_at_a_gentle_pace(monkeypatch):
    """While the score counts up after a result, the confirming looks used to come
    every 40 ms: 25 grabs a second, in the busiest second of the hand."""
    from baccarat.screen import capture, glyphs
    monkeypatch.setattr(glyphs, "_LAST_NUMBER", {})
    gaps = []
    values = iter([100.0, 110.0, 120.0, 130.0, 130.0])
    monkeypatch.setattr(glyphs, "read_number", lambda name: next(values))
    monkeypatch.setattr(glyphs.time, "sleep", lambda s: gaps.append(s))
    assert glyphs.read_number_stable("score") == 130.0
    assert gaps and min(gaps) >= capture.CONFIRM_GAP >= 0.1


def test_the_load_line_names_the_busiest_process_and_when(monkeypatch):
    from baccarat.play.loadmeter import describe
    d = {"seconds": 30, "grabs": 88, "by_region": {"board": 70, "score": 18},
         "busiest_second": 9, "cores": 8,
         "cpu": {"bot": (6, 31), "helpers": (4, 12), "compositor": (18, 55),
                 "browser": (44, 80), "machine": (22, 41)},
         "peak_when": {"browser": "the clicks"}, "watching": {"compositor": 1, "browser": 9}}
    s = describe(d)
    assert "88 grabs (board 70, score 18; busiest second 9)" in s
    assert "browser 44/80" in s and "machine 22/41% of 8 cores" in s
    assert s.endswith("busiest: browser, during the clicks")


def test_the_meter_counts_a_hand_of_grabs(monkeypatch):
    from baccarat.play import loadmeter
    from baccarat.screen import capture
    monkeypatch.setattr(capture, "SHOTS_BY", {})
    capture.SHOT_TIMES.clear()
    m = loadmeter.LoadMeter()
    now = __import__("time").monotonic()
    capture.SHOTS_BY.update({"board": 5, "score": 2})
    capture.SHOT_TIMES.extend([now + i * 0.1 for i in range(7)])
    d = m.hand_done()
    assert d["grabs"] == 7 and d["by_region"] == {"board": 5, "score": 2}
    assert d["busiest_second"] == 7
    assert m.hand_done()["grabs"] == 0, "the next hand starts from zero"


def test_the_maths_libraries_run_on_one_thread():
    """A live session measured the bot at more than a whole core while it read the
    scoreboard twice a second: OpenCV and numpy wake a thread per core for every tiny
    job. Limited to one, before either is imported."""
    import os
    import cv2
    assert cv2.getNumThreads() == 1
    for var in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "OPENCV_FOR_THREADS_NUM"):
        assert os.environ.get(var), f"{var} should be set (to 1, unless you set it yourself)"


def test_the_pointer_is_redrawn_at_a_gentle_rate():
    """Each warp makes the page under the pointer re-check what it hovers over, while
    it decodes the stream; the biggest browser spikes came during the clicks."""
    assert pointer.MOVE_HZ <= 40


def test_a_move_keeps_its_timing_with_fewer_redraws(monkeypatch):
    warps = []
    monkeypatch.setattr(pointer, "_move_cursor", lambda x, y: warps.append((x, y)))
    t0 = __import__("time").perf_counter()
    pointer._glide((0, 0), (800, 300), 0.3, 20, 2)
    took = __import__("time").perf_counter() - t0
    assert len(warps) <= 0.3 * pointer.MOVE_HZ + 1
    assert 0.27 <= took <= 0.45, "the same move in the same time"
    assert warps[-1] == (800, 300), "and it still ends exactly on the target"


def test_the_meter_knows_programs_behind_a_nixos_wrapper():
    """Hyprland on NixOS runs as '.Hyprland-wrapped', which the kernel cuts to 15
    characters -- so the meter never found it and showed the compositor at 0."""
    from baccarat.screen.desktop import process_name
    assert process_name(".Hyprland-wrapp\n") == "hyprland"
    assert process_name(".firefox-wrappe") == "firefox"
    assert process_name("Isolated Web Co") == "isolated web co"
    assert process_name("some-wrapper-x") == "some-wrapper-x"


def test_with_nothing_measured_it_watches_at_full_speed():
    assert main.poll_step(0.0, floor=0.0, quiet=0.8) == main.POLL
    assert main.poll_step(99.0, floor=0.0, quiet=0.8) == main.POLL


def test_early_in_a_hand_it_looks_rarely():
    """No result can have landed yet, and every look is a screenshot the
    compositor has to copy a whole frame for."""
    assert main.poll_step(1.0, floor=15.0, quiet=0.8) == 0.8


def test_as_the_result_becomes_due_it_looks_more_often():
    mid = main.poll_step(15.0 * 0.7, floor=15.0, quiet=0.8)
    assert main.POLL < mid < 0.8


def test_once_a_result_is_really_due_it_watches_at_full_speed():
    assert main.poll_step(15.0 * 0.95, floor=15.0, quiet=0.8) == main.POLL


def test_it_never_polls_slower_than_the_caller_asked_for():
    """The chips loop passes its own full-speed step; the gears must not make
    it slower than it was before any of this."""
    assert main.poll_step(0.0, floor=0.0, quiet=0.8, fast=0.2) == 0.2


def test_the_gears_only_ever_speed_up():
    steps = [main.poll_step(t, 15.0, 0.8) for t in (0, 4, 8, 12, 14.5)]
    assert steps == sorted(steps, reverse=True)


# --- the quickest hand, used to decide when to speed up ---------------------

def test_the_floor_needs_a_few_hands_before_it_is_trusted():
    assert main.Player._quickest([15.0, 15.0, 15.0]) == 0.0


def test_the_floor_ignores_one_freak_short_hand():
    """A shuffle or a misread produces one tiny gap. Taking the plain minimum
    would collapse the floor and throw the saving away for the session."""
    normal = [15.1, 14.8, 15.3, 14.9, 15.0, 15.2]
    assert main.Player._quickest(normal) == pytest.approx(14.9)
    assert main.Player._quickest(normal + [6.0]) == pytest.approx(14.8)


def test_the_floor_is_never_above_the_quickest_two_hands():
    """Being late for a result costs a bet, so the floor has to sit at the fast
    end of what the table has done — never in the middle of it."""
    times = [10.0, 15.0, 15.0, 20.0, 25.0]
    floor = main.Player._quickest(times)
    assert floor == sorted(times)[1]
    assert floor < sum(times) / len(times)


# --- can this bet be clicked in time? ---------------------------------------

TIMING = {"click_speed": (0.1, 0.1), "move_speed": 0.30, "bet_window": 6.0}


def cost(coords_fixture, max_steps, window=6.0):
    return main.click_cost({"base": 20, "max_steps": max_steps, "budget": 11000.0},
                           {**TIMING, "bet_window": window})


def test_the_cost_is_the_biggest_bet_not_the_first(coords):
    c = cost(coords, max_steps=6)
    assert c["stake"] == 1280.0 and c["clicks"] == 8


def test_a_window_that_cannot_fit_the_biggest_bet_is_refused(coords):
    c = cost(coords, max_steps=6, window=1.0)
    assert not c["fits"]


def test_the_same_set_up_fits_once_the_window_is_wide_enough(coords):
    assert cost(coords, max_steps=6, window=10.0)["fits"]


def test_repeats_cost_nothing_when_the_button_has_points_far_apart(coords):
    assert cost(coords, max_steps=6)["repeats"] == 0


def test_repeats_cost_time_when_there_is_only_one_point(site):
    import json
    c = {"chip_20": {"x": 100, "y": 900, "action": "click"},
         "spot_player_1": {"x": 400, "y": 800, "action": "click"},
         "spot_banker_1": {"x": 600, "y": 800, "action": "click"},
         "redo_bet": {"x": 800, "y": 900, "action": "click"}}
    bet.coords_file().write_text(json.dumps(c))
    one = main.click_cost({"base": 20, "max_steps": 6, "budget": 11000.0}, TIMING)
    assert one["repeats"] > 0
    assert one["needs"] > one["clicks"] * one["per_click"]


def test_setup_refuses_a_configuration_that_can_never_place_its_biggest_bet(coords):
    problem = main.click_budget_problem({"base": 20, "max_steps": 6, "budget": 11000.0},
                                        {**TIMING, "bet_window": 1.0})
    assert problem and "never be placed" in problem


def test_setup_is_happy_when_the_biggest_bet_fits(coords):
    assert main.click_budget_problem({"base": 20, "max_steps": 6, "budget": 11000.0},
                                     {**TIMING, "bet_window": 10.0}) is None


# --- two presses in one place -----------------------------------------------

def test_consecutive_presses_on_one_point_clear_the_double_click_window(monkeypatch):
    """The bug: two presses ~300 ms apart on the same button, one of which the
    table swallowed, leaving half the stake on."""
    import time
    slept = []
    monkeypatch.setattr(pointer.time, "sleep", slept.append)
    pointer._LAST_PRESS = (800.0, 900.0, time.perf_counter())
    bet._hold_off_same_spot(800.0, 900.0)
    assert slept and slept[0] > 0.5


def test_a_press_somewhere_else_is_not_held_back(monkeypatch):
    import time
    slept = []
    monkeypatch.setattr(pointer.time, "sleep", slept.append)
    pointer._LAST_PRESS = (800.0, 900.0, time.perf_counter())
    bet._hold_off_same_spot(400.0, 800.0)
    assert slept == []


class TestTheFloorTheCodeActuallyUses:
    """`_quickest` is tested above, but the hand loop calls `hand_floor` and
    `chip_floor`, and those add the fallback used before anything is measured.
    Testing only the helper leaves the fallback uncovered — and the fallback is
    what every short session runs on."""

    def player(self, hand_seconds=15.0):
        import main
        from analysis import new_session
        return main.Player(new_session(strategy="streak_or_chop_2", budget=1000, base=20),
                           road=None, hand_seconds=hand_seconds)

    def test_before_anything_is_measured_it_uses_the_pace_from_setup(self):
        p = self.player(hand_seconds=15.0)
        assert p.hand_times == []
        assert 0 < p.hand_floor() < 15.0        # a safe fraction, not the whole hand

    def test_a_measured_table_overrides_the_setting(self):
        p = self.player(hand_seconds=15.0)
        p.hand_times = [25.0, 24.8, 25.2, 24.9]
        assert p.hand_floor() > 20.0

    def test_one_freak_short_hand_does_not_collapse_the_floor(self):
        """The plain minimum would drop to 6 and throw the saving away for the
        rest of the session."""
        p = self.player()
        p.hand_times = [15.1, 14.8, 15.3, 14.9, 15.0, 6.0]
        assert p.hand_floor() > 12.0

    def test_the_chips_floor_has_its_own_fallback(self):
        p = self.player()
        assert p.chip_floor() > 0                # nothing comes up instantly
        p.chip_times = [3.0, 2.9, 3.2, 3.1]
        assert 2.5 < p.chip_floor() < 3.5
