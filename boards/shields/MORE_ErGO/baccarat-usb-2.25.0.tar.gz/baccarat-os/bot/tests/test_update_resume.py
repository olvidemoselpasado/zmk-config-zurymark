"""An update downloaded during a session: the run in progress is played out, the session
stops at the base bet, the update installs, and the session carries on by itself with
the balance it stopped on. And the stick hears of a new release at once (the poke)."""
import json
import os
import time
from types import SimpleNamespace

import pytest

from baccarat.study.replay import new_session
from baccarat.web import resume, updatestatus as us


def bet(s, win: bool):
    b = s.next_bet()
    assert b, "the strategy should bet here"
    side, _ = b
    s.record(side if win else ("banker" if side == "player" else "player"), b)


# -- the session: stops only at the base bet -------------------------------------------
def test_halt_waits_for_the_run_to_be_won():
    s = new_session("streak_or_chop_2", 10000, 20)
    s.new_table(["player", "player"])
    bet(s, False)
    bet(s, False)                      # two losses: the run is in progress (next: 80)
    assert s.in_run
    s.halt_for = "update 2.23.0"
    nxt = s.next_bet()
    assert nxt and nxt[1] == 80        # still played out: the run is never left half-way
    s.record(nxt[0], nxt)              # … and won
    assert not s.in_run
    assert s.next_bet() is None        # the next would be the base bet: stop here
    assert s.finished and s.skip_reason == "update 2.23.0"


def test_halt_at_the_base_bet_stops_at_once():
    s = new_session("streak_or_chop_2", 10000, 20)
    s.new_table(["player", "player"])
    s.halt_for = "update 2.23.0"
    assert s.next_bet() is None and s.finished


# -- the player notices the downloaded update --------------------------------------------
@pytest.fixture
def status(tmp_path, monkeypatch):
    f = tmp_path / "status.json"
    monkeypatch.setattr(us, "FILE", f)

    def write(**kv):
        f.write_text(json.dumps({"version": "2.23.0", "done": 0, "total": 0, "at": time.time(), **kv}))
    return write


@pytest.mark.parametrize("state,due", [("downloading", False), ("queued", False),
                                       ("waiting", True), ("current", False)])
def test_player_stops_only_once_it_is_downloaded(status, state, due):
    from baccarat.play.player import Player
    status(state=state)
    me = SimpleNamespace(s=SimpleNamespace(halt_for=None))
    assert Player.update_due(me) is due
    assert (me.s.halt_for == "update 2.23.0") is due


def test_a_stale_waiting_status_stops_nothing(status):
    from baccarat.play.player import Player
    status(state="waiting", at=time.time() - 300)
    me = SimpleNamespace(s=SimpleNamespace(halt_for=None))
    assert not Player.update_due(me) and me.s.halt_for is None


# -- carrying on ----------------------------------------------------------------------------
def test_resume_keeps_the_balance_and_target(site):
    resume.save({"strategy": "streak_or_chop_2", "budget": "1000", "base": "20", "target": "200"},
                1137.5, 1200.0, None, "update 2.23.0")
    assert oct(os.stat(site / resume.NAME).st_mode & 0o777) == "0o600"
    rec = resume.take()
    assert rec["over"]["budget"] == "1137.50" and rec["over"]["target"] == "=1200.00"
    assert rec["over"]["ask_road"] is False
    assert rec["body"]["budget"] == "1000"            # the set-up itself is untouched
    assert resume.take() is None                     # taken once


def test_resume_with_cycles_keeps_the_step(site):
    resume.save({}, 1100, 1200, 3, "update 2.23.0", step=100)
    over = resume.take()["over"]
    assert over["cycles"] == "3" and over["ceiling_step"] == "100.00"


def test_an_old_resume_is_dropped(site):
    resume.save({}, 1000, None, None, "update 2.23.0")
    rec = json.loads((site / resume.NAME).read_text())
    rec["at"] -= resume.MAX_AGE + 1
    (site / resume.NAME).write_text(json.dumps(rec))
    assert resume.take() is None and not (site / resume.NAME).exists()


def test_resume_never_travels_to_the_server():
    from baccarat.web import configsync
    assert {"resume.json", "resume.new"} <= configsync.KEEP_HERE


def test_the_resumed_start_uses_the_balance_and_saves_the_setup_as_it_was(site, monkeypatch):
    """The start: the template applies, then the carried-on values on top; the Setup page
    keeps the user's own budget."""
    from baccarat.web import routes_session as rs
    saved = {}
    monkeypatch.setattr(rs, "save_settings", lambda b: saved.update(b))
    monkeypatch.setattr(rs.updatestatus, "read", lambda: None)
    monkeypatch.setattr(rs, "check_live_setup", lambda: None)
    seen = {}

    class Stop(Exception):
        pass

    def fake_new_session(**kw):
        seen.update(kw)
        raise Stop
    monkeypatch.setattr(rs.analysis, "new_session", fake_new_session)
    import threading
    me = SimpleNamespace(running=False, lock=threading.Lock())
    body = {"strategy": "streak_or_chop_2", "budget": "1000", "base": "20", "target": "200",
            "resume": {"budget": "1137.50", "target": "=1200.00", "ask_road": False, "start_at": ""}}
    with pytest.raises(Stop):
        rs.SessionRoutes.start(me, body)
    assert seen["budget"] == 1137.5 and seen["ceiling"] == 1200.0
    assert saved["budget"] == "1000" and saved["target"] == "200"


def test_the_watch_carries_on_once_nothing_holds(site, status, monkeypatch):
    monkeypatch.setattr(resume, "SETTLE", 0)
    started = []
    ctl = SimpleNamespace(running=False, dash=SimpleNamespace(update=lambda **kv: None),
                          start=lambda body: started.append(body))
    resume.save({"strategy": "x", "budget": "1000"}, 1050, None, None, "update 2.23.0")
    status(state="installing")
    resume.watch(ctl, every=0.05)
    time.sleep(0.3)
    assert not started                                # held while it installs
    status(state="done")
    for _ in range(40):
        if started:
            break
        time.sleep(0.05)
    assert started and started[0]["resume"]["budget"] == "1050.00"
    assert started[0]["budget"] == "1000"


# -- the poke: a new release is fetched at once -------------------------------------------
@pytest.fixture
def stick(tmp_path, monkeypatch):
    d = tmp_path / "poke"
    d.mkdir()
    cur = tmp_path / "current-system"
    os.symlink("/nix/store/" + "a" * 32 + "-nixos-system-usb-old", cur)
    monkeypatch.setattr(us, "POKE", d / "now")
    monkeypatch.setattr(us, "CURRENT", cur)
    monkeypatch.setattr(us, "FILE", tmp_path / "status.json")
    us._poked.update(system=None, at=0.0)
    return d


from baccarat import __version__ as THIS  # noqa: E402
NEW = {"system": "/nix/store/" + "b" * 32 + "-nixos-system-usb-new", "version": THIS}


def test_poke_for_a_new_release(stick):
    assert us.poke(NEW, now=1000)
    assert (stick / "now").read_text().strip() == NEW["system"]
    assert not us.poke(NEW, now=1030)                 # not again at once
    assert us.poke(NEW, now=1061)                     # but again a minute on (queued)


def test_no_poke_when_already_on_it_or_not_a_stick(stick, tmp_path, monkeypatch):
    cur = tmp_path / "current-system"
    cur.unlink()
    os.symlink(NEW["system"], cur)
    assert not us.poke(NEW, now=1000)
    monkeypatch.setattr(us, "POKE", tmp_path / "nowhere" / "now")
    assert not us.poke({**NEW, "system": NEW["system"] + "x"}, now=2000)
    assert not us.poke(None) and not us.poke({"system": "evil"})


def test_no_poke_while_it_downloads(stick, tmp_path):
    (tmp_path / "status.json").write_text(json.dumps({"state": "downloading", "at": time.time()}))
    assert not us.poke(NEW, now=1000)


def test_never_poked_for_an_older_release(stick):
    """A stick put on a newer version by hand doesn't go back to the server's older one."""
    from baccarat import __version__
    assert not us.poke({**NEW, "version": "2.22.2"}, now=1000)
    assert us.older("2.22.2", "2.23.0") and not us.older("2.23.0", "2.23.0")
    assert not us.older("?", "2.23.0") and us.older("2.9.0", "2.10.0")
    assert us.poke({**NEW, "version": __version__}, now=1000)    # the same version: the updater decides
