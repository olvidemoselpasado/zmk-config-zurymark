"""Shared fixtures.

These tests never touch a screen, a mouse or a real table. Anything that would
is replaced here, so a failure always means the logic is wrong rather than the
machine being busy.
"""
import atexit
import os
import shutil
import sys
import pathlib
import tempfile
import pytest

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
# The project, so the tests can import bet/main/strategies; and this folder, so
# they can import helpers.py. pytest only adds this folder itself under some of
# its import modes, and conftest.py is always loaded before any test module, so
# doing it here is what makes the suite behave the same everywhere.
for path in (str(ROOT), str(HERE)):
    if path not in sys.path:
        sys.path.insert(0, path)

# bet.py looks for a Hyprland session on import; it must not find a real one.
os.environ.setdefault("HYPRLAND_INSTANCE_SIGNATURE", "test")

# Never your real data folder, for any test, fixture or not. The package picks a site
# the moment it is imported, and that writes data/site.json; and a Player built
# without the `site` fixture reads runs.json. Both used to land in the real data/,
# so running the tests rewrote your site file and read your run history. Set before
# anything imports the package, and assigned rather than defaulted, because a
# BACCARAT_DATA of your own pointing at the real folder is exactly what to avoid.
_SCRATCH = tempfile.mkdtemp(prefix="bot-tests-")
os.environ["BACCARAT_DATA"] = _SCRATCH
atexit.register(shutil.rmtree, _SCRATCH, ignore_errors=True)
# … and never the real report server: a test that starts an Uplink gives its own address
os.environ["BACCARAT_SERVER"] = "off"


@pytest.fixture
def site(tmp_path):
    """A throwaway data folder, so a test never reads or writes your real set-up.

    One call does it: every path in the program is asked for at the moment it is
    used and comes from here, so there is nothing left to monkeypatch. If a new
    module ever reaches a real folder during the tests, that is the bug.
    """
    import bet
    from baccarat.store import paths
    paths.use_data_dir(tmp_path)
    bet.use_site("test")
    yield tmp_path
    paths.use_data_dir(None)


@pytest.fixture
def coords(site):
    """A plausible table: one chip, six spots a side, four repeat buttons,
    all far enough apart to count as different places."""
    import json
    import bet
    c = {"chip_20": {"x": 100, "y": 900, "action": "click"}}
    for i in range(1, 7):
        c[f"spot_player_{i}"] = {"x": 400 + i * 30, "y": 800, "action": "click"}
        c[f"spot_banker_{i}"] = {"x": 600 + i * 30, "y": 800, "action": "click"}
    for i in range(1, 5):
        c[f"redo_bet_{i}"] = {"x": 800 + i * 25, "y": 900, "action": "click"}
    bet.coords_file().write_text(json.dumps(c))
    return c


# The helpers live in helpers.py; re-exported here so that tests which import
# them from conftest keep working.
from helpers import board, road, table_coords          # noqa: E402,F401
