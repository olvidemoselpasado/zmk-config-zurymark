"""Shared helpers for the tests.

A plain module rather than something imported out of `conftest.py`: pytest only
puts the tests folder on the import path under some of its import modes, so
`from conftest import ...` works on one machine and fails on the next. This
file is importable because `conftest.py` puts this folder on the path before
any test module is loaded, which pytest does guarantee.
"""

WINNERS = {"B": "banker", "P": "player", "T": "tie"}


def road(letters: str) -> list[str]:
    """'B B P' or 'BBP' -> the winners, as the engine spells them."""
    return [WINNERS[ch.upper()] for ch in letters.replace(" ", "")]


def board(game: int = 10, player: int = 5, banker: int = 4, tie: int = 1) -> dict:
    """What the scoreboard bar reads."""
    return {"game": game, "player": player, "banker": banker, "tie": tie,
            "player_pair": 0, "banker_pair": 0}


def table_coords(spots: int = 6, redos: int = 4, chips=(20,), step: int = 30) -> dict:
    """A recorded table. `step` is how far apart the variants of one button sit:
    30 px is a normal recording, 2 px is everything stacked on one point."""
    c = {f"chip_{v}": {"x": 100 + i * 40, "y": 900, "action": "click"}
         for i, v in enumerate(chips)}
    for i in range(1, spots + 1):
        c[f"spot_player_{i}"] = {"x": 400 + i * step, "y": 800, "action": "click"}
        c[f"spot_banker_{i}"] = {"x": 600 + i * step, "y": 800, "action": "click"}
    for i in range(1, redos + 1):
        c[f"redo_bet_{i}"] = {"x": 800 + i * step, "y": 900, "action": "click"}
    return c
