"""Game logic — strategies.py.

This module decides what to bet and how much. It touches nothing outside
itself, so everything here is exact: given this road, that bet, every time.
"""
import unittest

import strategies as S
from analysis import new_session
from helpers import road

P, B, T = "player", "banker", "tie"


class Settling(unittest.TestCase):
    def test_player_pays_even_money(self):
        self.assertEqual(S.settle(P, 100, P), ("WIN", 100.0))

    def test_banker_pays_commission(self):
        self.assertEqual(S.settle(B, 100, B), ("WIN", 95.0))

    def test_a_tie_returns_the_stake(self):
        self.assertEqual(S.settle(P, 100, T), ("PUSH", 0.0))

    def test_a_loss_costs_the_stake(self):
        self.assertEqual(S.settle(P, 100, B), ("LOSS", -100))


class StreakOrChop(unittest.TestCase):
    """Looks at the last n results: all the same -> follow; strictly
    alternating -> follow the alternation; anything else -> no bet."""

    def decide(self, letters, n=2):
        name = "streak_or_chop_2" if n == 2 else "streak_or_chop"
        return S.get_strategy(name).decide(road(letters))

    def test_follows_a_streak(self):
        self.assertEqual(self.decide("BB"), B)

    def test_follows_a_chop(self):
        self.assertEqual(self.decide("BP"), B)

    def test_waits_until_it_has_enough(self):
        self.assertIsNone(self.decide("B"))

    def test_ties_are_not_results(self):
        self.assertEqual(self.decide("BTB"), B)     # still BB once the tie is dropped

    def test_three_in_a_row_needs_three(self):
        self.assertIsNone(self.decide("BB", n=3))
        self.assertEqual(self.decide("BBB", n=3), B)

    def test_no_pattern_means_no_bet(self):
        self.assertIsNone(self.decide("BBP", n=3))


class Doubling(unittest.TestCase):
    def test_doubles_after_a_loss(self):
        d = S.Doubling(20)
        self.assertEqual(d.amount, 20)
        d.update("LOSS")
        self.assertEqual(d.amount, 40)
        d.update("LOSS")
        self.assertEqual(d.amount, 80)

    def test_a_win_goes_back_to_base(self):
        d = S.Doubling(20)
        d.update("LOSS"); d.update("LOSS"); d.update("WIN")
        self.assertEqual(d.amount, 20)

    def test_a_tie_leaves_the_stake_alone(self):
        d = S.Doubling(20)
        d.update("LOSS"); d.update("PUSH")
        self.assertEqual(d.amount, 40)

    def test_the_limit_restarts_the_ladder(self):
        d = S.Doubling(20, max_steps=3)
        for _ in range(3):
            d.update("LOSS")
        self.assertEqual(d.amount, 20)          # accepted the loss, back to base


class Lives(unittest.TestCase):
    def test_counts_the_doublings_the_balance_can_cover(self):
        seq, fail = S.lives(140.0, S.Doubling(20))
        self.assertEqual(seq, [20, 40, 80])     # 140 covers three, 160 would be the fourth
        self.assertEqual(fail, 160)

    def test_no_lives_at_all(self):
        seq, _ = S.lives(10.0, S.Doubling(20))
        self.assertEqual(seq, [])


class Majority(unittest.TestCase):
    """After n losses in a row, follow the favourite of the last `window`
    results. The window exists because a table whose majority is shifting looks
    one way over the whole shoe and the other way over the recent hands."""

    def rule(self, n=3, window=11):
        return S.build_rules([{"name": "majority", "n": n, "window": window}])[0]

    def test_follows_the_favourite_of_the_window_only(self):
        r = self.rule(window=4)
        s = new_session(strategy="streak_or_chop_2", budget=1000, base=20)
        s.new_table(road("PPPPPPBBBB"))         # player leads overall, banker in the last 4
        side, _ = r.pick_side(s)
        self.assertEqual(side, B)

    def test_window_zero_means_the_whole_table(self):
        r = self.rule(window=0)
        s = new_session(strategy="streak_or_chop_2", budget=1000, base=20)
        s.new_table(road("PPPPPPBBBB"))
        side, _ = r.pick_side(s)
        self.assertEqual(side, P)

    def test_a_lead_of_one_is_enough(self):
        r = self.rule(window=11)
        s = new_session(strategy="streak_or_chop_2", budget=1000, base=20)
        s.new_table(road("PPPPPBBBBB" + "P"))   # 6 player, 5 banker
        side, why = r.pick_side(s)
        self.assertEqual(side, P)
        self.assertIn("6", why)

    def test_level_stays_with_the_last_winner(self):
        r = self.rule(window=4)
        s = new_session(strategy="streak_or_chop_2", budget=1000, base=20)
        s.new_table(road("PPBB"))
        side, why = r.pick_side(s)
        self.assertEqual(side, B)
        self.assertIn("level", why)

    def test_ties_are_ignored_entirely(self):
        r = self.rule(window=4)
        s = new_session(strategy="streak_or_chop_2", budget=1000, base=20)
        s.new_table(road("TTPPPB"))
        p, b, seen = r.tally(s)
        self.assertEqual((p, b, seen), (3, 1, 4))

    def test_it_re_reads_the_window_every_hand(self):
        """The bug this guards: the side was decided once when the rule took
        over and then never looked at again, so it kept betting player while
        banker overtook it."""
        r = self.rule(window=11)
        s = new_session(strategy="streak_or_chop_2", budget=1000, base=20)
        s.new_table(road("PPPPPPPBBBB"))        # 7 player, 4 banker
        r.active = True
        self.assertEqual(r.decide(s), P)
        s.new_table(road("PPPPPBBBBBB"))        # now 5 player, 6 banker
        self.assertEqual(r.decide(s), B)

    def test_counts_are_published_for_the_dashboard(self):
        r = self.rule(window=11)
        s = new_session(strategy="streak_or_chop_2", budget=1000, base=20)
        s.new_table(road("PPPPPPPBBBB"))
        r.pick_side(s)
        self.assertEqual(r.stats()["player"], 7)
        self.assertEqual(r.stats()["banker"], 4)
        self.assertEqual(r.stats()["lead"], 3)


class BuildingRules(unittest.TestCase):
    def test_numbers_in_order_from_a_string(self):
        r = S.build_rules(["majority=3,12"])[0]
        self.assertEqual((r.n, r.window), (3, 12))

    def test_defaults_when_nothing_is_given(self):
        r = S.build_rules(["majority"])[0]
        self.assertEqual(r.n, S.RULES["majority"].params["n"]["default"])

    def test_unknown_rule_is_refused(self):
        with self.assertRaises(ValueError):
            S.build_rules(["nonsense=3"])

    def test_too_many_numbers_is_refused(self):
        with self.assertRaises(ValueError):
            S.build_rules(["majority=3,12,99"])

    def test_a_number_below_its_minimum_is_refused(self):
        with self.assertRaises(ValueError):
            S.build_rules([{"name": "majority", "n": 0}])


class RoadShapes(unittest.TestCase):
    """Only the two helpers test_screens.py does not already own."""

    def test_runs(self):
        self.assertEqual(S.run_lengths(road("PBBPPP")), [(P, 1), (B, 2), (P, 3)])

    def test_letters_drop_ties(self):
        self.assertEqual(S.road_letters(road("PBTBP")), "PBBP")


class SessionAccounting(unittest.TestCase):
    def session(self, **kw):
        return new_session(strategy="streak_or_chop_2", budget=1000, base=20, **kw)

    def test_a_win_adds_to_the_balance(self):
        s = self.session()
        s.record(P, (P, 20.0), 1)
        self.assertEqual(s.balance, 1020)

    def test_a_banker_win_adds_the_commission_price(self):
        s = self.session()
        s.record(B, (B, 20.0), 1)
        self.assertEqual(s.balance, 1019)

    def test_a_push_moves_nothing(self):
        s = self.session()
        s.record(T, (P, 20.0), 1)
        self.assertEqual(s.balance, 1000)

    def test_a_correction_does_not_count_as_profit(self):
        """A stake that never went on is not a bet that lost, and must never be
        totted up as one."""
        s = self.session()
        s.record(P, (P, 20.0), 1)               # +20 of real winnings
        s.correct_balance(-120.0, "a stake that never reached the table")
        self.assertEqual(s.balance, 900)
        self.assertEqual(s.net, 20)             # the betting still made 20
        self.assertEqual(s.corrected, -120)

    def test_corrections_are_kept_for_the_record(self):
        s = self.session()
        s.correct_balance(-40.0, "why")
        s.correct_balance(-40.0, "why")
        self.assertEqual(len(s.corrections), 2)
        self.assertEqual(s.corrected, -80)

    def test_correcting_by_nothing_does_nothing(self):
        s = self.session()
        s.correct_balance(0.0, "why")
        self.assertEqual(s.corrections, [])


if __name__ == "__main__":
    unittest.main()
