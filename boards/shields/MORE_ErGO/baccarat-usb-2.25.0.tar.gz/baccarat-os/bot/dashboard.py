"""dashboard.py — kept so existing imports keep working. Now baccarat/web/server.py."""

import sys

import baccarat.web.server

sys.modules[__name__] = baccarat.web.server
