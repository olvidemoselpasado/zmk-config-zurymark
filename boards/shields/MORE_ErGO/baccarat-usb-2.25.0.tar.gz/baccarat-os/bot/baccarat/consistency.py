"""Checking that every part of the program came from the same version.

This exists because of two real debugging sessions spent on a bot behaving
impossibly, both of which turned out to be one module copied across and its
neighbour not. A package makes that much harder to do by accident, but one
module dragged over on its own still does it, so the check stays: each layer is
asked for the names the rest of the program calls on it, and anything missing is
named at startup rather than discovered at a table."""

from __future__ import annotations

from baccarat import screen as bet
import analysis
from baccarat.log import log
from baccarat.core import bets as betting
from baccarat import core as strategies




# What this main.py needs from the files beside it. The whole program is a handful of
# modules copied across by hand, so one of them being a version behind is the single
# most likely thing to go wrong — and an AttributeError halfway through a session says
# nothing useful about which file to copy.
NEEDS = {
    "baccarat/core/bets.py": (betting, ["worst_bet", "chip_values", "redo_names",
                                        "plan_bet", "describe"]),
    "baccarat/screen/": (bet, ["save_ink", "ink_of", "forget_board", "shots_taken",
                               "start_click_run", "set_move_speed", "read_board_stable",
                               "read_road"]),
    "baccarat/core/": (strategies, ["build_patterns", "screen_table", "clean_pattern",
                                    "describe_pattern", "big_road"]),
    "baccarat/study/": (analysis, ["entry_scan", "entry_detail", "new_session"]),
}


def stale_files() -> list[str]:
    """Which files beside this one are older than it expects, and what is missing."""
    out = []
    for fname, (mod, needs) in NEEDS.items():
        missing = [n for n in needs if not hasattr(mod, n)]
        if missing:
            out.append(f"{fname} is out of date — it has no {', '.join(missing)}")
    return out


def check_files() -> None:
    for line in stale_files():
        log.error("%s. Copy the latest %s across; every file of this program has to come "
                  "from the same version.", line, line.split()[0])
