"""A baccarat table bot: reads a live table off the screen and bets a strategy.

The layers, lowest first. Nothing lower imports anything higher, and that one
rule is what keeps this from collapsing back into three enormous files.

    store/      where things are kept on disk. paths.py is the only module in
                the program that works out where the data folder is.
    core/       the game. Pure functions of their arguments: no screen, no
                mouse, no files. The simulations and the live table run this
                same code, which is the only reason a replay means anything.
    screen/     the screen, mouse and keyboard. desktop.py is the only module
                that talks to the operating system, so it is also the whole of
                the macOS/Windows port.
    play/       playing a table: the loop, the timing, the money, finding and
                leaving tables.
    study/      replaying recorded tables, and the totals.
    web/        the dashboard and its API.
    cli.py      the command line.

    python -m baccarat             the dashboard
    python -m baccarat --play      play the table (places real bets)
    python -m baccarat.screen      set up and check the screen reading
"""

__version__ = "2.25.0"

# One thread for the maths libraries. Everything the bot computes is tiny -- a strip of
# the screen a couple of hundred pixels wide -- and a thread pool sized to the machine
# costs more to wake for each job than the job does: a live session measured the bot at
# more than a whole core while it read the scoreboard twice a second. These only take
# effect if set before numpy is first imported, which is why they are here. Your own
# setting of any of them wins.
import os as _os

for _var in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
             "NUMEXPR_NUM_THREADS", "OPENCV_FOR_THREADS_NUM"):
    _os.environ.setdefault(_var, "1")
