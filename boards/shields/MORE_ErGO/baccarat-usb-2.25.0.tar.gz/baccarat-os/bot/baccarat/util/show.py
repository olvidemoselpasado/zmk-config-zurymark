"""Colour and money for a terminal.

    red    money lost
    green  budget and balance
    blue   money about to be bet

Turned off when the output is not a terminal, or when NO_COLOR is set."""

from __future__ import annotations

import os
import sys
from baccarat.core.session import Session




# ---------------------------------------------------------------------------
# Colors:  red = money lost,  green = budget / balance,  blue = money to bet
# ---------------------------------------------------------------------------

USE_COLOR = sys.stdout.isatty() and sys.stderr.isatty() and not os.environ.get("NO_COLOR")


def _c(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


def red(t) -> str:   return _c("1;31", t)


def green(t) -> str: return _c("1;32", t)


def blue(t) -> str:  return _c("1;94", t)


def money(x: float) -> str:
    return f"{x:,.2f}"


def signed(x: float) -> str:
    """+76.00 plain, -40.00 red."""
    return red(f"{x:+,.2f}") if x < 0 else f"{x:+,.2f}"


def summary_line(s: Session) -> str:
    return (f"W {s.count('WIN')}  L {s.count('LOSS')}  push {s.count('PUSH')}  "
            f"skipped {s.count('NO BET')}  │  balance {green(money(s.balance))}  "
            f"net {signed(s.net)}  next stake {blue(f'{s.staking.amount:,.0f}')}")


def colored_report(s: Session) -> str:
    return s.report(bal=green, loss=red, stake=blue)
