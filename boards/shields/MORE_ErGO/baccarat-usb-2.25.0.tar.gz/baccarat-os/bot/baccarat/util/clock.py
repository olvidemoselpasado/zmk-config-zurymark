"""Times and durations: parsing "21:30" or "in 40 min", and saying a number of
seconds back in words.

Pure. Nothing here waits for anything -- a wait that can be stopped lives in
play.stop, because it has to ask whether the Stop button has been pressed."""

from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone




def _hms(seconds: float) -> str:
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    return f"{h}h {m}m" if h else (f"{m}m {s}s" if m else f"{s}s")


# ---------------------------------------------------------------------------
# Starting at a set time
# ---------------------------------------------------------------------------

_TIME_RE = re.compile(r"^\s*(?:(\d{4})-(\d{1,2})-(\d{1,2})[ T]+)?(\d{1,2})(?::(\d{2}))?(?::(\d{2}))?"
                      r"\s*(am|pm)?\s*(utc|local)?\s*$", re.I)


START_GRACE = 60    # s: a start time that passed less than this ago starts right away


def parse_start_at(text: str, tz: str = "utc", now: datetime | None = None,
                   date: str | None = None) -> tuple[float, str]:
    """When to start → (epoch seconds, label).
    text: '12:45', '12:45:30', '12:45 PM', '18:45 local', '2026-09-20 12:45 UTC'.
    date: 'YYYY-MM-DD' (the dashboard sends it separately).
    With a date: that exact moment. If it passed less than START_GRACE s ago the
    session starts now; longer ago is an error (never silently moved to tomorrow).
    Without a date: the next time it happens (today, or tomorrow if already past).
    A 'utc' / 'local' word in the text wins over `tz`."""
    m = _TIME_RE.match(text or "")
    if not m:
        raise ValueError(f"'{text}' isn't a time — use e.g. 12:45, 12:45 PM or 2026-09-20 18:45 UTC")
    y, mo, d, h, mi, sec, ampm, zone = m.groups()
    h, mi, sec = int(h), int(mi or 0), int(sec or 0)
    ampm, zone = (ampm or "").lower(), (zone or tz or "utc").lower()
    if ampm:
        if not 1 <= h <= 12:
            raise ValueError("with AM/PM the hour must be 1–12")
        h = (h % 12) + (12 if ampm == "pm" else 0)
    if h > 23 or mi > 59 or sec > 59:
        raise ValueError(f"'{text}' isn't a valid time")
    now = now or datetime.now(timezone.utc)
    now = now.astimezone() if zone == "local" else now.astimezone(timezone.utc)
    if date and not y:
        dm = re.match(r"^\s*(\d{4})-(\d{1,2})-(\d{1,2})\s*$", date)
        if not dm:
            raise ValueError(f"'{date}' isn't a date — use YYYY-MM-DD")
        y, mo, d = dm.groups()
    try:
        day = now.replace(year=int(y), month=int(mo), day=int(d)) if y else now
        target = day.replace(hour=h, minute=mi, second=sec, microsecond=0)
    except ValueError:
        raise ValueError(f"'{y}-{mo}-{d}' isn't a valid date") from None
    late = (now - target).total_seconds()
    if y:                                       # an exact date was given
        if late > START_GRACE:
            raise ValueError(f"{target:%Y-%m-%d %H:%M:%S} {'UTC' if zone == 'utc' else 'local'} "
                             "has already passed — pick a later time")
    elif late > START_GRACE:                    # plain time already past today → tomorrow
        target += timedelta(days=1)
    if late > 0 and late <= START_GRACE:        # just missed it: start now
        target = now
    utc = target.astimezone(timezone.utc)
    when = f"{target:%Y-%m-%d %H:%M:%S}"
    label = f"{when} UTC" if zone == "utc" else f"{when} local ({utc:%H:%M:%S} UTC)"
    return target.timestamp(), label


def _duration(sec: float) -> str:
    sec = max(0, int(sec))
    h, m = divmod(sec // 60, 60)
    return f"{h} h {m} min" if h else f"{m} min {sec % 60} s"
