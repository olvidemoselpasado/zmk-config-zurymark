"""The locked bot's configuration lives on the server.

At boot (`boot`), before the dashboard's controls exist: the bot gives the server its
key, waits -- showing its code on the screen -- until it has been approved on the
server's page, then downloads its configuration (its whole data folder, as it was last
saved) and its casino logins, and only then starts. Nothing of it was on the stick.

While it runs (`ConfigSync`): every few seconds it looks whether anything in the data
folder changed, and sends it:
  - the set-up (coordinates, regions, patterns, settings, sites, the game's page …):
    as soon as it has stopped changing for a look -- a burst of edits is one upload;
  - what it learnt (the recorded tables, the run history, the table calls): when no
    session is running -- at the end of each session, not after every hand;
  - the casino logins: on their own, to /v1/login -- never inside the configuration.

Never sent: logs/, debug/ (screenshots), attic/, the bot's id and key.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import tarfile
import threading
import time
from pathlib import Path, PurePosixPath
from urllib.parse import quote

from baccarat.log import log
from baccarat.store.paths import data_dir
from baccarat.web import template
from baccarat.web.remote import Remote, ServerError

LOOK = 10                                  # s between looks at the data folder
SKIP_DIRS = {"logs", "debug", "attic", "__pycache__", ".incoming"}
KEEP_HERE = {"bot_id", "bot_key", "resume.json", "resume.new"}          # this bot's own: never sent, never replaced
LEARNED = ("tables", "runs.json", "table_calls.json")
MAX_SIZE = 120 * 1024 * 1024


def _skip(rel: PurePosixPath) -> bool:
    return (rel.parts[0] in SKIP_DIRS or (len(rel.parts) == 1 and rel.name in KEEP_HERE)
            or rel.name == "login.json" or rel.name.endswith(".tmp") or "__pycache__" in rel.parts)


def files(root: Path) -> list[tuple[PurePosixPath, Path]]:
    """What a configuration is made of: every file of the data folder that is sent."""
    out = []
    for p in sorted(root.rglob("*")):
        if p.is_file() and not p.is_symlink():
            rel = PurePosixPath(p.relative_to(root).as_posix())
            if not _skip(rel):
                out.append((rel, p))
    return out


def learned(rel: PurePosixPath) -> bool:
    return rel.parts[0] in LEARNED


def fingerprints(root: Path) -> tuple[str, str, str]:
    """(set-up, learnt, logins): each changes when anything in it does."""
    a, b, c = hashlib.sha256(), hashlib.sha256(), hashlib.sha256()
    for rel, p in files(root):
        st = p.stat()
        (b if learned(rel) else a).update(f"{rel}\0{st.st_size}\0{st.st_mtime_ns}\n".encode())
    for f in sorted(root.glob("sites/*/login.json")):
        try:
            c.update(f.parent.name.encode() + b"\0" + f.read_bytes())
        except OSError:
            pass
    return a.hexdigest(), b.hexdigest(), c.hexdigest()


def pack(root: Path) -> bytes:
    """The data folder as a .tar.gz, without what is never sent."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz", compresslevel=6) as t:
        for rel, p in files(root):
            info = tarfile.TarInfo(str(rel))
            st = p.stat()
            info.size, info.mtime, info.mode = st.st_size, int(st.st_mtime), 0o600
            with open(p, "rb") as f:
                t.addfile(info, f)
    return buf.getvalue()


def unpack(data: bytes, root: Path) -> int:
    """Replace the data folder's configuration with this one (its logs, screenshots and
    this bot's id and key stay). Only plain files, only inside the folder. → files."""
    root.mkdir(parents=True, exist_ok=True)
    incoming = root / ".incoming"
    shutil.rmtree(incoming, ignore_errors=True)
    incoming.mkdir(mode=0o700)
    n = 0
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as t:
        for m in t:
            rel = PurePosixPath(m.name)
            if m.isdir():
                continue
            if (not m.isfile() or rel.is_absolute() or ".." in rel.parts or not rel.parts
                    or _skip(rel)):
                log.warning("Configuration from the server: '%s' left out (not a plain file "
                            "inside the data folder).", m.name)
                continue
            dest = incoming.joinpath(*rel.parts)
            dest.parent.mkdir(parents=True, exist_ok=True)
            src = t.extractfile(m)
            fd = os.open(dest, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "wb") as out:
                shutil.copyfileobj(src, out)
            os.utime(dest, (m.mtime, m.mtime))
            n += 1
    for p in root.iterdir():                     # out with the old …
        if p.name in SKIP_DIRS or p.name in KEEP_HERE:
            continue
        shutil.rmtree(p) if p.is_dir() and not p.is_symlink() else p.unlink()
    for p in incoming.iterdir():                 # … in with the new
        p.rename(root / p.name)
    incoming.rmdir()
    return n


def collect_logins(root: Path) -> dict:
    out = {}
    for f in sorted(root.glob("sites/*/login.json")):
        try:
            d = json.loads(f.read_text())
        except (OSError, ValueError):
            continue
        if isinstance(d, dict) and (d.get("email") or d.get("password")):
            out[f.parent.name] = {"email": str(d.get("email") or ""),
                                  "password": str(d.get("password") or "")}
    return out


def write_logins(root: Path, sites: dict) -> int:
    n = 0
    for site, d in (sites or {}).items():
        if not isinstance(d, dict) or "/" in site or site.startswith("."):
            continue
        f = root / "sites" / site / "login.json"
        f.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(f, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as out:
            json.dump({"email": str(d.get("email") or ""), "password": str(d.get("password") or "")}, out)
        n += 1
    return n


# ---------------------------------------------------------------------------------------
# at boot
# ---------------------------------------------------------------------------------------

def boot(dash, remote: Remote | None = None, wait=time.sleep) -> "ConfigSync":
    """Get this bot's configuration and logins from the server before anything else.
    Shows where it is on the dashboard's boot page (dash.boot) the whole time; returns
    once it has them (or the server has none yet: then it starts empty, to be set up)."""
    remote = remote or Remote()
    root = data_dir()
    if not remote.url:
        raise SystemExit("The locked bot needs its server: set BACCARAT_SERVER.")

    def say(state: str, text: str, **more) -> None:
        dash.boot = {"state": state, "text": text, "code": remote.code, "id": remote.id, **more}

    say("start", "Asking the server for this bot's configuration…")
    pause = 3
    while True:
        try:
            reply = remote.enroll()
            if not reply.get("trusted"):
                say("approval", "This bot is waiting to be approved on the server's page. "
                    "Check that the code there is the same as this one, and press Approve.")
                wait(5)
                continue
            status, headers, data = remote.call("GET", "/v1/config", timeout=120)
            if status == 200:
                n = unpack(data, root)
                cid = headers.get("X-Config-Id", "")
                log.info("Configuration loaded from the server: %d files (%d KB).", n, len(data) // 1024)
            elif status == 404:
                cid = ""
                log.info("The server has no configuration for this bot yet: set it up on the "
                         "dashboard and it will be kept there.")
            elif status == 403:
                continue                              # approval taken back meanwhile
            else:
                raise ServerError(status, f"the server answered {status} for the configuration")
            status, reply = remote.json("GET", "/v1/login")
            if status == 200:
                k = write_logins(root, reply.get("sites") or {})
                if k:
                    log.info("Casino login loaded from the server for %d site(s).", k)
            fetch_template(remote)
            say("done", "Ready.")
            return ConfigSync(dash, remote, loaded=cid)
        except ServerError as e:
            say("refused", f"The server refuses this bot: {e}", error=str(e))
            wait(15)
        except OSError as e:
            why = str(getattr(e, "reason", e))
            say("offline", f"Can't reach the server ({remote.url}): {why}. Trying again…", error=why)
            wait(pause)
            pause = min(30, pause * 2)


def fetch_template(remote: Remote) -> bool:
    """The server's template for this bot, if any. → whether it changed."""
    status, reply = remote.json("GET", "/v1/template")
    if status != 200:
        return False
    name, settings = reply.get("name"), reply.get("settings") or {}
    changed = template.set_current(name, settings)
    if changed:
        log.info("Game set-up: %s.", f"the server's template '{name}' — its fields are locked here"
                 if name else "this bot's own (no template on the server)")
    return changed


# ---------------------------------------------------------------------------------------
# while running
# ---------------------------------------------------------------------------------------

class ConfigSync:
    def __init__(self, dash, remote: Remote, loaded: str = ""):
        self.dash, self.remote = dash, remote
        self.root = data_dir()
        self.saved = fingerprints(self.root)          # what the server has: what was just loaded
        self.loaded = loaded
        self.seen = self.saved
        self.last_ok: float | None = time.time() if loaded else None
        self.error: str | None = None
        self.quit = threading.Event()
        self.thread: threading.Thread | None = None
        self.retry_at = 0.0
        self.template_at = 0.0
        self.on_template = None            # called when the server's template changed

    def start(self) -> "ConfigSync":
        self.publish()
        self.thread = threading.Thread(target=self.loop, name="configsync", daemon=True)
        self.thread.start()
        return self

    def loop(self) -> None:
        while not self.quit.wait(LOOK):
            try:
                self.look()
            except Exception as e:                     # never take the bot down
                log.debug("configsync: %s", e)

    def look(self, final: bool = False) -> None:
        now = fingerprints(self.root)
        steady = now == self.seen or final            # unchanged since the last look
        self.seen = now
        if time.time() < self.retry_at and not final:
            return
        running = bool(self.dash.snapshot().get("running"))
        if not running and not final and time.time() - self.template_at >= 60:
            self.template_at = time.time()
            try:
                if fetch_template(self.remote) and self.on_template:
                    self.on_template()
            except OSError:
                pass
        if now[2] != self.saved[2]:
            self.send_logins(now)
        setup_changed = now[0] != self.saved[0]
        learnt_changed = now[1] != self.saved[1] and (not running or final)
        if steady and (setup_changed or learnt_changed):
            self.send_config(now, "set-up changed" if setup_changed else "tables recorded")

    def send_logins(self, now) -> None:
        status, reply = self.remote.json("PUT", "/v1/login", {"sites": collect_logins(self.root)})
        if status == 200:
            self.saved = (self.saved[0], self.saved[1], now[2])
            log.info("Casino login saved on the server (on this computer it is only in memory).")
        else:
            self.failed(reply.get("error") or f"the server answered {status}")

    def send_config(self, now, why: str) -> None:
        data = pack(self.root)
        if len(data) > MAX_SIZE:
            self.failed(f"the configuration is {len(data) // 1048576} MB: too big to keep on the server")
            return
        try:
            status, _, body = self.remote.call("PUT", "/v1/config", data,
                                               {"Content-Type": "application/gzip",
                                                "X-Why": quote(why)}, timeout=300)
        except OSError as e:
            self.failed(str(getattr(e, "reason", e)))
            return
        if status != 200:
            try:
                err = json.loads(body).get("error")
            except (ValueError, AttributeError):
                err = None
            self.failed(err or f"the server answered {status}")
            return
        self.saved = (now[0], now[1], self.saved[2])
        self.last_ok, self.error = time.time(), None
        log.info("Configuration saved on the server (%d KB, %s).", len(data) // 1024, why)
        self.publish()

    def failed(self, why: str) -> None:
        if why != self.error:
            log.warning("Couldn't save the configuration on the server: %s — trying again.", why)
        self.error = why
        self.retry_at = time.time() + 60
        self.publish()

    def publish(self) -> None:
        pending = self.seen != self.saved
        self.dash.update(sync={"ok": self.error is None, "error": self.error,
                               "saved": self.last_ok, "pending": pending})

    def stop(self) -> None:
        """Before the bot quits (the computer going off): whatever changed goes now."""
        self.quit.set()
        if self.thread:
            self.thread.join(timeout=LOOK + 1)
        try:
            self.retry_at = 0
            self.look(final=True)
        except Exception as e:
            log.warning("The last changes couldn't be saved on the server: %s", e)
