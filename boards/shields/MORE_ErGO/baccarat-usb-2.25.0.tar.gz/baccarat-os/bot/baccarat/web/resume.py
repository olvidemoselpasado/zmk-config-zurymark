"""A session stopped for an update, started again by itself once it is installed.

When the stick's update is downloaded during a session, the session plays out the run
in progress and stops at the base bet (play/player.py, update_due). What it would need
to carry on is written here: the same set-up, with the balance it ended on as the
budget and the same target. Once nothing holds the start back any more (the update is
installed -- the bot may have been restarted by it in between -- or it failed), the
session starts again: the table is opened as at any start.

Kept on this stick only (configsync never sends or replaces it), and only for half an
hour: a stick switched off in between doesn't start betting on its own hours later.
Starting a session by hand, or "Don't carry on" on the dashboard, drops it.
"""

from __future__ import annotations

import json
import os
import threading
import time

from baccarat.log import log
from baccarat.store.paths import data_dir
from baccarat.web import updatestatus

NAME = "resume.json"
MAX_AGE = 30 * 60          # s: older than this, it is not carried on
SETTLE = 15                # s after the update before the table is opened again


def _file():
    return data_dir() / NAME


def save(body: dict, balance: float, ceiling: float | None, cycles_left: int | None,
         why: str, step: float | None = None) -> dict:
    over = {"budget": f"{balance:.2f}", "target": f"={ceiling:.2f}" if ceiling else "",
            "ask_road": False, "start_at": ""}
    if cycles_left:
        over["cycles"] = str(cycles_left)
        if step:
            over["ceiling_step"] = f"{step:.2f}"   # the next targets as they were
    rec = {"at": time.time(), "why": why, "body": body, "over": over}
    f = _file()
    tmp = f.with_suffix(".new")
    tmp.write_text(json.dumps(rec))
    os.chmod(tmp, 0o600)
    os.replace(tmp, f)
    log.info("The session carries on by itself once %s is installed: balance %.2f as the "
             "budget%s.", why, balance, f", target {ceiling:,.2f}" if ceiling else "")
    return rec


def peek() -> dict | None:
    try:
        rec = json.loads(_file().read_text())
    except (OSError, ValueError):
        return None
    if not isinstance(rec, dict) or time.time() - float(rec.get("at") or 0) > MAX_AGE:
        drop()
        return None
    return rec


def take() -> dict | None:
    rec = peek()
    if rec:
        drop()
    return rec


def drop() -> None:
    try:
        _file().unlink()
    except OSError:
        pass


def shown(rec: dict | None) -> dict | None:
    """What the dashboard shows of it (never the set-up itself)."""
    return {"why": rec.get("why"), "at": rec.get("at")} if rec else None


def watch(ctl, every: float = 3.0) -> threading.Thread:
    """Start the stopped session again once the update is done with."""
    def ready(st) -> bool:
        return not updatestatus.holding(st)

    def loop():
        clear_since = None
        said = None
        while True:
            time.sleep(every)
            rec = peek()
            if said != (rec or {}).get("at"):
                said = (rec or {}).get("at")
                ctl.dash.update(resume=shown(rec))
            if not rec:
                clear_since = None
                continue
            if ctl.running:                    # started by hand meanwhile
                drop()
                continue
            if not ready(updatestatus.read()):
                clear_since = None
                continue
            clear_since = clear_since or time.monotonic()
            if time.monotonic() - clear_since < SETTLE:
                continue
            rec = take()
            if not rec:
                continue
            ctl.dash.update(resume=None)
            st = updatestatus.read() or {}
            log.info("Carrying on with the session stopped for %s (the update is %s).",
                     rec.get("why"), st.get("state") or "done")
            try:
                ctl.start({**rec["body"], "resume": rec["over"]})
            except Exception as e:             # e.g. the set-up changed meanwhile
                log.error("Couldn't carry on with the session: %s", e)
                ctl.dash.update(error=f"Couldn't carry on with the session after the update: {e}")
    t = threading.Thread(target=loop, name="resume", daemon=True)
    t.start()
    return t
