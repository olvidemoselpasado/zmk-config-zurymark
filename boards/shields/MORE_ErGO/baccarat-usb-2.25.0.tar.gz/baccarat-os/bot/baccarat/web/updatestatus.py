"""Where the USB stick's own update is: downloading (how far), waiting for the session
to end, installing.

The stick's updater (modules/updates.nix, run as root) writes it to a file anyone may
read; this shows it on the dashboard -- a bar, and Start held back while an update is
about to be installed, so a session is never cut off by it -- and the uplink passes it
on to the server's page. A session in play when the download is done stops at its next
base bet for it (play/player.py, update_due) and carries on afterwards (resume.py). A status nobody has refreshed for a minute is stale (the
updater stopped): it holds nothing back. Not on a stick: there is no file, and nothing
shows.
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
from pathlib import Path

from baccarat import __version__

FILE = Path(os.environ.get("BACCARAT_UPDATE_STATUS", "/run/baccarat-update-status/status.json"))
# Writing here starts the stick's updater at once (a systemd path unit watches it): how
# a newly published release is fetched within seconds of the server mentioning it,
# instead of at the updater's next look.
POKE = Path(os.environ.get("BACCARAT_UPDATE_POKE", "/run/baccarat-update-poke/now"))
CURRENT = Path(os.environ.get("BACCARAT_CURRENT_SYSTEM", "/run/current-system"))
STALE = 60            # s without a heartbeat: the updater isn't there any more
BUSY = ("downloading", "waiting", "installing")
POKE_EVERY = 60       # s between pokes for the same release (queued: try again)
_poked: dict = {"system": None, "at": 0.0}


def read() -> dict | None:
    try:
        st = json.loads(FILE.read_text())
    except (OSError, ValueError):
        return None
    if not isinstance(st, dict):
        return None
    # a download in progress beats every 2 s, a waiting one every 5 s; "queued" is
    # written once a try and refreshed when the bot wakes the updater again (~1 min)
    most = STALE * 3 if st.get("state") in ("queued", "failed") else STALE
    st["stale"] = time.time() - float(st.get("at") or 0) > most
    total, done = st.get("total") or 0, st.get("done") or 0
    st["pct"] = round(100 * done / total) if total else None
    return st


def holding(st: dict | None) -> bool:
    """Is an update about to be installed? Then a session must not start."""
    return bool(st) and not st.get("stale") and st.get("state") in BUSY


def _key(v: str) -> tuple:
    return tuple(int(n) for n in re.findall(r"\d+", v.split("-")[0]))


def older(v: str, than: str) -> bool:
    """Is version v before `than`? ('2.22.2' before '2.23.0'; an unknown one isn't.)"""
    return bool(_key(v)) and bool(_key(than)) and _key(v) < _key(than)


def poke(release: dict | None, now: float | None = None) -> bool:
    """The server says which system is out. Not this stick's, and its updater isn't on
    it already: wake the updater. True = poked."""
    if not isinstance(release, dict) or not POKE.parent.is_dir():
        return False                          # not a stick (or one without the path unit)
    want = str(release.get("system") or "")
    if not want.startswith("/nix/store/"):
        return False
    if older(str(release.get("version") or ""), __version__):
        return False                          # never backwards (the updater checks too)
    try:
        if os.path.realpath(CURRENT) == want:
            return False                      # already running it
    except OSError:
        pass
    st = read()
    if holding(st) or (st and not st.get("stale") and st.get("state") == "installing"):
        return False                          # on its way
    now = time.time() if now is None else now
    if _poked["system"] == want and now - _poked["at"] < POKE_EVERY:
        return False
    try:
        tmp = POKE.with_suffix(".new")
        tmp.write_text(f"{want}\n")
        os.replace(tmp, POKE)
    except OSError:
        return False
    _poked.update(system=want, at=now)
    return True


def why(st: dict) -> str:
    v = st.get("version") or "?"
    if st.get("state") == "downloading":
        pct = st.get("pct")
        return f"Update {v} is downloading{f' ({pct}%)' if pct is not None else ''}"
    if st.get("state") == "waiting":
        return f"Update {v} is downloaded and installs as soon as this session ends"
    return f"Update {v} is installing"


def watch(dash, every: float = 2.0) -> threading.Thread:
    """Keep the dashboard told (only when it changes)."""
    def loop():
        last = None
        while True:
            st = read()
            key = json.dumps(st, sort_keys=True, default=str) if st else None
            if key != last:
                dash.update(update=st)
                last = key
            time.sleep(every)
    t = threading.Thread(target=loop, name="update-status", daemon=True)
    t.start()
    return t
