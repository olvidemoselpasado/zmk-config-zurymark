"""Talking to the server: who this bot is, its secret key, and signed calls.

Who: an id (data/bot_id, made once; on the USB stick, the stick's own, given as
$BACCARAT_BOT_ID). Its key: 32 random bytes, made once and never sent again after the
first call (/v1/enroll) -- on the stick it is kept on the stick, readable by root only,
and handed to this service by systemd ($CREDENTIALS_DIRECTORY/bot-key); elsewhere in
data/bot_key (0600).

Every call is signed with it: HMAC-SHA256 of the method, the path, the time and a hash
of the body. So nobody else can speak for this bot, and the server gives it its
configuration and its casino login only once it has been approved on the server's page
(where the same short code as on this bot's screen is shown).

Where: $BACCARAT_SERVER (e.g. http://192.168.0.2:4444, or https://...), else SERVER
below; "off" turns it off. HTTPS with a certificate of your own: $BACCARAT_SERVER_CA is
the file to trust.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import ssl
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

from baccarat import __version__
from baccarat.log import log
from baccarat.store.paths import data_dir

SERVER = "http://192.168.0.2:4444"
TIMEOUT = 15


def server_url() -> str | None:
    url = (os.environ.get("BACCARAT_SERVER") or SERVER).strip().rstrip("/")
    if not url or url.lower() in ("off", "none", "no"):
        return None
    return url if "://" in url else "http://" + url


def locked() -> bool:
    """The locked bot (the USB stick): its configuration lives on the server."""
    return os.environ.get("BACCARAT_LOCKED", "").strip().lower() in ("1", "yes", "true", "on")


def _private_file(f: Path, text: str) -> None:
    f.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(f, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as out:
        out.write(text + "\n")


def bot_id() -> str:
    env = (os.environ.get("BACCARAT_BOT_ID") or "").strip()
    if env:
        return env
    f = data_dir() / "bot_id"
    try:
        got = f.read_text().strip()
        if got:
            return got
    except OSError:
        pass
    new = uuid.uuid4().hex
    try:
        _private_file(f, new)
    except OSError as e:
        log.warning("Couldn't keep this bot's id (%s): the server will see a new bot each start.", e)
    return new


def bot_key() -> str:
    """This bot's secret, as 64 hex digits. Whatever the file holds is used: 64 hex
    digits as they are, anything else through SHA-256."""
    for f in (Path(os.environ["CREDENTIALS_DIRECTORY"]) / "bot-key"
              if os.environ.get("CREDENTIALS_DIRECTORY") else None,
              Path(os.environ["BACCARAT_BOT_KEY_FILE"])
              if os.environ.get("BACCARAT_BOT_KEY_FILE") else None):
        if f is not None and f.is_file():
            raw = f.read_bytes().strip()
            return _as_key(raw)
    f = data_dir() / "bot_key"
    try:
        raw = f.read_bytes().strip()
        if raw:
            return _as_key(raw)
    except OSError:
        pass
    new = secrets.token_hex(32)
    _private_file(f, new)
    return new


def _as_key(raw: bytes) -> str:
    s = raw.decode(errors="replace").strip().lower()
    return s if re.fullmatch(r"[0-9a-f]{64}", s) else hashlib.sha256(raw).hexdigest()


def code_of(key: str) -> str:
    """The short code shown on this bot's screen and on its page on the server."""
    h = hashlib.sha256(bytes.fromhex(key)).hexdigest()[:8].upper()
    return f"{h[:4]}-{h[4:]}"


def signature(key: str, method: str, path: str, when: str, body: bytes) -> str:
    msg = f"{method}\n{path}\n{when}\n{hashlib.sha256(body).hexdigest()}".encode()
    return hmac.new(bytes.fromhex(key), msg, hashlib.sha256).hexdigest()


def computer() -> str:
    try:
        with open("/sys/class/dmi/id/product_name") as f:    # readable by anyone, on Linux
            name = f.read().strip()
        with open("/sys/class/dmi/id/sys_vendor") as f:
            vendor = f.read().strip()
        return f"{vendor} {name}".strip()
    except OSError:
        import platform
        return platform.node()


class ServerError(Exception):
    def __init__(self, status: int, message: str, reply: dict | None = None):
        super().__init__(message)
        self.status, self.reply = status, reply or {}


class Remote:
    """One bot's line to the server."""

    def __init__(self, url: str | None = None):
        self.url = url if url is not None else server_url()
        self.id = bot_id() if self.url else ""
        self.key = bot_key() if self.url else ""
        self.code = code_of(self.key) if self.key else ""
        self.offset = 0.0              # the server's clock minus ours, once it has said
        self.ctx = None
        ca = os.environ.get("BACCARAT_SERVER_CA")
        if self.url and self.url.startswith("https") and ca:
            self.ctx = ssl.create_default_context(cafile=ca)

    def call(self, method: str, path: str, body: bytes = b"", headers: dict | None = None,
             timeout: float = TIMEOUT, sign: bool = True) -> tuple[int, dict, bytes]:
        """→ (status, headers, body). Network trouble raises OSError."""
        for attempt in (1, 2):
            when = f"{time.time() + self.offset:.3f}"
            h = {"User-Agent": f"baccarat-bot/{__version__}", **(headers or {})}
            if sign:
                h.update({"X-Bot": self.id, "X-Time": when,     # the path signed, not its ?query
                          "X-Sign": signature(self.key, method, path.split("?")[0], when, body)})
            req = urllib.request.Request(self.url + path, data=body if method != "GET" else None,
                                         method=method, headers=h)
            try:
                with urllib.request.urlopen(req, timeout=timeout, context=self.ctx) as r:
                    return r.status, dict(r.headers), r.read()
            except urllib.error.HTTPError as e:
                data = e.read()
                if e.code == 401 and attempt == 1:
                    reply = _json(data)
                    if reply.get("error") == "clock" and isinstance(reply.get("now"), (int, float)):
                        # this computer's clock is off: sign with the server's time instead
                        self.offset = reply["now"] - time.time()
                        log.info("This computer's clock is %.0f s off the server's — using "
                                 "the server's.", self.offset)
                        continue
                return e.code, dict(e.headers), data
        return 401, {}, b"{}"

    def json(self, method: str, path: str, obj=None, timeout: float = TIMEOUT,
             sign: bool = True) -> tuple[int, dict]:
        body = json.dumps(obj, separators=(",", ":")).encode() if obj is not None else b""
        status, _, data = self.call(method, path, body, {"Content-Type": "application/json"},
                                    timeout, sign)
        return status, _json(data)

    def info(self) -> dict:
        import platform
        return {"version": __version__, "computer": computer(), "host": platform.node(),
                "os": "USB stick" if os.environ.get("BACCARAT_OS") else platform.system(),
                "python": platform.python_version(), "locked": locked()}

    def enroll(self) -> dict:
        """Give the server this bot's key (only the first time does it keep it).
        → {trusted, code}. Raises ServerError if the server refuses."""
        status, reply = self.json("POST", "/v1/enroll",
                                  {"bot": self.id, "key": self.key, "info": self.info()}, sign=False)
        if status != 200:
            raise ServerError(status, reply.get("error") or f"the server answered {status}", reply)
        return reply


def _json(data: bytes) -> dict:
    try:
        d = json.loads(data or b"{}")
        return d if isinstance(d, dict) else {}
    except ValueError:
        return {}
