"""The game set-up a locked bot plays, when the server gives it a template.

A template holds the GAME set-up -- strategy, budget, base, target, rules, extra life,
cut-off, pattern and table-kind judging -- and nothing else: where to click, the timing,
the login and the game's page stay this bot's own. Several bots on one template, others
on another: the server compares how each did, and suggests.

While a template is set, the dashboard shows those fields locked, and whatever the page
sends, a session starts with the template's values. The server says which template, and
its values, at boot and then every minute while no session runs (configsync.py); a
change is taken before the next session, never in the middle of one.
"""

from __future__ import annotations

import threading

# as the server's GAME_KEYS
GAME_KEYS = ("strategy", "budget", "base", "max_steps", "target", "rules", "cycles",
             "at_cutoff", "cutoff_margin", "shadow_unit", "shadow_after", "shadow_min_lives",
             "extra_on", "extra_every", "extra_strict", "extra_after", "extra_for",
             "pattern_leave", "kind_on", "kind_exceptional", "kind_regular", "kind_after")

_lock = threading.Lock()
_current: dict = {"name": None, "settings": {}}


def current() -> dict:
    with _lock:
        return {"name": _current["name"], "settings": dict(_current["settings"])}


def set_current(name: str | None, settings: dict | None) -> bool:
    """→ whether it changed."""
    new = {"name": name or None,
           "settings": {k: v for k, v in (settings or {}).items() if k in GAME_KEYS} if name else {}}
    with _lock:
        changed = new != _current
        _current.update(new)
    return changed


def apply(values: dict) -> dict:
    """The template's game set-up over `values` (settings, or what the page sent)."""
    t = current()
    return {**values, **t["settings"]} if t["name"] else values


def game_of(settings: dict) -> dict:
    return {k: settings[k] for k in GAME_KEYS if k in settings}
