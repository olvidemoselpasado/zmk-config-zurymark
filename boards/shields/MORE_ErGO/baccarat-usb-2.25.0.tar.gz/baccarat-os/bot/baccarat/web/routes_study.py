"""Looking at what happened, and at what would have happened.

The recorded tables, the totals, one table in detail, the what-if replays and
the simulations. Nothing here can change a session or touch the screen: it
reads and it counts."""

from __future__ import annotations

from baccarat import screen as bet
from baccarat.study import expect
import analysis
from baccarat.log import log
from baccarat import core as strategies
from baccarat.core.game import SIDES
from baccarat.core.rules import config_key
from baccarat.core.strategy import STRATEGIES
from baccarat.store.history import reset_runs, run_history
from baccarat.play.reading import parse_road, road_from_screen
from baccarat.setup import (
    _num, _unknown_action, click_cost, session_params, timing_params)


class StudyRoutes:
    """Mixed into Player. See the module docstring."""

    def history(self, body: dict) -> dict:
        """What the losing runs really played with this strategy + these rules needed.
        The budget and base bet are not part of the configuration."""
        strategy = body.get("strategy") or ""
        if strategy not in STRATEGIES:
            raise ValueError("pick a strategy first")
        key = config_key(strategy, body.get("rules") or [])
        if body.get("action") == "reset":
            gone = reset_runs(key)
            log.info("Run history reset for '%s' (%d runs, worst %d lives) — the old one is in "
                     "data/attic.", key, gone.get("runs", 0), gone.get("max_lives", 0))
            p = getattr(self, "player", None)
            if p is not None and p.s.config == key:     # the session playing it forgets too
                p.run_stats = run_history(key)
                p.push()
        return {"result": run_history(key)}

    def stats(self, body: dict) -> dict:
        p = session_params(body)
        p.pop("target", None)                   # only the session itself uses the win target
        return {"result": analysis.stats_data(**p)}

    def table_detail(self, body: dict) -> dict:
        """One stored table, replayed hand by hand (for the Analysis screen)."""
        p = session_params(body)
        p.pop("target", None)
        name = (body.get("table") or "").strip()
        if not name:
            raise ValueError("which table?")
        if p["strategy"] == "all":
            raise ValueError("pick one strategy to look at a table")
        return {"result": analysis.table_detail(name, **p)}

    def clickcost(self, body: dict) -> dict:
        """What the longest possible bet would cost in clicks and seconds, so Setup can
        say so while you are typing instead of the session finding out mid-hand."""
        return click_cost(session_params(body), timing_params(body))

    def estimate(self, body: dict) -> dict:
        """What the target in Setup really takes: the value of a win measured by
        replaying this setup over the recorded tables (or tables dealt from the game's
        odds while there are too few), and so the wins, the hands and the risk."""
        p = session_params(body)
        if p.get("ceiling") is None or p["strategy"] == "all":
            return {"estimate": None}
        v = expect.win_value(**p)
        remaining = round(p["ceiling"] - p["budget"], 2)
        wins = expect.wins_for(remaining, v, p["base"])
        return {"estimate": {**{k: v.get(k) for k in ("source", "per_win", "hands_per_win",
                                                       "tables", "cover", "banker_share")},
                             "remaining": remaining, "wins": wins,
                             "naive": int(-(-remaining // p["base"])),
                             "hands": None if wins is None else round(wins * v["hands_per_win"]),
                             "cut_short": expect.cut_short_chance(wins, v)}}

    def whatif(self, body: dict) -> dict:
        """The table on screen, replayed as if we had joined at each hand in turn.
        'read' takes the results off the screen; 'scan' and 'detail' are given them back,
        so the same results are used however long you spend looking at them."""
        action = str(body.get("action") or "read")
        if action == "read":
            board = None
            try:                                 # the counters are a nice cross-check, not
                board = bet.read_board_stable()  # a requirement: the road stands on its own
            except Exception as e:
                log.info("Reading the table: no usable counters (%s) — using the road alone.", e)
            road = road_from_screen(board) if board else None
            if road is None:
                road = bet.read_road()
            if not road:
                raise ValueError("couldn't read this table's results. Select a 'road' region "
                                 "on the Interface tab (a box around the grid of coloured "
                                 "circles), or type the results in below.")
            return {"road": road, "board": board}
        road = body.get("road")
        if isinstance(road, str):
            road = parse_road(road)
        road = [w for w in (road or []) if w in SIDES]
        if not road:
            raise ValueError("no results to replay — read the table first")
        p = session_params(body)
        p.pop("target", None)
        if p["strategy"] == "all":
            raise ValueError("pick one strategy")
        if action == "scan":
            return {"result": analysis.entry_scan(
                road, int(body.get("first") or 1),
                int(body.get("last") or len(road)), **p)}
        if action == "detail":
            return {"result": analysis.entry_detail(road, int(body.get("at") or 1), **p)}
        if action == "screen":
            # what the Setup patterns make of this table, had the bot walked up to it
            screens = strategies.build_patterns(body.get("screens") or [])
            if not screens:
                raise ValueError("no patterns are ticked in Setup — nothing to look for")
            least = _num(body, "screen_min", "Results needed to judge a table",
                         integer=True, optional=True)
            return {"result": strategies.screen_table(
                road, screens, 20 if least is None else int(least))}
        raise _unknown_action(action, ("read", "scan", "detail", "screen"))

    def simulate(self, body: dict) -> dict:
        p = session_params(body)
        p.pop("target", None)                   # only the session itself uses the win target
        if p["strategy"] == "all":
            raise ValueError("pick one strategy to simulate")
        rounds = _num(body, "rounds", "Rounds per session", integer=True)
        runs = _num(body, "runs", "Sessions", integer=True)
        if rounds * runs > 5_000_000:
            raise ValueError("that's too many rounds in total — keep rounds × sessions under 5 million")
        seed = _num(body, "seed", "Seed", positive=False, integer=True, optional=True)
        d = analysis.random_data(**p, rounds=rounds, runs=runs, seed=seed)
        ex = d.pop("example")
        d["example"] = ex.report()
        return {"result": d}
