"""
dashboard — a small local web page that shows what main.py is doing.

main.py --ui starts it; open the printed address (http://127.0.0.1:8765) in a
SEPARATE browser window, placed where it doesn't cover the game: the bot reads
the game from the screen and clicks on it.

Only the Python standard library is used. The page is dashboard.html (it's
re-read on every load, so you can restyle it while the bot runs).
"""

from __future__ import annotations

import json
import logging
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from baccarat.store import paths
from urllib.parse import parse_qs, unquote, urlparse

# Shipped with the code, not with your data, so it comes from the package.
HTML_FILE = paths.web_file("dashboard.html")
BOOT_FILE = paths.web_file("boot.html")       # the locked bot, before its configuration is in

log = logging.getLogger("dashboard")

# The alarm: by default the page makes its own sound, so nothing has to be installed.
# Drop a file with one of these names next to this one and it plays that instead.
ALARM_NAMES = ("alarm.mp3", "alarm.ogg", "alarm.wav", "alarm.m4a")
ALARM_TYPES = {".mp3": "audio/mpeg", ".ogg": "audio/ogg", ".wav": "audio/wav",
               ".m4a": "audio/mp4"}


def alarm_file() -> Path | None:
    """The sound file to play, if you put one next to dashboard.py."""
    here = Path(__file__).parent
    return next((f for f in (here / n for n in ALARM_NAMES) if f.is_file()), None)



class LogBuffer(logging.Handler):
    """Keeps the last log lines so the page's console can show them."""

    def __init__(self, size: int = 8000):
        super().__init__()
        self.lines: deque = deque(maxlen=size)
        self.seq = 0
        self.session_from = 0          # the first line of the session in play (or last played)
        self.session_day = ""
        self.lines_lock = threading.Lock()
        self.setFormatter(logging.Formatter("%(asctime)s  %(levelname)-8s  %(message)s", "%H:%M:%S"))

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
        except Exception:
            return
        with self.lines_lock:
            self.seq += 1
            self.lines.append({"n": self.seq, "level": record.levelname, "text": msg})

    def mark_session(self) -> None:
        """A session starts: the report covers from here on (the bot may have been up
        for days, and what happened yesterday is not this session's)."""
        with self.lines_lock:
            self.session_from = self.seq + 1
        import time as _t
        self.session_day = _t.strftime("%Y-%m-%d")

    def session_lines(self) -> list:
        with self.lines_lock:
            return [line for line in self.lines if line["n"] >= self.session_from]

    def since(self, n: int) -> dict:
        with self.lines_lock:
            return {"seq": self.seq, "lines": [l for l in self.lines if l["n"] > n]}


class Dashboard:
    def __init__(self, port: int = 8765, shots_dir: Path | None = None, snaps_dir=None):
        self.port = port
        self.shots_dir = shots_dir          # screenshots the page may show (read-only)
        # the saved screen regions. A callable, because the folder moves with the site.
        self.snaps_dir = snaps_dir
        self._state: dict = {}
        self._lock = threading.Lock()
        self.logs = LogBuffer()
        logging.getLogger().addHandler(self.logs)
        self._server: ThreadingHTTPServer | None = None
        self._routes: dict = {}
        # the locked bot, while it gets its configuration from the server: the page shows
        # where it is ({state, text, code}) instead of the controls, which don't exist yet
        self.boot: dict | None = None
        self.game_url = lambda: ""        # the game's page, for the USB stick's window

    def route(self, path: str, fn) -> None:
        """POST `path` with a JSON body → fn(body) → JSON reply.
        Raise ValueError (or any error) to answer 400 with {"error": message}."""
        self._routes[path] = fn

    def replace(self, **values) -> None:
        """Replace the whole state (keeps keys listed in `keep`)."""
        with self._lock:
            keep = {k: self._state[k] for k in values.pop("keep", []) if k in self._state}
            self._state = {**keep, **values, "updated": time.time()}

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    def update(self, **values) -> None:
        with self._lock:
            self._state.update(values)
            self._state["updated"] = time.time()

    def snapshot(self) -> dict:
        with self._lock:
            return dict(self._state)

    def start(self) -> None:
        dash = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):          # keep the terminal clean
                pass

            def _send(self, code: int, body: bytes, ctype: str) -> None:
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):
                u = urlparse(self.path)
                if u.path in ("/", "/index.html") and dash.boot is not None:
                    try:
                        self._send(200, BOOT_FILE.read_bytes(), "text/html; charset=utf-8")
                    except OSError:
                        self._send(200, b"Starting...", "text/plain")
                elif u.path == "/api/boot":
                    self._send(200, json.dumps(dash.boot or {"state": "done"}).encode(),
                               "application/json")
                elif u.path == "/api/game-url":
                    # asked by the USB stick's screen: which page to open beside the dashboard
                    # (not before the configuration is in: it is part of it)
                    ready = dash.boot is None
                    try:
                        url = dash.game_url() if ready else ""
                    except Exception:
                        url = ""
                    self._send(200, json.dumps({"ready": ready, "url": url}).encode(),
                               "application/json")
                elif u.path in ("/", "/index.html"):
                    try:
                        # stamp the page with the file's own date, so the footer always
                        # says which dashboard.html the browser is really showing
                        html = HTML_FILE.read_bytes().replace(
                            b"__BUILD__",
                            time.strftime("%d %b %H:%M",
                                          time.localtime(HTML_FILE.stat().st_mtime)).encode())
                        self._send(200, html, "text/html; charset=utf-8")
                    except OSError:
                        self._send(500, b"dashboard.html is missing from baccarat/web/static/",
                                   "text/plain")
                elif u.path == "/api/state":
                    body = json.dumps(dash.snapshot(), default=str).encode()
                    self._send(200, body, "application/json")
                elif u.path.startswith("/shot/") and dash.shots_dir:
                    # a screenshot from the debug folder, by file name only
                    name = Path(unquote(u.path[len("/shot/"):])).name
                    f = dash.shots_dir / name
                    try:
                        self._send(200, f.read_bytes(), "image/png")
                    except OSError:
                        self._send(404, b"gone", "text/plain")
                elif u.path.startswith("/snap/") and dash.snaps_dir:
                    # a saved screen region, so the page can show what the bot reads
                    d = dash.snaps_dir() if callable(dash.snaps_dir) else dash.snaps_dir
                    name = Path(unquote(u.path[len("/snap/"):])).name
                    try:
                        self._send(200, (Path(d) / name).read_bytes(), "image/png")
                    except OSError:
                        self._send(404, b"not selected yet", "text/plain")
                elif u.path == "/alarm-sound":
                    f = alarm_file()
                    if f is None:
                        self._send(404, b"no sound file", "text/plain")   # the page makes its own
                        return
                    try:
                        self._send(200, f.read_bytes(),
                                   ALARM_TYPES.get(f.suffix.lower(), "application/octet-stream"))
                    except OSError:
                        self._send(404, b"can't read it", "text/plain")
                elif u.path == "/api/report":
                    # everything needed to look into a problem, as plain text to paste
                    from baccarat.web import report
                    q = parse_qs(u.query)
                    n = int(q.get("lines", ["300"])[0] or 0)
                    # this session's lines only: the bot may have been up for days
                    lines = dash.logs.session_lines()
                    try:
                        text = report.build(dash.snapshot(), lines, n or None,
                                            since=dash.logs.session_day)
                    except Exception as e:     # never fail to hand back the log itself
                        text = (f"(the report couldn't be built: {e!r})\n"
                                + "\n".join(report.plain(x["text"]) for x in lines))
                    self._send(200, text.encode(), "text/plain; charset=utf-8")
                elif u.path == "/api/logs":
                    since = int(parse_qs(u.query).get("since", ["0"])[0] or 0)
                    self._send(200, json.dumps(dash.logs.since(since)).encode(),
                               "application/json")
                else:
                    self._send(404, b"not found", "text/plain")

            def do_POST(self):
                path = urlparse(self.path).path
                fn = dash._routes.get(path)
                if fn is None:
                    log.warning("Dashboard asked for %s, which this build doesn't have.", path)
                    self._send(404, json.dumps(
                        {"ok": False, "error": f"this main.py has no {path}"}).encode(),
                        "application/json")
                    return
                body = {}
                try:
                    n = int(self.headers.get("Content-Length") or 0)
                    body = json.loads(self.rfile.read(n) or b"{}")
                    reply = fn(body) or {}
                    self._send(200, json.dumps({"ok": True, **reply}, default=str).encode(),
                               "application/json")
                except Exception as e:                 # shown in the page AND in the log
                    # Never answer with an empty reason: some exceptions carry no message
                    # at all, and "Request failed (400)" on the page with nothing in the
                    # log is the least useful thing this could possibly say.
                    msg = str(e).strip() or f"{type(e).__name__} (no details)"
                    # a value the page refused (a field half typed, a check that failed) is
                    # shown on the page and logged quietly; anything else is a real fault
                    (log.info if isinstance(e, ValueError) else log.warning)(
                        "%s failed: %s%s", path, msg,
                        f"  — asked for {body.get('action')}" if body.get("action") else "")
                    log.debug("%s failed", path, exc_info=True)
                    self._send(400, json.dumps({"ok": False, "error": msg}).encode(),
                               "application/json")

        try:
            self._server = ThreadingHTTPServer(("127.0.0.1", self.port), Handler)
        except OSError as e:
            raise RuntimeError(f"Can't start the dashboard on port {self.port} ({e}). "
                               f"Is another main.py running? Try --ui-port {self.port + 1}") from e
        self._server.daemon_threads = True
        threading.Thread(target=self._server.serve_forever, daemon=True).start()

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()


class NoDashboard:
    """Used when --ui isn't given: every update is ignored."""
    url = ""

    def update(self, **values) -> None:
        pass

    def route(self, path, fn) -> None:
        pass

    def start(self) -> None:
        pass

    def stop(self) -> None:
        pass
