"""Starting, pausing and stopping a session, and the questions it asks back.

The road question matters: joining a table that has already been running means
the bot cannot see the results it missed, so rather than guess it asks, and the
page answers. check() is the pre-flight -- everything that would stop a session
working, said before any money is involved rather than after."""

from __future__ import annotations

import functools

import threading
from baccarat.web import resume, template, updatestatus
from baccarat import screen as bet
import analysis
from baccarat.log import log
from baccarat.core import bets as betting
from baccarat.core.game import SIDES
from baccarat.play.actions import check_live_setup, pattern_variants
from baccarat.play.player import Player
from baccarat.play.reading import Board, no_road_question, parse_road, total
from baccarat.play.stop import check_stop, PAUSE, STOP, Stopped, wait_until
from baccarat.setup import (
    click_budget_problem, cycle_params, login_params, screen_params,
    session_params, timing_params, kind_params)
from baccarat.store.settings import save_settings
from baccarat.study.expect import win_value
from baccarat.study.tablekinds import player_args as kind_player
from baccarat.util.clock import parse_start_at


class SessionRoutes:
    """Mixed into Player. See the module docstring."""

    # -- session -----------------------------------------------------------------
    def start(self, body: dict) -> dict:
        over = body.pop("resume", None)          # carrying on after an update (web/resume.py)
        body = template.apply(body)             # a server template's game set-up wins
        own = dict(body)                         # what the Setup page keeps
        if over:
            body = {**body, **over}             # … with the balance it stopped on
        st = updatestatus.read()
        if updatestatus.holding(st):
            # it would be cut off by the update installing: wait for it instead
            raise ValueError(updatestatus.why(st) + " — start the session once it is done "
                             "(the dashboard restarts by itself).")
        with self.lock:
            if self.running:
                raise ValueError("A session is already running — stop it first.")
            params = session_params(body)
            if params["strategy"] == "all":
                raise ValueError("pick one strategy to play")
            road = parse_road(body.get("road") or "") or None
            when = None
            if body.get("start_at"):
                when = parse_start_at(body["start_at"], body.get("start_tz") or "utc",
                                      date=body.get("start_date") or None)
            check_live_setup()
            login_params(body)                   # refuse a bad value before anything starts
            kind_params(body)
            problem = click_budget_problem(params, timing_params(body))
            if problem:
                raise ValueError("This can't place its own bets: " + problem)
            save_settings({**own, "target": own.get("target", "")})
            if not over:
                resume.drop()                    # started by hand: nothing to carry on
            self.last_body = own
            STOP.clear()
            PAUSE.clear()
            target = params.pop("target", None)
            session = analysis.new_session(**params, watch=True)
            params["target"] = target            # cycle_params needs it
            cyc = cycle_params(body, params)
            params.pop("target", None)
            ask = self.ask if body.get("ask_road", True) and cyc["cycles"] == 1 else no_road_question
            player = Player(session, road=road, dash=self.dash, ask=ask,
                            alarm=bool(body.get("alarm", True)),
                            open_scroll=body.get("open_scroll") or {},
                            **timing_params(body), **screen_params(body, params), **cyc,
                            **login_params(body),
                            estimator=functools.partial(win_value, **params),
                            **kind_player(session.rules, params, kind_params(body)),
                            pattern_leave=bool(body.get("pattern_leave")))
            # new session: wipe the previous one's numbers from the page
            logs = getattr(self.dash, "logs", None)
            if logs is not None:
                logs.mark_session()            # the report covers this session from here
            self.dash.replace(keep=["control", "options", "uplink", "sync", "update", "template", "game"], running=True, question=None,
                              error=None, scheduled=None)
            self.publish()                  # the page now gets the settings just saved
            self.player = player
            self.thread = threading.Thread(target=self._run, args=(player, when), daemon=True)
            self.thread.start()
            log.info("Session started from the dashboard: %s, site %s",
                     params["strategy"], bet.site_name())
            return {}

    def _run(self, player: "Player", when=None) -> None:
        try:
            if when:
                ts, label = when
                self.dash.update(scheduled={"ts": ts, "label": label},
                                 status=f"Scheduled: starts at {label}")
                wait_until(ts, label)
                self.dash.update(scheduled=None)
            player.run()
            s = player.s
            if s.halt_for and s.halt_resume and not STOP.is_set() and not s.busted:
                left = (player.cycles - player.cycle + 1) if player.cycles > 1 else None
                resume.save(getattr(self, "last_body", None) or {}, s.balance, s.ceiling,
                            left, s.halt_for, step=player.ceiling_step)
                self.dash.update(resume=resume.shown(resume.peek()),
                                 status=f"Paused for {s.halt_for} — it carries on by itself")
        except Stopped:
            log.info("Stopped from the dashboard before the session began.")
            self.dash.update(status="Cancelled before it started", scheduled=None)
        except Exception as e:
            log.error("Session ended with an error: %s", e)
            self.dash.update(error=str(e), status=f"Error: {e}", stopped=True)
        finally:
            self.dash.update(running=False, question=None)

    def pause(self, body: dict) -> dict:
        """Hold the bot where it stands, or let it go again. Nothing is lost: no reads,
        no clicks, and every countdown is pushed back by however long it was held."""
        want = body.get("paused")
        want = (not PAUSE.is_set()) if want is None else bool(want)
        if want:
            PAUSE.set()
            log.warning("PAUSED — nothing will be clicked or read until you resume.")
        else:
            PAUSE.clear()
            log.info("Resuming.")
        self.dash.update(paused=want)
        return {"paused": want}

    AFTER_RESULT_MAX = 90       # s: a result that never comes doesn't keep Stop waiting

    def stop(self, body: dict) -> dict:
        """Stop. With a bet on the table (the clicks done), it waits for that hand's
        result first -- nothing is left unknown -- unless asked "now" (Stop pressed
        again). "after_run": the run in progress is played out and the session ends at
        the base bet, as for an update, but isn't started again."""
        if not self.running:
            return {"message": "Nothing is running."}
        p = getattr(self, "player", None)
        body = body or {}
        if body.get("after_run") and p is not None and not STOP.is_set():
            if p.s.in_run or p.current_bet:
                p.s.halt_for = "you asked to stop after this run"
                p.s.halt_resume = False
                log.info("Stop after this run: the run in progress is played out, then the "
                         "session ends at the base bet.")
                self.dash.update(status="Stopping after this run…", stop_after_run=True)
                return {"message": "Stopping once this run is won (at the base bet)."}
            # nothing in progress: that is the base bet already -- stop now
        if (not body.get("now") and not body.get("after_run") and p is not None
                and p.current_bet and getattr(p, "stake_down", 0) and not STOP.is_set()
                and not p.stop_after_result):
            p.stop_after_result = True
            threading.Timer(self.AFTER_RESULT_MAX, STOP.set).start()
            log.info("Stop: %s is on the table — stopping as soon as its result is in "
                     "(Stop again to stop at once).", f"{p.current_bet[1]:,.0f} on {p.current_bet[0]}")
            self.dash.update(status="Stopping once this hand's result is in… (Stop again: at once)",
                             stopping=True)
            return {"message": "Stopping once this hand's result is in."}
        STOP.set()
        self.answered.set()
        # say so on the page at once: the session itself notices within a tenth of a
        # second, but its own last word comes after it has closed the table
        self.dash.update(status="Stopping…", stopping=True)
        return {"message": "Stopping…"}

    # -- joining a table that already has results ------------------------------------
    def ask(self, board: Board, need: int = 3) -> list[str]:
        if total(board) < max(1, need):
            return []
        self.answer, _ = None, self.answered.clear()
        self.dash.update(question={"total": total(board), "board": board, "need": need},
                         status="Waiting for you: enter the table's last results")
        while not self.answered.wait(0.3):
            check_stop()
        check_stop()
        self.dash.update(question=None)
        return self.answer or []

    def answer_road(self, body: dict) -> dict:
        self.answer = parse_road(body.get("road") or "")
        self.answered.set()
        return {}

    # -- tools -------------------------------------------------------------------
    def check(self, body: dict) -> dict:
        """Read the screen once, so setup problems show up before starting."""
        out = {"board": None, "score": None, "problems": []}
        try:
            r = bet.read_board_detailed()
            out["board"] = r["values"]
            if r["values"] is None:
                why, shot = bet.board_trouble()
                out["shot"] = shot.name if shot else None
                out["problems"].append(f"Scoreboard bar not readable: {why}")
        except Exception as e:
            out["problems"].append(str(e))
        # the bead road (optional): loads the table's history when joining
        out["road"] = None
        try:
            road = bet.read_road()
            if road is None:
                out["problems"].append("No 'road' region (optional): with it, the whole table is "
                                       "loaded when joining. Set it with: python bet.py --snap road")
            else:
                b = out["board"]
                match = b is not None and all(road.count(k) == b[k] for k in SIDES)
                out["road"] = {"count": len(road), "match": match,
                               "last": " ".join({"player": "P", "banker": "B", "tie": "T"}[w]
                                                for w in road[-12:])}
                if b is not None and not match:
                    out["problems"].append(
                        f"The road shows {len(road)} results (P{road.count('player')} "
                        f"B{road.count('banker')} T{road.count('tie')}) but the counters say "
                        f"P{b['player']} B{b['banker']} T{b['tie']} — check it with "
                        "python bet.py --read-road")
        except Exception as e:
            out["problems"].append(f"Road: {e}")
        try:
            out["score"] = bet.read_number("score")
            if out["score"] is None:
                out["problems"].append("Score not readable (only needed for live mode). "
                                       "Run: python bet.py --teach score")
        except Exception as e:
            out["problems"].append(f"Score: {e} (only needed for live mode)")
        errors, warnings = betting.setup_problems(bet.load_coords())
        out["live_ready"] = not errors
        out["problems"] += [f"Live mode: {e} (record it on the Interface tab (Name, then Record))" for e in errors]
        out["problems"] += [f"Live mode: {w}" for w in warnings]
        if not pattern_variants("close"):
            out["problems"].append("Nothing named 'close' (or close_1, close_2 …), so the game "
                                   "window won't be closed when a session ends — record a "
                                   "coordinate (--coords) or a pattern (--capture)")
        return out
