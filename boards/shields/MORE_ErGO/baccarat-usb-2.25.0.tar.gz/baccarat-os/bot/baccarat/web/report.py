"""One block of plain text that says everything needed to look into a problem.

The dashboard's Copy report buttons put this on the clipboard, to be pasted into a
conversation as it is. It reads top to bottom from the conclusions to the evidence:

    checks      what the report itself sees: risks, problems, settings worth a look --
                each with the numbers behind it ("!" = look at this, "ok" = fine)
    session     how the session went, in numbers, and the runs it played
    tables      every table of the session, one line each
    now         what the session thinks is true right now
    setup       the settings that differ from the defaults, then all of them
    warnings    every warning and error of the WHOLE session, grouped by kind --
                not just the ones in the log tail
    table kinds the tally of calls, and the last few
    log         the last N lines

Colour codes are taken out, so it reads the same pasted anywhere. Nothing in it is a
secret: no passwords or account details ever pass through the bot.
"""

from __future__ import annotations

import json
import platform
import re
import sys
import time
from collections import Counter

import baccarat
from baccarat import screen as bet
from baccarat.play import tuning
from baccarat.store.settings import DEFAULTS, load_settings
from baccarat.store.tablecalls import is_right, load_calls

ANSI = re.compile(r"\x1b\[[\d;]*m")

# the knobs that decide how a bet is confirmed and when the bot backs off
KNOBS = ("STAKE_LOOK", "STAKE_WATCH", "STAKE_CONFIRM", "REJECT_LIMIT", "REJECT_WINDOW",
         "REJECT_COOLOFF", "REJECT_GROWTH", "REJECT_MAX_COOLOFFS", "SCORE_GLANCE",
         "SCORE_RECHECK", "BET_MARGIN", "POLL", "QUIET_POLL")


def plain(text: str) -> str:
    return ANSI.sub("", str(text))


def _n(x, nd=0) -> str:
    """12,345 or 12,345.67 -- or '?' when there is nothing."""
    try:
        return f"{float(x):,.{nd}f}"
    except (TypeError, ValueError):
        return "?"


def _num(v) -> float | None:
    try:
        return float(str(v).replace(",", ""))
    except (TypeError, ValueError):
        return None


def _hm(seconds: float) -> str:
    m = int(seconds // 60)
    return f"{m // 60} h {m % 60:02d} min" if m >= 60 else f"{m} min"


def cover_of(budget: float | None, base: float | None, limit=None) -> tuple[int, float]:
    """Lives a balance pays for from the base bet, and the last stake it pays."""
    if not budget or not base or base <= 0:
        return 0, 0.0
    n, left, stake = 0, budget, base
    while stake <= left + 1e-9 and n < 60:
        left -= stake
        n += 1
        if limit and n >= int(limit):
            break
        stake *= 2
    return n, base * 2 ** (n - 1) if n else 0.0


# --- what the report sees by itself ----------------------------------------------------

STUCK = re.compile(r"looks stuck|no new hand|Still on game", re.I)
UNREAD = re.compile(r"couldn't be read|unreadable|can't read|couldn't read", re.I)


def checks(s: dict, st: dict, log_lines: list[dict]) -> list[str]:
    """Findings worth a look, each with its numbers. '!' first, then 'ok'."""
    bad, good = [], []
    timing, runs = s.get("timing") or {}, s.get("runs") or {}
    hist = runs.get("history") or {}
    base, budget = _num(s.get("base") or st.get("base")), _num(s.get("budget") or st.get("budget"))
    limit = _num(st.get("max_steps")) or None

    # the money: what the session ended or stands at
    status = plain(s.get("status") or "")
    if s.get("watch") or "Lost everything" in status:
        w = s.get("watch") or {}
        bad.append(f"! The money ran out: {status or w.get('text', '')} — balance "
                   f"{_n(s.get('settled'), 2)} of the {_n(budget, 2)} budget.")

    # lives: what the budget pays for against what this configuration has needed
    cover, top = cover_of(budget, base, limit)
    if cover and hist.get("runs"):
        lives = {int(k): int(v) for k, v in (hist.get("lives") or {}).items()}
        over = sum(v for k, v in lives.items() if k > cover)
        worst, total = int(hist.get("max_lives") or 0), int(hist.get("runs") or 0)
        line = (f"the budget covers {cover} lives ({_n(base)} … {_n(top)}); "
                f"'{runs.get('config', '?')}' has needed up to {worst} over {total:,} runs")
        if over:
            bad.append(f"! {line[0].upper() + line[1:]} — {over} of them needed more than "
                       f"{cover} (1 run in {total // over:,}).")
        else:
            good.append(f"ok {line} — none needed more than {cover}.")

    # the target: how many wins, and the chance a run too long for the balance turns up
    e = s.get("estimate") or {}
    if s.get("wins_needed") and e.get("cut_short") is not None:
        msg = (f"target: {_n(s.get('remaining'))} to go ≈ {s['wins_needed']} wins at "
               f"{_n(e.get('per_win'), 2)} a win; chance of a run longer than the balance "
               f"covers on the way ≈ {e['cut_short'] * 100:.0f}%")
        (bad if e["cut_short"] >= 0.2 else good).append(("! " if e["cut_short"] >= 0.2 else "ok ") + msg + ".")

    # stopped partway: money this session's numbers don't include
    sw = s.get("stopped_with")
    if sw:
        bits = []
        if sw.get("amount"):
            bits.append(f"{_n(sw['amount'])} on {sw.get('side')} was on the table and its result "
                        "wasn't seen (check the casino's balance)")
        if sw.get("lost"):
            bits.append(f"the run had lost {sw['lost']} bet(s), {_n(sw.get('lost_total'))} in all, "
                        "not won back")
        bad.append(("! Stopped in the middle of a run: " if sw.get("lost") else
                    "! Stopped with a bet on the table: ") + "; ".join(bits) + ".")

    # the screen and the clicks
    if timing.get("hard_score") is False:
        sp = timing.get("spot") or {}
        if sp.get("apart"):
            bad.append(f"! The screen's balance and the bot's books drifted apart {sp['apart']} "
                       f"time(s) (last: {sp.get('last'):+,.2f}) — with 'Trust the screen score' "
                       "off nothing was corrected: check the casino's balance against the "
                       "report's.")
        bad.append("! Trust the screen score is OFF: bets aren't checked one by one against the "
                   "table's own balance, so a missed or doubled click goes unnoticed"
                   + (f" (looked at every 10 bets anyway: {sp.get('agreed', 0)} of "
                      f"{sp.get('looks', 0)} looks agreed)" if sp.get("looks") else
                      " (no look at the screen could be read: is the score region set?)")
                   + " — Setup → Screen score.")
    ref = s.get("refused") or {}
    if ref.get("count"):
        bad.append(f"! {ref['count']} bet(s) not accepted by the site this session "
                   f"({ref.get('breaks', 0)} break(s) taken).")
    corr = s.get("corrections") or {}
    if corr.get("count"):
        bad.append(f"! The balance was put right from the screen {corr['count']} time(s), "
                   f"{_n(corr.get('total'), 2)} in all — money the bot couldn't account for.")
    if s.get("mismatch"):
        bad.append("! A money mismatch is waiting for an answer on the dashboard.")
    text = [plain(x.get("text", "")) for x in log_lines]
    stuck = sum(bool(STUCK.search(x)) for x in text)
    unread = sum(bool(UNREAD.search(x)) for x in text if " WARNING " in x or " ERROR " in x)
    if stuck:
        bad.append(f"! The table looked stuck or slow {stuck} time(s) (see warnings below).")
    if unread:
        bad.append(f"! The screen couldn't be read {unread} time(s) (see warnings below).")
    if not (ref.get("count") or corr.get("count") or stuck or unread):
        good.append("ok no refused bets, no money corrections, no stuck table, no unreadable screen.")

    # the machine
    cpu = ((s.get("load") or {}).get("cpu") or {})
    if cpu.get("browser") and cpu["browser"][1] >= 300:
        bad.append(f"! The browser peaks at {cpu['browser'][1]}% of one core (average "
                   f"{cpu['browser'][0]}%) — the game's stream may stutter.")
    if cpu.get("bot") and cpu["bot"][1] >= 50:
        bad.append(f"! The bot itself peaks at {cpu['bot'][1]}% of one core.")

    # extra life: what it cost, and whether it ever mattered
    x = s.get("extra")
    if x:
        msg = (f"extra life: bought {x.get('bought', 0)} × {_n(base)} = {_n(x.get('cost'))}, "
               f"saves {x.get('saved', 0)}")
        if x.get("bought") and not x.get("saved"):
            bad.append(f"! {msg} — it has cost money and not saved a run yet.")
        else:
            good.append(f"ok {msg}.")
    return bad + good


# --- the session, the tables ------------------------------------------------------------

def session_lines(s: dict) -> list[str]:
    out = []
    se, st, runs = s.get("session") or {}, s.get("stats") or {}, s.get("runs") or {}
    started = se.get("started") or s.get("started")
    if started:
        out.append(f"started {time.strftime('%H:%M', time.localtime(started))} · ran "
                   f"{_hm(time.time() - started)} · {len(s.get('played') or [])} table(s) closed · "
                   f"{se.get('hands', '?')} hands · {se.get('bets', '?')} bets")
    out.append(f"budget {_n(s.get('budget'), 2)} → balance {_n(s.get('settled'), 2)} "
               f"(net {_n(s.get('net'), 2)}) · peak {_n(se.get('peak'), 2)} · max drawdown "
               f"{_n(st.get('max_drawdown'), 2)} · biggest bet {_n(st.get('max_bet'))} · "
               f"longest losing streak {st.get('max_losing_streak', '?')}")
    if s.get("ceiling") is not None:
        out.append(f"target {_n(s.get('ceiling'), 2)} · {_n(s.get('remaining'), 2)} to go · "
                   f"≈ {s.get('wins_needed', '?')} wins")
    lives = runs.get("lives") or {}
    if lives:
        dist = " ".join(f"{k}:{v}" for k, v in sorted((int(k), v) for k, v in lives.items()))
        out.append(f"runs this session: {runs.get('count', '?')} (lives needed:count → {dist})"
                   f" · not won {runs.get('not_won', 0)} · the lives budget now "
                   f"{se.get('lives_now', '?')} left, {se.get('lost_now', 0)} lost in this run")
    h = runs.get("history") or {}
    if h.get("runs"):
        dist = " ".join(f"{k}:{v}" for k, v in sorted((int(k), int(v))
                                                      for k, v in (h.get("lives") or {}).items()))
        out.append(f"all runs ever for '{runs.get('config')}': {h['runs']:,}, worst "
                   f"{h.get('max_lives')} lives ({h.get('max_at') or '?'}) · {dist}")
    return out


def table_lines(s: dict) -> list[str]:
    out = []
    for t in s.get("played") or []:
        out.append(f"{t.get('started')}–{t.get('ended')} {t.get('name')} · joined at "
                   f"#{t.get('joined')} · {t.get('rounds')} rounds · {t.get('bets')} bets "
                   f"({t.get('won')}W {t.get('lost')}L) · net {_n(t.get('net'), 2)} · deepest "
                   f"run {t.get('deepest')} · biggest {_n(t.get('biggest'))} · {t.get('reason')}")
    return out or ["(no table closed yet this session)"]


# --- every warning of the session, grouped -----------------------------------------------

LINE = re.compile(r"^(\d\d:\d\d:\d\d)\s+(\w+)\s+(.*)$")


def warning_groups(log_lines: list[dict], most: int = 25) -> list[str]:
    """Each kind of warning or error once, with how often and when: numbers are taken
    out to tell the kinds apart, so 'Still on game 40 after 30 s' and 'Still on game
    42 after 30 s' are one kind seen twice."""
    groups: dict[str, dict] = {}
    for x in log_lines:
        if x.get("level") not in ("WARNING", "ERROR", "CRITICAL"):
            continue
        text = plain(x.get("text", ""))
        m = LINE.match(text)
        when, msg = (m.group(1), m.group(3)) if m else ("?", text)
        key = re.sub(r"[\d,.]+", "#", msg)[:90]
        g = groups.setdefault(key, {"n": 0, "first": when, "last": when, "level": x["level"],
                                    "example": msg})
        g["n"] += 1
        g["last"] = when
    # in the order they first happened: a session's trouble reads as a story
    rows = list(groups.values())[-most:]
    if not rows:
        return ["(none — not one warning or error this session)"]
    return [f"{g['n']:>3}× {g['level']:<7} {g['first']}" + (f"–{g['last']}" if g["n"] > 1 else "")
            + f"  {g['example'][:240]}" for g in rows]


def setup_lines() -> list[str]:
    st = load_settings()
    changed = {k: v for k, v in st.items() if k in DEFAULTS and str(v) != str(DEFAULTS[k])
               and k not in ("screens",)}
    return ["changed from the defaults: " + json.dumps(changed, default=str, separators=(",", ":"),
                                                      ensure_ascii=False),
            "all: " + json.dumps({k: v for k, v in st.items() if k not in ("screens",)},
                                 default=str, separators=(",", ":"), ensure_ascii=False),
            "tuning: " + " ".join(f"{k}={getattr(tuning, k, '?')}" for k in KNOBS)]


def _section(out: list[str], title: str, fn, *args) -> None:
    out.append("")
    out.append(f"--- {title} ---")
    try:
        out.extend(fn(*args))
    except Exception as e:                       # the report must never fail to copy
        out.append(f"(couldn't put this part together: {e!r})")


def build(state: dict, log_lines: list[dict], last: int | None = 300, since: str = "") -> str:
    """`last` = how many of the most recent log lines; None for all of them. The lines
    are the session's own (from its start; `since` = the day it started)."""
    out: list[str] = []
    add = out.append
    add(f"=== bot report · {time.strftime('%Y-%m-%d %H:%M:%S')} ===")
    add(f"version {getattr(baccarat, '__version__', '?')} · python "
        f"{sys.version.split()[0]} · {platform.system()} · site {bet.site_name() or '-'}")
    s = state or {}
    try:
        st = load_settings()
    except Exception:
        st = {}

    _section(out, "checks (what the report sees by itself)", checks, s, st, log_lines)
    if s.get("session") or s.get("budget") is not None:     # a session has run (or is running)
        _section(out, "session", session_lines, s)
        _section(out, "tables this session", table_lines, s)
    if any(s.get(k) is not None for k in ("status", "bet", "table", "balance")):
        _section(out, "now", now_lines, s)
    _section(out, "setup", setup_lines)
    _section(out, "warnings and errors, this session" + (f" (since {since})" if since else "")
             + ", grouped", warning_groups, log_lines)
    _section(out, "patterns (what every bot saw after each one)", pattern_lines, s)
    _section(out, "table kinds", kind_lines, s)

    lines = log_lines if last is None else log_lines[-last:]
    add("")
    add(f"--- log: the last {len(lines)} of this session's {len(log_lines)} lines ---")
    out.extend(plain(line["text"]) for line in lines)
    return "\n".join(out) + "\n"


def now_lines(s: dict) -> list[str]:
    out = []
    add = out.append
    add(f"status: {plain(s.get('status', '-'))}")
    if s.get("bet_reason"):
        add(f"why: {plain(s['bet_reason'])}")
    add(f"balance shown {s.get('balance')} · settled {s.get('settled')} · on the table "
        f"{s.get('on_table')} · screen score {s.get('score')} · budget {s.get('budget')} · "
        f"net {s.get('net')}")
    b = s.get("bet")
    if b:
        add(f"bet: {b.get('amount')} on {b.get('side')} for game {b.get('game')}")
    a = s.get("ahead") or {}
    if a.get("stakes"):
        add(f"bets to come if they keep losing: {' › '.join(_n(x) for x in a['stakes'])} · then "
            f"{a.get('then')}")
    t = s.get("table") or {}
    if t:
        add(f"table: {t.get('name')} game {t.get('game')} counts {t.get('counts')} "
            f"hand {t.get('hand')} of {t.get('hands')}")
    stt = s.get("stats") or {}
    if stt:
        add(f"last 11: won {stt.get('W')} lost {stt.get('L')} pushes {stt.get('push')} "
            f"no-bet {stt.get('skipped')} · biggest bet {stt.get('max_bet')}")
    for key in ("refused", "bet_notice", "mismatch", "corrections", "alarm", "timing",
                "screen", "load", "cycle", "extra", "watch"):
        if s.get(key):
            add(f"{key}: {json.dumps(s[key], default=str, ensure_ascii=False)}")
    if s.get("road"):
        letters = {"player": "P", "banker": "B", "tie": "T"}
        add("road: " + " ".join(letters.get(w, "?") for w in s["road"]))
    if s.get("shots"):
        add("screenshots: " + ", ".join(f"{x.get('file')} ({x.get('why')})" for x in s["shots"]))
    add(f"paused: {s.get('paused')} · stopped: {s.get('stopped')}")
    return out


def call_line(c: dict) -> str:
    """One table call and what the table turned out to be, on one line."""
    f, o = c.get("features") or {}, c.get("outcome") or {}
    spec, gen = c.get("spectrum") or {}, c.get("general") or {}
    right = is_right(c)
    verdict = ("stopped early" if o.get("partial") else
               "RIGHT" if right else "WRONG" if right is False else "?")
    return (f"{c.get('when', '?')} {c.get('table', '?')} hand {c.get('hand')} "
            f"[{'last ' + str(c['window']) if c.get('window') else 'whole table'}] "
            f"{c.get('pattern', '')} chop {f.get('chop', 0):.2f} banker {f.get('banker', 0):.0%} "
            f"longest {f.get('longest', 0)} doubles {f.get('doubles', 0):.0%} "
            f"→ called {str(c.get('call', '?')).upper()}"
            f"{' leaning ' + c['lean'] if c.get('call') == 'ordinary' and c.get('lean') else ''} (bad {spec.get('bad', 0):.0%} vs "
            f"{gen.get('bad', 0):.0%}, good+exc {spec.get('good', 0) + spec.get('exceptional', 0):.0%} "
            f"vs {gen.get('good', 0) + gen.get('exceptional', 0):.0%}, proven "
            f"{','.join(k for k, v in ((c.get('record') or {}).get('proven') or {}).items() if v) or 'no'}, "
            f"on {'+'.join(c.get('uses') or [])}) "
            f"→ was {str(o.get('tier', '?')).upper()} {o.get('profit')} deepest "
            f"{o.get('deepest')}/{o.get('cover')}"
            f"{' last two lives at hand ' + str(o['bad_at']) if o.get('bad_at') else ''}"
            f" over {o.get('results')} results · {verdict}")


def pattern_lines(s: dict) -> list[str]:
    from baccarat.core import patterns
    v = s.get("pattern")
    if not v:
        return []
    out = [f"now: {patterns.describe(v)}" + (" · leaves a BAD table once the run is won"
                                             if v.get("leave") else "")]
    rows = [r for r in v.get("lengths") or [] if r.get("n")]
    if rows:
        out.append("by length: " + " · ".join(
            f"{r['pattern']} {r['n']}" + (f" z{r['z']:+.1f}" if r.get("z") is not None else "")
            for r in rows))
    if v.get("line"):
        out.append(f"BAD/GOOD needs |z| ≥ {v['line']:.2f} ({v.get('m', 0):,} patterns with "
                   f"{patterns.MIN_N}+ bets compared)")
    out.append("track record (bets made after each call, all bots): "
               + patterns.describe_track(v.get("track") or []))
    return out


def kind_lines(s: dict) -> list[str]:
    out = []
    k = s.get("kind") or {}
    now = k.get("now")
    if now:
        keep = ("hand", "window", "pattern", "features", "ready", "why", "call", "spectrum",
                "general", "record", "uses", "examples", "similar", "typical", "cover")
        out.append("this table: " + json.dumps({x: now.get(x) for x in keep if x in now},
                                               default=str, ensure_ascii=False))
    if k.get("track"):
        out.append("since the call: " + json.dumps(k["track"], ensure_ascii=False))
    calls = load_calls()
    done = [c for c in calls if c.get("outcome") and not c["outcome"].get("partial")]
    if done:
        tally = Counter((c.get("call"), is_right(c)) for c in done)
        parts = [f"{call.upper()} {tally[(call, True)] + tally[(call, False)]} "
                 f"({tally[(call, True)]} right)" for call in ("good", "bad", "ordinary")
                 if tally[(call, True)] + tally[(call, False)]]
        tiers = Counter(c["outcome"]["tier"] for c in done)
        out.append(f"all calls checked: {', '.join(parts)} · the tables turned out "
                   + ", ".join(f"{tiers[k]} {k}" for k in ("exceptional", "good", "regular", "bad")))
    out.extend(call_line(c) for c in calls[-8:])
    if not calls:
        out.append("no table calls stored yet")
    return out
