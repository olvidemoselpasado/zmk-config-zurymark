"""The dashboard's HTTP API.

One route per thing the page can do. Every route is a thin call into the rest
of the program -- the page may not do anything the CLI cannot -- so the two can
never drift into doing the same job two different ways."""

from __future__ import annotations

import signal
import sys
import threading
import time
from pathlib import Path
from baccarat import screen as bet
import analysis
from baccarat.log import log
from baccarat.core import bets as betting
from baccarat.web.routes_session import SessionRoutes
from baccarat.web.routes_setup import SetupRoutes
from baccarat.web.routes_study import StudyRoutes
from baccarat.web import configsync, remote, report, resume, template, updatestatus
from baccarat.web.server import Dashboard
from baccarat.web.uplink import Uplink
from baccarat import core as strategies
from baccarat.core.rules import RULES
from baccarat.core.strategy import STRATEGIES


from baccarat.consistency import check_files, stale_files
from baccarat.play.stop import STOP
from baccarat.store.settings import load_patterns, load_settings


# ---------------------------------------------------------------------------
# Control mode: everything is driven from the dashboard
# ---------------------------------------------------------------------------

class Controller(SessionRoutes, SetupRoutes, StudyRoutes):
    """Handles the dashboard's buttons. The bot runs in a background thread."""

    def __init__(self, dash: Dashboard):
        self.dash = dash
        self.thread: threading.Thread | None = None
        self.player = None                # the session being played (the last one, once over)
        self.answer: list[str] | None = None
        self.frames: dict = {}            # the last picture of each region, for teaching
        self.answered = threading.Event()
        self.lock = threading.Lock()
        for path, fn in {"/api/start": self.start, "/api/stop": self.stop,
                         "/api/answer": self.answer_road, "/api/check": self.check,
                         "/api/stats": self.stats, "/api/simulate": self.simulate,
                         "/api/table": self.table_detail,
                         "/api/pause": self.pause,
                         "/api/site": self.site,
                         "/api/coords": self.coords,
                         "/api/login": self.login,
                         "/api/window": self.window,
                         "/api/regions": self.regions,
                         "/api/patterns": self.patterns,
                         "/api/whatif": self.whatif,
                         "/api/roadpatterns": self.road_patterns,
                         "/api/clickcost": self.clickcost,
                         "/api/estimate": self.estimate,
                         "/api/budget": self.budget_from_screen,
                         "/api/history": self.history,
                         "/api/resume-cancel": self.resume_cancel}.items():
            dash.route(path, fn)
        self.publish(running=False)

    @property
    def running(self) -> bool:
        return self.thread is not None and self.thread.is_alive()

    def publish(self, **extra) -> None:
        self.dash.update(
            control=True,
            options={"strategies": [{"name": n, "description": c.description}
                                    for n, c in STRATEGIES.items()],
                     "rules": [{"name": n, "title": c.title, "description": c.description,
                                "params": c.params} for n, c in RULES.items()],
                     "screens": load_patterns(),
                     "patterns": sorted(set(bet.pattern_names()) | set(bet.load_coords())),
                     "site": bet.site_name(), "sites": bet.list_sites(),
                     "server": {n: int(Path(f.__file__).stat().st_mtime)
                                for n, f in (("main", sys.modules[__name__]), ("bet", bet),
                                             ("betting", betting), ("strategies", strategies),
                                             ("analysis", analysis))},
                     "stale": stale_files(),
                     "settings": template.apply(load_settings())},
            template=({"name": t["name"], "keys": sorted(t["settings"])}
                      if (t := template.current())["name"] else None),
            **extra)

    def resume_cancel(self, body: dict) -> dict:
        """'Don't carry on': the session stopped for an update stays stopped."""
        resume.drop()
        self.dash.update(resume=None)
        log.info("The session stopped for the update won't be carried on (you said so).")
        return {}

    # -- the set-up itself: coordinates, regions, patterns ----------------------
    def _hands_off(self, action: str) -> None:
        """Recording takes the mouse and the screen, so it can't happen mid-session."""
        if action in ("list", "detail", "cursor"):
            return                           # reading changes nothing
        if self.running:
            raise ValueError("A session is running — stop it before changing the set-up.")


def open_window(url: str) -> None:
    """Open the dashboard in its OWN window, so it never replaces the game's tab."""
    try:
        bet.desktop.open_url(url)
    except Exception:
        pass


def _quit(*_):
    raise KeyboardInterrupt


def control_mode(args) -> None:
    bet.setup_logging(args.debug)
    bet.set_number_format("score", decimals=2, symbol="$")   # shown as $1,250.50
    check_files()                       # say so before anything else if one is behind
    is_locked = bool(getattr(args, "locked", False)) or remote.locked()
    dash = Dashboard(args.ui_port, shots_dir=bet.debug_dir(),
                     snaps_dir=bet.snaps_dir)
    dash.game_url = bet.load_game_url
    if is_locked:
        dash.boot = {"state": "start", "text": "Starting…"}
    try:
        dash.start()
    except RuntimeError as e:
        log.error("%s", e)
        sys.exit(1)
    if not args.no_open:
        open_window(dash.url)
    # a computer going off stops the bot with SIGTERM: treated like Ctrl+C, so the
    # session closes its table and the last changes reach the server
    signal.signal(signal.SIGTERM, _quit)
    sync = None
    if is_locked:
        # the locked bot: its configuration and its login come from the server, before
        # anything reads them
        log.info("Locked bot: getting this bot's configuration from %s…", remote.server_url())
        try:
            sync = configsync.boot(dash)
        except KeyboardInterrupt:
            return
        bet.sites._start_site()            # the site in use is the configuration's
    ctl = Controller(dash)
    dash.boot = None                       # the page now shows the controls
    log.info("Dashboard: %s — set up and start everything from there. Ctrl+C here quits.",
             dash.url)
    up = Uplink(dash, report=report.build, remote=sync.remote if sync else None).start()
    updatestatus.watch(dash)                 # the stick's own update, if one is under way
    resume.watch(ctl)                        # a session stopped for it carries on afterwards
    if sync:
        sync.on_template = ctl.publish            # the Setup page shows the new values
        sync.template_at = time.time()            # (just fetched at boot)
        sync.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        STOP.set()
        print()
        if ctl.running:                       # let it finish, e.g. run pattern 'close'
            log.info("Stopping the session…")
            ctl.thread.join(timeout=20)
        if sync:
            sync.stop()
        up.stop()
