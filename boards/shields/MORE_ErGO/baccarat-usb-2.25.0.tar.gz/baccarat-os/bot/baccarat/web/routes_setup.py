"""The Interface tab: the site, the recorded points, the regions, the patterns,
and the road-pattern library.

All of it editable from the page without re-recording from scratch, which is
the difference between a set-up you can fix and one you have to redo. Every
route here refuses to change anything while a session is running -- moving a
button under a bot that is about to click it is not a thing to allow."""

from __future__ import annotations

import time
from baccarat import screen as bet
from baccarat.log import log
from baccarat import core as strategies
from baccarat.setup import (
    _unknown_action)
from baccarat.play import tuning
from baccarat.store.settings import load_patterns, load_settings, save_patterns


class SetupRoutes:
    """Mixed into Player. See the module docstring."""

    # -- sites ---------------------------------------------------------------
    def site(self, body: dict) -> dict:
        """Switch to another site, make a new one, or delete one. A site holds its own
        coordinates, patterns, screen regions, digits, colours and session settings, so
        setting up a second site leaves the first exactly as it was."""
        action = str(body.get("action") or "use")
        name = str(body.get("name") or "").strip()
        with self.lock:
            if self.running and action != "list":
                raise ValueError("A session is running — stop it before changing site.")
            if action == "delete":
                others = [n for n in bet.list_sites() if n != bet.site_slug(name)]
                if not others:
                    raise ValueError("that is the only site there is")
                if bet.site_slug(name) == bet.site_name():
                    bet.use_site(others[0])        # step off it first, then remove it
                    log.info("Site: %s", bet.site_name())
                bet.delete_site(name)
            elif action in ("use", "new"):
                if not bet.site_slug(name):
                    raise ValueError("a site needs a name made of letters or numbers")
                if action == "new" and bet.site_slug(name) in bet.list_sites():
                    raise ValueError(f"there is already a site called '{bet.site_slug(name)}'")
                known = bet.site_slug(name) in bet.list_sites()
                bet.use_site(name)
                log.info("Site: %s%s. Coordinates, patterns, regions and settings now come "
                         "from %s", bet.site_name(), "" if known else " (new, nothing recorded yet)",
                         bet.site_dir())
            else:
                raise ValueError(f"unknown site action '{action}'")
            self.publish()
            return {"site": bet.site_name(), "sites": bet.list_sites()}

    def login(self, body: dict) -> dict:
        """The Login section of Setup. {} reads; {email, password} saves (an empty
        password keeps the saved one); {action: 'forget'} deletes them; {action:
        'check'} looks at success_login now. The password never comes back out."""
        from baccarat.play.login import login_missing, looks_logged_in, success_region
        action = str(body.get("action") or "read")
        if action == "save":
            if self.running:
                raise ValueError("A session is running — stop it before changing the login.")
            email = str(body.get("email") or "").strip()
            if email and "@" not in email:
                raise ValueError("that doesn't look like an email address")
            bet.save_login(email, str(body.get("password") or ""))
            log.info("Login details saved for site %s (in its login.json, readable only "
                     "by you).", bet.site_name())
        elif action == "forget":
            if self.running:
                raise ValueError("A session is running — stop it before changing the login.")
            bet.forget_login()
            log.info("Login details forgotten for site %s.", bet.site_name())
        out = {**bet.login_summary(), "missing": login_missing(),
               "region": success_region(), "match": tuning.LOGIN_MATCH}
        if action == "check":
            shows, diff = looks_logged_in()
            out.update(logged_in=shows, difference=None if diff is None else round(diff, 1))
            log.info("Login check: success_login %s.",
                     "isn't set up" if out["region"] is None else
                     "can't be read" if diff is None else
                     f"is {diff:.1f} from its saved picture — "
                     + ("logged in" if shows else "not logged in" if shows is False
                        else "changing, look again"))
        return out

    def budget_from_screen(self, body: dict) -> dict:
        """The Budget, read off the casino's balance (the 'score' region). {action: 'read'}
        takes a picture and reads it; {action: 'use', text} takes what you confirm --
        and if the reading was wrong, or not a number at all, the very same picture
        teaches the score's digits what you typed, so it reads right next time."""
        from baccarat.screen.numbers import number_format, parse_shown
        action = str(body.get("action") or "read")
        if self.running:
            raise ValueError("A session is running — the budget is set before one starts.")
        if not any(r["name"] == "score" for r in bet.region_list()):
            raise ValueError("there is no 'score' region yet: select the casino's balance on "
                             "the Interface tab (Screen regions → score) first")
        if action == "read":
            f = bet.number_frame("score")
            self.frames["score"] = f.pop("frame")
            text = f["texts"].get("number") or ""
            value = parse_shown(text, number_format("score")) if text else None
            self.budget_read = text
            return {"text": text, "value": value, "note": f.get("note") or "",
                    "shot": f["shot"].name if f.get("shot") else None,
                    "example": (f.get("format") or {}).get("example", "")}
        if action != "use":
            raise ValueError(f"unknown action '{action}'")
        typed = str(body.get("text") or "").strip()
        fmt = number_format("score")
        value = parse_shown(typed, fmt)          # '$10,752.96' is 10752.96: the $ doesn't count
        if value is None:
            raise ValueError(f"'{typed}' isn't a number the way this site writes them "
                             f"(e.g. {fmt.get('example') or '1,250.50'})")
        out = {"value": value, "taught": 0, "problems": []}
        img = self.frames.get("score")
        read = getattr(self, "budget_read", "")
        if img is not None and parse_shown(read, fmt) != value:
            # it read it wrong (or not at all): this picture is the lesson. The picture has
            # the $ too: typed without it, it is put back for the lesson
            sym = fmt.get("symbol") or (read[:1] if read[:1] in "$#" else "")
            lesson = typed
            if sym and sym not in typed:
                lesson = sym + typed if fmt.get("symbol_at", "start") == "start" else typed + sym
            got = bet.teach_number_from("score", img, lesson)
            out.update(taught=got.get("kept", 0), problems=got.get("problems", []))
            log.info("Budget from the screen: %s (the score read '%s' — taught %d digit "
                     "example(s) from the same picture).", typed, read or "nothing", out["taught"])
        else:
            log.info("Budget from the screen: %s.", typed)
        return out

    def window(self, body: dict) -> dict:
        """The game window's width: what is saved, what it is now; save it; fit it."""
        action = str(body.get("action") or "status")
        if action == "url":
            try:
                url = bet.save_game_url(str(body.get("url") or ""))
            except Exception as e:
                raise ValueError(str(e)) from e
            log.info("Game page for site %s: %s", bet.site_name(), url or "none")
            return {**bet.window_status(), "url": url}
        if action in ("save", "fit", "forget") and self.running:
            raise ValueError("A session is running — stop it before changing the game window.")
        if action == "save":
            bet.save_game_window()
        elif action == "forget":
            bet.forget_window()
            log.info("Game window width forgotten for site %s.", bet.site_name())
        elif action == "fit":
            done = bet.fit_game_window()
            return {**bet.window_status(), "done": done, "url": bet.load_game_url()}
        elif action != "status":
            raise ValueError(f"unknown action '{action}'")
        return {**bet.window_status(), "url": bet.load_game_url()}

    def coords(self, body: dict) -> dict:
        """Record, rename, nudge, show or delete a click position. Recording waits a few
        seconds first, so there is time to put the pointer on the thing itself."""
        action = str(body.get("action") or "list")
        name = str(body.get("name") or "").strip()
        self._hands_off(action)
        out = {}
        if action == "record":
            out["saved"] = bet.record_coord(
                name, str(body.get("act") or "click"),
                delay=float(body.get("delay") or 3), text=str(body.get("text") or ""),
                enter=body.get("enter") is not False)
        elif action == "delete":
            bet.delete_coord(name)
        elif action == "rename":
            bet.rename_coord(name, str(body.get("to") or ""))
        elif action == "nudge":
            out["saved"] = bet.nudge_coord(name, int(body.get("dx") or 0),
                                           int(body.get("dy") or 0))
        elif action == "show":
            out["at"] = bet.show_coord(name)
        elif action == "cursor":
            pos = bet.get_cursor_pos()
            out["cursor"] = {"x": pos[0], "y": pos[1]} if pos else None
        elif action == "check":
            # No check_stop() here: STOP stays set after a session is stopped, and this
            # walk has nothing to do with a session — it used to die instantly, on an
            # exception carrying no message, which is what made it a bare 400.
            names = [n for n in sorted(bet.load_coords()) if n.startswith(name)]
            if not names:
                raise ValueError("no coordinates recorded for this site yet"
                                 + (f" starting with '{name}'" if name else ""))
            hold = min(2.0, max(0.2, float(body.get("hold") or 0.7)))
            log.info("Showing %d coordinate%s, %.1f s each. Nothing is clicked.",
                     len(names), "" if len(names) == 1 else "s", hold)
            for n in names:
                bet.show_coord(n)
                time.sleep(hold)
            out["checked"] = names
        elif action != "list":
            raise _unknown_action(action, ("list", "record", "delete", "rename", "nudge",
                                           "show", "cursor", "check"))
        if action not in ("cursor",):
            self.publish()                       # the Setup lists follow the coordinates
        return {**out, "coords": bet.coord_list()}

    def regions(self, body: dict) -> dict:
        """The screen regions the bot reads. Every one of them is listed whether or not
        it has been set up ('slots'), each with what it is for, whether these settings
        need it, and what it still needs. Selecting one hands the screen to slurp until
        a box is dragged."""
        action = str(body.get("action") or "list")
        name = str(body.get("name") or "").strip()
        self._hands_off(action)
        out = {}
        if action == "grab":
            out["saved"] = bet.grab_region(name, str(body.get("geo") or "") or None)
        elif action == "again":                  # same box, fresh picture
            rows = {r["name"]: r for r in bet.region_list()}
            if name not in rows:
                raise ValueError(f"there is no region called '{name}'")
            out["saved"] = bet.grab_region(name, rows[name]["geo"])
        elif action == "delete":
            bet.delete_region(name)
        elif action == "forget":
            out["forgot"] = (bet.forget_colors(name) if bet.region_kind(name) == "trigger"
                             else bet.forget_digits(name))
        elif action == "look":
            # one press, one example: what the chips area looks like right now
            out["learned"] = bet.teach_color_sample(name, str(body.get("label") or ""))
            out["now"] = bet.bets_open(name)
        elif action in ("board", "shot"):
            # one look at the region, kept so the digits can be taught from these very
            # pixels rather than from whatever the table shows a few seconds later
            name = name or "board"
            kind = bet.region_kind(name)
            if kind == "picture":
                raise ValueError(f"'{name}' has nothing to teach — its picture, taken while "
                                 f"logged in, is all it needs. 'Check now' says if it matches")
            if kind == "unused":
                raise ValueError(f"nothing in the bot reads a region called '{name}'")
            if kind == "colours":
                raise ValueError(f"'{name}' is a grid of coloured circles — there are no "
                                 f"digits in it to teach")
            if kind == "trigger":
                raise ValueError(f"'{name}' is watched for how it LOOKS, not read — show it "
                                 f"once with the chips and once without")
            f = bet.board_frame(name) if kind == "board" else bet.number_frame(name)
            self.frames[name] = f.pop("frame")
            out["board"] = {**f, "kind": kind,
                            "shot": f["shot"].name if f.get("shot") else None}
        elif action == "learn":
            name = name or "board"
            img = self.frames.get(name)
            if img is None:
                raise ValueError("take a picture of it first")
            if bet.region_kind(name) == "board":
                out["learned"] = bet.teach_board_from(name, img, body.get("values") or {})
            else:
                vals = body.get("values") or {}
                if str(vals.get("format") or "").strip():
                    out["format"] = bet.save_number_format(name, vals["format"])
                out["learned"] = bet.teach_number_from(name, img, vals.get("number", ""))
        elif action == "ink":
            # read the number by its colour instead of its brightness
            img = self.frames.get(name)
            out["ink"] = bet.save_ink(name, img)
            log.info("'%s' will now be found by colour, so its box can have room to spare.",
                     name)
        elif action == "unink":
            bet.forget_ink(name)
            log.info("'%s' goes back to being read by brightness.", name)
        elif action != "list":
            raise _unknown_action(action, ("list", "grab", "again", "delete", "forget",
                                           "shot", "board", "learn", "look", "ink", "unink"))
        rows = bet.region_list()
        return {**out, "regions": rows, "slots": bet.region_slots(load_settings(), rows)}

    def patterns(self, body: dict) -> dict:
        """A pattern is a named list of clicks (and typing) built from the coordinates."""
        action = str(body.get("action") or "list")
        name = str(body.get("name") or "").strip()
        self._hands_off(action)
        out = {}
        if action == "detail":
            out["pattern"] = bet.pattern_detail(name)
        elif action == "save":
            out["pattern"] = bet.save_pattern(name, body.get("steps") or [])
        elif action == "delete":
            bet.delete_pattern(name)
        elif action == "run":
            bet.run_pattern(name)
            out["ran"] = name
        elif action != "list":
            raise _unknown_action(action, ("list", "detail", "save", "delete", "run"))
        if action in ("save", "delete"):
            self.publish()                       # the open_table list follows the patterns
        return {**out, "patterns": [{"name": n, "steps": len(bet.pattern_detail(n)["steps"])}
                                    for n in bet.pattern_names()]}

    def road_patterns(self, body: dict) -> dict:
        """The library of road shapes you have written down: list, add, change, remove.
        Shared by every site, because a shape of road is not a property of a site."""
        action = str(body.get("action") or "list")
        items = load_patterns()
        if action == "list":
            return {"patterns": items}
        name = str(body.get("name") or "").strip()
        if action == "delete":
            if not name:
                raise ValueError("which pattern should be removed?")
            left = [p for p in items if p["name"] != name]
            if len(left) == len(items):
                raise ValueError(f"there's no saved pattern called '{name}'")
            save_patterns(left)
            log.info("Road pattern '%s' deleted.", name)
            self.publish()                    # so a reload shows the library as it now is
            return {"patterns": left}
        if action in ("save", "add"):
            pat = strategies.clean_pattern(body.get("pattern"))
            name = name or pat
            was = str(body.get("was") or "").strip()      # the name it is replacing, if renamed
            clash = [p for p in items if p["name"] == name and p["name"] != was]
            if clash and action == "add":
                raise ValueError(f"there's already a pattern called '{name}' ({clash[0]['pattern']})"
                                 " — give this one another name")
            item = {"name": name, "pattern": pat, "note": str(body.get("note") or "").strip()}
            items = [item if p["name"] in (name, was) else p for p in items]
            if not any(p["name"] == name for p in items):
                items.append(item)
            save_patterns(items)
            log.info("Road pattern '%s' saved: %s (%s).", name, pat,
                     strategies.describe_pattern(pat))
            self.publish()
            return {"patterns": items, "saved": item}
        if action == "preview":
            pat = strategies.clean_pattern(body.get("pattern"))
            return {"pattern": pat, "columns": strategies.big_road(pat),
                    "describe": strategies.describe_pattern(pat)}
        raise _unknown_action(action, ("list", "save", "delete", "preview"))
