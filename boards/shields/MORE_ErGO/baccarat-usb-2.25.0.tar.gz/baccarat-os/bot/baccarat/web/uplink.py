"""Tells the report server what this bot is doing.

About every 30 s (the server says how often, so a thousand bots don't swamp it) one
small request, gzip'd JSON:
  - the status now: balance, net, lives, table, wins and losses -- a few hundred bytes;
  - what happened since the last call: sessions started and ended, tables finished,
    and every warning and error logged;
  - the full Copy report when a session ends, or when the server's page asks for it.

It only reads what the dashboard already shows (Dashboard.snapshot and its log), so it
can't change how the bot plays. If the server can't be reached nothing waits for it:
the events are kept (the last 500) and sent once it answers again, and the dashboard's
header says so. Never in what is sent: the casino login (the Copy report never has it).

Where, which bot, and how its calls are signed: see remote.py.
"""

from __future__ import annotations

import gzip
import json
import random
import threading
import time
import uuid
from collections import deque
from urllib.parse import quote

from baccarat.core import patterns
from baccarat.log import log
from baccarat.web import template, updatestatus
from baccarat.web.remote import Remote, bot_id, server_url  # noqa: F401  (bot_id, server_url: re-exported)

EVERY = 30            # s between calls, unless the server says otherwise
LOOK = 5              # s between looks at the dashboard (cheap: memory only)
TIMEOUT = 10          # s for one call
MOST_BACKOFF = 300    # s between tries while the server can't be reached
KEEP = 500            # events kept while it can't
PATTERNS_EVERY = 300  # s between fetches of what all bots have seen after each pattern
WARN_LEVELS = {"WARNING": "warning", "ERROR": "error", "CRITICAL": "error"}


def compact(s: dict) -> dict:
    """The status, small: what the server's page shows for this bot now."""
    st = s.get("stats") or {}
    se = s.get("session") or {}
    tb = s.get("table") or {}
    bet = s.get("bet") or {}
    opts = s.get("options") or {}
    out = {
        "running": bool(s.get("running")), "paused": bool(s.get("paused")),
        "status": str(s.get("status") or "")[:160], "error": str(s.get("error") or "")[:200],
        "mode": s.get("mode"), "site": opts.get("site"),
        "strategy": (s.get("strategy") or {}).get("name"),
        "base": s.get("base"), "budget": s.get("budget"), "max_steps": s.get("max_steps"),
        "balance": s.get("balance"), "net": s.get("net"), "score": s.get("score"),
        "wins_needed": s.get("wins_needed"),
        "lives_now": se.get("lives_now"), "lost_now": se.get("lost_now"),
        "W": st.get("W"), "L": st.get("L"), "max_bet": st.get("max_bet"),
        "max_losing_streak": st.get("max_losing_streak"),
        "hands": se.get("hands"), "tables": len(s.get("played") or []),
        "table": tb.get("name"), "bet": bet.get("amount"), "side": bet.get("side"),
        "started": s.get("started"), "alarm": bool(s.get("alarm")),
        # the game set-up it plays, and the server's template it comes from (if any)
        "game": template.game_of(opts.get("settings") or {}) or None,
        "template": template.current()["name"],
        # the stick's own update, while one is under way
        "update": ({k: u.get(k) for k in ("state", "version", "pct")}
                   if (u := s.get("update")) and not u.get("stale")
                   and u.get("state") not in ("current", "done") else None),
    }
    return {k: v for k, v in out.items() if v not in (None, "")}


class Uplink:
    def __init__(self, dash, url: str | None = None, report=None, every: int = EVERY,
                 remote: Remote | None = None):
        self.dash = dash
        self.remote = remote or Remote(url)
        self.url = self.remote.url
        self.report = report            # (state, log lines) -> the Copy report's text
        self.every = every
        self.id = self.remote.id
        self.run = uuid.uuid4().hex[:12]   # this start of the bot: its events count from 1
        self.n = 0
        self.events: deque = deque(maxlen=KEEP)
        self.lock = threading.Lock()
        self.log_seq = dash.logs.since(0)["seq"] if self.url else 0   # only what comes from now on
        self.was_running = False
        self.tables_seen: set = set()
        self.want_report: str | None = None
        self.calls = 0
        self.ok: bool | None = None
        self.since = time.time()
        self.backoff = every
        self.error: str | None = None
        self.approved: bool | None = None
        self.quit = threading.Event()
        self.thread: threading.Thread | None = None
        self.patterns_at: dict[str, float] = {}

    # -- what happened ----------------------------------------------------------------
    def event(self, kind: str, text: str, data: dict | None = None) -> None:
        with self.lock:
            self.n += 1
            ev = {"n": self.n, "t": round(time.time(), 3), "kind": kind, "text": text[:1000]}
            if data:
                ev["data"] = data
            self.events.append(ev)

    def observe(self, s: dict) -> bool:
        """Compare the dashboard now with the last look. → whether to call at once."""
        urgent = False
        running = bool(s.get("running"))
        if running and not self.was_running:
            st = compact(s)
            self.event("session_start", f"session started: {st.get('strategy', '')}, base "
                       f"{st.get('base', '')}, budget {st.get('budget', '')}, site {st.get('site', '')}",
                       {k: st.get(k) for k in ("strategy", "base", "budget", "max_steps", "site")})
            self.tables_seen = set()
        if self.was_running and not running:
            st = compact(s)
            self.event("session_end", f"session ended: {st.get('status', '')} — net {st.get('net', '')}, "
                       f"balance {st.get('balance', '')}, {st.get('W', 0)}W {st.get('L', 0)}L, "
                       f"{st.get('tables', 0)} tables", st)
            self.want_report = "session ended"
            urgent = True
        self.was_running = running
        for t in s.get("played") or []:
            key = (t.get("name"), t.get("started"), t.get("ended"))
            if key in self.tables_seen:
                continue
            self.tables_seen.add(key)
            self.event("table", f"{t.get('name')}: {t.get('won', 0)}W {t.get('lost', 0)}L, net "
                       f"{t.get('net', 0)}, deepest run {t.get('deepest', 0)} lives, biggest bet "
                       f"{t.get('biggest', 0)} ({t.get('reason', '')})", t)
        got = self.dash.logs.since(self.log_seq)
        self.log_seq = got["seq"]
        bad = [ln for ln in got["lines"] if ln.get("level") in WARN_LEVELS]
        for ln in bad[:50]:
            self.event(WARN_LEVELS[ln["level"]], str(ln.get("text", "")))
        if len(bad) > 50:
            self.event("warning", f"… and {len(bad) - 50} more warnings in {LOOK} s (see the report)")
        return urgent

    # -- the call ---------------------------------------------------------------------
    def payload(self, s: dict) -> dict:
        with self.lock:
            events = list(self.events)
        msg = {"v": 1, "bot": self.id, "run": self.run, "status": compact(s), "events": events,
               # what came after each pattern, this bot's share of what all bots learn
               "obs": patterns.take()}
        if self.calls % 20 == 0:                 # who it is: now and then is enough
            msg["info"] = {**self.remote.info(), "site": (s.get("options") or {}).get("site")}
        if self.want_report and self.report:
            try:
                msg["report"] = {"why": self.want_report,
                                 "text": self.report(s, self.dash.logs.since(0)["lines"])}
            except Exception as e:                # a report that can't be built is no reason to stop
                msg["report"] = {"why": self.want_report, "text": f"(the report failed: {e})"}
        return msg

    def send(self, s: dict) -> int:
        """One call. → seconds until the next."""
        msg = self.payload(s)
        body = gzip.compress(json.dumps(msg, separators=(",", ":"), default=str).encode(), 6)
        hdrs = {"Content-Type": "application/json", "Content-Encoding": "gzip"}
        try:
            status, _, data = self.remote.call("POST", "/v1/report", body, hdrs, TIMEOUT)
            reply = json.loads(data or b"{}") if data else {}
            if status == 401 and "enroll" in str(reply.get("error", "")):
                self.remote.enroll()              # the server doesn't know this bot's key yet
                status, _, data = self.remote.call("POST", "/v1/report", body, hdrs, TIMEOUT)
                reply = json.loads(data or b"{}") if data else {}
        except (OSError, ValueError) as e:
            patterns.put_back(msg["obs"])
            return self.failed(str(getattr(e, "reason", e)))
        except Exception as e:                    # the server refused the key (ServerError)
            patterns.put_back(msg["obs"])
            return self.failed(str(e))
        if status != 200:
            patterns.put_back(msg["obs"])
            return self.failed(reply.get("error") or f"the server answered {status}")
        self.calls += 1
        self.approved = reply.get("trusted")
        # the server says up to which event it has stored (it skips any it already had)
        ack = reply.get("ack")
        upto = ack if isinstance(ack, int) else (msg["events"][-1]["n"] if msg["events"] else 0)
        with self.lock:
            while self.events and self.events[0]["n"] <= upto:
                self.events.popleft()
        if "report" in msg:
            self.want_report = None
        if reply.get("report") and not self.want_report:
            self.want_report = "asked from the server"
        if updatestatus.poke(reply.get("release")):   # a new version is out: fetch it now
            log.info("Update %s is out — this stick fetches it now.",
                     (reply.get("release") or {}).get("version") or "?")
        if self.ok is not True:
            log.info("Report server %s: connected.", self.url)
            self.ok, self.since = True, time.time()
        self.publish()
        nxt = reply.get("next")
        wait = nxt if isinstance(nxt, (int, float)) and 5 <= nxt <= 3600 else self.every
        return 1 if self.want_report else wait

    def failed(self, why: str) -> int:
        if self.ok is not False:
            # logged once, as information: it is not the bot's problem, and a warning
            # would only be queued up to be sent to the same server
            log.info("Report server %s can't be reached (%s) — the bot carries on; what "
                     "happens is kept and sent once it answers.", self.url, why)
            self.ok, self.since, self.backoff = False, time.time(), self.every
        else:
            self.backoff = min(MOST_BACKOFF, self.backoff * 2)
        self.error = why
        self.publish()
        return self.backoff

    def publish(self) -> None:
        self.dash.update(uplink={"url": self.url, "ok": self.ok, "since": self.since,
                                 "error": None if self.ok else self.error,
                                 "waiting": len(self.events), "id": self.id[:12],
                                 "code": self.remote.code, "approved": self.approved})

    # -- the thread -------------------------------------------------------------------
    def start(self) -> "Uplink":
        if not self.url:
            log.info("Report server: off.")
            return self
        self.dash.update(uplink={"url": self.url, "ok": None, "id": self.id[:12],
                                 "code": self.remote.code})
        self.thread = threading.Thread(target=self.loop, name="uplink", daemon=True)
        self.thread.start()
        return self

    def fetch_patterns(self, s: dict) -> None:
        """What all bots have seen after the patterns this table shows -- and may show
        after the next hand -- for the set-up being played. Asked again after every new
        result (a few hundred bytes), and every few minutes in any case."""
        cfg = (s.get("runs") or {}).get("config")
        if not cfg:
            return
        road = patterns.bp(s.get("road") or [])[-patterns.KEEP:]
        key = (cfg, road)
        if (self.patterns_at.get("key") == key
                and time.monotonic() - self.patterns_at.get(cfg, -1e9) < PATTERNS_EVERY):
            return
        self.patterns_at[cfg], self.patterns_at["key"] = time.monotonic(), key
        try:
            status, reply = self.remote.json("GET", "/v1/patterns?config=" + quote(cfg)
                                             + "&road=" + road)
        except OSError:
            return
        if status == 200 and isinstance(reply.get("patterns") or reply.get("by_side"), dict):
            patterns.set_stats(cfg, reply)

    def loop(self) -> None:
        due = time.monotonic() + random.uniform(1, 6)   # bots started together don't call together
        while not self.quit.wait(LOOK):
            try:
                s = self.dash.snapshot()
                urgent = self.observe(s)
                if urgent or time.monotonic() >= due:
                    wait = self.send(self.dash.snapshot())
                    due = time.monotonic() + wait * random.uniform(0.9, 1.1)
                if self.ok:
                    self.fetch_patterns(s)
            except Exception as e:                       # never take the bot down
                log.debug("uplink: %s", e)
                due = time.monotonic() + self.every

    def stop(self) -> None:
        """Last call before quitting: what is waiting goes now (a few seconds at most)."""
        self.quit.set()
        if self.thread:
            self.thread.join(timeout=LOOK + 1)
            if self.ok:
                try:
                    s = self.dash.snapshot()
                    self.observe(s)
                    self.send(s)
                except Exception:
                    pass
