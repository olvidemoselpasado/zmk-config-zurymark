"""The command line: python -m baccarat ...

    python -m baccarat                    open the dashboard
    python -m baccarat --play             play the table (places real bets)
    python -m baccarat --stats            every strategy against every stored table
    python -m baccarat --random 300       simulate

Nothing here does any work itself: it reads the arguments, builds a session, and
hands off."""

from __future__ import annotations

import functools

import argparse
import sys
import time
from baccarat import screen as bet
import analysis
from baccarat.study.expect import win_value
from baccarat.study.tablekinds import player_args as kind_player
from baccarat.log import log
from baccarat.web.server import Dashboard, NoDashboard
from baccarat.core.rules import build_rules, RULES
from baccarat.core.session import Session
from baccarat.core.strategy import STRATEGIES


from baccarat.play.actions import LEAVE_WAYS, set_leave_way
from baccarat.play.player import Player
from baccarat.play.reading import no_road_question, parse_road
from baccarat.play.stop import wait_until
from baccarat.play import tuning
from baccarat.setup import cycle_params, kind_params, parse_target
from baccarat.util.clock import parse_start_at
from baccarat.util.show import blue, colored_report, green, money, red, signed
from baccarat.web.api import control_mode


# ---------------------------------------------------------------------------
# Command line: statistics and random simulation (data from analysis.py)
# ---------------------------------------------------------------------------

def print_stats(args) -> None:
    d = analysis.stats_data(args.strategy, args.budget, args.base, args.max_steps, args.ceiling,
                            args.rule, args.table_hands, args.at_cutoff, args.cutoff_margin,
                            args.shadow, args.shadow_after, args.shadow_min_lives,
                            extra_every=args.extra_life, extra_strict=args.extra_strict,
                            extra_after=args.extra_at, extra_for=args.extra_for)
    if not d["tables"]:
        print("\n  No stored tables yet. Record some by playing a table.\n")
        return
    f = d["freq"]
    print(f"\n═══ STATISTICS on {d['tables']} stored tables, {d['rounds']} rounds ═══")
    print(f"Results seen: banker {f['banker']:.1%}  player {f['player']:.1%}  tie {f['tie']:.1%}")
    print(f"Each table played separately │ budget {green(money(args.budget))} │ "
          f"base bet {blue(money(args.base))}"
          + (f" │ max {args.max_steps} doublings" if args.max_steps else "")
          + (f" │ ceiling {green(money(args.ceiling))}" if args.ceiling else "")
          + "".join(f" │ rule {r.label}" for r in build_rules(args.rule))
          + (f" │ {args.table_hands} hands/table" if args.table_hands else ""))
    if d["rows"]:
        print(f"\nStrategy {d['strategies'][0]}\n")
        print(f"  {'table':26s} {'seen':>5s} {'bets':>5s} {'W-L':>7s} {'net':>11s} "
              f"{'max bet':>9s}  note")
        for r in d["rows"]:
            note = "complete" if r["complete"] else f"joined at #{r['joined_at']}"
            if r["stopped"]:
                note += red(" · stopped (bet > balance)")
            if r["reached"]:
                note += green(" · reached ceiling")
            net = f"{r['net']:+,.2f}"
            max_bet = f"{r['max_bet']:9,.0f}"
            print(f"  {r['table']:26s} {r['seen']:5d} {r['bets']:5d} {r['wins']:3d}-{r['losses']:<3d} "
                  f"{red(f'{net:>11s}') if r['net'] < 0 else f'{net:>11s}'} "
                  f"{blue(max_bet)}  {note}")
        t = d["totals"][0]
        rate = f"{t['rate']:.1%}" if t["rate"] is not None else "-"
        per100 = f"{t['per100']:+.2f}" if t["per100"] is not None else "-"
        print(f"\n  Bets {t['bets']}   wins {t['wins']}   losses {t['losses']}   win rate {rate}")
        print(f"  Tables ahead {t['ahead']}/{t['sessions']}   stopped early {t['stopped']}"
              + (f"   reached ceiling {t['reached']}" if args.ceiling else ""))
        print(f"  Total net {signed(t['net'])}   return per 100 bet {per100}")
    else:
        print(f"\n  {'strategy':18s} {'bets':>6s} {'win rate':>9s} {'tables ahead':>13s} "
              f"{'stopped':>8s} {'total net':>12s} {'per 100 bet':>12s}")
        for t in d["totals"]:
            rate = f"{t['rate']:.1%}" if t["rate"] is not None else "-"
            per100 = f"{t['per100']:+.2f}" if t["per100"] is not None else "-"
            net_s = f"{t['net']:+,.2f}"
            print(f"  {t['strategy']:18s} {t['bets']:6d} {rate:>9s} "
                  f"{str(t['ahead']) + '/' + str(t['sessions']):>13s} {t['stopped']:8d} "
                  f"{red(f'{net_s:>12s}') if t['net'] < 0 else f'{net_s:>12s}'} {per100:>12s}")
    if d["tables"] < 30:
        print(f"\n  (only {d['tables']} tables — results this small are mostly luck;"
              f" compare with --random for the long run)")
    print()


def print_random(args) -> None:
    d = analysis.random_data(args.strategy, args.budget, args.base, args.max_steps,
                             ceiling=args.ceiling, rounds=args.random, runs=args.runs,
                             seed=args.seed, rules=args.rule, table_hands=args.table_hands,
                             at_cutoff=args.at_cutoff, cutoff_margin=args.cutoff_margin,
                             shadow_unit=args.shadow, shadow_after=args.shadow_after,
                             shadow_min_lives=args.shadow_min_lives,
                             extra_every=args.extra_life, extra_strict=args.extra_strict,
                            extra_after=args.extra_at, extra_for=args.extra_for)
    n = d["runs"]
    print(f"\n═══ RANDOM SIMULATION: {n} sessions × up to {d['rounds']} rounds ═══")
    print(f"Strategy {args.strategy}  │  budget {green(money(args.budget))}  │  "
          f"base bet {blue(money(args.base))}"
          + (f"  │  max {args.max_steps} doublings" if args.max_steps else "")
          + (f"  │  ceiling {green(money(args.ceiling))}" if args.ceiling is not None else "")
          + "".join(f"  │  rule {r.label}" for r in build_rules(args.rule))
          + (f"  │  {args.table_hands} hands/table" if args.table_hands else ""))
    print(f"\n  Finished ahead        {d['ahead'] / n:6.1%}  ({d['ahead']} sessions)")
    print(f"  Stopped early         {d['stopped'] / n:6.1%}  "
          f"({d['stopped']} sessions: next doubled bet > balance)")
    if args.table_hands and args.at_cutoff == "stop":
        print(f"  Ended at a table's end {d['finished'] / n:6.1%}  ({d['finished']} sessions)")
    if args.ceiling is not None:
        print(f"  Reached ceiling       {d['reached'] / n:6.1%}  ({d['reached']} sessions)")
    print(f"  Average net           {signed(d['mean'])}")
    print(f"  Median net            {signed(d['median'])}")
    print(f"  Best / worst session  {signed(d['best'])} / {signed(d['worst'])}")
    if d["per100"] is not None:
        print(f"  Return per 100 bet    {d['per100']:+.2f}")
    print(f"  Avg biggest bet       {blue(money(d['avg_max_bet']))}")
    print(f"  Longest losing streak {d['max_streak']}")
    print(f"  Worst losing run      {d['worst_run']} lives needed to win it back")
    for rs in d["rule_stats"]:
        print(f"  Rule '{rs['rule']}': took over {rs['triggered']}×, won back {rs['rescued']}× "
              f"({rs['rescued'] / rs['triggered']:.0%})" if rs["triggered"] else
              f"  Rule '{rs['rule']}': never triggered")
    print("\n── Example session ──")
    print(colored_report(d["example"]))


# ---------------------------------------------------------------------------

def _scroll_arg(text: str) -> tuple:
    name, _, n = str(text).partition("=")
    try:
        return name.strip(), int(n)
    except ValueError:
        raise SystemExit(f"--open-scroll: '{text}' should look like open_table_3=5") from None


def new_session(args) -> Session:
    return analysis.new_session(args.strategy, args.budget, args.base, args.max_steps, args.ceiling,
                                args.rule, args.table_hands, args.at_cutoff, args.cutoff_margin,
                                args.shadow, args.shadow_after, args.shadow_min_lives,
                                extra_every=args.extra_life, extra_strict=args.extra_strict,
                            extra_after=args.extra_at, extra_for=args.extra_for,
                                watch=not args.no_watch)


def main() -> None:
    global USE_COLOR
    p = argparse.ArgumentParser(
        prog="python -m baccarat",description="Baccarat table bot / strategy tester")
    mode = p.add_mutually_exclusive_group()
    mode.add_argument("--play", action="store_true",
                      help="Play the table — this places real bets with real money.")
    mode.add_argument("--stats", action="store_true", help="Strategy results on the stored tables.")
    mode.add_argument("--random", type=int, metavar="ROUNDS", help="Simulate random rounds.")
    mode.add_argument("--list-strategies", action="store_true")
    p.add_argument("--strategy", default="streak_or_chop", help="A strategy name, or 'all' with --stats.")
    p.add_argument("--budget", type=float, default=1000.0)
    p.add_argument("--base", type=float, default=20.0, help="Base bet (doubled after each loss).")
    p.add_argument("--max-steps", type=int, default=None,
                   help="Restart at the base bet after this many losses in a row.")
    p.add_argument("--rule", action="append", default=[], metavar="NAME[=N[,N…]]",
                   help="Add a rule, e.g. loss_streak=3, or majority=3,12 (3 losses, favourite "
                        "of the last 12 results). Repeatable. See --list-strategies.")
    p.add_argument("--win", type=str, default=None, metavar="AMOUNT",
                   help="How much to win before stopping, e.g. 60 (budget 320 → stop at 380).")
    p.add_argument("--ceiling", type=str, default=None,
                   help="Stop betting when the balance reaches this (e.g. 1500), or +PROFIT (e.g. +500).")
    p.add_argument("--ui", action="store_true", help="With --play: also show the dashboard.")
    p.add_argument("--ui-port", type=int, default=8765)
    p.add_argument("--no-open", action="store_true", help="Don't open the dashboard window automatically.")
    p.add_argument("--locked", action="store_true",
                   help="The locked bot: its configuration and casino login come from the server "
                        "(BACCARAT_SERVER) at start and are kept there. Also BACCARAT_LOCKED=1.")
    p.add_argument("--start-at", type=str, default=None, metavar="TIME",
                   help='With --play: wait until this time, e.g. "12:45", "12:45 PM", '
                        '"18:45 local". UTC unless it says local.')
    p.add_argument("--table-hands", type=int, default=None, metavar="N",
                   help="Hands per table (e.g. 40). No new losing run starts in the last "
                        "--cutoff-margin hands of it.")
    p.add_argument("--shadow", type=float, default=0.0, metavar="AMOUNT",
                   help="Shadow bet: a second martingale for this flat amount, joining a "
                        "losing run once it is --shadow-after losses deep (0 = off).")
    p.add_argument("--shadow-after", type=int, default=2, metavar="N",
                   help="Losses in a row before the shadow joins (default 2).")
    p.add_argument("--shadow-min-lives", type=int, default=5, metavar="N",
                   help="The shadow stands down unless the run can still reach this many "
                        "bets with it attached (default 5).")
    p.add_argument("--extra-life", type=int, default=0, metavar="N",
                   help="Extra life: one first loss in N is taken and the base bet placed again "
                        "instead of doubling -- one more life for one base bet (0 = off, the "
                        "default). It is bought on the first one, then every Nth.")
    p.add_argument("--extra-strict", type=int, default=2, metavar="S",
                   help="… one in S instead once a run reaches --extra-at (default 2).")
    p.add_argument("--extra-at", type=int, default=6, metavar="L",
                   help="The life that makes it strict: base × 2^(L-1), so life 6 is the 640 "
                        "bet at base 20 (default 6).")
    p.add_argument("--extra-for", type=int, default=20, metavar="M",
                   help="Strict until M losses go by with no run reaching life L; a run that "
                        "reaches it again starts the count over (default 20).")
    p.add_argument("--cutoff-margin", type=int, default=tuning.CUTOFF_MARGIN, metavar="N",
                   help=f"Hands kept free at the end of a table: no new run starts after hand "
                        f"(table-hands - N), +/-1 at random (default {tuning.CUTOFF_MARGIN}).")
    p.add_argument("--at-cutoff", choices=("wait", "switch", "stop"), default="switch",
                   help="When a table runs out of room: close it and open another one "
                        "(default, needs --open-pattern), wait for it to end, or stop. "
                        "With an open action set, waiting also closes and reopens, so the "
                        "browser is never left idle.")
    p.add_argument("--cycles", type=int, default=1, metavar="N",
                   help="Unattended: reach the ceiling N times, opening a new table each time.")
    p.add_argument("--open-pattern", action="append", default=[], metavar="NAME",
                   help="Pattern that opens a table (repeatable; used in order).")
    p.add_argument("--open-scroll", action="append", default=[], metavar="NAME=N",
                   help="Arrow presses needed to bring an open action into view, e.g. "
                        "open_table_3=5 (negative scrolls up; repeatable).")
    p.add_argument("--wait-hands", type=int, default=None, metavar="N",
                   help="Hands a table usually lasts (e.g. 44), used only to guess how long to "
                        "wait for it to finish. The cutoff still uses --table-hands.")
    p.add_argument("--hand-seconds", type=float, default=tuning.HAND_SECONDS,
                   help="Seconds one hand takes, for the wait between tables (default 15).")
    p.add_argument("--extra-wait", type=float, default=tuning.CYCLE_EXTRA,
                   help="Extra seconds on top of that wait (default 20, times 1–1.5 at random).")
    p.add_argument("--leave", choices=LEAVE_WAYS, default="close",
                   help="How to leave a table: close its tab (default), or reload the page "
                        "for sites that load the table into the same page.")
    p.add_argument("--bet-start-on", choices=("game", "chips"), default="game",
                   help="When the betting window starts counting: when the game number "
                        "changes (default), or when the chips appear on screen — for tables "
                        f"that don't open the betting at a fixed moment. Needs a '{tuning.CHIP_REGION}' "
                        "region with one example of each look.")
    p.add_argument("--hard-score", action="store_true",
                   help="Treat the screen score as the real money: refuse to start unless it "
                        "matches the budget. Without it the score is never read.")
    p.add_argument("--bet-window", type=float, default=tuning.BET_WINDOW[1], metavar="SECONDS",
                   help=f"Seconds the table takes bets after a game ends (default {tuning.BET_WINDOW[1]:g}).")
    p.add_argument("--click-min", type=float, default=tuning.CLICK_SPEED[0], metavar="SECONDS",
                   help=f"Fastest a single click may be (default {tuning.CLICK_SPEED[0]:g}).")
    p.add_argument("--click-max", type=float, default=tuning.CLICK_SPEED[1], metavar="SECONDS",
                   help=f"Slowest a single click may be (default {tuning.CLICK_SPEED[1]:g}).")
    p.add_argument("--no-alarm", action="store_true",
                   help="Don't sound the alarm when the next bet is the last one the balance "
                        "can cover (the alarm needs the dashboard: --ui).")
    p.add_argument("--no-watch", action="store_true",
                   help="When the money runs out, stop at once instead of watching the same "
                        "table (for free) to see how many more lives the run needed.")
    p.add_argument("--no-ask", action="store_true",
                   help="Don't ask for the table's results when joining (watch first rounds instead).")
    p.add_argument("--road", type=str, default=None,
                   help='Results already on the table when joining, oldest first, e.g. "B P B".')
    p.add_argument("--runs", type=int, default=1000, help="--random: number of sessions.")
    p.add_argument("--seed", type=int, default=None, help="--random: repeatable results.")
    p.add_argument("--no-color", action="store_true")
    p.add_argument("--debug", action="store_true")
    p.add_argument("--site", type=str, metavar="NAME",
                   help="Play this site: its own coordinates, patterns, screen regions and "
                        "settings, from sites/NAME/ (made if it is new). Without it, the site "
                        "last used. Record one with: python bet.py --site NAME --coords")
    p.add_argument("--list-sites", action="store_true",
                   help="Show the sites that are set up, and which one is in use.")
    args = p.parse_args()

    if args.no_color:
        USE_COLOR = False
    if args.site:
        bet.use_site(args.site)
    set_leave_way(args.leave)
    if args.list_sites:
        print("Sites (* = in use):")
        for n in bet.list_sites() or ["(none yet)"]:
            print(f"  {'*' if n == bet.site_name() else ' '} {n}")
        return
    if not (args.play or args.stats or args.random or args.list_strategies):
        control_mode(args)                  # no mode given → everything from the dashboard
        return
    if args.list_strategies:
        print("Strategies:")
        for name, cls in STRATEGIES.items():
            print(f"  {name:18s} {cls.description}")
        print("\nRules (add with --rule NAME=N, or NAME=N,N… in this order):")
        for name, cls in RULES.items():
            ps = ", ".join(f"{k} = {p['label']} (default {p['default']})"
                           for k, p in cls.params.items())
            print(f"  {name:18s} {cls.description}" + (f"  [{ps}]" if ps else ""))
        return
    if args.strategy != "all" and args.strategy not in STRATEGIES:
        p.error(f"unknown strategy '{args.strategy}' (see --list-strategies)")
    try:
        build_rules(args.rule)
    except ValueError as e:
        p.error(f"--rule: {e}")
    try:
        if args.win and args.ceiling:
            p.error("use --win (how much to win) or --ceiling (a fixed balance), not both")
        args.ceiling, args.target = parse_target(
            args.win if args.win else (f"={args.ceiling}" if args.ceiling else None), args.budget)
    except ValueError as e:
        p.error(f"--win: {e}")
    when = None
    if args.start_at:
        if not args.play:
            p.error("--start-at works with --play")
        try:
            when = parse_start_at(args.start_at)
        except ValueError as e:
            p.error(f"--start-at: {e}")
    road = None
    if args.road is not None:
        try:
            road = parse_road(args.road)
        except ValueError as e:
            p.error(f"--road: {e}")

    try:
        if args.stats:
            print_stats(args)
        elif args.random:
            print_random(args)
        else:
            if args.strategy == "all":
                p.error("'all' only works with --stats")
            bet.setup_logging(args.debug)
            bet.set_number_format("score", decimals=2, symbol="$")   # shown as $1,250.50
            dash = NoDashboard()
            if args.ui:
                dash = Dashboard(args.ui_port, shots_dir=bet.debug_dir(),
                                 snaps_dir=bet.snaps_dir)
                try:
                    dash.start()
                except RuntimeError as e:
                    p.error(str(e))
                log.info("Dashboard: %s  (open it in its own window, not over the game)", dash.url)
            if when:
                wait_until(*when)
            try:
                cyc = cycle_params({"cycles": args.cycles, "open_patterns": args.open_pattern,
                                    "hand_seconds": args.hand_seconds, "extra_wait": args.extra_wait,
                                    "wait_hands": args.wait_hands},
                                   {"ceiling": args.ceiling, "target": args.target,
                                    "budget": args.budget, "table_hands": args.table_hands,
                                    "at_cutoff": args.at_cutoff})
            except ValueError as e:
                p.error(f"--cycles: {e}")
            session = new_session(args)
            params = dict(strategy=args.strategy, budget=args.budget, base=args.base,
                          max_steps=args.max_steps, rules=args.rule,
                          table_hands=args.table_hands, at_cutoff=args.at_cutoff,
                          cutoff_margin=args.cutoff_margin, extra_every=args.extra_life,
                          extra_strict=args.extra_strict, extra_after=args.extra_at,
                          extra_for=args.extra_for)
            Player(session, road=road, dash=dash,
                   ask=no_road_question if (args.no_ask or cyc["cycles"] > 1) else None,
                   alarm=not args.no_alarm, hard_score=args.hard_score,
                   bet_start_on=args.bet_start_on,
                   open_scroll=dict(_scroll_arg(v) for v in args.open_scroll),
                   bet_window=args.bet_window,
                   click_speed=(args.click_min, args.click_max), **cyc,
                   estimator=functools.partial(
                       win_value, **params),
                   **kind_player(session.rules, params, kind_params({}))).run()
            if args.ui:
                log.info("Stopped. The dashboard stays open at %s — press Ctrl+C to quit.", dash.url)
                try:
                    while True:
                        time.sleep(1)
                except KeyboardInterrupt:
                    print()
    except bet.BetError as e:
        log.error("%s", e)
        sys.exit(1)
    except KeyboardInterrupt:
        print()
