"""core — the game, with no screen, no mouse and no files.

Everything here is a function of its arguments. That is what makes a replay
worth anything: the simulations and the live table run this same code, so a
strategy cannot be scored one way in a backtest and another way with money on
it.

    game       the three sides, their letters, what a win pays
    strategy   which side, from the road
    rules      taking over from the strategy for a while
    staking    how much; how many losses this balance survives
    session    the balance, the road, the statistics -- one sitting
    road       runs, letters, the big road, finding a shape in it
    screening  deciding a table is not worth sitting at
    bets       chips, and the clicks that place them

This list is the layer's public surface.
"""

from __future__ import annotations

# Every import below is a re-export: that is this file's whole job.
# ruff: noqa: F401

# game — the rules of baccarat nothing disagrees about
from baccarat.core.game import (OPPOSITE, PAYOUT, SHORT, SIDES, SKIP)

# strategy — which side to bet on
from baccarat.core.strategy import (AllDowns, BluesDown, get_strategy, no_ties,
    register, STRATEGIES, Strategy, StreakOrChop, StreakOrChop2)

# rules — taking over from the strategy
from baccarat.core.rules import (BluesOnce, build_rules, config_key, LossStreak,
    Majority, register_rule, Rule, RULES)

# staking — how much, and how many losses the balance survives
from baccarat.core.staking import (Doubling, lives, settle)

# session — the balance, the road and the statistics
from baccarat.core.session import (RoundResult, Session)

# road — runs, letters, and finding a shape
from baccarat.core.road import (big_road, find_pattern, road_letters, run_lengths)

# screening — turning a table down before sitting at it
from baccarat.core.screening import (build_patterns, clean_pattern, describe_pattern,
    screen_table)

from baccarat.core import bets, game, road, rules, screening, session
from baccarat.core import staking, strategy

# `import *` skips underscored names and a few tests want them.
__all__ = [_n for _n in list(globals()) if not _n.startswith("__")]
