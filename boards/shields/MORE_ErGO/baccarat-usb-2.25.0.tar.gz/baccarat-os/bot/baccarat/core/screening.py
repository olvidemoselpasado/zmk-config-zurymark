"""Screening a table before sitting down.

Every strategy has shapes of road that beat it. Rather than discover that with
money, the road is read first and compared against the patterns you have
written down; enough of them and the table is turned down, with the reason and
a screenshot saying which shape was found where.

min_history exists because a shape means nothing on a table that has barely
started -- there is no evidence either way in nine hands."""

from __future__ import annotations



from baccarat.core.road import find_pattern, road_letters, run_lengths


def clean_pattern(text: str) -> str:
    """What you typed → the letters to look for. Spaces and case don't matter."""
    pat = "".join(c for c in str(text or "").upper() if not c.isspace())
    bad = sorted(set(pat) - set("PB"))
    if bad:
        raise ValueError("a pattern is written with P and B only (ties are ignored) — "
                         f"not {', '.join(repr(c) for c in bad)}")
    if len(pat) < 2:
        raise ValueError("a pattern needs at least two results, like PPBB")
    if len(pat) > 60:
        raise ValueError("that pattern is longer than any table — keep it under 60 results")
    return pat


def describe_pattern(pattern: str) -> str:
    """'BBPPBB' → 'two banker, two player, two banker'."""
    counts = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six"}
    return ", ".join(f"{counts.get(n, n)} {w}" for w, n in run_lengths(
        ["player" if c == "P" else "banker" for c in pattern]))


def build_patterns(specs) -> list[dict]:
    """[{"name": …, "pattern": "BBPPBB", "times": 2}, …] → checked patterns.
    A pattern seen `times` or more on a table is a reason to walk away from it."""
    out = []
    for spec in specs or []:
        if isinstance(spec, str):
            name, _, rest = spec.partition("=")
            spec = {"name": name.strip(), "pattern": rest or name}
        pat = clean_pattern(spec.get("pattern"))
        try:
            # not `or 1`: that reads a typed 0 as "once", which is the most
            # eager setting there is — a table turned down the first time the
            # shape appears — and it would arrive silently.
            given = spec.get("times")
            times = 1 if given is None or given == "" else int(given)
        except (TypeError, ValueError):
            raise ValueError(f"'{spec.get('name') or pat}': how many times to see it "
                             "must be a whole number") from None
        if times < 1:
            raise ValueError(f"'{spec.get('name') or pat}': it has to be seen at least once")
        out.append({"name": str(spec.get("name") or pat).strip() or pat,
                    "pattern": pat, "times": times})
    return out


def screen_table(road, patterns, min_history: int = 20) -> dict:
    """Should we sit down at this table? Reports every pattern, the ones that were
    not found as well as the one that was, so the dashboard can show the near misses."""
    letters = road_letters(road)
    if not patterns:
        return {"bad": False, "why": "", "short": False, "hands": len(letters), "checks": []}
    if len(letters) < min_history:
        return {"bad": True, "short": True, "hands": len(letters), "checks": [],
                "why": (f"only {len(letters)} results on this table — {min_history} are "
                        f"needed before it can be judged")}
    checks, bad = [], []
    for p in patterns:
        found = find_pattern(letters, p["pattern"])
        hit = len(found) >= p["times"]
        where = (f" (at {', '.join('hand ' + str(i + 1) for i in found[:4])}"
                 + (", …" if len(found) > 4 else "") + ")") if found else ""
        why = (f"{p['pattern']} on whole runs {len(found)}× in {len(letters)} results"
               f"{where}, needs {p['times']}×")
        checks.append({"name": p["name"], "pattern": p["pattern"], "times": p["times"],
                       "found": len(found), "at": found, "bad": hit, "why": why})
        if hit:
            bad.append(f"{p['name']} ({p['pattern']}) seen {len(found)}×")
    return {"bad": bool(bad), "short": False, "hands": len(letters), "checks": checks,
            "why": "; ".join(bad)}
