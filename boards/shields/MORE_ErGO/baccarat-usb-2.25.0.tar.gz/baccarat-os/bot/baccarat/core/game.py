"""The rules of baccarat that nothing gets to disagree about.

The three sides, their letters, and what a winning bet pays. PAYOUT["banker"]
is 0.95 because most tables take 5% commission on a banker win; set it to 1.0
for a commission-free table and every strategy, replay and statistic follows."""

from __future__ import annotations





SIDES = ("player", "banker", "tie")


SHORT = {"player": "P", "banker": "B", "tie": "T"}


# Winnings per unit bet. Most tables take 5% commission on banker wins.
# Change BANKER to 1.0 if your table is commission-free.
PAYOUT = {"player": 1.0, "banker": 0.95, "tie": 8.0}


# ---------------------------------------------------------------------------
# Rules: take over from the strategy for a while, then hand control back
# ---------------------------------------------------------------------------

OPPOSITE = {"player": "banker", "banker": "player"}


SKIP = "skip"        # a rule may ask for NO bet at all this hand, instead of a side
