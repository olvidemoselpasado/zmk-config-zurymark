"""Session -- the balance, the road and the statistics.

One object per sitting. The same Session is used for live play and for every
simulation, which is the only reason a replay can be trusted to tell you what
would have happened: there is not a second implementation of the counting to
drift away from this one.

It is a big class and that is on purpose. Everything here is one piece of state
that changes together on every hand -- balance, ladder step, run, road,
counters -- and splitting that across objects buys tidier files at the price of
the thing being hard to reason about. What has been lifted out is everything
that is NOT that state: the maths of the ladder (staking), what the strategies
and rules decide (strategy, rules), and the formatting (report)."""

from __future__ import annotations

import math

import random
from dataclasses import dataclass, field


from baccarat.core.game import PAYOUT, SHORT, SKIP
from baccarat.core.rules import config_key
from baccarat.core.staking import Doubling, lives, settle
from baccarat.core.strategy import no_ties, Strategy


# ---------------------------------------------------------------------------
# Session: balance, road and statistics
# ---------------------------------------------------------------------------

def _nth(k: int) -> str:
    """1st, 2nd, 3rd, 4th … 11th, 12th, 13th … 21st."""
    return f"{k}{'th' if 10 <= k % 100 <= 20 else {1: 'st', 2: 'nd', 3: 'rd'}.get(k % 10, 'th')}"


@dataclass
class RoundResult:
    game: int | None
    winner: str | None
    side: str | None = None          # what we bet on (None = no bet)
    amount: float = 0.0
    outcome: str = "NO BET"          # WIN / LOSS / PUSH / NO BET / UNKNOWN
    profit: float = 0.0
    balance: float = 0.0
    by: str | None = None            # who chose the bet: the strategy or a rule
    # After the money runs out the session keeps watching without betting: this is
    # the bet it WOULD have made, and how it would have gone. The balance doesn't move.
    virtual: dict | None = None


@dataclass
class Session:
    strategy: Strategy
    staking: Doubling
    budget: float
    ceiling: float | None = None     # stop betting once the balance reaches this
    balance: float = field(init=False)
    road: list[str] = field(default_factory=list)
    leave_for: str | None = None      # a reason to leave this table once the run is won
    halt_for: str | None = None       # a reason to end the session once the run is won
    halt_resume: bool = False         # … and to start it again afterwards (an update)
    results: list[RoundResult] = field(default_factory=list)
    busted: bool = False
    reached_ceiling: bool = False
    peak: float = field(init=False)
    max_drawdown: float = 0.0
    max_bet: float = 0.0
    losing_streak: int = 0
    max_losing_streak: int = 0
    rules: list = field(default_factory=list)
    # Table end: a table lasts `table_hands` hands, and a NEW losing run only starts
    # while at least `cutoff_margin` of them are left. A flat margin on purpose: how many
    # HANDS a run occupies depends on the strategy (all_downs bets every hand, blues_down
    # only about one in three), so counting lives would be wrong for half of them.
    table_hands: int | None = None
    cutoff_margin: int = 20          # hands kept in reserve at the end of a table
    at_cutoff: str = "wait"          # after the cutoff: "wait" for the next table, or "stop"
    cutoff_jitter: int = 0           # −1, 0 or +1, picked for each table
    table_done: bool = False         # this table is past its cutoff (no new runs)
    finished: bool = False           # at_cutoff == "stop" and the cutoff was reached
    skip_reason: str = ""
    decided_by: str | None = None
    events: list = field(default_factory=list)     # messages from the last record()
    # After the money runs out: keep watching the table and follow the losing run
    # without betting, to see how many more lives it would have needed to win.
    watch_after_bust: bool = True
    watching: bool = False           # busted, still following the run for free
    watch_over: bool = False         # the watch finished (won, or the table ended)
    watch_bets: int = 0              # virtual bets since busting (each one = one more life)
    watch_stakes: list = field(default_factory=list)
    watch_result: str = ""           # one line for the log and the dashboard
    watch_won: bool = False
    virtual_bet: tuple | None = None    # the bet this hand would have taken
    bust_stake: float = 0.0           # the bet the balance couldn't cover
    bust_balance: float = 0.0         # the balance left at that moment
    lives_used: int = 0               # losses paid for before the money ran out
    lives_needed: int | None = None   # lives the whole run needed to win (None = never won)
    # Shadow bet: once a losing run is `shadow_after` losses deep, the stake becomes the
    # shadow amount INSTEAD of the doubled base bet, and doubles from there. It dwarfs
    # the base ladder anyway, so adding the two together only made amounts the chips
    # couldn't build. It wins the run's losses back and more. It only takes over a bet
    # the strategy chose, and only when the run can still reach `shadow_min_lives` bets.
    # A winning episode moves the unit up the ladder (1000 → 2000 → 4000); three wins,
    # or any losing episode, puts it back.
    shadow_unit: float = 0.0          # 0 = off
    shadow_after: int = 2             # losses in a row before it joins
    shadow_ladder: int = 3            # winning episodes before the unit starts over
    shadow_min_lives: int = 5         # the run must still reach this many bets
    shadow_level: int = 0             # 0,1,2 → unit × 2^level
    shadow_on: bool = False           # riding the run going on now
    shadow_stake: float = 0.0         # the extra on the bet just picked
    shadow_staked: float = 0.0        # extra money put up this session
    shadow_wins: int = 0
    shadow_losses: int = 0
    shadow_blocked: int = 0           # times it stood down to protect the lives floor
    shadow_capped: int = 0            # times the budget pushed it back down the ladder
    # Extra life: when a run's FIRST bet (the base bet) loses, the loss can be taken and
    # the base bet placed again instead of doubling -- from there the run doubles as
    # usual. That is one more life for the price of one base bet. It is always on (when
    # set up), on a rhythm: one first loss bought, then `extra_every - 1` doubling as
    # usual, then one bought … Once a run reaches life `extra_after` (with base 20,
    # life 6 is the 640 bet) it goes STRICT: one bought in every `extra_strict` (2 = every
    # other). Every run that reaches that life again keeps it strict and starts the
    # count over; `extra_for` losses without one put it back to the usual rhythm.
    extra_every: int = 0              # 0 = off; usually one first loss bought in this many
    extra_strict: int = 2             # … and one in this many while strict
    extra_after: int = 6              # the life that makes it strict
    extra_for: int = 20               # losses without reaching that life end the strictness
    extra_active: bool = False        # strict right now
    extra_quiet: int = 0              # losses since a run last reached that life
    extra_seen: int = 0               # first losses since the rhythm (re)started
    extra_buy_next: bool = True       # the next first loss is bought
    extra_held: bool = False          # this run's first loss was bought: stake still base
    extra_bought: int = 0             # extra lives bought this session
    extra_cost: float = 0.0           # the base bets they cost
    extra_ons: int = 0                # times it switched on
    # a SAVE: a run the extra life was bought for that won on a bet the balance alone
    # couldn't have paid for -- without the extra life it would have ended the session
    extra_run: dict | None = None     # the run going on now was bought for: where it began
    extra_deep: bool = False          # the run going on now has reached that life
    extra_saves: list = field(default_factory=list)
    extra_finished: int = 0           # bought runs that have ended, saved or not
    # every losing run (base → doubled → … → win) this session actually played
    run_bets: int = 0                 # decided bets in the run going on now
    last_run: dict | None = None      # set by the record() that ended a run
    # what one win really nets, and the hands it takes: measured by replaying this
    # configuration (study/expect.py) and handed in from outside -- the session itself
    # never reads a file. None = not measured yet: one base bet a win.
    per_win: float | None = None
    hands_per_win: float | None = None
    runs: list = field(default_factory=list)

    @property
    def active_rule(self):
        return next((r for r in self.rules if r.active), None)

    def __post_init__(self):
        self.balance = self.peak = self.budget
        self.extra_buy_next = self._extra_turn(0)
        self.corrections: list[dict] = []    # times the screen put our balance right

    def new_table(self, prior_road: list[str] | None = None) -> None:
        """A new table (shoe) started: strategies only look at this table's
        results. Balance and the current stake carry over."""
        self.road = list(prior_road or [])
        self.leave_for = None
        self.cutoff_jitter = random.choice((-1, 0, 1))
        self.table_done = False

    # -- table end ------------------------------------------------------------
    @property
    def in_run(self) -> bool:
        """A losing run is going on (doubled stake, a rule in charge, or a first loss
        bought with an extra life and the base bet going on again)."""
        return self.staking.step > 0 or self.active_rule is not None or self.extra_held

    def hands_needed(self) -> int:
        """Hands kept in reserve at the end of a table, for a run to play itself out in."""
        return max(1, int(self.cutoff_margin))

    def lives_affordable(self) -> int:
        """Lives the balance pays for from the base bet (for the report, not the cutoff)."""
        fresh = Doubling(self.staking.base, self.staking.max_steps)
        n = len(lives(self.balance, fresh)[0])
        return min(n, self.staking.max_steps) if self.staking.max_steps else n

    def cutoff_hand(self) -> int | None:
        """Last hand of the table on which a new run may start."""
        if not self.table_hands:
            return None
        return self.table_hands - self.hands_needed() + self.cutoff_jitter

    # -- before the round ---------------------------------------------------
    def pick(self) -> tuple[str, float] | None:
        """Side and stake for this round, ignoring the balance: a rule first, then
        the strategy. None = nothing to bet on."""
        side, self.decided_by = None, None
        for rule in self.rules:
            choice = rule.decide(self)
            if choice == SKIP:                   # this rule wants no bet at all this hand
                self.skip_reason = rule.skip_text()
                return None
            if choice:
                side, self.decided_by = choice, rule.name
                break
        if side is None:
            side = self.strategy.decide(self.road)
            self.decided_by = self.strategy.name if side else None
            if side is None and not self.skip_reason:
                seen = len(no_ties(self.road))
                need = getattr(self.strategy, "n", 0)
                self.skip_reason = (
                    f"{self.strategy.name} needs {need} result{'' if need == 1 else 's'} in "
                    f"order and has {seen} — it can't know what came before you joined unless "
                    f"the road is loaded"
                    if seen < need else
                    f"{self.strategy.name} sees no bet in this pattern")
        if side not in ("player", "banker"):     # tie is never bet
            self.decided_by = None
            return None
        self.shadow_stake = self._shadow_bet()
        # the shadow replaces the stake, it is not added to it
        return side, round(self.shadow_stake or self.staking.amount, 2)

    # -- the shadow bet -------------------------------------------------------
    @property
    def shadow_now(self) -> float:
        """The unit the next episode would use."""
        return self.shadow_unit * (2 ** self.shadow_level)

    def _shadow_bet(self) -> float:
        """What the shadow stakes this hand (0 when it isn't riding)."""
        if not self.shadow_unit:
            return 0.0
        k = self.staking.step
        if k < self.shadow_after:
            return 0.0
        if not self.shadow_on:
            # it joins at the trigger or not at all — a martingale started halfway
            # through could never win back what it had already lost
            if k != self.shadow_after:
                return 0.0
            if self.decided_by != self.strategy.name:
                return 0.0                       # rule bets are left alone
            # take the highest rung of the ladder the lives floor can carry. Without
            # this the ladder would jam: one win pushes the unit to a rung the budget
            # can't afford, it stands down for ever and never wins its way back.
            lvl = self.shadow_level
            while lvl >= 0 and not self.shadow_affordable(self.shadow_unit * 2 ** lvl):
                lvl -= 1
            if lvl < 0:
                self.shadow_blocked += 1
                return 0.0
            if lvl != self.shadow_level:
                self.shadow_capped += 1
                self.shadow_level = lvl
            self.shadow_on = True
        return self.shadow_now * (2 ** (k - self.shadow_after))

    def stake_at(self, j: int, unit: float | None = None) -> float:
        """The stake on the j-th bet of a run (0-based): the doubled base bet until the
        shadow takes over, the shadow's own ladder after that."""
        unit = self.shadow_now if unit is None else unit
        if unit and j >= self.shadow_after:
            return unit * 2 ** (j - self.shadow_after)
        return self.staking.base * 2 ** j

    def shadow_affordable(self, unit: float | None = None) -> bool:
        """Could the run still reach shadow_min_lives bets once the shadow takes over?
        Deliberately ignores the doubling limit, so the answer is never optimistic."""
        unit = self.shadow_now if unit is None else unit
        left = self.balance
        for j in range(self.staking.step, self.shadow_min_lives):
            stake = self.stake_at(j, unit)
            if stake > left + 1e-9:
                return False
            left -= stake
        return True

    def shadow_ladder_stakes(self, lives: int = 8) -> list[float]:
        """The whole stake ladder a fresh run would climb, shadow included."""
        return [self.stake_at(i) for i in range(lives)]

    def next_bet(self, hand: int | None = None) -> tuple[str, float] | None:
        """What to bet this round: (side, amount), or None to skip.
        hand = this hand's number on the table (1 = first), for the table-end cutoff."""
        self.skip_reason = ""
        self.virtual_bet = None
        if self.watching:
            # the money is gone: follow the same run for free, to see where it ends
            self.virtual_bet = self.pick()
            if self.virtual_bet is None:
                self.skip_reason = "watching without betting: nothing to bet on this hand"
            return None
        if self.busted or self.reached_ceiling or self.finished:
            return None
        # the target comes first: reaching it ends the cycle even late in a table
        if self.ceiling is not None and self.balance >= self.ceiling:
            self.reached_ceiling = True
            return None
        if self.halt_for and not self.in_run:
            # back at the base bet: the place to stop (an update installs, then it resumes)
            self.finished = True
            self.skip_reason = self.halt_for
            return None
        if self.leave_for and not self.in_run:
            self.table_done = True
            self.skip_reason = self.leave_for
            return None
        cut = self.cutoff_hand()
        if cut is not None and hand is not None and hand > cut and not self.in_run:
            self.table_done = True
            if self.at_cutoff == "stop":
                self.finished = True
            self.skip_reason = (f"hand {hand} of {self.table_hands}: too late for a new run "
                                f"(the last {self.hands_needed()} hands are kept in reserve, "
                                f"last start hand {cut})")
            return None
        bet = self.pick()
        if bet is None:
            return None
        side, amount = bet
        if amount > self.balance:
            self.busted = True                   # can't cover the doubled bet
            if self.shadow_on:
                self.shadow_losses += 1
                self.shadow_level, self.shadow_on = 0, False
            self.bust_stake = amount
            self.lives_used = self.run_bets      # losses already paid for in this run
            self.bust_balance = self.balance
            if self.watch_after_bust and not self.watch_over:
                self.watching = True
                self.virtual_bet = bet           # the first bet we can't afford
            return None
        return side, amount

    # -- watching after the money runs out -----------------------------------
    def end_watch(self, reason: str) -> None:
        """Stop following the run. reason 'won' = the virtual bet won; anything else
        is why it couldn't be finished (the table ended, the session stopped …)."""
        if not self.watching:
            return
        self.watching, self.watch_over = False, True
        n = self.watch_bets
        more = f"{n} more life" if n == 1 else f"{n} more lives"
        if reason == "won":
            self.watch_won = True
            self.lives_needed = self.lives_used + n
            self.watch_result = (f"the run would have won {more} later — "
                                 f"{self.lives_needed} lives in all, {n} short")
        else:
            self.lives_needed = None
            self.watch_result = (f"{reason} — still losing after {more}: the run needed "
                                 f"more than {self.lives_used + n} lives")
            if self.run_bets:
                self._note_run(False)          # an unfinished run is still worth knowing

    # -- after the round ----------------------------------------------------
    def record(self, winner: str | None, bet: tuple[str, float] | None,
               game: int | None = None, outcome_hint: str | None = None) -> RoundResult:
        """Settle a round. `winner` = who won (None if unknown).
        outcome_hint = WIN/LOSS/PUSH from another source (e.g. the score)
        used only when the winner is unknown."""
        r = RoundResult(game, winner, balance=self.balance)
        self._game = game
        self.events = []
        self.last_run = None
        seen = r                         # what the rules are shown (the virtual bet, if any)
        if bet:
            side, amount = bet
            r.side, r.amount, r.by = side, amount, self.decided_by
            if winner:
                r.outcome, r.profit = settle(side, amount, winner)
            elif outcome_hint:
                r.outcome = outcome_hint
                r.profit = {"WIN": round(amount * PAYOUT[side], 2),
                            "LOSS": -amount}.get(outcome_hint, 0.0)
            else:
                r.outcome = "UNKNOWN"    # stake stays as it is
            step = self.staking.step          # which life this bet was (0 = the base bet)
            bought = self._extra_life(r.outcome)
            if not bought:
                self.staking.update(r.outcome)
            self.balance = round(self.balance + r.profit, 2)
            r.balance = self.balance
            self.max_bet = max(self.max_bet, amount)
            if self.shadow_stake:
                self.shadow_staked += self.shadow_stake
            if r.outcome == "LOSS":
                self.losing_streak += 1
                self.max_losing_streak = max(self.max_losing_streak, self.losing_streak)
            elif r.outcome == "WIN":
                self.losing_streak = 0
            self.peak = max(self.peak, self.balance)
            self.max_drawdown = max(self.max_drawdown, self.peak - self.balance)
            self._extra_reach(step, r.outcome)
            self._run_progress(r.outcome, bought)
            self._extra_count(r.outcome)
        elif self.watching and self.virtual_bet and (winner or outcome_hint):
            # no money was staked: settle the bet we would have made, so the doubling
            # and the rules carry on exactly as they would have
            side, amount = self.virtual_bet
            if winner:
                outcome, profit = settle(side, amount, winner)
            else:
                outcome = outcome_hint
                profit = {"WIN": round(amount * PAYOUT[side], 2),
                          "LOSS": -amount}.get(outcome_hint, 0.0)
            r.virtual = {"side": side, "amount": amount, "outcome": outcome,
                         "profit": profit, "by": self.decided_by}
            seen = RoundResult(game, winner, side=side, amount=amount, outcome=outcome,
                               profit=profit, balance=self.balance, by=self.decided_by)
            self.staking.update(outcome)
            if outcome in ("WIN", "LOSS"):
                self.watch_bets += 1
                self.watch_stakes.append(amount)
            if outcome == "WIN":
                self.end_watch("won")
            self._run_progress(outcome)
        if winner:
            self.road.append(winner)
        self.results.append(r)
        for rule in self.rules:
            msg = rule.observe(self, seen)
            if msg:
                self.events.append(msg)
        self.virtual_bet = None
        return r

    def _run_progress(self, outcome: str, bought: bool = False) -> None:
        """Follow the losing run going on now, and note it down when it ends.
        A tie leaves the run untouched (the stake comes back). `bought` = this loss
        was taken with an extra life: the run goes on at the base bet."""
        if outcome not in ("WIN", "LOSS"):
            return
        self.run_bets += 1
        if not bought:
            self.extra_held = False
        if outcome == "WIN":
            self._note_run(True)
        elif self.staking.step == 0 and not bought:   # the doubling limit restarted the run
            self._note_run(False)

    # -- extra life --------------------------------------------------------------
    @property
    def extra_rhythm(self) -> int:
        """One first loss bought in this many, right now (0 = off)."""
        if not self.extra_every:
            return 0
        return max(1, self.extra_strict if self.extra_active else self.extra_every)

    def _extra_turn(self, seen: int, active: bool | None = None) -> bool:
        """Is the first loss after `seen` of them bought? Usually the Nth one: 1 in 3 lets
        two first losses double as usual and buys the third, so a session doesn't pay
        for a life before it has seen a single loss. Strict buys at once, then 1 in N."""
        n = self.extra_rhythm
        if not n:
            return False
        strict = self.extra_active if active is None else active
        return seen % n == 0 if strict else (seen + 1) % n == 0

    @property
    def extra_until(self) -> int:
        """Which first loss from now is bought: 1 = the next one."""
        n = self.extra_rhythm
        if not n:
            return 0
        return next(j for j in range(1, n + 1) if self._extra_turn(self.extra_seen + j - 1))

    def ladder_ahead(self, on_table: float | None = None, most: int = 16) -> dict:
        """The bets to come if every one of them loses, until the money runs out --
        worked out the way the session itself would play them: the doubling, the
        doubling limit, the shadow, and an extra life the next first loss would buy.
        `on_table` = a bet already placed: the ladder starts with it.
        → {"stakes": [...], "bought": index of a bought repeat or None,
           "then": "out" (the next one isn't covered) | "limit" (starts over) | "more"}"""
        step, run, left = self.staking.step, self.run_bets, self.balance
        seen, held = self.extra_seen, self.extra_held
        stakes, bought, then = [], None, "more"
        for i in range(most):
            if i == 0 and on_table:
                stake = on_table                 # the settled balance still includes it
            else:
                stake = self.stake_at(step)
            if stake > left + 1e-9:
                then = "out"
                break
            stakes.append(stake)
            left -= stake
            # … and it loses: what comes next
            n = self.extra_rhythm
            first = step == 0 and run == 0 and not held and self.active_rule is None
            if n and first and self._extra_turn(seen):
                bought, held = len(stakes), True     # the next stake is the base bet again
                seen += 1
            else:
                if n and first:
                    seen += 1
                held = False
                step += 1
                if self.staking.max_steps and step >= self.staking.max_steps:
                    then = "limit"
                    break
            run += 1
        else:
            then = "more"
        return {"stakes": stakes, "bought": bought, "then": then}

    def _extra_restart(self) -> None:
        """A new rhythm: the next first loss is bought, and the count goes from there."""
        self.extra_seen = 0
        self.extra_buy_next = self._extra_turn(0)

    def _extra_life(self, outcome: str) -> bool:
        """Is this loss bought with an extra life? Only a run's first bet, and only when
        it is that one's turn in the rhythm."""
        if not (self.extra_every and outcome == "LOSS" and self.staking.step == 0
                and self.run_bets == 0 and self.active_rule is None):
            return False
        n = self.extra_rhythm
        buy = self._extra_turn(self.extra_seen)
        self.extra_seen += 1
        self.extra_buy_next = self._extra_turn(self.extra_seen)
        base = self.staking.base
        if buy:
            # the balance hasn't moved for this loss yet: it is what the run began with
            self.extra_run = {"balance": self.balance, "game": getattr(self, "_game", None)}
            self.extra_held = True
            self.extra_bought += 1
            self.extra_cost = round(self.extra_cost + base, 2)
            self.events.append(f"extra life bought: the base bet lost, so {base:,.0f} goes on "
                               f"again instead of {2 * base:,.0f} — the run has one more life, "
                               f"for {base:,.0f}")
        else:
            k = self.extra_until
            self.events.append(f"extra life: not this time (one in {n}) — doubling as usual; "
                               + ("the next first loss is bought" if k == 1 else
                                  f"the {_nth(k)} first loss from now is bought"))
        return buy

    def _extra_run_ended(self, won: bool) -> None:
        """A run the extra life was bought for has ended. Was it a save?

        It is, once the run it was bought for went as deep as the life it is set for
        (extra_after: life 6 = the 640 bet with base 20) or deeper, and won: every bet
        after the bought loss was one doubling lower than it would have been, so that run
        reached life 6 betting half -- 320 where it would have been 640. And it is the
        more so when the run won on a bet the balance alone couldn't have paid for."""
        run, self.extra_run = self.extra_run, None
        self.extra_finished += 1
        base, k = self.staking.base, self.run_bets
        alone = lives(run["balance"], Doubling(base, self.staking.max_steps))[0]
        cover = min(len(alone), self.staking.max_steps) if self.staking.max_steps else len(alone)
        deep = bool(self.extra_after) and k >= self.extra_after
        if self.busted or self.watching or self.watch_over:
            # the money ran out in this run: whatever it "won" later was watched, not
            # staked -- the extra life didn't save it, however deep it went
            return
        if not (won and (deep or k > cover)):
            return
        top = base * 2 ** max(0, k - 2)              # the biggest bet: one doubling lower …
        save = {"from_game": run["game"], "game": getattr(self, "_game", None), "lives": k,
                "cover": cover, "biggest": top, "instead": top * 2,       # … than without it
                # what was NOT put on the table: the bets after the bought loss, once more
                "at_risk": round(base * (2 ** max(0, k - 1) - 1), 2),
                "busted_without": k > cover,
                "lost_without": round(sum(alone[:cover]), 2) if k > cover else 0}
        self.extra_saves.append(save)
        if save["busted_without"]:
            self.events.append(
                f"extra life SAVED the session: the run won on bet {k}, and the balance alone "
                f"paid for {cover} — without it {save['lost_without']:,.0f} would have been lost")
        else:
            self.events.append(
                f"extra life saved: the run went to life {k} (life {self.extra_after} or deeper) "
                f"and won with its biggest bet {top:,.0f} instead of {top * 2:,.0f} — "
                f"{save['at_risk']:,.0f} less put on the table")

    def _extra_reach(self, step: int, outcome: str) -> None:
        """Was this bet life `extra_after` -- the base × 2^(N-1) stake (with base 20,
        life 6 is the 640 bet)? Then the extra life goes strict, or stays strict with its
        count of losses started over."""
        if not (self.extra_every and self.extra_after) or outcome not in ("WIN", "LOSS"):
            return
        if step + 1 != self.extra_after:
            return
        self.extra_deep = True                   # this run is that deep: its losses don't count
        stake = self.staking.base * 2 ** step
        if not self.extra_active:
            self.extra_active = True
            self._extra_restart()
            self.extra_ons += 1
            self.events.append(
                f"extra life STRICT: a run reached life {self.extra_after} (the {stake:,.0f} bet). "
                f"The next first loss is bought, then one in {self.extra_rhythm}, until "
                f"{self.extra_for} losses go by without a run reaching life {self.extra_after}")
        elif self.extra_quiet:
            self.events.append(f"extra life stays strict: a run reached life {self.extra_after} "
                               f"again — the count of {self.extra_for} losses starts over")
        self.extra_quiet = 0

    def _extra_count(self, outcome: str) -> None:
        """One more bet settled: a loss counts towards switching the extra life off,
        unless it is part of a run that has reached the life that keeps it on."""
        if not self.extra_active or outcome != "LOSS":
            return
        if self.extra_deep:
            return                               # this run reached that life: it keeps it on
        self.extra_quiet += 1
        if self.extra_quiet >= self.extra_for:
            self.extra_active, self.extra_quiet = False, 0
            self._extra_restart()
            self.events.append(f"extra life back to one in {self.extra_every}: "
                               f"{self.extra_for} losses without a run reaching life "
                               f"{self.extra_after}")

    def _note_run(self, won: bool) -> None:
        self.last_run = {"lives": self.run_bets, "won": won,
                         "virtual": self.watch_bets if self.watching or self.watch_over else 0,
                         "shadow": self.shadow_on}
        self.extra_deep = False
        if self.extra_run is not None:
            self._extra_run_ended(won)
        self.runs.append(self.last_run)
        self.run_bets = 0
        if self.shadow_on:                       # the shadow episode ended with the run
            if won:
                self.shadow_wins += 1
                self.shadow_level = (self.shadow_level + 1) % max(1, self.shadow_ladder)
            else:
                self.shadow_losses += 1
                self.shadow_level = 0            # a losing episode starts over
            self.shadow_on = False

    # -- reporting ----------------------------------------------------------
    def count(self, outcome: str) -> int:
        return sum(1 for r in self.results[-11:] if r.outcome == outcome)

    @property
    def remaining(self) -> float | None:
        """Money still to win to reach the ceiling (None = no ceiling)."""
        return None if self.ceiling is None else max(0.0, round(self.ceiling - self.balance, 2))

    @property
    def wins_needed(self) -> int | None:
        """How many winning bets reach the ceiling. A win after a run of doubled
        losses recovers them and nets one base bet -- on player. On banker it pays
        0.95, which takes more off the longer the run was, so what a win is worth is
        measured (per_win) rather than assumed. None = a win doesn't make money on
        average with this configuration."""
        r = self.remaining
        if r is None:
            return None
        per = self.per_win if self.per_win is not None else self.staking.base
        if per <= 0:
            return None
        return int(math.ceil(max(0.0, r) / per - 1e-9))

    @property
    def net(self) -> float:
        """What the betting actually made, with any correction from the screen taken
        back out. A stake that never went on is not a losing bet and must not be
        reported as one: fold it into the profit and a dropped click looks exactly
        like a hand that lost, which is the one thing it must never look like."""
        return round(self.balance - self.budget - self.corrected, 2)

    @property
    def corrected(self) -> float:
        """Everything the screen has put right that the betting cannot account for."""
        return round(sum(c["by"] for c in self.corrections), 2)

    @property
    def worst_run(self) -> int:
        """Most lives any losing run of this session needed (a run still going counts)."""
        return max([r["lives"] for r in self.runs] + [self.run_bets], default=0)

    def correct_balance(self, by: float, why: str) -> float:
        """The screen is the money; this is only a model of it. When the two disagree
        the model is the one that is wrong, so move it — otherwise every later stake,
        every count of the lives left and the decision about going bust are all worked
        out from a figure that is known to be false, and nothing ever puts it right."""
        by = round(float(by), 2)
        if not by:
            return self.balance
        self.balance = round(self.balance + by, 2)
        self.peak = max(self.peak, self.balance)
        self.corrections.append({"by": by, "why": why, "balance": self.balance})
        return self.balance

    @property
    def config(self) -> str:
        return config_key(self.strategy.name, self.rules)

    def road_str(self, last: int = 20) -> str:
        return " ".join(SHORT[w] for w in self.road[-last:]) or "-"

    def report(self, bal=str, loss=str, stake=str) -> str:
        """bal / loss / stake: optional functions to color those numbers."""
        net = f"{self.net:+,.2f}"
        bets = [r for r in self.results if r.side]
        wins = self.count("WIN")
        decided = wins + self.count("LOSS")
        lines = [
            f"Strategy        {self.strategy.name}",
            f"Rounds seen     {len(self.results)}   bets placed {len(bets)}",
            f"Wins / losses   {wins} / {self.count('LOSS')}   pushes {self.count('PUSH')}"
            + (f"   win rate {wins / decided:.1%}" if decided else ""),
            f"Balance         {bal(f'{self.budget:,.2f}')} → {bal(f'{self.balance:,.2f}')}   "
            f"net {loss(net) if self.net < 0 else net}",
            f"Biggest bet     {stake(f'{self.max_bet:,.2f}')}   "
            f"longest losing streak {self.max_losing_streak}",
            f"Max drawdown    {loss(f'{self.max_drawdown:,.2f}')}",
        ]
        for rule in self.rules:
            by_rule = [r for r in self.results if r.by == rule.name]
            lines.append(f"Rule            {rule.label}: took over {rule.triggered}×, "
                         f"won back {rule.rescued}×, {len(by_rule)} bets")
        if self.ceiling is not None:
            lines.append(f"Ceiling         {bal(f'{self.ceiling:,.2f}')}   " +
                         ("REACHED" if self.reached_ceiling or self.balance >= self.ceiling
                          else f"{self.remaining:,.2f} to go (≈ {self.wins_needed} wins)"))
        if self.shadow_unit:
            lines.append(f"Shadow bet      {stake(f'{self.shadow_unit:,.0f}')} after "
                         f"{self.shadow_after} losses, next episode "
                         f"{stake(f'{self.shadow_now:,.0f}')}: won {self.shadow_wins}, "
                         f"lost {self.shadow_losses}"
                         + (f", stood down {self.shadow_blocked}×" if self.shadow_blocked else "")
                         + (f", held down a rung {self.shadow_capped}×" if self.shadow_capped else "")
                         + f", {stake(f'{self.shadow_staked:,.0f}')} put up")
        won_runs = [r["lives"] for r in self.runs if r["won"]]
        if self.runs:
            lines.append(f"Losing runs     {len(self.runs)} finished, worst needed "
                         f"{max(won_runs, default=0) or self.worst_run} lives"
                         + (f" (won {len(won_runs)})" if won_runs else ""))
        if self.busted:
            lines.append(f"STOPPED         couldn't cover the next doubled bet "
                         f"({stake(f'{self.bust_stake or self.staking.amount:,.2f}')} > balance "
                         f"{bal(f'{self.bust_balance:,.2f}')}) after {self.lives_used} lives")
        if self.watch_result:
            lines.append(f"Kept watching   {self.watch_result}")
            if self.watch_stakes:
                lines.append("                the bets it would have taken: "
                             + ", ".join(stake(f"{a:,.0f}") for a in self.watch_stakes))
        elif self.watching and self.watch_bets:
            lines.append(f"Kept watching   {self.watch_bets} bets so far, still losing")
        return "\n".join(lines)
