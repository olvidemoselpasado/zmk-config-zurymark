"""Rules: take over from the strategy for a while, then hand control back.

A rule watches what has been happening and, when its condition is met, goes
active and chooses the side itself until it is done. The doubling still applies,
whoever chose. A rule may also ask for no bet at all this hand (SKIP), which is
not the same as having no opinion.

config_key names a set-up -- the strategy and its rules, and deliberately not
the money -- so the same plan played with different stakes counts as the same
configuration and shares its run history."""

from __future__ import annotations



from typing import TYPE_CHECKING

if TYPE_CHECKING:          # annotations only. A rule is HANDED the session;
    from baccarat.core.session import RoundResult, Session   # it never imports it

from baccarat.core.game import OPPOSITE, SKIP
from baccarat.core.strategy import no_ties


RULES: dict[str, type["Rule"]] = {}


def register_rule(cls):
    RULES[cls.name] = cls
    return cls


class Rule:
    """While `active`, the rule chooses the side instead of the strategy.
    The doubling still applies, whoever chooses.

    A rule may also return SKIP from decide() to hold the strategy back for a hand
    (nothing is staked and the stake doesn't move). A rule that only holds back
    leaves `active` False — it never takes charge of a side — and reports itself
    through `holding` instead."""
    name = "base"
    title = ""
    description = ""
    params: dict = {}            # {"n": {"label": …, "default": 3, "min": 1}}

    def __init__(self, **values):
        for k, spec in self.params.items():
            setattr(self, k, int(values.get(k, spec["default"])))
        self.active = False
        self.triggered = 0           # times it took over
        self.rescued = 0             # times its bet won and gave control back

    def decide(self, session: "Session") -> str | None:
        """Side to bet while active, SKIP for no bet, else None (the strategy decides)."""
        return None

    def observe(self, session: "Session", result: "RoundResult") -> str | None:
        """Called after every round. Returns a message when something changes."""
        return None

    def active_text(self) -> str:
        return ""

    def stats(self) -> dict | None:
        """The numbers behind the rule's current choice, for the dashboard to draw.
        None when the rule doesn't decide by counting anything."""
        return None

    @property
    def holding(self) -> bool:
        """True while the rule is keeping the strategy from betting."""
        return False

    def skip_text(self) -> str:
        return f"rule '{self.label}' is holding the bet back"

    @property
    def label(self) -> str:
        return self.title.format(**{k: getattr(self, k) for k in self.params})


class _AfterLosses(Rule):
    """Shared by the rules that take over after N losses in a row and keep betting
    one side until a bet wins. Subclasses only choose which side."""
    params = {"n": {"label": "losses in a row", "default": 3, "min": 1}}

    def __init__(self, **values):
        super().__init__(**values)
        self.streak = 0
        self.side: str | None = None
        self.why = ""

    def choose(self, session) -> tuple[str | None, str]:
        """→ (side to bet, short reason). (None, …) = don't take over yet."""
        raise NotImplementedError

    def decide(self, session):
        return self.side if self.active else None

    def observe(self, session, result):
        if result.outcome == "WIN":
            self.streak = 0
            if self.active:
                self.active, self.side = False, None
                self.swaps = 0
                self.rescued += 1
                return f"rule '{self.label}': the bet won — back to {session.strategy.name}"
        elif result.outcome == "LOSS":
            self.streak += 1
        if not self.active and self.streak >= self.n:
            side, why = self.choose(session)
            if side:
                self.active, self.side, self.why = True, side, why
                self.triggered += 1
                return (f"rule '{self.label}': {self.streak} losses in a row — betting "
                        f"{side} ({why}) until a win")
        return None

    def active_text(self) -> str:
        return f"{self.streak} losses in a row: betting {self.side} ({self.why}), until a win"


@register_rule
class LossStreak(_AfterLosses):
    name = "loss_streak"
    title = "After {n} losses in a row, bet against the last winner"
    description = ("After N losses in a row, bet against the last winning side (ties "
                   "ignored) and keep betting that side until a bet wins. Then the "
                   "strategy takes over again.")

    def choose(self, session):
        last = next((w for w in reversed(session.road) if w != "tie"), None)
        return (OPPOSITE[last], f"against last winner {last}") if last else (None, "")


@register_rule
class Majority(_AfterLosses):
    name = "majority"
    title = "After {n} losses in a row, follow the favourite of the last {window} results"
    description = ("After N losses in a row, bet the side that has won more RECENTLY, and keep "
                   "doing so until a bet wins — or the money runs out. It re-reads the window "
                   "before every hand, so if the favourite changes while it is in charge the "
                   "bet follows it. Only the last W results count, because a table that has "
                   "been red all shoe and is turning blue still looks red over the whole "
                   "table: the old results outvote the ones happening now, and the rule bets "
                   "into the change. W = 0 counts the whole table instead. Ties don't exist as "
                   "far as this rule is concerned — they are dropped before anything is "
                   "counted, so they never use up a place in the window. When the window is "
                   "exactly level it stays with the last winner rather than guessing.")

    # "n" stays first: --rule majority=3 still means 3 losses. A window of 12 is about a
    # quarter of a shoe — long enough that a lead isn't one lucky hand, short enough that
    # a table changing sides shows up in it. 0 = the whole table.
    params = {**_AfterLosses.params,
              "window": {"label": "results to look at", "default": 12, "min": 0}}

    # One win ahead is a favourite. A dead heat has none, and there the side that won
    # last is the only thing on the table that points anywhere, so that is what it backs.
    MIN_LEAD = 1

    def __init__(self, **values):
        super().__init__(**values)
        self.counts: dict | None = None   # what the window holds right now
        self.swaps = 0               # times the side changed while it was in charge

    @property
    def label(self) -> str:
        if not self.window:
            return f"After {self.n} losses in a row, follow the whole table's favourite"
        return (f"After {self.n} losses in a row, follow the favourite of the last "
                f"{self.window} result" + ("" if self.window == 1 else "s"))

    def stats(self) -> dict | None:
        return dict(self.counts) if self.counts else None

    def tally(self, session) -> tuple[int, int, int]:
        """(player wins, banker wins, results looked at) inside the window.
        Ties are dropped first, so a tie neither counts nor takes up one of the W places."""
        seen = no_ties(session.road)
        if self.window:
            seen = seen[-self.window:]
        return seen.count("player"), seen.count("banker"), len(seen)

    def where(self, seen: int) -> str:
        if not self.window:
            return "on this table"
        if seen < self.window:                   # the table hasn't filled the window yet
            return f"in all {seen} result{'' if seen == 1 else 's'} so far"
        return f"in the last {self.window} results"

    def pick_side(self, session) -> tuple[str | None, str]:
        """The side to back right now, and why. Read fresh from the window every hand:
        each result that lands changes the count, and a side that was 7-4 up can be 5-6
        down three hands later."""
        p, b, seen = self.tally(session)
        self.counts = {"player": p, "banker": b, "seen": seen,
                       "window": self.window, "lead": abs(p - b)}
        where = self.where(seen)
        if abs(p - b) >= self.MIN_LEAD:
            return ("player" if p > b else "banker"), f"{p} player vs {b} banker {where}"
        last = next((w for w in reversed(session.road) if w != "tie"), None)
        if last is None:
            return None, ""                      # nothing on the table to go on at all
        return last, f"level at {p}-{b} {where} — staying with the last winner"

    def choose(self, session):
        return self.pick_side(session)

    def decide(self, session):
        if not self.active:
            return None
        side, why = self.pick_side(session)
        if side:
            if self.side and side != self.side:
                self.swaps += 1
            self.side, self.why = side, why
        return self.side

    def active_text(self) -> str:
        if not self.side:
            return ""
        moved = f", changed {self.swaps}×" if self.swaps else ""
        return (f"{self.streak} losses in a row: betting {self.side} ({self.why}){moved}, "
                f"until a win")


@register_rule
class BluesOnce(Rule):
    """The 'once' half of blues_down: take the first repeat of a blue run and then leave
    the rest of that run alone. It never chooses a side — it only holds the strategy back,
    and only when no losing run is going on, so a recovery is never blocked."""
    name = "blues_once"
    title = "Only the first repeat of each blue run"
    description = ("For blues_down. After a player bet WINS, no more player bets until the "
                   "road starts a new blue run: a banker win, then a player win. So P P P P "
                   "is bet once, not three times. Without it, blues_down bets every repeat. "
                   "A losing run is never held back — the doubling always plays itself out.")
    params: dict = {}

    def __init__(self, **values):
        super().__init__(**values)
        self.armed = True            # may bet
        self.seen_banker = False     # a banker has won since we stopped

    @property
    def holding(self) -> bool:
        return not self.armed

    def decide(self, session):
        # never hold back a doubling run: by the time we disarm, a win has just ended one,
        # so this only ever bites at the base bet
        if self.armed or session.in_run:
            return None
        return SKIP

    def skip_text(self) -> str:
        return ("this blue run has had its bet — waiting for a banker, then a player, "
                "before betting blue again")

    def observe(self, session, result):
        if self.armed:
            if result.outcome == "WIN" and result.side == "player":
                self.armed, self.seen_banker = False, False
                self.triggered += 1
                return (f"rule '{self.label}': the blue repeat won — no more player bets "
                        f"until a banker wins and a player wins after it")
            return None
        if result.winner == "banker":
            self.seen_banker = True
        elif result.winner == "player" and self.seen_banker:
            self.armed, self.seen_banker = True, False
            self.rescued += 1
            return f"rule '{self.label}': banker then player — a new blue run, betting again"
        return None

    def active_text(self) -> str:
        return ("waiting for a banker win" if not self.seen_banker else
                "banker seen — waiting for a player win to start the new blue run")


def config_key(strategy: str, rules) -> str:
    """One name for a set-up: the strategy and its rules, nothing else. The budget,
    base bet and doubling limit are left out on purpose, so the same plan played with
    different money counts as the same configuration.
        "all_downs + loss_streak=3"        "all_downs + majority=3,12"
    A rule with several numbers lists them in name order, so changing the majority
    window counts as a different configuration — which it is: the same money played to
    a different plan, and its run history should not be mixed in with the old one.
    `rules` may be Rule objects, specs or "name=n" strings."""
    objs = [r for r in (rules or []) if isinstance(r, Rule)]
    objs += build_rules([r for r in (rules or []) if not isinstance(r, Rule)])
    parts = sorted(r.name + ("=" + ",".join(str(getattr(r, k)) for k in sorted(r.params))
                             if r.params else "") for r in objs)
    return " + ".join([strategy] + parts)


def build_rules(specs) -> list[Rule]:
    """[{"name": "loss_streak", "n": 3}, …] or ["loss_streak=3"] → fresh rule objects."""
    out = []
    for spec in specs or []:
        if isinstance(spec, str):
            name, _, value = spec.partition("=")
            cls = RULES.get(name.strip())
            if cls is None:
                raise ValueError(f"Unknown rule '{name}'. Available: {', '.join(RULES)}")
            # "majority=3" sets the first number, "majority=3,12" sets them in order
            keys = list(cls.params)
            given = [v.strip() for v in value.split(",") if v.strip()] if value else []
            if len(given) > len(keys):
                raise ValueError(f"rule '{cls.name}' takes "
                                 + (f"{len(keys)} numbers ({', '.join(keys)})" if keys
                                    else "no numbers")
                                 + f", not {len(given)}")
            spec = {"name": cls.name, **dict(zip(keys, given))}
        cls = RULES.get(spec.get("name"))
        if cls is None:
            raise ValueError(f"Unknown rule '{spec.get('name')}'")
        values = {}
        for k, p in cls.params.items():
            v = spec.get(k, p["default"])
            try:
                v = int(v)
            except (TypeError, ValueError):
                raise ValueError(f"{cls.name}: '{p['label']}' must be a whole number") from None
            low = p.get("min", 1)
            if v < low:
                raise ValueError(f"{cls.name}: '{p['label']}' " +
                                 ("can't be negative" if low == 0
                                  else f"must be at least {low}"))
            values[k] = v
        out.append(cls(**values))
    return out
