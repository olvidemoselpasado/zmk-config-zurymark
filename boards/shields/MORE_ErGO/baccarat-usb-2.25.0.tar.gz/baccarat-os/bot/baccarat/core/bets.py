"""
betting — how a bet is put on the table in live mode.

Coordinates (python bet.py --coords), any number of each:
    spot_player_1 … spot_player_n    places to click for PLAYER (one is picked at random per bet)
    spot_banker_1 … spot_banker_n    same for BANKER
    chip_20, chip_100, …             chip buttons (chip_20_1, chip_20_2 … also work)
    redo_bet_1 … redo_bet_n          the redo button(s): repeats the last bet / doubles it
                                     (one is picked at random per bet; plain redo_bet works too)
Tie is never bet.

How the clicks are chosen (plan_bet), with the redo button:
  • same side as the bet on the previous game, doubled after a loss
        → redo, redo              (repeat the last bet, then double it)
  • same side, same amount (the previous game was a tie, bet returned)
        → redo                    (repeat the last bet)
  • anything else (e.g. switching side after a loss), stake = base × 2^k
        → one base bet on the new spot, then redo k times (each click doubles it)
          i.e. redo (current life − 1) times: 20 → +0, 40 → +1, 80 → +2 …
  • when there's no redo button
        → chips for the whole stake
A chip stays selected on the table, so it's only clicked the first time (or when a
different chip value is needed).
"""

from __future__ import annotations

import math
import random
import re
from collections import Counter
from dataclasses import dataclass

BET_SIDES = ("player", "banker")
_SPOT = re.compile(r"^spot_(player|banker)(?:_\d+)?$")
_CHIP = re.compile(r"^chip_(\d+)(?:_\d+)?$")
_REDO = re.compile(r"^redo_bet(?:_\d+)?$")


@dataclass
class Placed:
    """A bet that was placed. `hand` is the table's hand number (P+B+T of the
    round it was placed for) — it counts every hand, ties included, so the
    "was my last bet on the hand right before this one?" test is reliable."""
    side: str
    amount: float
    hand: int
    table: str | None


# ---------------------------------------------------------------------------
# Coordinates
# ---------------------------------------------------------------------------

def spots(coords: dict, side: str) -> list[str]:
    return sorted(k for k in coords if (m := _SPOT.match(k)) and m.group(1) == side)


def chip_values(coords: dict) -> list[int]:
    return sorted({int(m.group(1)) for k in coords if (m := _CHIP.match(k))}, reverse=True)


def chip_names(coords: dict, value: int) -> list[str]:
    return [k for k in coords if (m := _CHIP.match(k)) and int(m.group(1)) == value]


def redo_names(coords: dict) -> list[str]:
    return [k for k in coords if _REDO.match(k)]


def setup_problems(coords: dict) -> tuple[list[str], list[str]]:
    """→ (errors that block live mode, warnings)."""
    errors, warnings = [], []
    for side in BET_SIDES:
        if not spots(coords, side):
            errors.append(f"no spot_{side}_1 … coordinates (where to click for {side})")
    if not chip_values(coords):
        errors.append("no chip_<value> coordinates (e.g. chip_20)")
    if not redo_names(coords):
        warnings.append("no redo_bet_1 … coordinates: every bet will be placed with chips only")
    return errors, warnings


# ---------------------------------------------------------------------------
# Planning (pure: no clicks, easy to test)
# ---------------------------------------------------------------------------

def chips_for(amount: float, values: list[int]) -> Counter | None:
    """Fewest chips that add up to exactly `amount`, or None when these chips can't
    make it. Exact, not greedy: 1,160 from 500/200/100/50/20 is 500+500+100+20+20+20,
    and taking the biggest chip each time never finds it — it reaches 500+500+100+50
    and strands 10."""
    if not values:
        return None
    total = round(float(amount), 2)
    if total <= 0:
        return Counter() if abs(total) < 1e-9 else None
    chips = sorted({int(v) for v in values if int(v) > 0}, reverse=True)
    if not chips:
        return None
    step = math.gcd(*chips) if len(chips) > 1 else chips[0]
    units = total / step
    if abs(units - round(units)) > 1e-6:        # not a whole number of the smallest step
        return None
    n = int(round(units))
    coins = [c // step for c in chips]
    best = [0] + [None] * n                     # fewest chips to reach each amount
    pick = [0] * (n + 1)
    for i in range(1, n + 1):
        for c in coins:
            if c <= i and best[i - c] is not None and (best[i] is None or best[i - c] + 1 < best[i]):
                best[i], pick[i] = best[i - c] + 1, c
    if best[n] is None:
        return None
    out, i = Counter(), n
    while i:
        out[pick[i] * step] += 1
        i -= pick[i]
    return out


def _close(a: float, b: float) -> bool:
    return abs(a - b) < 1e-6


def _doublings(amount: float, base: float) -> int | None:
    """k when amount == base × 2^k, else None."""
    k, a = 0, base
    while a < amount - 1e-9 and k < 40:
        a *= 2
        k += 1
    return k if _close(a, amount) else None


def plan_bet(side: str, amount: float, base: float, values: list[int],
             last: Placed | None = None, hand: int | None = None, table: str | None = None,
             has_redo: bool = True) -> list[tuple]:
    """The clicks for one bet, as actions:
         ("chip", value)   select a chip      ("spot",)   click the side's spot
         ("redo",)         click the redo button"""
    if side not in BET_SIDES:
        raise ValueError(f"only player or banker can be bet, not {side!r}")

    def with_chips(total: float) -> list[tuple] | None:
        c = chips_for(total, values)
        if c is None:
            return None
        acts = []
        for v, n in sorted(c.items(), reverse=True):
            acts.append(("chip", v))
            acts += [("spot",)] * n
        return acts

    if has_redo:
        consecutive = (last is not None and hand is not None and last.hand == hand - 1
                       and last.table == table)
        if consecutive and side == last.side:
            if _close(amount, 2 * last.amount):
                return [("redo",), ("redo",)]           # repeat + double
            if _close(amount, last.amount):
                return [("redo",)]                      # repeat (after a tie)
        k = _doublings(amount, base)
        first = with_chips(base)
        if k is not None and first is not None:
            return first + [("redo",)] * k              # base bet, then double k times

    full = with_chips(amount)
    if full is None:
        raise ValueError(f"can't make {amount:g} from the chips {values}")
    return full


def spread_out(coords: dict, names: list[str], px: int = 14) -> bool:
    """Are there at least two recorded points for this button far enough apart to
    count as different places? If so, repeated presses are dealt round them and never
    need holding back."""
    pts = [(coords[n]["x"], coords[n]["y"]) for n in names if n in coords]
    return any(math.hypot(a[0] - b[0], a[1] - b[1]) > px
               for i, a in enumerate(pts) for b in pts[i + 1:])


def repeat_clicks(actions: list[tuple], coords: dict | None = None, side: str = "player",
                  px: int = 14) -> int:
    """How many clicks in this plan land in the same place as the click before them.

    Each of those has to be held apart past the double-click window, so the betting
    window has to pay for it. Presses that can be dealt round two or more recorded
    points far enough apart are free, and don't count here."""
    repeats = [actions[i][0] for i in range(1, len(actions)) if actions[i] == actions[i - 1]]
    if coords is None:
        return len(repeats)
    free = set()
    if spread_out(coords, spots(coords, side), px):
        free.add("spot")
    if spread_out(coords, redo_names(coords), px):
        free.add("redo")
    return sum(1 for kind in repeats if kind not in free)


def worst_bet(values: list[int], base: float, max_steps: int | None,
              budget: float, has_redo: bool = True) -> tuple[int, float, list[tuple]]:
    """The most clicks any bet this session could need, and the stake that needs them.

    Every doubling adds a click, so the longest bet is the top of the ladder — not
    the first bet, which is the one everybody checks. Worked out with no help from
    the repeat button, because that only applies when the previous hand was bet on
    the same side at this table, which the first bet of a losing run never is.
    → (clicks, stake, the actions)"""
    worst: tuple[int, float, list[tuple]] = (0, 0.0, [])
    for k in range(0, 31):
        if max_steps is not None and k > max_steps:
            break
        stake = round(float(base) * (2 ** k), 2)
        if budget and stake > budget:
            break
        try:
            acts = plan_bet("player", stake, base, values, None, None, None, has_redo)
        except ValueError:
            continue                       # these chips can't make it; the session can't either
        if len(acts) > worst[0]:
            worst = (len(acts), stake, acts)
    return worst


def describe(actions: list[tuple], side: str, short: bool = False) -> str:
    """The clicks, in order. `short` collapses repeats — a 64-chip bet is unreadable
    written out, and the point of showing it is the shape, not every click."""
    out = []
    for a in actions:
        out.append(f"chip {a[1]}" if a[0] == "chip" else side if a[0] == "spot" else "redo")
    if not short:
        return " → ".join(out)
    runs: list[list] = []
    for w in out:
        if runs and runs[-1][0] == w:
            runs[-1][1] += 1
        else:
            runs.append([w, 1])
    return " → ".join(w if n == 1 else f"{w} ×{n}" for w, n in runs)


# ---------------------------------------------------------------------------
# Doing it
# ---------------------------------------------------------------------------

class BetPlacer:
    """Remembers the last bet it placed (so the next one can use redo) and which
    chip is selected (a selected chip stays selected, so it isn't clicked again)."""

    def __init__(self, click_coord, load_coords, rng: random.Random | None = None):
        self.click = click_coord          # bet.click_coord(name)
        self.load_coords = load_coords    # bet.load_coords()
        self.rng = rng or random.Random()
        self.last: Placed | None = None
        self.chip: int | None = None      # chip value currently selected on the table
        self.cut_short: float | None = None   # the last bet stopped before its repeats
        self.interrupted: dict | None = None  # the last bet cut off by Stop mid-clicks

    def _without_selected_chip(self, actions: list[tuple]) -> list[tuple]:
        """Drop chip clicks for the chip that's already selected at that point."""
        out, sel = [], self.chip
        for a in actions:
            if a[0] == "chip":
                if a[1] == sel:
                    continue
                sel = a[1]
            out.append(a)
        return out

    def _ring(self, names: list[str]):
        """Hand out the recorded variants of a button in turn, starting at a random
        one, so no two presses in a row land on the same point when there is a choice."""
        names = list(names or [])
        if not names:
            while True:
                yield None
        self.rng.shuffle(names)
        i = 0
        while True:
            yield names[i % len(names)]
            i += 1

    def plan(self, side: str, amount: float, base: float, hand: int,
             table: str | None) -> list[tuple]:
        """The clicks this bet will need (nothing is clicked)."""
        coords = self.load_coords()
        return self._without_selected_chip(
            plan_bet(side, amount, base, chip_values(coords), self.last, hand, table,
                     has_redo=bool(redo_names(coords))))

    def why_no_redo(self, hand: int, table: str | None, side: str | None = None,
                    amount: float | None = None, base: float | None = None) -> str:
        """Empty when redo can be used; otherwise why it can't (for the log)."""
        if amount is not None and base is not None and abs(amount - base) < 1e-9:
            return ""                                  # a base bet is simply placed, no redo needed
        if self.last is None:
            return "no bet placed yet this session"
        if hand is None:
            return "the table's hand number couldn't be read"
        if self.last.table != table:
            return f"last bet was on another table ({self.last.table})"
        if self.last.hand != hand - 1:
            return f"last bet was on hand {self.last.hand}, this is hand {hand}"
        return ""

    def place(self, side: str, amount: float, base: float, hand: int,
              table: str | None, confirm=None, check=None) -> str:
        """Click the bet on. `confirm(staked)` -> bool, when given, is asked after the
        chips and before the first press of the repeat button: has the table taken the
        `staked` the chips put down? Pressed on an EMPTY table the repeat button repeats
        last round's bet -- whatever side and size that was -- so a chip click that
        missed turns 'banker 20, double, double, double' into four times last round's
        bet on the other side. That is exactly what happened on a live table. No -> the
        repeats are not pressed, `cut_short` says how much the chips were meant to put
        down, and nothing about this bet is remembered for the next one.
        `check()`, when given, is called before every click and may raise to stop the
        bet where it is (the Stop button); `interrupted` then says how far it got."""
        self.cut_short = None
        self.interrupted = None
        coords = self.load_coords()
        redo = redo_names(coords)
        actions = self._without_selected_chip(
            plan_bet(side, amount, base, chip_values(coords), self.last, hand, table,
                     has_redo=bool(redo)))
        # Spread repeats over the recorded variants instead of hammering one point.
        # Two presses in the same place have to be held apart past the double-click
        # window or one of them can be swallowed; two presses far enough apart don't,
        # so the bet goes on quicker as well as more reliably.
        spot_ring = self._ring(spots(coords, side))
        redo_ring = self._ring(redo)
        spot = redo_btn = None
        down = 0.0                          # what the chip clicks have put on so far
        checked = False
        done = []
        for a in actions:
            if check is not None:
                try:
                    check()
                except BaseException:
                    self.last = None            # the repeat button's memory is unknown now
                    self.interrupted = {"clicks": len(done), "of": len(actions), "chips": down}
                    raise
            if a[0] == "chip":
                self.click(self.rng.choice(chip_names(coords, a[1])))
                self.chip = a[1]
            elif a[0] == "spot":
                spot = next(spot_ring)
                self.click(spot)
                down += self.chip or 0
            else:
                if down and confirm is not None and not checked:
                    checked = True
                    if not confirm(down):
                        self.cut_short = down
                        self.last = None        # the repeat button's memory is unknown now
                        return (f"{describe(done, side)} — STOPPED before the repeats: the "
                                f"chips didn't show on the balance  (spot {spot})")
                redo_btn = next(redo_ring)
                self.click(redo_btn)
            done.append(a)
        used_redo = any(a[0] == "redo" for a in actions)
        # why redo wasn't used — worked out before this bet becomes "the last bet"
        why = "" if used_redo or not redo else self.why_no_redo(hand, table, side, amount, base)
        spot = spot or self.rng.choice(spots(coords, side))
        self.last = Placed(side, amount, hand, table)
        return (f"{describe(actions, side)}  (spot {spot}" + (f", {redo_btn})" if used_redo else ")")
                + (f"  [no redo: {why}]" if why else ""))
