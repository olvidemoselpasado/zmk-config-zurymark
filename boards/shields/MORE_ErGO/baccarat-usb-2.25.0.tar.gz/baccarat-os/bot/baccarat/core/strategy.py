"""Strategies: which side to bet on, from the road.

A strategy sees only the past winners, oldest first, and answers with
"player", "banker", or None to sit this hand out. It knows nothing about money,
about the table, or about how much is riding on the answer -- which is what
makes each one a few lines long and testable on its own.

Adding one:

    @register
    class MyStrategy(Strategy):
        name = "my_strategy"
        description = "One line shown in --list-strategies"

        def decide(self, road):
            return "banker"          # or "player", or None to skip"""

from __future__ import annotations





# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

STRATEGIES: dict[str, type["Strategy"]] = {}


def register(cls):
    STRATEGIES[cls.name] = cls
    return cls


class Strategy:
    name = "base"
    description = ""
    n = 0          # results (ties ignored) the strategy needs before its first bet

    def decide(self, road: list[str]) -> str | None:
        raise NotImplementedError


def no_ties(road: list[str]) -> list[str]:
    return [w for w in road if w != "tie"]


class _StreakOrChop(Strategy):
    """Looks at the last `n` results, ties ignored:
         all the same        → bet that side again (follow the streak)
         strictly alternating → bet the next side in the alternation
         anything else        → skip"""
    n = 3

    def decide(self, road):
        last = no_ties(road)[-self.n:]
        if len(last) < self.n:
            return None                          # table needs n results first
        if all(x == last[-1] for x in last):
            return last[-1]                      # B B B → B
        if all(a != b for a, b in zip(last, last[1:])):
            return last[-2]                      # B P B → P ,  B P → B
        return None


@register
class StreakOrChop(_StreakOrChop):
    name = "streak_or_chop"
    n = 3
    description = ("Last 3 results, ties ignored: all the same → bet that side; "
                   "alternating (B P B) → bet the next in the alternation (P); otherwise skip.")


@register
class AllDowns(Strategy):
    name = "all_downs"
    n = min_results = 1
    description = ("Always bet that the last result repeats (a repeat draws the big road "
                   "downwards): last was banker → bet banker; player wins → bet player. "
                   "Ties are ignored, so it follows the last non-tie result.")

    def decide(self, road):
        last = no_ties(road)
        return last[-1] if last else None


@register
class BluesDown(Strategy):
    name = "blues_down"
    n = min_results = 1
    description = ("Blue only. When the last result (ties ignored) is player, bet player "
                   "expecting it to repeat and draw the blue column downwards. When the last "
                   "result is banker, nothing is bet at all — it simply waits for blue to come "
                   "back, and a losing run keeps its stake while it waits. Tick the rule 'only "
                   "the first repeat of each blue run' to bet once per run instead of on every "
                   "repeat.")

    def decide(self, road):
        last = no_ties(road)
        return "player" if last and last[-1] == "player" else None


@register
class StreakOrChop2(_StreakOrChop):
    name = "streak_or_chop_2"
    n = 2
    description = ("Last 2 results, ties ignored: the same (B B) → bet that side; "
                   "different (B P) → bet the next in the alternation (B). "
                   "Starts after 2 results and bets every game after that.")


def get_strategy(name: str) -> Strategy:
    if name not in STRATEGIES:
        raise ValueError(f"Unknown strategy '{name}'. Available: {', '.join(STRATEGIES)}")
    return STRATEGIES[name]()
