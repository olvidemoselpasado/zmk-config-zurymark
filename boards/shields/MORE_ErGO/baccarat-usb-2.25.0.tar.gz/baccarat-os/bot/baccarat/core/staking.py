"""How much: base bet, doubled after every loss, back to base after a win.

Unchanged after a tie, because the bet is returned. The doubling applies to
every strategy automatically, and `lives` answers the question the whole thing
turns on: how many losses in a row can this balance actually survive."""

from __future__ import annotations



from baccarat.core.game import PAYOUT


# ---------------------------------------------------------------------------
# Staking: double after a loss (applies to every strategy)
# ---------------------------------------------------------------------------

class Doubling:
    """base, 2×base, 4×base … after each loss; back to base after a win;
    unchanged after a tie. `max_steps` optionally caps the doubling
    (e.g. 5 → after 5 losses in a row, accept the loss and restart at base)."""

    def __init__(self, base: float, max_steps: int | None = None):
        self.base = base
        self.max_steps = max_steps
        self.step = 0

    @property
    def amount(self) -> float:
        return self.base * (2 ** self.step)

    def update(self, outcome: str) -> None:
        if outcome == "WIN":
            self.step = 0
        elif outcome == "LOSS":
            self.step += 1
            if self.max_steps is not None and self.step >= self.max_steps:
                self.step = 0


def lives(balance: float, staking: Doubling, limit: int = 60) -> tuple[list[float], float | None]:
    """How many losses in a row the balance can still pay for, from the current stake.
    Returns (the affordable stakes, the first stake we could NOT pay).
    e.g. balance 300, stake 20 → ([20, 40, 80, 160], 320)"""
    d = Doubling(staking.base, staking.max_steps)
    d.step = staking.step
    left, seq = balance, []
    for _ in range(limit):
        a = d.amount
        if a > left + 1e-9:
            return seq, a
        seq.append(a)
        left -= a
        d.update("LOSS")
    return seq, None


def settle(side: str, amount: float, winner: str) -> tuple[str, float]:
    """→ (outcome, profit). A tie returns player/banker bets (PUSH)."""
    if winner == side:
        return "WIN", round(amount * PAYOUT[side], 2)
    if winner == "tie":
        return "PUSH", 0.0
    return "LOSS", -amount
