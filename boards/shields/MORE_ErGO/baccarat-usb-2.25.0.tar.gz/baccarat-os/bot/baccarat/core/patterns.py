"""Judging a table by its pattern: what has the strategy done right after it?

A pattern is the last few results of the table, ties left out, in their exact colours:
BBPPBB is one pattern, PPBBPP another. Every bot, every bet: the pattern the table
showed just before it (the last 16 results), the configuration that chose the bet
(strategy + rules), the side it bet, whether it won, and what the judge said before it.
All of that goes to the server, which adds up every bot's: for each configuration and
each pattern of 4 to 16 results, how many bets right after it won and lost -- per side,
because banker wins a little more often than player (and pays a little less), and a
pattern after which the strategy happens to bet banker must not look "good" for that.

Judging the table now: for each length, the pattern the table shows now and its record,
against what the same bets win anywhere (that side's baseline). BAD (or GOOD) only on
evidence strong enough for the number of patterns compared: with thousands of them, a
fixed z of 3 calls hundreds bad by luck alone on a fair shoe (measured: 2 million
simulated bets, lengths 4-16 -> ~240 false calls at z 3, none at the corrected line).
So the line rises with the count (Bonferroni: a 5% chance of even one false call over
all of them) -- about 4 for a thousand patterns, 4.6 for ten thousand, 5 for a hundred
thousand. "Leaning" is shown too, but is not evidence: one in ten patterns leans by luck.

Whether it works is not assumed: every bet carries the verdict that stood before it, and
the server counts how bets after a BAD call did against what they should have won
(`track`). That is the test -- measured on bets made after the call, never on the data
the call came from.

Nothing here touches the screen or the server: the bot passes in the numbers the
server sent (`set_stats`) and gets back a verdict.
"""

from __future__ import annotations

import math
import threading
import time
from collections import deque
from statistics import NormalDist

LENGTHS = range(4, 17)
KEEP = 16                # results sent with each bet: enough for every length
MIN_N = 30               # bets after a pattern before it is judged at all
STRONG = 3.0             # z for BAD / GOOD at the least (the line rises with the count)
LEAN = 1.65              # z for "leaning" (not evidence)
FAMILY = 0.05            # the chance allowed of even one false BAD/GOOD over all patterns
SIDES = ("B", "P", "U")  # banker, player, unknown (bets sent by bots before 2.24)
GROUPS = ("bad", "leaning bad", "neutral", "leaning good", "good")

# what the bot has seen and not yet sent (the uplink takes them)
_obs: deque = deque(maxlen=20000)
_lock = threading.Lock()
# what the server has sent: config -> {"base": [w, l], "patterns": {p: [w, l]}, "at": t}
_stats: dict[str, dict] = {}


def bp(road) -> str:
    """The road as B and P, ties left out."""
    return "".join("B" if w == "banker" else "P" for w in road if w in ("banker", "player"))


def group_of(verdict: str | None) -> str:
    """bad / leaning bad / neutral / leaning good / good: what the judge said before a bet."""
    return verdict if verdict in GROUPS else "neutral"


def observe(config: str, road_before, outcome: str, side: str | None = None,
            verdict: str | None = None) -> None:
    """A bet settled: what the table showed before it, the side bet, whether it won, and
    what the pattern judge said before it (its track record)."""
    if outcome not in ("WIN", "LOSS"):
        return
    p = bp(road_before)[-KEEP:]
    if len(p) < min(LENGTHS):
        return
    o = {"cfg": config, "road": p, "out": "W" if outcome == "WIN" else "L",
         "t": round(time.time(), 1), "v": group_of(verdict)}
    if side in ("banker", "player"):
        o["side"] = "B" if side == "banker" else "P"
    with _lock:
        _obs.append(o)


def take() -> list[dict]:
    """Everything observed since the last time (for the uplink)."""
    with _lock:
        out = list(_obs)
        _obs.clear()
    return out


def put_back(items: list[dict]) -> None:
    """Couldn't be sent: kept for the next call, oldest first."""
    with _lock:
        _obs.extendleft(reversed(items))


CACHE = 4000             # pattern records kept per config (the newest ones)


def set_stats(config: str, stats: dict) -> None:
    """What the server sent. A 2.24 server sends only the records the table needs now
    and next: they are added to what is kept, newest last, the oldest dropped."""
    have = _stats.get(config) or {}
    if isinstance(stats.get("by_side"), dict):
        by = dict(have.get("by_side") or {})
        for p, rec in stats["by_side"].items():
            by.pop(p, None)
            by[p] = rec
        while len(by) > CACHE:
            by.pop(next(iter(by)))
        stats = {**stats, "by_side": by}
    _stats[config] = {**stats, "at": time.time()}


def stats_for(config: str) -> dict | None:
    return _stats.get(config)


def z_of(w: int, n: int, base: float) -> float:
    if n <= 0 or not 0 < base < 1:
        return 0.0
    return (w / n - base) / math.sqrt(base * (1 - base) / n)


def line_for(m: int) -> float:
    """The z a pattern needs to be called BAD or GOOD when m patterns are compared."""
    return max(STRONG, NormalDist().inv_cdf(1 - FAMILY / 2 / max(1, m)))


def _rates(st: dict) -> dict:
    """What a bet on each side wins, anywhere (the baselines)."""
    sides = st.get("sides")
    if not isinstance(sides, dict):                       # a server before 2.24
        bw, bl = (st.get("base") or [0, 0])[:2]
        return {"U": bw / (bw + bl) if bw + bl else 0.5}
    out = {}
    for k in SIDES:
        w, lo = (sides.get(k) or [0, 0])[:2]
        if w + lo:
            out[k] = w / (w + lo)
    return out or {"U": 0.5}


def record_of(st: dict, pattern: str, rates: dict) -> dict | None:
    """w, n and the win rate expected of those very bets (their sides) after a pattern."""
    by = (st.get("by_side") or {}).get(pattern)
    if isinstance(by, dict):
        w = n = 0
        exp = 0.0
        for k, wl in by.items():
            a, b = (wl or [0, 0])[:2]
            w, n = w + a, n + a + b
            exp += (a + b) * rates.get(k, rates.get("U", 0.5))
        return {"w": w, "n": n, "exp": exp / n if n else 0.5} if n else None
    wl = (st.get("patterns") or {}).get(pattern)              # a server before 2.24
    if wl:
        a, b = wl[:2]
        return {"w": a, "n": a + b, "exp": rates.get("U", 0.5)} if a + b else None
    return None


def judge(config: str, road) -> dict:
    """What the table's pattern says now, for this configuration.
    → {verdict: bad|good|leaning bad|leaning good|nothing special|learning|no data,
       pattern, n, rate, base, z, line, lengths: [...]}"""
    st = _stats.get(config)
    seq = bp(road)
    if not st:
        return {"verdict": "no data", "pattern": seq[-6:], "n": 0}
    rates = _rates(st)
    m = int(st.get("m") or len(st.get("by_side") or st.get("patterns") or {}))
    strong = line_for(m)
    rows = []
    for L in LENGTHS:
        if len(seq) < L:
            continue
        p = seq[-L:]
        rec = record_of(st, p, rates)
        n = rec["n"] if rec else 0
        rows.append({"pattern": p, "n": n,
                     "rate": round(rec["w"] / n, 3) if n else None,
                     "base": round(rec["exp"], 3) if rec else None,
                     "z": round(z_of(rec["w"], n, rec["exp"]), 2) if rec and n >= MIN_N else None})
    judged = [r for r in rows if r["z"] is not None]
    base_all = sum(rates.values()) / len(rates)
    if not judged:
        best = max(rows, key=lambda r: r["n"], default={"pattern": seq[-6:], "n": 0})
        return {"verdict": "learning", "pattern": best["pattern"], "n": best["n"],
                "rate": best.get("rate"), "base": round(base_all, 3), "need": MIN_N,
                "line": round(strong, 2), "lengths": rows}
    top = max(judged, key=lambda r: abs(r["z"]))
    z = top["z"]
    verdict = ("bad" if z <= -strong else "good" if z >= strong else
               "leaning bad" if z <= -LEAN else "leaning good" if z >= LEAN else "nothing special")
    return {"verdict": verdict, "pattern": top["pattern"], "n": top["n"], "rate": top["rate"],
            "base": top["base"], "z": z, "line": round(strong, 2), "m": m, "lengths": rows}


def track(config: str) -> list[dict]:
    """How the bets after each kind of call did, against what they should have won:
    the judge's own test, on bets made after the call. [{group, n, rate, exp, z}]"""
    st = _stats.get(config) or {}
    rates = _rates(st)
    out = []
    for g in GROUPS:
        by = (st.get("track") or {}).get(g)
        if not isinstance(by, dict):
            continue
        w = n = 0
        exp = 0.0
        for k, wl in by.items():
            a, b = (wl or [0, 0])[:2]
            w, n = w + a, n + a + b
            exp += (a + b) * rates.get(k, rates.get("U", 0.5))
        if n:
            out.append({"group": g, "n": n, "rate": round(w / n, 3), "exp": round(exp / n, 3),
                        "z": round(z_of(w, n, exp / n), 2)})
    return out


def describe_track(rows: list[dict]) -> str:
    if not rows:
        return "no bets yet after a judged pattern"
    return " · ".join(f"after {r['group'].upper()}: {r['n']:,} bets, won {r['rate'] * 100:.1f}% "
                      f"(expected {r['exp'] * 100:.1f}%, z {r['z']:+.1f})" for r in rows)


def describe(v: dict) -> str:
    if v["verdict"] == "no data":
        return "no pattern data from the server yet"
    if v["verdict"] == "learning":
        return (f"pattern {v['pattern']}: {v['n']} bets seen after it by all bots, "
                f"{v.get('need', MIN_N)} needed to judge")
    tail = {"bad": f" (beyond the line of z {v.get('line', STRONG):.1f} that {v.get('m', 0):,} "
                   "patterns compared call for)",
            "good": f" (beyond the line of z {v.get('line', STRONG):.1f})",
            "leaning bad": " — not proven: one pattern in ten leans by luck",
            "leaning good": " — not proven: one pattern in ten leans by luck"}.get(v["verdict"], "")
    return (f"pattern {v['pattern']}: {v['rate'] * 100:.0f}% of {v['n']} bets won after it "
            f"(the same bets win {v['base'] * 100:.0f}% anywhere) — {v['verdict']}{tail}")
