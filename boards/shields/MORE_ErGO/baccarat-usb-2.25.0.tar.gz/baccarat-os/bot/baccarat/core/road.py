"""The road: runs, letters, and finding a shape in it.

    road      the winners in order, as the engine spells them
    letters   the same thing as "BBPPB", ties dropped
    runs      [("B", 2), ("P", 2), ("B", 1)]
    big road  the columns a table actually draws

find_pattern matches WHOLE runs only, and that is the important part. "BPPBB"
does not match inside "BPPBBB": the run of two B is really a run of three, and a
strategy that loses to exactly-two does not lose to three. So a match needs the
run before the pattern to be a different side, the run after it to exist (an
unfinished run at the end of the road is not yet a known length), and that run
to be a different side too."""

from __future__ import annotations



from baccarat.core.strategy import no_ties


# ---------------------------------------------------------------------------
# Table screening: the road shapes that beat a strategy
# ---------------------------------------------------------------------------
# Every strategy has a shape of road that takes it apart. streak_or_chop_2 is
# undone by runs of exactly two — BBPPBB — because each bet lands on the hand
# the run ends. You write the shapes down yourself, as plain P and B letters,
# and the bot reads what a table has already done before sitting down at it.
# They judge the past only: they cut down how often you walk into the shape you
# lose to, they do not predict the next hand.

def run_lengths(road: list[str]) -> list[tuple[str, int]]:
    """The road as runs, ties ignored: PBBPPP → [(player,1), (banker,2), (player,3)]."""
    out: list[list] = []
    for w in no_ties(road):
        if out and out[-1][0] == w:
            out[-1][1] += 1
        else:
            out.append([w, 1])
    return [(w, n) for w, n in out]


def road_letters(road) -> str:
    """A road as the letters you would type: ties dropped, P and B only."""
    if isinstance(road, str):
        return "".join(c for c in road.upper() if c in "PB")
    return "".join("P" if w == "player" else "B" for w in no_ties(road or []))


def _runs_are_whole(letters: str, pattern: str, at: int) -> bool:
    """Is the pattern sitting on whole runs here, or is it a slice through longer ones?

    BPPBB inside ...BPPBBB... is not a match: that last run is three, not two. Nor is
    it one inside ...BBPPBB..., where the run in front is two, not one. The runs in
    the middle take care of themselves — the pattern's own letters fix where they end.

    A match running to the very end of the road is refused too: the last run has not
    finished yet, and the next hand may well extend it."""
    end = at + len(pattern)
    if at > 0 and letters[at - 1] == pattern[0]:
        return False                      # the first run carries on behind us
    if end >= len(letters):
        return False                      # nothing after it yet: the last run is still open
    return letters[end] != pattern[-1]    # the last run carries on in front of us


def find_pattern(letters: str, pattern: str) -> list[int]:
    """Where the pattern appears, on whole runs only. Positions are 0-based into
    `letters` (ties already dropped)."""
    at, out = letters.find(pattern), []
    while at != -1:
        if _runs_are_whole(letters, pattern, at):
            out.append(at)
        at = letters.find(pattern, at + 1)
    return out


def big_road(letters: str, rows: int = 6) -> list[list[str]]:
    """The letters laid out the way the table draws them: a new column for each
    change of side, running down to `rows` and then sideways. Returned as columns
    so the dashboard can draw the same picture you see on the screen."""
    cols: list[list[str]] = []
    for w in letters:
        if cols and cols[-1][0] == w and len(cols[-1]) < rows:
            cols[-1].append(w)
        elif cols and cols[-1][0] == w:
            cols.append([w])              # ran out of room: it turns the corner
        else:
            cols.append([w])
    return cols
