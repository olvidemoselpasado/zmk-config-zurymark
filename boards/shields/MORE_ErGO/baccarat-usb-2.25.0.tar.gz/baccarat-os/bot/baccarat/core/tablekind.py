"""What kind of table this is: the shape of its road, and what a table turned out
to be worth.

The pattern is the stretch of road the majority rule looks at -- its last W
results, ties left out -- or, with no window (or no majority rule), the whole
table so far. Every pattern is described by the same four numbers, so two
tables can be compared even when their letters never match exactly:

    chop     how often the side changes from one result to the next
             (0 = one long streak, 1 = P B P B … all the way)
    banker   the share of results that went to banker
    longest  the longest run of one side
    doubles  the share of runs exactly two long (PP, BB) -- the shape
             streak_or_chop_2 lives on

What a table turned out to be worth, from the moment it was judged to its end:

    exceptional   made at least `exceptional_at`
    good          made at least `regular_below`
    regular       made something, less than that
    bad           lost money, or a run reached the next-to-last life

Nothing here reads a file or knows about a screen.
"""

from __future__ import annotations

from baccarat.core.road import road_letters, run_lengths

TIERS = ("exceptional", "good", "regular", "bad")
FEATURES = ("chop", "banker", "longest", "doubles")
EXCEPTIONAL_AT = 400.0        # the defaults Setup starts from
REGULAR_BELOW = 150.0
WHOLE_TABLE_AFTER = 12        # with no window: results seen before a table is judged


def window_of(rules) -> int:
    """The majority rule's window; 0 = the whole table (no window, or no majority rule)."""
    for r in rules or []:
        if getattr(r, "name", None) == "majority":
            return int(getattr(r, "window", 0) or 0)
    return 0


def pattern_of(road, window: int) -> str:
    """The letters that make up this table's pattern right now."""
    letters = road_letters(road)
    return letters[-window:] if window else letters


def ready(road, window: int, whole_after: int = WHOLE_TABLE_AFTER) -> bool:
    """Is there enough of the road to have a pattern at all?"""
    return len(road_letters(road)) >= (window or whole_after)


def shape(letters: str) -> dict:
    """The four numbers that describe a pattern."""
    n = len(letters)
    if n == 0:
        return {"chop": 0.0, "banker": 0.0, "longest": 0, "doubles": 0.0}
    runs = run_lengths(["player" if c == "P" else "banker" for c in letters])
    switches = sum(1 for a, b in zip(letters, letters[1:]) if a != b)
    return {"chop": round(switches / (n - 1), 3) if n > 1 else 0.0,
            "banker": round(letters.count("B") / n, 3),
            "longest": max(k for _, k in runs),
            "doubles": round(sum(1 for _, k in runs if k == 2) / len(runs), 3)}


def penultimate(cover: int) -> int:
    """The bet in a run that is the next-to-last one the balance pays for."""
    return max(2, int(cover) - 1)


def tier(profit: float, deepest: int, cover: int, exceptional_at: float = EXCEPTIONAL_AT,
         regular_below: float = REGULAR_BELOW) -> str:
    """What a table was worth. `deepest` = the most bets in a row one run needed on it;
    `cover` = the bets in a row the balance paid for."""
    if profit < 0 or deepest >= penultimate(cover):
        return "bad"
    if profit >= exceptional_at:
        return "exceptional"
    if profit >= regular_below:
        return "good"
    return "regular"


def describe(letters: str, f: dict | None = None) -> str:
    """'PBBPBPPB: chop 0.71, banker 50%, longest run 2, doubles 67%'."""
    f = f or shape(letters)
    return (f"{letters or '—'}: chop {f['chop']:.2f}, banker {f['banker'] * 100:.0f}%, "
            f"longest run {f['longest']}, doubles {f['doubles'] * 100:.0f}%")
