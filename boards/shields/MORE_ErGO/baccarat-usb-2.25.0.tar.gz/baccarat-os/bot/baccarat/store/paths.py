"""Where everything on disk lives — the one module that knows.

No other module works a path out from its own `__file__`. That used to be the
rule in three places, and it is the single thing that makes a folder
reorganisation dangerous: a module that computes `Path(__file__).parent / "tables"`
and then calls `.mkdir(parents=True, exist_ok=True)` does not fail when it is
moved. It quietly creates an empty folder next to its new home and starts up with
no sites, no recorded tables and no settings — which looks exactly like losing
everything, while the real files sit untouched one directory up.

So: one module, asked at call time, never captured into another module's global.

Where the data is, in order of preference:

    $BACCARAT_DATA          set it to keep your tables and sites outside the
                            program folder, or to point at a copy
    <project>/data/         where the reorganised layout puts it
    <project>/             the old flat layout — still found, so this code runs
                            against an un-migrated folder instead of starting empty
"""

from __future__ import annotations

import os
from pathlib import Path

# .../<project>/baccarat/store/paths.py  ->  baccarat/  ->  <project>/
PACKAGE = Path(__file__).resolve().parent.parent
PROJECT = PACKAGE.parent

ENV_VAR = "BACCARAT_DATA"

# Any one of these says "the data lives here". Used to tell a migrated folder
# from an un-migrated one without being told which it is.
MARKERS = ("sites", "tables", "site.json", "runs.json", "road_patterns.json")

_override: Path | None = None


def use_data_dir(where: str | Path | None) -> Path:
    """Point everything at another folder — a copy, a test's tmp_path, a backup.
    Passing None goes back to looking it up. Returns the folder now in use."""
    global _override
    _override = Path(where).expanduser().resolve() if where else None
    return data_dir()


def _has_data(d: Path) -> bool:
    return any((d / m).exists() for m in MARKERS)


def data_dir() -> Path:
    if _override is not None:
        return _override
    env = os.environ.get(ENV_VAR, "").strip()
    if env:
        return Path(env).expanduser().resolve()
    new = PROJECT / "data"
    if _has_data(new) or not _has_data(PROJECT):
        return new                     # migrated, or a fresh install
    return PROJECT                     # un-migrated: the old flat layout


def layout() -> str:
    """Which of the three it found — for the startup line and the dashboard."""
    if _override is not None:
        return "chosen"
    if os.environ.get(ENV_VAR, "").strip():
        return "$" + ENV_VAR
    return "data/" if data_dir() != PROJECT else "old flat layout"


# --- Shared across every site: what HAPPENED, not how a site is laid out ----

def sites_dir() -> Path:
    return data_dir() / "sites"


def site_file() -> Path:
    """Which site is in use, so every entry point agrees whichever you run."""
    return data_dir() / "site.json"


def debug_dir() -> Path:
    return data_dir() / "debug"


def tables_dir() -> Path:
    return data_dir() / "tables"


def runs_file() -> Path:
    return data_dir() / "runs.json"


def calls_file() -> Path:
    """Every table the bot called good or bad, and what it turned out to be."""
    return data_dir() / "table_calls.json"


def patterns_file() -> Path:
    """The road patterns you have written down. Outside the site folders on
    purpose: a shape of road is a fact about baccarat, not about one site's
    buttons, so the same library is there whichever site you play."""
    return data_dir() / "road_patterns.json"


def attic_dir() -> Path:
    """Files the program no longer reads but has no business deleting."""
    return data_dir() / "attic"


# --- Inside the package: shipped with the code, not your data ---------------

def web_file(name: str) -> Path:
    return PACKAGE / "web" / "static" / name
