"""Every table the bot called good, bad or ordinary -- and what it turned out to be.

This is the record a wrong call is read from: the pattern it saw, the four
numbers, what the closest tables had made, and then what this one made. One
list for every configuration, newest last, kept to the last KEEP calls.
"""

from __future__ import annotations

import json
import os
import threading

from baccarat.store import paths

KEEP = 2000
# the same four as core/tablekind.py: the store sits below core and can't import it
# (a test checks the two agree)
TIERS = ("exceptional", "good", "regular", "bad")
_lock = threading.Lock()

# a call is right when the table turned out to be one of these
RIGHT = {"good": ("exceptional", "good"), "bad": ("bad",), "ordinary": ("good", "regular")}


def load_calls(config: str | None = None) -> list[dict]:
    try:
        calls = json.loads(paths.calls_file().read_text()).get("calls", [])
    except (OSError, json.JSONDecodeError, AttributeError):
        return []
    return [c for c in calls if config is None or c.get("config") == config]


def save_call(call: dict) -> None:
    with _lock:
        calls = (load_calls() + [call])[-KEEP:]
        f = paths.calls_file()
        f.parent.mkdir(parents=True, exist_ok=True)
        tmp = f.with_suffix(".tmp")
        tmp.write_text(json.dumps({"calls": calls}, indent=1) + "\n")
        os.replace(tmp, f)


def is_right(call: dict) -> bool | None:
    got = (call.get("outcome") or {}).get("tier")
    return None if got is None else got in RIGHT.get(call.get("call"), ())


def calibration(config: str | None = None, calls: list[dict] | None = None) -> dict:
    """How the calls have gone: for each call, how many tables turned out to be what.
    Tables the session was stopped on are left out -- what they were worth is unknown."""
    calls = [c for c in (load_calls(config) if calls is None else calls)
             if c.get("outcome") and not c["outcome"].get("partial")]
    out = {call: {"n": 0, "right": 0, "tiers": {t: 0 for t in TIERS}}
           for call in ("good", "ordinary", "bad")}
    for c in calls:
        row = out.get(c.get("call"))
        if row is None:
            continue
        row["n"] += 1
        row["tiers"][c["outcome"]["tier"]] += 1
        row["right"] += bool(is_right(c))
    every = {t: sum(r["tiers"][t] for r in out.values()) for t in TIERS}
    n = sum(every.values())
    return {"calls": out, "n": n, "right": sum(r["right"] for r in out.values()),
            "tiers": every, "last": [_short(c) for c in calls[-12:]]}


def _short(c: dict) -> dict:
    o = c["outcome"]
    return {"table": c.get("table"), "when": c.get("when"), "hand": c.get("hand"),
            "pattern": c.get("pattern"), "call": c.get("call"), "tier": o["tier"],
            "profit": o["profit"], "deepest": o["deepest"], "right": is_right(c)}
