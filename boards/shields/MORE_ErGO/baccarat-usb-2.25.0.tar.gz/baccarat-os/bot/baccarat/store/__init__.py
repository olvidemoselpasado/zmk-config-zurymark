"""store — what is kept on disk: where it lives, and reading and writing it.

    paths      the one module that knows where the data folder is
    settings   the per-site session settings, and the road-pattern library
    history    the recorded tables (one file per shoe) and the run history
    tablecalls every table called good or bad, and what it turned out to be
"""
