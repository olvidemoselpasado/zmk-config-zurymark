"""The session settings, and the library of road patterns.

The settings belong to the SITE they were set up for: a table's pace, its chips
and its open-table actions are no use on another site, so they live in that
site's folder and switching site switches them.

The patterns do not. A shape of road is a fact about baccarat, not about one
site's buttons, so the library you have written down is there whichever site you
play."""

from __future__ import annotations

import json
from pathlib import Path
from baccarat import screen as bet
from baccarat.store import paths
from baccarat import core as strategies
from baccarat.core.strategy import STRATEGIES




# The session settings belong to the site they were set up for: a table's pace,
# its chips and its open_table actions are no use on another one.
def settings_file() -> Path:
    return bet.site_dir() / "settings.json"


def patterns_file() -> Path:
    """The road patterns you have written down. Kept outside the site folders: a shape
    of road is a fact about baccarat, not about one site's buttons, so the same library
    is there whichever site you play."""
    return paths.patterns_file()


def load_patterns() -> list[dict]:
    try:
        saved = json.loads(patterns_file().read_text())
    except (OSError, json.JSONDecodeError):
        return list(STARTER_PATTERNS)
    out = []
    for p in saved if isinstance(saved, list) else []:
        try:
            out.append({"name": str(p.get("name") or "").strip() or p["pattern"],
                        "pattern": strategies.clean_pattern(p.get("pattern")),
                        "note": str(p.get("note") or "")})
        except (ValueError, KeyError, AttributeError, TypeError):
            continue                      # a line that got mangled is dropped, not fatal
    return out


def save_patterns(items: list[dict]) -> None:
    patterns_file().write_text(json.dumps(items, indent=1) + "\n")


# Written down to start you off — change or delete them like any other.
STARTER_PATTERNS = [
    {"name": "two by two", "pattern": "BBPPBB",
     "note": "runs of exactly two, the shape streak_or_chop_2 loses to"},
    {"name": "two by two (the other way)", "pattern": "PPBBPP", "note": ""},
    {"name": "ping-pong", "pattern": "PBPBPB",
     "note": "the road changing side every hand"},
]


DEFAULTS = {"strategy": "streak_or_chop", "budget": 1000, "base": 20,
            "max_steps": "", "target": "", "rounds": 300, "runs": 1000,
            "start_at": "", "start_tz": "utc", "rules": [], "ask_road": True,
            "table_hands": 40, "at_cutoff": "switch", "cutoff_margin": 20,
            "shadow_unit": 0, "shadow_after": 2, "shadow_min_lives": 5,
            "cycles": 1, "hand_seconds": 15, "extra_wait": 10, "open_patterns": [],
            "wait_hands": 44, "alarm": True, "hard_score": False, "open_scroll": {},
            "leave": "close", "bet_start_on": "game",
            "bet_window": 6, "click_min": 0.10, "click_max": 0.30, "quiet_poll": 0.8,
            "move_speed": 0.26, "on_mismatch": "carry_on", "stake_on_place": True,
            "login_tries": 3, "login_wait": 60, "login_enter": True,
            "screens": [], "screen_min": 20,
            "extra_on": False, "extra_every": 3, "extra_strict": 2, "extra_after": 6,
            "extra_for": 20,
            "pattern_leave": False,
            "kind_on": True, "kind_exceptional": 400, "kind_regular": 150, "kind_after": 12}


def load_settings() -> dict:
    try:
        st = {**DEFAULTS, **json.loads(settings_file().read_text())}
    except (OSError, json.JSONDecodeError):
        st = dict(DEFAULTS)
    if st["strategy"] not in STRATEGIES:            # e.g. a strategy that was removed
        st["strategy"] = DEFAULTS["strategy"]
    return st


def save_settings(values: dict) -> None:
    keep = {k: values.get(k, DEFAULTS[k]) for k in DEFAULTS}
    settings_file().parent.mkdir(parents=True, exist_ok=True)
    settings_file().write_text(json.dumps(keep, indent=1) + "\n")
