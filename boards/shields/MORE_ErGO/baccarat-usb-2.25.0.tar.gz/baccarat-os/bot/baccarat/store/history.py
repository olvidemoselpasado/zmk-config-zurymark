"""
tables — every table (shoe) is stored in its own file:  tables/table_<date>_<time>.json

A new table starts when the P/B/T counters go back to 0. Each file holds the
results in order (plus any bets made on it), and is rewritten after every
round, so nothing is lost if the program stops.
"""

from __future__ import annotations

import json
import os
import threading
import time

from baccarat.store import paths

# Where these live is paths' business, not ours — asked for at the moment
# of use so the data folder can be moved or pointed elsewhere.
SIDES = ("player", "banker", "tie")

# Every losing run really played (live or paper) — not replays. Keyed by the
# configuration (strategy + rules), so Setup can say how many lives past runs needed.

_runs_lock = threading.Lock()


class TableLog:
    def __init__(self, board: dict, mode: str, strategy: str,
                 prior_road: list[str] | None = None, complete: bool | None = None,
                 site: str = ""):
        paths.tables_dir().mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        path, n = paths.tables_dir() / f"table_{stamp}.json", 1
        while path.exists():
            n += 1
            path = paths.tables_dir() / f"table_{stamp}_{n}.json"
        self.path = path
        played = sum(board[k] for k in SIDES)
        self.data = {
            "started": time.strftime("%Y-%m-%d %H:%M:%S"),
            "ended": None,
            "end_reason": None,
            "mode": mode,
            "strategy": strategy,
            "site": site,                  # which gaming site it was played on

            # complete = we saw it from its first game, so `rounds` is the whole table
            "complete": played == 0 if complete is None else complete,
            "joined_at_game": board["game"],
            "start_counts": {k: board[k] for k in SIDES},
            "prior_road": list(prior_road or []),      # results before we joined (typed or read)
            "rounds": [],
        }
        self.save()

    @property
    def name(self) -> str:
        return self.path.stem

    def add(self, game, winner, pairs, board, result=None) -> None:
        row = {"game": game, "winner": winner, "pairs": pairs,
               "counts": {k: board[k] for k in SIDES} if board else None}
        if result is not None and result.side:
            row.update(side=result.side, stake=result.amount, outcome=result.outcome,
                       profit=result.profit, balance=result.balance, by=result.by)
        elif result is not None and getattr(result, "virtual", None):
            # the money had run out: the bet that would have been made, never staked
            row["virtual"] = result.virtual
        self.data["rounds"].append(row)
        self.save()

    def close(self, reason: str) -> None:
        self.data["ended"] = time.strftime("%Y-%m-%d %H:%M:%S")
        self.data["end_reason"] = reason
        self.save()

    def save(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, indent=1) + "\n")
        os.replace(tmp, self.path)


# ---------------------------------------------------------------------------
# Losing runs, remembered per configuration
# ---------------------------------------------------------------------------

def _read_runs() -> dict:
    try:
        d = json.loads(paths.runs_file().read_text())
    except (OSError, json.JSONDecodeError):
        return {"configs": {}}
    return d if isinstance(d.get("configs"), dict) else {"configs": {}}


def _blank() -> dict:
    return {"runs": 0, "won": 0, "unfinished": 0, "busted": 0,
            "max_lives": 0, "max_won": 0, "max_virtual": 0,
            "max_at": None, "max_mode": None, "max_table": None,
            "lives": {}, "modes": {}, "first": None, "last": None}


def note_run(config: str, lives: int, won: bool, virtual: int = 0, mode: str = "paper",
             table: str | None = None) -> dict:
    """Remember one losing run that was really played.
        lives   = bets it took (1 = won at the base bet straight away)
        won     = it ended with a win (False = the doubling limit or the table cut it short)
        virtual = of those bets, how many came after the money ran out
    Returns this configuration's totals afterwards."""
    if not config or lives <= 0:
        return {}
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    with _runs_lock:
        data = _read_runs()
        c = {**_blank(), **data["configs"].get(config, {})}
        c["runs"] += 1
        c["won"] += bool(won)
        c["unfinished"] += (not won)
        c["busted"] += bool(virtual)
        c["lives"][str(lives)] = int(c["lives"].get(str(lives), 0)) + 1
        c["modes"][mode] = int(c["modes"].get(mode, 0)) + 1
        c["max_virtual"] = max(c["max_virtual"], virtual)
        if won:
            c["max_won"] = max(c["max_won"], lives)
        if lives > c["max_lives"]:
            c.update(max_lives=lives, max_at=now, max_mode=mode, max_table=table)
        c["first"] = c["first"] or now
        c["last"] = now
        data["configs"][config] = c
        tmp = paths.runs_file().with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=1) + "\n")
        os.replace(tmp, paths.runs_file())
        return dict(c)


def reset_runs(config: str) -> dict:
    """Forget the runs played with one configuration -- the worst it ever needed starts
    again from nothing. What it had is kept in data/attic (runs-reset-<when>.json), so a
    reset by mistake can be put back by hand. → what was forgotten."""
    with _runs_lock:
        data = _read_runs()
        gone = data["configs"].pop(config, None)
        if gone is None:
            return {}
        attic = paths.attic_dir()
        attic.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        (attic / f"runs-reset-{stamp}.json").write_text(
            json.dumps({"config": config, "reset": stamp, "history": gone}, indent=1) + "\n")
        tmp = paths.runs_file().with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=1) + "\n")
        os.replace(tmp, paths.runs_file())
        return gone


def run_history(config: str | None = None) -> dict:
    """One configuration's totals, or {config: totals} for all of them."""
    data = _read_runs()["configs"]
    if config is None:
        return data
    return {**_blank(), **data.get(config, {}), "config": config}


def shoe_lengths(tables: list[dict] | None = None, site: str | None = None) -> list[int]:
    """How many hands the shoes really lasted: the tables watched until their counters
    went back to zero (a new shoe), each one's last hand. Only those -- a table left
    early says nothing about where its shoe ends."""
    out = []
    for t in tables if tables is not None else load_tables():
        if t.get("end_reason") != "counters reset — new table" or (site and t.get("site") != site):
            continue
        last = next((r for r in reversed(t.get("rounds") or []) if r.get("counts")), None)
        if last:
            n = sum(int(last["counts"].get(k) or 0) for k in SIDES)
            if n >= 10:
                out.append(n)
    return out


def load_tables() -> list[dict]:
    """All stored tables, oldest first. Each dict gets a 'name' and a 'road'."""
    out = []
    for f in sorted(paths.tables_dir().glob("table_*.json")):
        try:
            t = json.loads(f.read_text())
        except (OSError, json.JSONDecodeError):
            continue
        t["name"] = f.stem
        t["road"] = [r["winner"] for r in t.get("rounds", []) if r.get("winner") in SIDES]
        out.append(t)
    return out
