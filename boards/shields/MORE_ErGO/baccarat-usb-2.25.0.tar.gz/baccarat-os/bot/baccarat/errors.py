"""The one exception type this program raises on purpose.

BetError means "this cannot be done and here is the reason in a sentence you
can act on". It is caught at the edges -- the CLI prints it, the dashboard
shows it -- so the message is written for whoever is reading it, not for a
stack trace."""

from __future__ import annotations





class BetError(RuntimeError):
    """Raised for setup/runtime problems (missing pattern, region, daemon …)."""
