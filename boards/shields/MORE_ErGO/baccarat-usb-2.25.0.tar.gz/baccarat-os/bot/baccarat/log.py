"""Logging, shared by everything."""

from __future__ import annotations

import logging
import re
import time




DEBUG = False


log = logging.getLogger("bet")


def setup_logging(debug: bool = False) -> None:
    """Call once from your main script to see bet's log output."""
    global DEBUG
    DEBUG = debug
    logging.basicConfig(
        level=logging.DEBUG if debug else logging.INFO,
        format="%(asctime)s  %(levelname)-8s  %(message)s",
        datefmt="%H:%M:%S",
    )
    log.setLevel(logging.DEBUG if debug else logging.INFO)
    _log_to_file()


class _Plain(logging.Formatter):
    """The file gets the text without the terminal's colour codes."""
    def format(self, record):
        return re.sub(r"\x1b\[[\d;]*m", "", super().format(record))


def _log_to_file() -> None:
    """Everything also goes to data/logs/bot-<date>.log, so a session can be looked at
    after the terminal and the dashboard are gone. One file a day, appended to."""
    from baccarat.store import paths          # here, not at the top: nothing low imports up
    root = logging.getLogger()
    if any(getattr(h, "_bot_file", False) for h in root.handlers):
        return
    try:
        folder = paths.data_dir() / "logs"
        folder.mkdir(parents=True, exist_ok=True)
        h = logging.FileHandler(folder / f"bot-{time.strftime('%Y%m%d')}.log", encoding="utf-8")
    except OSError as e:
        log.warning("Couldn't open a log file (%s) — the log is on screen only.", e)
        return
    h._bot_file = True
    h.setFormatter(_Plain("%(asctime)s  %(levelname)-8s  %(message)s", "%Y-%m-%d %H:%M:%S"))
    h.setLevel(logging.DEBUG)
    root.addHandler(h)
    log.info("Log file: %s", h.baseFilename)
