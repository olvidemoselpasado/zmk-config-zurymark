"""Totals across many sessions: real tables, and random ones.

stats_data replays every recorded table. random_data plays made-up roads, which
is the control: a strategy that does the same on random roads as on real ones
has found nothing in the real ones."""

from __future__ import annotations

import random
import statistics
from collections import Counter
from baccarat.core.strategy import STRATEGIES
from baccarat.store.history import load_tables


from baccarat.study.replay import new_session, simulate_road
from baccarat.study.totals import _totals


# Real baccarat odds (8 decks)
ODDS = {"banker": 0.458597, "player": 0.446247, "tie": 0.095156}


def stats_data(strategy: str, budget: float, base: float,
               max_steps: int | None = None, ceiling: float | None = None, rules=None,
               table_hands: int | None = None, at_cutoff: str = "wait",
               cutoff_margin: int = 20, shadow_unit: float = 0.0,
               shadow_after: int = 2, shadow_min_lives: int = 5,
               extra_after: int = 6, extra_for: int = 20,
               extra_every: int = 0, extra_strict: int = 2) -> dict:
    """strategy may be 'all' to compare every strategy."""
    tables = [t for t in load_tables() if t["road"]]
    names = list(STRATEGIES) if strategy == "all" else [strategy]
    rounds = sum(len(t["road"]) for t in tables)
    counts = Counter(w for t in tables for w in t["road"])
    out = {
        "tables": len(tables), "rounds": rounds,
        "freq": {k: (counts[k] / rounds if rounds else 0) for k in ("banker", "player", "tie")},
        "strategies": names, "rows": [], "totals": [],
        "params": {"budget": budget, "base": base, "max_steps": max_steps, "ceiling": ceiling,
                   "rules": rules or [], "table_hands": table_hands, "at_cutoff": at_cutoff,
                   "cutoff_margin": cutoff_margin, "shadow_unit": shadow_unit,
                   "shadow_after": shadow_after, "shadow_min_lives": shadow_min_lives,
                   "extra_after": extra_after, "extra_for": extra_for,
                   "extra_every": extra_every, "extra_strict": extra_strict},
    }
    for name in names:
        sessions = []
        for t in tables:
            s = new_session(name, budget, base, max_steps, ceiling, rules, table_hands,
                            at_cutoff, cutoff_margin, shadow_unit, shadow_after, shadow_min_lives,
                            extra_after=extra_after, extra_for=extra_for,
                    extra_every=extra_every, extra_strict=extra_strict)
            s.new_table(t.get("prior_road"))
            seen_before = sum((t.get("start_counts") or {}).values())    # joined mid-table
            simulate_road(s, t["road"], first_hand=seen_before + 1)
            sessions.append(s)
            if len(names) == 1:
                out["rows"].append({
                    "table": t["name"], "seen": len(t["road"]),
                    "bets": sum(1 for r in s.results if r.side),
                    "wins": s.count("WIN"), "losses": s.count("LOSS"),
                    "net": s.net, "max_bet": s.max_bet,
                    "complete": bool(t.get("complete")), "joined_at": t.get("joined_at_game"),
                    "stopped": s.busted, "reached": s.reached_ceiling,
                })
        out["totals"].append(_totals(name, sessions))
    return out


def random_data(strategy: str, budget: float, base: float, max_steps: int | None = None,
                ceiling: float | None = None, rounds: int = 300, runs: int = 1000,
                seed: int | None = None, bins: int = 24, rules=None,
                table_hands: int | None = None, at_cutoff: str = "wait",
                cutoff_margin: int = 20, shadow_unit: float = 0.0,
               shadow_after: int = 2, shadow_min_lives: int = 5,
               extra_after: int = 6, extra_for: int = 20,
               extra_every: int = 0, extra_strict: int = 2) -> dict:
    rng = random.Random(seed)
    random.seed(seed)                      # the per-table cutoff jitter, repeatable too
    sessions = []
    for _ in range(runs):
        s = new_session(strategy, budget, base, max_steps, ceiling, rules, table_hands,
                    at_cutoff, cutoff_margin, shadow_unit, shadow_after, shadow_min_lives,
                            extra_after=extra_after, extra_for=extra_for,
                    extra_every=extra_every, extra_strict=extra_strict)
        left = rounds
        while left > 0 and not (s.busted or s.reached_ceiling or s.finished):
            n = min(left, table_hands or left)             # one table at a time
            simulate_road(s, rng.choices(list(ODDS), weights=list(ODDS.values()), k=n))
            left -= n
            if left > 0:
                s.new_table()
        sessions.append(s)
    nets = [s.net for s in sessions]
    lo, hi = min(nets), max(nets)
    width = (hi - lo) / bins or 1
    hist = [0] * bins
    for n in nets:
        hist[min(bins - 1, int((n - lo) / width))] += 1
    t = _totals(strategy, sessions)
    ex = sessions[0]
    return {
        **t,
        "runs": runs, "rounds": rounds,
        "params": {"budget": budget, "base": base, "max_steps": max_steps, "ceiling": ceiling,
                   "rules": rules or [], "table_hands": table_hands, "at_cutoff": at_cutoff,
                   "cutoff_margin": cutoff_margin, "shadow_unit": shadow_unit,
                   "shadow_after": shadow_after, "shadow_min_lives": shadow_min_lives,
                   "extra_after": extra_after, "extra_for": extra_for,
                   "extra_every": extra_every, "extra_strict": extra_strict},
        "rule_stats": [{"rule": r.label, "triggered": sum(x.rules[i].triggered for x in sessions),
                        "rescued": sum(x.rules[i].rescued for x in sessions)}
                       for i, r in enumerate(sessions[0].rules)] if sessions else [],
        "mean": statistics.mean(nets), "median": statistics.median(nets),
        "best": hi, "worst": lo,
        "avg_max_bet": statistics.mean(s.max_bet for s in sessions),
        "max_streak": max(s.max_losing_streak for s in sessions),
        "hist": {"lo": lo, "width": width, "counts": hist},
        "example": ex,
    }
