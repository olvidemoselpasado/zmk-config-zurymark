"""Adding up a pile of finished sessions into one row of numbers.

Its own module because both halves of study need it -- the per-table detail and
the totals across all of them -- and a helper that two modules share is not a
private detail of either.
"""

from __future__ import annotations


from baccarat.core.session import Session


def _totals(name: str, sessions: list[Session]) -> dict:
    staked = sum(r.amount for s in sessions for r in s.results)
    wins = sum(s.count("WIN") for s in sessions)
    losses = sum(s.count("LOSS") for s in sessions)
    net = round(sum(s.net for s in sessions), 2)
    return {
        "strategy": name,
        "sessions": len(sessions),
        "bets": sum(1 for s in sessions for r in s.results if r.side),
        "wins": wins, "losses": losses,
        "pushes": sum(s.count("PUSH") for s in sessions),
        "rate": wins / (wins + losses) if wins + losses else None,
        "net": net,
        "ahead": sum(s.net > 0 for s in sessions),
        "stopped": sum(s.busted for s in sessions),
        "finished": sum(s.finished for s in sessions),
        "reached": sum(s.reached_ceiling for s in sessions),
        "per100": net / staked * 100 if staked else None,
        "max_bet": max((s.max_bet for s in sessions), default=0),
        # the longest losing run (base → doubled → … → win) any session had to sit through
        "worst_run": max((s.worst_run for s in sessions), default=0),
    }
