"""Is this a good table or a bad one -- judged from the shape of its road, against
what tables of that shape turned out to be worth with this configuration.

How a table is judged
    At the moment the table has a pattern (the majority window has filled, or
    with no window, WHOLE_TABLE_AFTER results are in), every recorded table is
    taken back to the same hand. Its pattern there is described by the same four
    numbers (core/tablekind.py), and this configuration is replayed over the rest
    of it, exactly as it would play from that point: what it made, and how deep
    its worst run went. That is one example of "a table that looked like this at
    this hand, and what it turned out to be worth".

    The examples closest in shape to this table are its kind. What they turned
    out to be -- so many exceptional, good, regular, bad -- is the spectrum shown.
    It is called good or bad only when that spectrum leans further from tables
    in general than a kind that size could by chance (Z); otherwise it is
    ordinary.

How it gets better
    Every table stored is one more example, and a bigger kind: the more tables,
    the smaller a lean it can trust. Which of the four numbers measure "closest"
    is chosen again at every judgement: the set that would have best predicted
    your own recorded tables, each one judged from all the others.

Its track record
    Next to every call is what calls like it would have been worth on your own
    tables: of the tables it would have called bad, how many were -- against how
    many tables are bad in general. It is measured honestly: the numbers are
    chosen on one half of the tables and the calls made on the other half, both
    ways round, so no table is judged by a choice it helped make. If the shape of
    the road tells nothing for this configuration, this is where it shows.
"""

from __future__ import annotations

import functools
import itertools
import math
import time

import numpy as np

from baccarat.core.tablekind import (
    FEATURES, TIERS, WHOLE_TABLE_AFTER, EXCEPTIONAL_AT, REGULAR_BELOW,
    pattern_of, ready, shape, tier, window_of)
from baccarat.store.history import load_tables
from baccarat.study.expect import affordable
from baccarat.study.replay import new_session, simulate_road

MIN_SAMPLES = 30          # fewer examples than this at the hand: not judged yet
Z = 1.65                  # how many standard errors a kind must lean by to be called
LEAN = 0.03               # an ORDINARY kind this far from tables in general is said to lean
SMOOTH = 2.0              # examples' worth of "tables in general" mixed into each kind
SUBSETS = [c for n in range(1, len(FEATURES) + 1) for c in itertools.combinations(FEATURES, n)]


def known_road(t: dict) -> tuple[int, list[str]]:
    """(hand number of the first result we know, every result we know) for a stored table."""
    prior = list(t.get("prior_road") or [])
    before = sum((t.get("start_counts") or {}).values())
    return max(1, before - len(prior) + 1), prior + list(t.get("road") or [])


def examples(strategy: str, budget: float, base: float, hand: int, window: int,
             max_steps: int | None = None, rules=None, table_hands: int | None = None,
             at_cutoff: str = "wait", cutoff_margin: int = 20, shadow_unit: float = 0.0,
             shadow_after: int = 2, shadow_min_lives: int = 5,
             extra_after: int = 6, extra_for: int = 20, extra_every: int = 0,
             extra_strict: int = 2,
             whole_after: int = WHOLE_TABLE_AFTER, exceptional_at: float = EXCEPTIONAL_AT,
             regular_below: float = REGULAR_BELOW, tables: list[dict] | None = None,
             exclude=(), **_) -> tuple[list[dict], int]:
    """Every recorded table taken back to `hand`: its pattern there, and what this
    configuration made on it from there to the end. → (examples, bets the balance covers)"""
    cover = affordable(budget, base, max_steps)
    out = []
    for n, t in enumerate(load_tables() if tables is None else tables):
        if t.get("name") in exclude:
            continue
        first, full = known_road(t)
        i = hand - first + 1                     # results known up to and including `hand`
        if i < 1 or i >= len(full) or (not window and first != 1):
            continue                             # not there yet, already over, or no start
        before = full[:i]
        if not ready(before, window, whole_after):
            continue
        letters = pattern_of(before, window)
        s = new_session(strategy, 1e15, base, max_steps, None, rules, table_hands, at_cutoff,
                        cutoff_margin, shadow_unit, shadow_after, shadow_min_lives,
                        extra_after=extra_after, extra_for=extra_for,
                    extra_every=extra_every, extra_strict=extra_strict)
        s.new_table(before)
        s.cutoff_jitter = 0
        simulate_road(s, full[i:], first_hand=hand + 1)
        profit = round(sum(r.profit for r in s.results if r.side), 2)
        deepest = max([r["lives"] for r in s.runs] + [s.run_bets], default=0)
        out.append({"table": t.get("name"), "pattern": letters, "f": shape(letters),
                    "profit": profit, "deepest": deepest, "hands": len(full) - i,
                    "tier": tier(profit, deepest, cover, exceptional_at, regular_below)})
        if n % 50 == 49:
            time.sleep(0.001)                    # let the table reader have the interpreter
    return out, cover


# --- measuring closeness ---------------------------------------------------------

def _matrix(rows: list[dict]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    X = np.array([[r["f"][k] for k in FEATURES] for r in rows], dtype=float)
    mean, sd = X.mean(axis=0), X.std(axis=0)
    sd[sd == 0] = 1.0
    return (X - mean) / sd, mean, sd


def _onehot(rows: list[dict]) -> np.ndarray:
    Y = np.zeros((len(rows), len(TIERS)))
    for j, r in enumerate(rows):
        Y[j, TIERS.index(r["tier"])] = 1
    return Y


def _k(n: int) -> int:
    """How many of the closest tables make up a kind. Outcomes vary a lot from table
    to table, so a kind needs a good many of them before its shares mean anything:
    a fifth of the examples, at least 15, at most 150."""
    return max(1, min(n - 1, max(15, min(150, int(round(n / 5))))))


def _mask(subset) -> np.ndarray:
    return np.array([k in subset for k in FEATURES], dtype=float)


def _parts(Xq, Xtrain) -> np.ndarray:
    """Squared distance along each of the numbers separately: (feature, query, example).
    Worked out once, then any choice of numbers is just a sum of some of them."""
    return (Xq.T[:, :, None] - Xtrain.T[:, None, :]) ** 2


def _predict(Xtrain, Ytrain, Xq, subset, k, self_out=False, parts=None) -> np.ndarray:
    """Each query's spectrum: the tiers of its k closest examples, with a little of
    the overall spread mixed in so one odd example can't make a 100%."""
    parts = _parts(Xq, Xtrain) if parts is None else parts
    d = parts[_mask(subset).astype(bool)].sum(axis=0)
    if self_out:
        np.fill_diagonal(d, np.inf)
    k = min(k, Xtrain.shape[0] - (1 if self_out else 0))
    idx = np.argpartition(d, k - 1, axis=1)[:, :k]
    counts = Ytrain[idx].sum(axis=1)
    base = Ytrain.mean(axis=0)
    return (counts + SMOOTH * base) / (k + SMOOTH)


def _brier(P, Y) -> float:
    return float(((P - Y) ** 2).sum(axis=1).mean())


def _best_subset(X, Y) -> tuple[tuple, float]:
    """The numbers that best predicted these tables, each judged from all the others."""
    k, base = _k(len(Y)), Y.mean(axis=0)
    ref = _brier(np.broadcast_to(base, Y.shape), Y)
    best, score = SUBSETS[-1], -1e9
    parts = _parts(X, X)
    for sub in SUBSETS:
        skill = 1 - _brier(_predict(X, Y, X, sub, k, True, parts), Y) / ref if ref else 0.0
        if skill > score + 1e-9:
            best, score = sub, skill
    return best, score


B, GOOD = TIERS.index("bad"), [TIERS.index("exceptional"), TIERS.index("good")]


def call_of(p, general, k: int) -> str:
    """good, bad or ordinary: the kind is called only when it leans further from
    tables in general than its own size could do by chance (Z standard errors).
    The more tables recorded, the bigger a kind, the smaller a lean that counts."""
    pb, gb = float(p[B]), float(general[B])
    pg, gg = float(sum(p[i] for i in GOOD)), float(sum(general[i] for i in GOOD))
    se_b = math.sqrt(max(gb * (1 - gb), 1e-6) / (k + SMOOTH))
    se_g = math.sqrt(max(gg * (1 - gg), 1e-6) / (k + SMOOTH))
    if pb - gb >= Z * se_b:
        return "bad"
    if pg - gg >= Z * se_g or gb - pb >= Z * se_b:
        return "good"
    return "ordinary"


def lean_of(p, general) -> str | None:
    """Which way a kind leans, when it isn't far enough to be called: 'bad', 'good' or None."""
    db = float(p[B] - general[B])
    dg = float(sum(p[i] for i in GOOD) - sum(general[i] for i in GOOD))
    if db >= LEAN and db >= dg:
        return "bad"
    if dg >= LEAN or -db >= LEAN:
        return "good"
    return None


def track_record(X, Y) -> dict:
    """What the calls would have been on your own tables, and what those tables really
    were. Honest: the numbers are chosen on one half of the tables and the calls made
    on the other half, both ways round -- no table is judged by a choice it helped make."""
    n = len(Y)
    rec = {c: {"n": 0, "bad": 0, "good": 0} for c in ("good", "ordinary", "bad")}
    general = Y.mean(axis=0)
    out = {"calls": rec, "n": 0, "bad_rate": round(float(general[B]), 3),
           "good_rate": round(float(sum(general[i] for i in GOOD)), 3),
           "proven": {"bad": False, "good": False}}
    if n < 2 * 15:
        return out
    order = np.random.default_rng(n).permutation(n)
    halves = order[: n // 2], order[n // 2:]
    for a, b in (halves, halves[::-1]):
        sub, _ = _best_subset(X[a], Y[a])
        k = _k(len(a))
        P = _predict(X[a], Y[a], X[b], sub, k)
        g = Y[a].mean(axis=0)
        for p, y in zip(P, Y[b]):
            row = rec[call_of(p, g, k)]
            row["n"] += 1
            row["bad"] += int(y[B])
            row["good"] += int(sum(y[i] for i in GOOD))
    out["n"] = n
    br, gr = out["bad_rate"], out["good_rate"]
    # a kind of call has proved itself when what it called really was that more often
    # than tables in general -- by more than chance would give that many calls
    bc, gc = rec["bad"], rec["good"]
    if bc["n"] >= 5:
        out["proven"]["bad"] = bc["bad"] / bc["n"] - br >= Z * math.sqrt(br * (1 - br) / bc["n"])
    if gc["n"] >= 5:
        out["proven"]["good"] = gc["good"] / gc["n"] - gr >= Z * math.sqrt(gr * (1 - gr) / gc["n"])
    return out


# --- judging one table --------------------------------------------------------------

def judge(road: list[str], hand: int, window: int, strategy: str, budget: float, base: float,
          whole_after: int = WHOLE_TABLE_AFTER, exceptional_at: float = EXCEPTIONAL_AT,
          regular_below: float = REGULAR_BELOW, tables: list[dict] | None = None,
          exclude=(), **params) -> dict:
    """What kind of table this is, at `hand`, from everything recorded."""
    letters = pattern_of(road, window)
    f = shape(letters)
    head = {"hand": hand, "window": window, "pattern": letters, "features": f,
            "exceptional_at": exceptional_at, "regular_below": regular_below}
    if not ready(road, window, whole_after):
        return {**head, "ready": False, "why": "not enough results for a pattern yet"}
    rows, cover = examples(strategy, budget, base, hand, window, tables=tables,
                           exclude=exclude, whole_after=whole_after,
                           exceptional_at=exceptional_at, regular_below=regular_below, **params)
    head["cover"] = cover
    if len(rows) < MIN_SAMPLES:
        return {**head, "ready": False, "examples": len(rows),
                "why": (f"only {len(rows)} recorded table{'' if len(rows) == 1 else 's'} reached "
                        f"hand {hand} with a pattern — {MIN_SAMPLES} are needed to judge one")}
    X, mean, sd = _matrix(rows)
    Y = _onehot(rows)
    sub, _ = _best_subset(X, Y)
    k = _k(len(rows))
    xq = ((np.array([[f[c] for c in FEATURES]], dtype=float) - mean) / sd)
    p = _predict(X, Y, xq, sub, k)[0]
    general = Y.mean(axis=0)
    spec = {t: round(float(p[i]), 3) for i, t in enumerate(TIERS)}
    base_spec = {t: round(float(general[i]), 3) for i, t in enumerate(TIERS)}
    # who the kind is: the closest examples themselves
    d = (((X - xq) * _mask(sub)) ** 2).sum(axis=1)
    near = np.argsort(d, kind="stable")[:k]
    profits = np.array([rows[j]["profit"] for j in near])
    return {
        **head, "ready": True, "call": call_of(p, general, k), "lean": lean_of(p, general),
        "spectrum": spec,
        "general": base_spec, "examples": len(rows), "similar": int(k), "uses": list(sub),
        "record": track_record(X, Y),
        # medians, not averages: a run the balance couldn't have paid for is in here
        # at its full size, and one of those would swamp any average
        "typical": {"median": round(float(np.median(profits)), 2),
                    "low": round(float(np.percentile(profits, 25)), 2),
                    "high": round(float(np.percentile(profits, 75)), 2)},
        "everyone": round(float(np.median([r["profit"] for r in rows])), 2),
        "nearest": [{k2: rows[j][k2] for k2 in ("table", "pattern", "profit", "deepest", "tier")}
                    for j in near[:5]],
        # what each tier's tables looked like here, for reading a wrong call afterwards
        "by_tier": {t: {c: round(float(np.mean([r["f"][c] for r in rows if r["tier"] == t])), 3)
                        for c in FEATURES}
                    for t in TIERS if any(r["tier"] == t for r in rows)},
    }


def player_args(rules, params: dict, kinds: dict) -> dict:
    """What the Player is handed: the judge, with this configuration and the Setup
    thresholds already in it (None when it is switched off)."""
    after = kinds["whole_after"]
    if not kinds["on"] or params.get("strategy") == "all":
        return {"kind_judge": None, "kind_after": after}
    p = {k: v for k, v in params.items() if k != "target"}
    return {"kind_judge": functools.partial(
                judge, window=window_of(rules), whole_after=after,
                exceptional_at=kinds["exceptional_at"], regular_below=kinds["regular_below"], **p),
            "kind_after": after}
