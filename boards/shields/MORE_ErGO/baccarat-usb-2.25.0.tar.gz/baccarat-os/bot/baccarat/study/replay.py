"""Replaying a road: what WOULD have happened.

Every replay runs the same Session the live table runs, over results that have
already been recorded. That is the whole point: there is no second
implementation of the counting, so a replay cannot flatter a strategy by
scoring it differently from the way the money was actually counted.

A replay stops where the real thing would have stopped -- a bust ends the
session, it does not carry on with a negative balance.

entry_scan answers the question that follows: the same road entered at hand 1,
hand 2, hand 3 ... is a different session each time, so it plays all of them and
shows which entry points survived."""

from __future__ import annotations

from baccarat.core.game import SIDES
from baccarat.core.rules import build_rules
from baccarat.core.session import Session
from baccarat.core.staking import Doubling
from baccarat.core.strategy import get_strategy
from baccarat.store.history import load_tables


from baccarat.study.totals import _totals


def new_session(strategy: str, budget: float, base: float,
                max_steps: int | None = None, ceiling: float | None = None,
                rules=None, table_hands: int | None = None, at_cutoff: str = "wait",
                cutoff_margin: int = 20, shadow_unit: float = 0.0,
                shadow_after: int = 2, shadow_min_lives: int = 5,
                extra_after: int = 6, extra_for: int = 20,
               extra_every: int = 0, extra_strict: int = 2,
                watch: bool = False) -> Session:
    """rules: specs like [{"name": "loss_streak", "n": 3}] — fresh rule state per session.
    table_hands: hands per table (e.g. 40); cutoff_margin: how many of them are kept
    free at the end, where no new losing run may start.
    watch: when the money runs out, keep following the run without betting (real play
    only — a replay just stops there)."""
    s = Session(get_strategy(strategy), Doubling(base, max_steps), budget, ceiling=ceiling,
                rules=build_rules(rules), table_hands=table_hands, at_cutoff=at_cutoff,
                cutoff_margin=cutoff_margin, shadow_unit=shadow_unit,
                shadow_after=shadow_after, shadow_min_lives=shadow_min_lives,
                extra_after=int(extra_after or 0), extra_for=int(extra_for or 20),
                extra_every=int(extra_every or 0), extra_strict=int(extra_strict or 2),
                watch_after_bust=watch)
    s.new_table()
    return s


def simulate_road(session: Session, road: list[str], first_hand: int = 1) -> Session:
    """Play one table's results. first_hand = the hand number of road[0] on the table."""
    for i, w in enumerate(road):
        session.record(w, session.next_bet(hand=first_hand + i))
        if session.busted or session.reached_ceiling or session.finished:
            break
    return session


def table_detail(table: str, strategy: str, budget: float, base: float,
                 max_steps: int | None = None, ceiling: float | None = None, rules=None,
                 table_hands: int | None = None, at_cutoff: str = "wait",
                 cutoff_margin: int = 20, shadow_unit: float = 0.0,
                 shadow_after: int = 2, shadow_min_lives: int = 5,
                 extra_after: int = 6, extra_for: int = 20,
               extra_every: int = 0, extra_strict: int = 2) -> dict:
    """Replay one stored table hand by hand → every result, and the bet on it.
    Also shows what was actually bet at the time, when the table has it."""
    t = next((x for x in load_tables() if x["name"] == table), None)
    if t is None:
        raise ValueError(f"no stored table named '{table}'")
    s = new_session(strategy, budget, base, max_steps, ceiling, rules, table_hands,
                    at_cutoff, cutoff_margin, shadow_unit, shadow_after, shadow_min_lives,
                    extra_after=extra_after, extra_for=extra_for,
                    extra_every=extra_every, extra_strict=extra_strict)
    prior = t.get("prior_road") or []
    s.new_table(prior)
    hand = sum((t.get("start_counts") or {}).values()) + 1
    rounds, stopped = [], None
    for row in t.get("rounds", []):
        winner = row.get("winner")
        if winner not in SIDES:                      # a round whose result wasn't read
            rounds.append({"hand": hand, "game": row.get("game"), "winner": None})
            hand += 1
            continue
        bet = s.next_bet(hand=hand)
        r = s.record(winner, bet, game=row.get("game"))
        rounds.append({
            "hand": hand, "game": row.get("game"), "winner": winner,
            "pairs": row.get("pairs") or [],
            "side": r.side, "stake": r.amount, "outcome": r.outcome, "profit": r.profit,
            "balance": r.balance, "by": r.by,
            "events": list(s.events),
            "live_side": row.get("side"), "live_stake": row.get("stake"),
            "live_outcome": row.get("outcome"),
        })
        hand += 1
        if s.busted or s.reached_ceiling or s.finished:
            stopped = ("balance too low" if s.busted else
                       "target reached" if s.reached_ceiling else "table end")
            break
    return {
        "table": {"name": t["name"], "started": t.get("started"), "mode": t.get("mode"),
                  "complete": bool(t.get("complete")), "joined_at": t.get("joined_at_game"),
                  "prior": len(prior), "rounds": len(t.get("rounds", []))},
        "rounds": rounds, "stopped": stopped,
        "summary": _totals(strategy, [s]),
    }


# ---------------------------------------------------------------------------
# "What if I had joined at hand N?"
#
# One real table, played again and again, each time joining at a different hand. The
# results are the ones that actually came out, so the only thing that changes between
# runs is where the money started — which is the question you can't answer by watching:
# whether a table was unplayable, or simply joined at the wrong moment.
# ---------------------------------------------------------------------------

def _play_from(road: list[str], at: int, **params) -> Session:
    """Join this table at hand `at` (1 = the very first hand) and play to the end.
    Everything before `at` is handed over as history the strategy may look at, exactly
    as a 'road' region would do when joining a table already in progress."""
    s = new_session(**params)
    s.new_table(road[:at - 1])
    simulate_road(s, road[at - 1:], first_hand=at)
    return s


def entry_scan(road: list[str], first: int = 1, last: int | None = None, **params) -> dict:
    """Join at every hand from `first` to `last` and report how each one would have gone."""
    road = [w for w in (road or []) if w in SIDES]
    if not road:
        raise ValueError("there are no results to replay")
    first = max(1, int(first))
    last = min(len(road), int(last or len(road)))
    if first > last:
        raise ValueError(f"the range runs backwards: {first} to {last}")
    out = []
    for at in range(first, last + 1):
        s = _play_from(road, at, **params)
        bets = [r for r in s.results if r.side]
        wins = sum(1 for r in s.results if r.outcome == "WIN")
        losses = sum(1 for r in s.results if r.outcome == "LOSS")
        first_bet = next((i + at for i, r in enumerate(s.results) if r.side), None)
        out.append({
            "at": at, "first_bet": first_bet, "hands": len(road) - at + 1,
            "bets": len(bets), "wins": wins, "losses": losses,
            "pushes": sum(1 for r in s.results if r.outcome == "PUSH"),
            "net": s.net, "max_bet": s.max_bet, "worst_run": s.worst_run,
            "busted": s.busted, "reached": s.reached_ceiling,
            "balance": s.balance, "lives_left": s.lives_affordable(),
        })
    nets = [e["net"] for e in out]
    return {
        "road": road, "first": first, "last": last,
        "entries": out,
        "summary": {"count": len(out), "ahead": sum(n > 0 for n in nets),
                    "best": max(nets), "worst": min(nets),
                    "mean": sum(nets) / len(nets), "busted": sum(e["busted"] for e in out)},
    }


def entry_detail(road: list[str], at: int, **params) -> dict:
    """One joining point, hand by hand: what it would have bet and what really came out."""
    road = [w for w in (road or []) if w in SIDES]
    at = max(1, min(int(at), len(road)))
    s = new_session(**params)
    s.new_table(road[:at - 1])
    rows = []
    for i, w in enumerate(road[at - 1:]):
        hand = at + i
        bet = s.next_bet(hand=hand)
        by, why = s.decided_by, s.skip_reason
        rule = next((r for r in s.rules if r.name == by), None)
        st = rule.stats() if rule else None
        r = s.record(w, bet)
        rows.append({"hand": hand, "winner": w, "side": r.side, "stake": r.amount,
                     "outcome": r.outcome, "profit": r.profit, "balance": r.balance,
                     "by": by, "why": why, "stats": st,
                     "events": list(s.events)})
        if s.busted or s.reached_ceiling or s.finished:
            break
    return {"at": at, "prior": road[:at - 1], "rows": rows,
            "net": s.net, "busted": s.busted, "reached": s.reached_ceiling,
            "balance": s.balance, "max_bet": s.max_bet, "worst_run": s.worst_run}
