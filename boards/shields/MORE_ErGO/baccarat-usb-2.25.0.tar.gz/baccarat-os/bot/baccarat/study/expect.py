"""How much one win is really worth -- and so how many wins, hands and minutes a
target really takes.

'Target 1,000 at a base bet of 20 = 50 wins' assumes every win nets exactly one
base bet. With doubling, a win does recover the run of losses before it and add
one base bet -- but only when it pays even money:

    a run of k bets ending in a win, base b:
        lost before the win      b·(2^(k-1) - 1)
        the winning stake        b·2^(k-1)
        won on PLAYER  (pays 1)  net  +b
        won on BANKER  (pays .95) net  b·(1 - 0.05·2^(k-1))

So a banker win straight away nets 19 of 20, after one loss 18, after two 16,
after three 12, after four 4 -- and from five losses on, a banker win still LOSES
money. Ties win nothing and cost hands. Runs your balance can't pay for aren't
wins at all.

The figure used is measured, not assumed: this exact configuration -- strategy,
rules, base bet, doubling limit, table cutoff -- replayed over every table you
have recorded, one after another the way the bot moves between tables. Every run
it plays is kept with what it really made. Runs longer than your balance covers
(with no doubling limit to stop them first) are taken out and counted apart: in real play they end the session, not count
as a win. With too few tables recorded, the same replay runs over tables dealt
from the game's own odds instead -- your strategy and rules all the same.

It also says how likely a target is to be cut short: a run longer than the balance
covers turns up about once in so many runs, and a target of N wins plays N runs.
"""

from __future__ import annotations

import math
import random

from baccarat.core.game import PAYOUT
from baccarat.core.staking import Doubling, lives
from baccarat.store.history import load_tables
from baccarat.study.replay import new_session, simulate_road

MIN_WINS = 100          # fewer won runs than this in your tables: deal some instead
DEALT_TABLES = 400      # … this many, from the game's own odds
DEALT_SEED = 20261102   # always the same ones, so the estimate doesn't wander
TIE_SHARE = 0.0952      # how often a hand is a tie (the game's own odds)
BANKER_WIN = 0.4586     # how often banker wins a hand
PLAYER_WIN = 0.4462     # … and player


def run_net(base: float, bets: int, side: str) -> float:
    """What a run of `bets` doubled bets, ending in a win on `side`, nets."""
    stake = base * 2 ** (bets - 1)
    return round(stake * PAYOUT[side] - base * (2 ** (bets - 1) - 1), 2)


def affordable(budget: float, base: float, max_steps: int | None = None) -> int:
    """How many bets in a row a run can have: as many as the balance pays for, and
    never more than the doubling limit (there the loss is taken and it starts over)."""
    return len(lives(budget, Doubling(base, max_steps), limit=max_steps or 60)[0])


def win_value(strategy: str, budget: float, base: float, max_steps: int | None = None,
              rules=None, table_hands: int | None = None, at_cutoff: str = "wait",
              cutoff_margin: int = 20, shadow_unit: float = 0.0, shadow_after: int = 2,
              shadow_min_lives: int = 5, tables: list[dict] | None = None,
              extra_after: int = 6, extra_for: int = 20,
               extra_every: int = 0, extra_strict: int = 2, **_) -> dict:
    """What one win is worth with this configuration, and how many hands it takes."""
    cover = affordable(budget, base, max_steps)
    tables = [t for t in (load_tables() if tables is None else tables) if t.get("road")]
    args = (cover, strategy, base, max_steps, rules, table_hands, at_cutoff, cutoff_margin,
            shadow_unit, shadow_after, shadow_min_lives, extra_after, extra_for,
            extra_every, extra_strict)
    measured = _replay(tables, *args)
    if measured and measured["wins"] >= MIN_WINS:
        return measured
    dealt = _replay(deal_tables(table_hands), *args)
    dealt["source"] = "dealt"
    if measured:
        dealt["recorded"] = {k: measured[k] for k in ("tables", "hands", "wins")}
    return dealt


def deal_tables(table_hands: int | None, n: int = DEALT_TABLES) -> list[dict]:
    """Tables dealt from the game's own odds, the same every time."""
    rng = random.Random(DEALT_SEED)
    hands = int(table_hands or 40) + 4
    return [{"name": f"dealt_{i}", "road": rng.choices(
        ["banker", "player", "tie"], [BANKER_WIN, PLAYER_WIN, TIE_SHARE], k=hands)}
        for i in range(n)]


def _replay(tables, cover, strategy, base, max_steps, rules, table_hands, at_cutoff,
            cutoff_margin, shadow_unit, shadow_after, shadow_min_lives,
            extra_after=6, extra_for=20, extra_every=0, extra_strict=2) -> dict | None:
    if not tables:
        return None
    # a balance nothing can exhaust, so every run plays out to the end and can be
    # looked at; whether YOUR balance would have paid for it is decided afterwards
    s = new_session(strategy, 1e15, base, max_steps, None, rules, table_hands, at_cutoff,
                    cutoff_margin, shadow_unit, shadow_after, shadow_min_lives,
                    extra_after=extra_after, extra_for=extra_for,
                    extra_every=extra_every, extra_strict=extra_strict)
    hands = 0
    for n, t in enumerate(tables):
        s.new_table(t.get("prior_road"))
        s.cutoff_jitter = (0, -1, 1)[n % 3]    # the bot's own pick is random; this isn't
        seen_before = sum((t.get("start_counts") or {}).values())
        n0 = len(s.results)
        simulate_road(s, t["road"], first_hand=seen_before + 1)
        hands += len(s.results) - n0
    # cut the results into runs, the way the session counted them
    runs, i, profit, bets, h = [], 0, 0.0, 0, 0
    for r in s.results:
        h += 1
        profit += r.profit if r.side else 0.0
        if r.outcome in ("WIN", "LOSS"):
            bets += 1
            if i < len(s.runs) and bets == s.runs[i]["lives"]:
                runs.append({"bets": bets, "won": s.runs[i]["won"], "profit": round(profit, 2),
                             "side": r.side, "hands": h})
                i, profit, bets, h = i + 1, 0.0, 0, 0
    if not runs:
        return None
    # with a doubling limit the balance pays for, a long run is a loss taken and
    # already counted in what a win is worth -- it doesn't end the session
    capped = bool(max_steps) and cover >= max_steps
    decided = [r for r in s.results if r.outcome in ("WIN", "LOSS")]
    lost = sum(r.outcome == "LOSS" for r in decided) / max(1, len(decided))
    paid = [r for r in runs if r["bets"] <= cover]
    beyond = [r for r in runs if r["bets"] > cover]
    won = [r for r in paid if r["won"]]
    if not won:
        return {"source": "replay", "tables": len(tables), "hands": hands, "runs": len(runs),
                "wins": 0, "per_win": None, "hands_per_win": None, "cover": cover,
                "beyond": len(beyond), "worst": max(r["bets"] for r in runs), "capped": capped}
    by_side = {side: [r["profit"] for r in won if r["side"] == side] for side in ("player", "banker")}
    return {
        "source": "replay", "tables": len(tables), "hands": hands, "runs": len(runs),
        "wins": len(won),
        "per_win": round(sum(r["profit"] for r in paid) / len(won), 2),
        "hands_per_win": round(sum(r["hands"] for r in paid) / len(won), 2),
        "banker_share": round(len(by_side["banker"]) / len(won), 3),
        "player_win": round(sum(by_side["player"]) / len(by_side["player"]), 2) if by_side["player"] else None,
        "banker_win": round(sum(by_side["banker"]) / len(by_side["banker"]), 2) if by_side["banker"] else None,
        "cover": cover, "beyond": len(beyond), "worst": max(r["bets"] for r in runs),
        # how often a run needs more bets than the balance covers. Counting the few
        # that did is mostly luck; how often ONE bet loses is measured on thousands,
        # and a run is too long when that happens `cover` times in a row
        "loss_rate": round(lost, 4), "beyond_per_run": None if capped else lost ** cover,
        "capped": capped,
    }


def wins_for(remaining: float, value: dict | None, base: float) -> int | None:
    """Wins to cover `remaining`, at the measured value of a win (one base bet each
    when there is no measurement)."""
    if remaining is None:
        return None
    per = (value or {}).get("per_win") or base
    if per <= 0:
        return None                          # on average a win doesn't make money here
    return int(math.ceil(max(0.0, remaining) / per - 1e-9))


def cut_short_chance(wins: int | None, value: dict | None) -> float | None:
    """How likely it is that, on the way to `wins` wins, a run turns up that needs more
    bets in a row than the balance covers -- the session would end there instead."""
    if not wins or not value or value.get("beyond_per_run") is None:
        return None
    return 1 - (1 - value["beyond_per_run"]) ** wins
