"""Telling one look of a region from another by colour alone.

Used for the things that have no text to read: whether the betting window is
open, whether a winner banner is up. A look is taught by example and from then
on the region is compared against every look that has been learnt; too far from
all of them and the answer is "I don't know", which is a better answer than a
guess."""

from __future__ import annotations

import json
import math
import time
from pathlib import Path
import cv2
import numpy as np


from baccarat.errors import BetError
from baccarat.log import log
from baccarat.screen.capture import read_region
from baccarat.screen.sites import colors_dir, snaps_dir


# ---------------------------------------------------------------------------
# Color states  (e.g. the winner banner in the middle of the screen)
#
#   1. --snap winner         select a spot INSIDE the banner (solid color, no text)
#   2. --teach-color winner  watches the region while you play a few rounds,
#                            groups every distinct look it sees, then asks you
#                            to name each one (player / banker / tie / none …)
#   3. read_color("winner")  → the name of the closest learned look
# ---------------------------------------------------------------------------

COLOR_MAX_DIST = 30.0     # further than this from every learned look → None (unknown)


COLOR_NEW_LOOK = 15.0     # teach mode: difference that counts as a new look


_COLOR_CACHE: dict[str, list[tuple[str, np.ndarray]]] = {}


def _color_feature(img: np.ndarray) -> np.ndarray:
    """Median + mean color in Lab space (perceptual: distances ≈ visible difference)."""
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB).reshape(-1, 3).astype(np.float32)
    return np.concatenate([np.median(lab, axis=0), lab.mean(axis=0)])


def _color_dist(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(a - b) / math.sqrt(2))


def _color_file(name: str) -> Path:
    return colors_dir() / f"{name}.json"


def _load_colors(name: str) -> list[tuple[str, np.ndarray]]:
    if name not in _COLOR_CACHE:
        f = _color_file(name)
        data = json.loads(f.read_text())["samples"] if f.exists() else []
        _COLOR_CACHE[name] = [(d["label"], np.array(d["f"], np.float32)) for d in data]
    return _COLOR_CACHE[name]


def read_color(name: str, img: np.ndarray | None = None) -> tuple[str | None, float]:
    """Which learned look region `name` shows now → (label, distance).
    label is None when it matches nothing learned closely enough."""
    refs = _load_colors(name)
    if not refs:
        raise BetError(f"No colors learned for '{name}'. Run: python bet.py --teach-color {name}")
    f = _color_feature(read_region(name) if img is None else img)
    label, d = min(((l, _color_dist(f, r)) for l, r in refs), key=lambda x: x[1])
    return (label if d <= COLOR_MAX_DIST else None), d


def read_color_stable(name: str, samples: int = 2, interval: float = 0.08,
                      timeout: float = 1.0) -> str | None:
    """Like read_color, but the same label must be seen `samples` times in a row
    (ignores fade-in/out frames). None if unknown or not stable in time."""
    end = time.monotonic() + timeout
    last, streak = object(), 0
    while time.monotonic() < end:
        label, _ = read_color(name)
        streak = streak + 1 if label == last else 1
        last = label
        if streak >= samples:
            return label
        time.sleep(interval)
    return None


# ---------------------------------------------------------------------------
# A region used as a go signal
#
# Some tables don't open the betting at a fixed moment after the last result — the
# chips simply appear when it is time, and vanish when it isn't. That is something
# the screen can be asked directly, which beats any amount of guessing from a clock:
# point a small region at the chips, show it once with them and once without, and
# "are bets open?" becomes a reading rather than an estimate.
# ---------------------------------------------------------------------------

TRIGGER_REGIONS = ("bets_open",)


OPEN_LABEL, SHUT_LABEL = "open", "shut"


def color_stats(name: str) -> dict:
    """How many examples of each look are stored for a region."""
    out: dict = {}
    for label, _ in _load_colors(name):
        out[label] = out.get(label, 0) + 1
    return dict(sorted(out.items()))


def teach_color_sample(name: str, label: str, img: np.ndarray | None = None) -> dict:
    """Store what the region looks like right now under `label` — one press, one
    example. Near-identical examples are skipped: what helps is variety."""
    label = str(label or "").strip().lower()
    if not label:
        raise BetError("say which look this is")
    if img is None:
        img = read_region(name)
    f = _color_feature(img)
    known = _load_colors(name)
    for lab, ref in known:
        if _color_dist(f, ref) < 3.0:
            if lab == label:
                return {"kept": 0, "colors": color_stats(name),
                        "note": f"already have this exact look as '{lab}'"}
            raise BetError(f"that looks the same as an example of '{lab}' — the two states "
                           f"have to look different for this to work. Point the region at "
                           f"the chips themselves, not at the space around them")
    colors_dir().mkdir(parents=True, exist_ok=True)
    samples = [{"label": l, "f": r.tolist()} for l, r in known] + [{"label": label,
                                                                    "f": f.tolist()}]
    _color_file(name).write_text(json.dumps({"samples": samples}, indent=1) + "\n")
    _COLOR_CACHE.pop(name, None)
    log.info("Learned '%s' for '%s'. Stored: %s", label, name, color_stats(name))
    return {"kept": 1, "colors": color_stats(name), "note": ""}


def forget_colors(name: str) -> int:
    n = len(_load_colors(name))
    _color_file(name).unlink(missing_ok=True)
    _COLOR_CACHE.pop(name, None)
    log.info("Forgot %d colour example(s) for '%s'.", n, name)
    return n


TRIGGER_MARGIN = 4.0      # below this the two looks are too close to call


def bets_open(name: str = "bets_open", img: np.ndarray | None = None) -> bool | None:
    """Are bets open right now? True / False / None when it can't tell.

    With exactly two states to choose between, the nearest one wins — no absolute
    cutoff. A table that dims a shade, or chips in slightly different colours, is still
    far nearer the 'chips up' examples than the 'chips gone' ones, where a fixed
    distance limit would have thrown the reading away and stalled the hand."""
    best: dict = {}
    for label, ref in _load_colors(name):
        try:
            d = _color_dist(_color_feature(read_region(name) if img is None else img), ref)
        except BetError:
            return None
        if label not in best or d < best[label]:
            best[label] = d
    if OPEN_LABEL not in best or SHUT_LABEL not in best:
        return None                                  # one of the two looks isn't taught
    gap = best[SHUT_LABEL] - best[OPEN_LABEL]
    if abs(gap) < TRIGGER_MARGIN:
        return None                                  # sitting between the two: wait
    return gap > 0


def trigger_ready(name: str = "bets_open") -> bool:
    """Is this region set up well enough to be used as the go signal?"""
    if not (snaps_dir() / f"{name}.geo").exists():
        return False
    s = color_stats(name)
    return s.get(OPEN_LABEL, 0) > 0 and s.get(SHUT_LABEL, 0) > 0
