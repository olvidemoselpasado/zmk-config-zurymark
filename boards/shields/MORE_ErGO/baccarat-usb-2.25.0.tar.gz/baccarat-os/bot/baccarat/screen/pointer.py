"""Moving and clicking like a hand, not like a program.

A straight jump to a pixel and an instant click is the easiest thing in the
world to spot. So: a curved path (a Bezier with a little sideways bend), a
min-jerk speed profile that starts slow, runs fast and eases in, a pixel or
two of wobble, the odd overshoot and correction, and a gap between presses on
the same spot so two clicks are never taken for a double-click.

The cost of all this is cursor warps, which the compositor has to draw. MOVE_HZ
is what that costs; it is in Setup because it is the one knob that trades
naturalness against CPU."""

from __future__ import annotations

import math
import random
import time


from baccarat.errors import BetError
from baccarat.log import log
from baccarat.screen import desktop
from baccarat.screen.desktop import get_cursor_pos


# --- Mouse movement tuning -------------------------------------------------
# Time for a ~1000 px move (seconds). Shorter moves scale down automatically.
# Lower = faster. Human-like range is roughly 0.15–0.35.
# How long the pointer takes to travel, for a 1000 px move; shorter moves are
# scaled down by sqrt(distance). A person crossing a screen to a button takes the
# better part of a second — the old values were under a fifth of that, which is the
# single most obvious thing about a machine driving a mouse. Nothing else in the
# path matters if the whole trip is over in 120 ms.
MOVE_TIME_MIN = 0.17           # seconds for a 1000 px move, fastest


MOVE_TIME_MAX = 0.32           # … slowest; shorter moves scale by sqrt(distance)


MOVE_CAP = 0.55                # no single move takes longer than this


MOVE_TYPICAL = 0.26            # what the betting window should set aside per move


def set_move_speed(seconds: float) -> None:
    """How long a 1000 px move takes, give or take. The original 0.12 s is quicker
    than a hand but barely noticeable; much above 0.4 s and placing a bet starts to
    feel slow, because every move is also work for the compositor."""
    global MOVE_TIME_MIN, MOVE_TIME_MAX, MOVE_CAP, MOVE_TYPICAL
    s = max(0.06, min(0.8, float(seconds)))
    MOVE_TIME_MIN, MOVE_TIME_MAX = s * 0.75, s * 1.35
    MOVE_CAP, MOVE_TYPICAL = s * 2.3, s * 1.1


SETTLE_CHANCE = 0.55           # chance of easing off the button after clicking it


# Two presses in the same place, close together, are a double-click — and a page that
# takes one and drops the other is how a doubled bet silently goes on at half size.
# A double-click is 400–500 ms nearly everywhere, so consecutive presses on the same
# spot are held apart by more than that.
SAME_SPOT_PX = 14              # within this many pixels counts as the same button


SAME_SPOT_GAP = (0.60, 0.85)   # s to leave between two presses on it


# Cursor updates per second along a path. Every one of these is a separate
# "dispatch movecursor" to Hyprland, which warps the pointer, re-evaluates
# focus-follows-mouse and lets the page fire hover events — while the game is
# rendering. 240 was survivable when a move took 120 ms (29 steps); with longer,
# more human moves it became 264 warps for a single move and the compositor felt
# it. No display shows more than ~165 Hz, and a cursor is smooth well below that.
# 70 still put the biggest browser spikes of a live session "during the clicks": every
# warp makes the page under the pointer re-check what it is hovering over, while it is
# decoding the stream. The move keeps its timing on a fixed clock, so 40 is the same
# curve in the same time, in coarser steps -- still smooth to the eye.
MOVE_HZ = 40


MOVE_STEPS_MAX = 80            # however long the move, never more warps than this


MOVE_CURVE = 0.18              # max sideways bend, as a fraction of distance


MOVE_WOBBLE = 1.5              # px of gentle hand wobble mid-path (0 = none)


OVERSHOOT_CHANCE = 0.25


CLICK_PAUSE = 0.10


# How long ONE click may take, end to end: glide + rest + press/hold/release + pause.
# A fresh figure is drawn from this range for every click and the parts are squeezed to
# fit it. main.py sets it from Setup ("Click speed"). A long glide across the screen can
# still overrun the top of the range: the floors below come first, so a click stays
# reliable rather than exactly on time.
CLICK_SPEED = (0.10, 0.30)


# ---------------------------------------------------------------------------
# Mouse movement  (fast Bézier, in screen units: what the pointer position reports)
# ---------------------------------------------------------------------------

def _bezier(t, p0, p1, p2, p3):
    u = 1 - t
    return (
        u**3*p0[0] + 3*u**2*t*p1[0] + 3*u*t**2*p2[0] + t**3*p3[0],
        u**3*p0[1] + 3*u**2*t*p1[1] + 3*u*t**2*p2[1] + t**3*p3[1],
    )


def _min_jerk(t):
    """Minimum-jerk velocity profile — how real hand movements accelerate
    and decelerate. Smooth start, fast middle, smooth stop."""
    return t * t * t * (10 - 15 * t + 6 * t * t)


def _move_cursor(x, y):
    """One step of the pointer, exactly to (x, y) in screen units. Everything that
    makes it look like a hand is above this; this is only the step."""
    desktop.move_cursor(x, y)


def _glide(p0, p3, duration, curve, wobble):
    """Move along a curved path from p0 to p3 in `duration` seconds,
    updating at MOVE_HZ on a fixed clock (so timing is accurate)."""
    dx, dy = p3[0] - p0[0], p3[1] - p0[1]
    dist = math.hypot(dx, dy) or 1.0
    nx, ny = -dy / dist, dx / dist                      # unit perpendicular

    # Control points: along the path, pushed sideways by `curve` px.
    # Same side for both = one gentle arc; slight difference = natural S-ish bend.
    b1 = curve * random.uniform(0.6, 1.0)
    b2 = curve * random.uniform(0.2, 0.8)
    a1, a2 = random.uniform(0.2, 0.4), random.uniform(0.6, 0.8)
    cp1 = (p0[0] + dx * a1 + nx * b1, p0[1] + dy * a1 + ny * b1)
    cp2 = (p0[0] + dx * a2 + nx * b2, p0[1] + dy * a2 + ny * b2)

    # Wobble: slow sideways drift, zero at both ends (no per-step shaking)
    freq = random.uniform(0.8, 2.0)
    phase = random.uniform(0, 2 * math.pi)

    steps = max(6, min(MOVE_STEPS_MAX, int(duration * MOVE_HZ)))
    t0 = time.perf_counter()
    last = None
    for i in range(1, steps + 1):
        t = i / steps
        x, y = _bezier(_min_jerk(t), p0, cp1, cp2, p3)
        w = wobble * math.sin(math.pi * t) * math.sin(2 * math.pi * freq * t + phase)
        xi, yi = round(x + nx * w), round(y + ny * w)
        if (xi, yi) != last:
            _move_cursor(xi, yi)
            last = (xi, yi)
        delay = t0 + duration * t - time.perf_counter()
        if delay > 0:
            time.sleep(delay)


def set_click_speed(low: float, high: float) -> None:
    """Seconds one click may take, as (fastest, slowest)."""
    global CLICK_SPEED
    low, high = float(low), float(high)
    if low <= 0 or high < low:
        raise BetError(f"click speed needs 0 < fastest ≤ slowest (got {low}, {high})")
    CLICK_SPEED = (low, high)


def move_mouse(x_end, y_end, budget: float | None = None):
    """Move cursor from wherever it is to (x_end, y_end) in hyprctl space,
    with a fresh random, human-like path every call.
    budget = the longest the move may take (the glide is scaled to fit)."""
    pos = get_cursor_pos()
    if pos is None:  # couldn't read the cursor — go direct
        _move_cursor(x_end, y_end)
        return
    x0, y0 = pos
    dist = math.hypot(x_end - x0, y_end - y0)
    if dist < 3:
        _move_cursor(x_end, y_end)
        return

    # Fitts-like timing: longer moves take longer, but sub-linearly
    duration = random.uniform(MOVE_TIME_MIN, MOVE_TIME_MAX) * math.sqrt(dist / 1000)
    duration = max(0.07, min(duration, MOVE_CAP))
    if budget is not None:                       # a click in a hurry: shorten the glide
        duration = max(0.03, min(duration, budget))
    curve = random.choice((-1, 1)) * random.uniform(0.03, MOVE_CURVE) * dist
    wobble = MOVE_WOBBLE * random.uniform(0.3, 1.0) * min(1.0, dist / 300)

    if dist > 80 and random.random() < OVERSHOOT_CHANCE:
        k = random.uniform(0.015, 0.05)
        over = (x_end + (x_end - x0) * k, y_end + (y_end - y0) * k)
        _glide((x0, y0), over, duration, curve, wobble)
        time.sleep(random.uniform(0.015, 0.045))
        _glide(over, (x_end, y_end), random.uniform(0.04, 0.08), 0, 0)
    else:
        _glide((x0, y0), (x_end, y_end), duration, curve, wobble)

    _move_cursor(x_end, y_end)   # land exactly


_LAST_PRESS: tuple[float, float, float] | None = None   # (x, y, when) of the last press


def same_spot_wait() -> float:
    """The longest pause that may be needed between two presses on one button."""
    return SAME_SPOT_GAP[1]


def _hold_off_same_spot(x: float, y: float) -> None:
    """Wait, if this press is landing where the last one did and too soon after it."""
    global _LAST_PRESS
    if _LAST_PRESS is not None:
        lx, ly, when = _LAST_PRESS
        if math.hypot(x - lx, y - ly) <= SAME_SPOT_PX:
            gap = random.uniform(*SAME_SPOT_GAP) - (time.perf_counter() - when)
            if gap > 0:
                time.sleep(gap)


_RUN_END: float | None = None    # when the current burst of clicks has to be finished


_RUN_LEFT = 0                    # clicks still to go in it


def start_click_run(seconds: float, clicks: int) -> None:
    """A burst of clicks that has to be over within `seconds` — the betting window.
    The pointer moves at its own pace while there is room, and hurries only when
    there isn't, which is what a person does too."""
    global _RUN_END, _RUN_LEFT
    _RUN_END, _RUN_LEFT = time.monotonic() + max(0.0, seconds), max(1, int(clicks))


def end_click_run() -> None:
    global _RUN_END, _RUN_LEFT
    _RUN_END, _RUN_LEFT = None, 0


def _move_budget() -> float | None:
    """How long this click may take. None = no hurry, travel at a human pace."""
    global _RUN_LEFT
    if _RUN_END is None:
        return None
    share = (_RUN_END - time.monotonic()) / max(1, _RUN_LEFT)
    _RUN_LEFT = max(1, _RUN_LEFT - 1)
    if share >= MOVE_TYPICAL + CLICK_SPEED[1]:
        return None                              # plenty of room: move naturally
    return max(0.05, share - CLICK_SPEED[0])     # tight: leave the press its time


def _settle_off(x, y) -> None:
    """Ease the pointer a few pixels off the button after clicking it. A hand does
    not freeze on the spot it just pressed. Kept small so focus stays where it is.

    Skipped when the betting window is nearly over — someone in a hurry doesn't
    drift either, and the bet landing matters more than the flourish."""
    if _RUN_END is not None and (_RUN_END - time.monotonic()) < 0.7:
        return
    if random.random() > SETTLE_CHANCE:
        return
    ang = random.uniform(0, 2 * math.pi)
    d = random.uniform(3, 11)
    try:
        _glide((x, y), (x + math.cos(ang) * d, y + math.sin(ang) * d),
               random.uniform(0.05, 0.13), 0, 0)
    except Exception:
        pass                                     # a flourish is never worth an error


def click(x, y, button="left"):
    """One click. The travel is timed like a hand moving across the screen; only the
    press is held to CLICK_SPEED. In a burst with a deadline (see start_click_run)
    the travel is compressed to fit — but a click the table misses is worse than a
    slow one, so the press and its hold are never squeezed below their floors."""
    t0 = time.perf_counter()
    budget = random.uniform(*CLICK_SPEED)
    desktop.ensure_input()
    move_mouse(x, y, budget=_move_budget())
    landed = get_cursor_pos()
    if landed is not None and math.hypot(landed[0] - x, landed[1] - y) > 3:
        log.warning("Cursor should be at (%d,%d) but the system reports %s", x, y, landed)
    hurried = _RUN_END is not None and (_RUN_END - time.monotonic()) < 0.7
    time.sleep(random.uniform(0.02, 0.04) if hurried
               else random.uniform(0.03, 0.09))  # rest over the button before pressing
    # Press, hold, release — like a real click. An instant press+release can be
    # missed by game interfaces that check the mouse once per frame.
    _hold_off_same_spot(x, y)                   # never two presses inside a double-click
    global _LAST_PRESS
    _LAST_PRESS = (x, y, time.perf_counter())
    pressed = desktop.mouse_button(True, button)
    time.sleep(random.uniform(0.03, 0.06))      # the hold, never shorter than this
    released = desktop.mouse_button(False, button)
    if not (pressed and released):
        log.error("click failed (press %s, release %s)", "ok" if pressed else "FAILED",
                  "ok" if released else "FAILED")
    _settle_off(x, y)
    # a small floor so two clicks are never sent back to back
    press = time.perf_counter() - t0
    time.sleep(max(0.03, budget - press) if press < budget else random.uniform(0.03, 0.08))


SCROLL_KEY = {"down": "Down", "up": "Up"}


SCROLL_PAUSE = (0.04, 0.09)      # s between key presses


def press_key(key: str, over: tuple | None = None, label: str = "") -> None:
    """Send one key to the game — reloading the page, say (desktop.RELOAD_KEY: F5 on
    Linux, ⌘R on a Mac).

    `over` is a point to put the MOUSE on first: moved there, never clicked. Keys go to
    whichever window holds the keyboard, which is usually this dashboard's browser, so
    without it the wrong window would be reloaded. On Hyprland focus follows the mouse,
    so parking the cursor over the game hands it the keyboard; on a Mac the window
    under that point is brought to the front instead."""
    if over:
        move_mouse(*over)
        time.sleep(random.uniform(0.08, 0.16))      # let the focus follow the cursor
        desktop.focus_point(*over)
    desktop.ensure_input()
    desktop.press_key(key, label or f"key {key}")
    log.debug("pressed %s over %s", key, over)


def scroll_list(steps: int, over: tuple | None = None) -> None:
    """Scroll a list with the arrow keys: `steps` presses of Down, or of Up when
    negative. 0 does nothing.

    `over` is a point to put the MOUSE on first — moved there, never clicked. Key
    presses go to whichever window has the keyboard, which is usually the dashboard's
    browser window, so without this the dashboard scrolls instead of the lobby. With
    focus-follows-mouse (Hyprland's default, input:follow_mouse = 1) parking the cursor
    over the lobby hands it the keyboard. If your Hyprland has follow_mouse = 0, the
    arrows will still go to whatever you last clicked."""
    steps = int(steps)
    if not steps:
        return
    if over:
        move_mouse(*over)
        time.sleep(random.uniform(0.05, 0.12))      # let the focus follow the cursor
        desktop.focus_point(*over)
    desktop.ensure_input()
    key = SCROLL_KEY["down" if steps > 0 else "up"]
    for _ in range(abs(steps)):
        desktop.press_key(key, "scroll")
        time.sleep(random.uniform(*SCROLL_PAUSE))
    log.debug("scrolled %d × %s over %s", abs(steps), key, over)


def type_private(text: str, label: str = "typing") -> bool:
    """Type text that must never be written down anywhere -- the password, the email.
    It is never logged and never on a command line. A short random gap between keys:
    a field filled in one instant is as obvious as a pointer that jumps."""
    desktop.ensure_input()
    return desktop.type_private(text, label, random.randint(45, 95))


def type_text(text, enter=False):
    desktop.ensure_input()
    desktop.type_text(text)
    if enter:
        time.sleep(random.uniform(0.03, 0.08))
        desktop.press_key("Return", "enter")
