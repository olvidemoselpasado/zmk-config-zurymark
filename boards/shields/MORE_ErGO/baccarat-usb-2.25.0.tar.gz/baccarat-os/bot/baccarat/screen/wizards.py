"""The interactive set-up: recording a point, teaching a font, a colour, the bar.

These talk to a person at a terminal -- print a prompt, wait, take a shot,
show what was read, ask if it is right. They are kept apart from everything
else because they are the only code here that blocks on a human, and because
nothing in the playing path may ever call them."""

from __future__ import annotations

import json
import re
import time
import cv2


from baccarat.screen.board import (
    _board_crops, _save_board_debug, read_board_detailed, READ_FIELDS)
from baccarat.screen.capture import read_region, region_geometry
from baccarat.screen.colors import (
    _COLOR_CACHE, _color_dist, _color_feature, _color_file, _load_colors, COLOR_NEW_LOOK,
    read_color)
from baccarat.screen.desktop import get_cursor_pos
from baccarat.screen.glyphs import (
    _binarize, _keep_sample, _load_templates, _normalize_glyph, _save_debug, _segment,
    _SEP_LABEL, _TEMPLATE_CACHE, digit_stats, font_of, read_number_detailed)
from baccarat.screen.sites import (
    _load_meta, _pattern_dir, _save_meta, _slug, colors_dir, debug_dir, digits_dir,
    list_patterns, load_coords, patterns_dir, save_coords)


def teach_wizard(name: str) -> None:
    """Capture the region, split into digits, ask what it says, save templates."""
    region_geometry(name)                       # fail early if no region
    font = font_of(name)
    d = digits_dir() / font
    d.mkdir(parents=True, exist_ok=True)
    shared = f"  (digit set '{font}')" if font != name else ""
    print(f"\n═══ TEACH DIGITS for '{name}'{shared} ═══")
    print("  Each round: I screenshot the region, you type the number you see.")
    print("  Repeat over a few games until every digit 0-9 has been seen.")
    while True:
        known = sorted({_SEP_LABEL.get(k, k) for k in (f.name.split('_')[0] for f in d.glob('*.png'))})
        missing = [c for c in "0123456789" if c not in known]
        print(f"\n  Known: {' '.join(known) or '-'}   missing digits: {''.join(missing) or 'none ✓'}")
        cmd = input("  Enter = capture now,  q = quit: ").strip().lower()
        if cmd == "q":
            break
        img = read_region(name)
        b = _binarize(img, name)
        boxes = _segment(b)
        guess = ""
        if _load_templates(name):
            r = read_number_detailed(name, img)
            guess = f"   (current reading: {r['text'] or '-'}  conf {r['conf']:.2f})"
        dbg = _save_debug(name, img, b, boxes, "")
        print(f"  Found {len(boxes)} digit(s){guess}\n  Preview: {dbg}")
        if not boxes:
            print("  ✗ No digits found — check the preview; re-select the region with --snap.")
            continue
        kinds = "".join("d" if bx[4] == "digit" else "s" for bx in boxes)
        typed = input("  Type it exactly as shown, with $ and dots/commas (empty = skip): ").strip()
        chars = re.sub(r"[^0-9.,$#]", "", typed)
        if not chars:
            continue
        typed_kinds = "".join("s" if c in ".," else "d" for c in chars)   # $ and # are big glyphs
        if typed_kinds != kinds:
            seen = "".join("9" if k == "d" else "." for k in kinds)
            print(f"  ✗ I detected the shape  {seen}  (9 = digit or $, . = dot/comma)"
                  f"\n    but you typed        {chars}  — skipped. Check the preview image.")
            continue
        kept = sum(_keep_sample(d, ch, _normalize_glyph(b, bx)) for ch, bx in zip(chars, boxes))
        _TEMPLATE_CACHE.pop(font, None)
        print(f"  ✓ Learned {chars}"
              + (f" — {kept} new example(s)" if kept else " — nothing new in that frame"))


def teach_board_wizard(name: str = "board") -> None:
    region_geometry(name)
    font = font_of(name)
    d = digits_dir() / font
    d.mkdir(parents=True, exist_ok=True)
    print(f"\n═══ TEACH BOARD '{name}' ═══")
    print("  Each round: I screenshot the bar, you type its first three numbers:")
    print("  game  player  banker   e.g.  30 13 13")
    print("  The ties work themselves out (game - player - banker), and the pair counts")
    print("  are not used, so there is nothing to type for them.")
    while True:
        known = sorted({_SEP_LABEL.get(k, k) for k in (f.name.split('_')[0] for f in d.glob('*.png'))})
        missing = [c for c in "0123456789" if c not in known]
        print(f"\n  Known: {' '.join(known) or '-'}   missing digits: {''.join(missing) or 'none ✓'}")
        if input("  Enter = capture now,  q = quit: ").strip().lower() == "q":
            break
        img = read_region(name)
        crops, icons = _board_crops(img)
        texts = []
        if crops is not None and any(t[0].isdigit() for t in _load_templates(name)):
            texts = [read_board_detailed(name, img)["texts"].get(f, "") or "?" for f in READ_FIELDS]
        prev = _save_board_debug(name, img, icons, texts)
        if crops is None:
            print(f"  ✗ Couldn't find the blue, red and green icons. Preview: {prev}")
            print("    Re-select the bar with --snap (whole bar, just inside its outline).")
            continue
        now = f"   current reading: {' '.join(texts)}" if texts else ""
        print(f"  ✓ Icons found.{now}\n  Preview: {prev}")
        nums = input("  game player banker: ").split()
        if len(nums) != 3 or not all(n.isdigit() for n in nums):
            print("  ✗ Need exactly 3 whole numbers — skipped.")
            continue
        learned = kept = 0
        for field, crop, typed in zip(READ_FIELDS, crops, nums):
            b = _binarize(crop)
            boxes = [bx for bx in _segment(b) if bx[4] == "digit"]
            chars = typed
            if field == "game" and len(boxes) == len(typed) + 1:
                chars = "#" + typed                  # the '#' before the game number
            if len(boxes) != len(chars):
                print(f"  ✗ {field}: you typed {typed} but I see {len(boxes)} glyph(s) — skipped")
                continue
            kept += sum(_keep_sample(d, ch, _normalize_glyph(b, bx))
                        for ch, bx in zip(chars, boxes))
            learned += 1
        _TEMPLATE_CACHE.pop(font, None)
        print(f"  ✓ Learned from {learned}/3 numbers — {kept} new example(s). "
              f"Stored so far: {digit_stats(name)}")


def teach_color_wizard(name: str) -> None:
    """Watch the region, collect every distinct look, then ask for names."""
    region_geometry(name)
    colors_dir().mkdir(parents=True, exist_ok=True)
    debug_dir().mkdir(parents=True, exist_ok=True)
    known = _load_colors(name)
    print(f"\n═══ TEACH COLORS for '{name}' ═══")
    if known:
        from collections import Counter
        print("  Already learned: " + ", ".join(f"{l} ×{n}" for l, n in Counter(l for l, _ in known).items()))
    print("  I'll watch the region. Let it show every state at least once:")
    print("  player wins, banker wins, tie, and the normal screen (no banner).")
    print("  Press Ctrl+C when you've seen them all.\n")

    looks: list[dict] = []                      # {f, img, count}
    try:
        while True:
            img = read_region(name)
            f = _color_feature(img)
            near = min(looks, key=lambda c: _color_dist(f, c["f"]), default=None)
            if near is None or _color_dist(f, near["f"]) > COLOR_NEW_LOOK:
                looks.append({"f": f, "img": img, "count": 1})
                print(f"  • new look #{len(looks)} seen  ({time.strftime('%H:%M:%S')})")
            else:
                near["count"] += 1
            time.sleep(0.15)
    except KeyboardInterrupt:
        print()

    if not looks:
        return
    print(f"\n  {len(looks)} different looks. Name each one — e.g. player, banker, tie, none.")
    print("  Enter = skip (use it for half-faded / transition frames).\n")
    samples = [{"label": l, "f": r.tolist()} for l, r in known]
    for i, c in enumerate(looks, 1):
        prev = debug_dir() / f"{name}_look{i}.png"
        big = cv2.resize(c["img"], None, fx=max(1, 120 // max(1, c["img"].shape[0])),
                         fy=max(1, 120 // max(1, c["img"].shape[0])),
                         interpolation=cv2.INTER_NEAREST)
        cv2.imwrite(str(prev), big)
        guess = ""
        if known:
            lab, d = read_color(name, c["img"])
            guess = f"   (looks like: {lab or '?'}, dist {d:.0f})"
        label = input(f"  #{i}  seen {c['count']}×  preview: {prev}{guess}\n      name: ").strip().lower()
        if label:
            samples.append({"label": label, "f": c["f"].tolist()})
    _color_file(name).write_text(json.dumps({"samples": samples}, indent=1) + "\n")
    _COLOR_CACHE.pop(name, None)
    print(f"\n  ✓ Saved {len(samples)} samples → {_color_file(name)}")


# ---------------------------------------------------------------------------
# Coordinates mode  (--coords)
# ---------------------------------------------------------------------------

def coords_wizard() -> None:
    """Record cursor positions interactively."""
    coords = load_coords()

    print()
    print("═" * 52)
    print("  COORDINATES MODE")
    print("═" * 52)

    while True:
        print()
        if coords:
            print("  Saved coordinates:")
            for name, data in sorted(coords.items()):
                act = data.get("action", "click")
                print(f"    • {name:20s}  ({data['x']}, {data['y']})  [{act}]")
            print()

        print("  Commands:")
        print("    <name>     Save a new coordinate")
        print("    d <name>   Delete a coordinate")
        print("    q          Quit")
        print()
        cmd = input("  > ").strip()

        if cmd.lower() == "q":
            break

        if cmd.lower().startswith("d "):
            dname = cmd[2:].strip()
            if dname in coords:
                del coords[dname]
                save_coords(coords)
                print(f"  ✓ Deleted '{dname}'.")
            else:
                print(f"  '{dname}' not found.")
            continue

        if not cmd:
            continue

        name = cmd
        act = input("  Action [click]: ").strip() or "click"
        extra = {}
        if act == "type":
            extra["text"] = input("  Text to type: ")
            e = input("  Press Enter after? [Y/n]: ").strip().lower()
            extra["enter"] = e != "n"

        print(f"\n  Move your cursor to '{name}' now!")
        for i in range(3, 0, -1):
            print(f"    {i} …")
            time.sleep(1)

        pos = get_cursor_pos()
        if pos is None:
            print("  ✗ Could not read cursor position (see error above).")
            continue
        x, y = pos
        coords[name] = {"x": x, "y": y, "action": act, **extra}
        save_coords(coords)
        print(f"  ✓ Saved '{name}' at ({x}, {y}) → {act}")

    print()


# ---------------------------------------------------------------------------
# Pattern capture  (--capture)
# ---------------------------------------------------------------------------

def _step_display(step: dict) -> str:
    action = step.get("action", "click")
    coord = step.get("coord", "")
    desc = step.get("desc", "")
    d = f'  "{desc}"' if desc else ""
    if action == "click":
        return f"[click]  @{coord}{d}"
    elif action == "type":
        text = step.get("text", "")
        enter = step.get("enter", False)
        preview = text if len(text) <= 35 else text[:32] + "…"
        e = " + Enter" if enter else ""
        c = f"  @{coord}" if coord else ""
        return f'[type]   "{preview}"{e}{c}{d}'
    return f"[{action}] {step}"


def capture_wizard() -> None:
    patterns_dir().mkdir(parents=True, exist_ok=True)
    coords = load_coords()

    if not coords:
        print("\n  No coordinates saved yet.  Run --coords first.\n")
        return

    while True:
        patterns = list_patterns()
        print()
        print("═" * 52)
        print("  PATTERN BUILDER")
        print("═" * 52)
        print()
        if patterns:
            for i, (name, _, count) in enumerate(patterns, 1):
                print(f"    {i}. {name}  ({count} steps)")
            print()
        print("    n  New pattern")
        print("    q  Quit")
        choice = input("\n  Select: ").strip().lower()
        if choice == "q":
            return
        if choice == "n":
            raw = input("  Pattern name: ").strip()
            if not raw:
                continue
            pd = _pattern_dir(raw)
            pd.mkdir(parents=True, exist_ok=True)
            meta = {"steps": []}
            _save_meta(pd, meta)
            display = _slug(raw).replace("_", " ")
        else:
            try:
                display, pd, _ = patterns[int(choice) - 1]
            except (ValueError, IndexError):
                continue
            meta = _load_meta(pd)

        # Edit loop
        while True:
            steps = meta["steps"]
            print(f"\n─── {display} ({'no steps' if not steps else f'{len(steps)} steps'}) ───")
            for i, s in enumerate(steps, 1):
                print(f"    {i}. {_step_display(s)}")

            print("\n  Available coordinates:")
            for name in sorted(coords):
                c = coords[name]
                print(f"    @{name:20s} ({c['x']}, {c['y']})")

            n = len(steps)
            print(f"\n  Enter      Append step {n+1}")
            print("  d<number>  Delete step")
            print("  b          Back")
            cmd = input("\n  > ").strip().lower()

            if cmd == "b":
                break

            if cmd.startswith("d"):
                try:
                    idx = int(cmd[1:]) - 1
                    if 0 <= idx < n:
                        steps.pop(idx)
                        _save_meta(pd, meta)
                        print(f"  ✓ Deleted step {idx+1}.")
                except ValueError:
                    pass
                continue

            # Add step
            pos = n + 1
            if cmd.isdigit():
                pos = max(1, min(int(cmd), n + 1))

            print("\n  Action type:")
            print("    1. click a coordinate  (default)")
            print("    2. type text")
            a = input("  Select [1]: ").strip()

            if a in ("", "1"):
                cname = input("  Coordinate name: @").strip()
                if cname not in coords:
                    print(f"  '{cname}' not found. Save it with --coords first.")
                    continue
                desc = input("  Description (optional): ").strip()
                steps.insert(pos-1, {"action": "click", "coord": cname, "desc": desc})
            elif a == "2":
                cname = input("  Click a coordinate first? (name or empty to skip): @").strip()
                if cname and cname not in coords:
                    print(f"  '{cname}' not found.")
                    continue
                text = input("  Text to type: ")
                if not text:
                    continue
                enter = input("  Press Enter after? [Y/n]: ").strip().lower() != "n"
                desc = input("  Description (optional): ").strip()
                step = {"action": "type", "text": text, "enter": enter, "desc": desc}
                if cname:
                    step["coord"] = cname
                steps.insert(pos-1, step)
            else:
                continue

            _save_meta(pd, meta)
            print(f"  ✓ Added step {pos}.")
