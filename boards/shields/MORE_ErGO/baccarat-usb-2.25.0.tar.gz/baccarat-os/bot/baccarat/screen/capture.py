"""Screenshots, and the rectangles of the screen we read.

A region is recorded once (snap_region) and from then on read by name. The
count of screenshots taken lives here too, because that is what the work
actually costs: every retry of an unreadable region is another screenshot, so
the backoff that governs retries belongs next to the thing it is rationing."""

from __future__ import annotations

import os
import time
from collections import deque
from pathlib import Path
import cv2
import numpy as np



from baccarat.errors import BetError
from baccarat.log import log
from baccarat.screen import desktop
from baccarat.screen.sites import debug_dir, snaps_dir


# OpenCV keeps its own pool of threads, one per core, and wakes all of them for every
# small job. On a 219×26 strip that is pure overhead. BACCARAT_CV_THREADS overrides it.
CV_THREADS = int(os.environ.get("BACCARAT_CV_THREADS", "1") or 1)
cv2.setNumThreads(CV_THREADS)


MATCH_THRESHOLD = 0.80


# ---------------------------------------------------------------------------
# Computer vision  (screen analysis — NOT for finding buttons)
# ---------------------------------------------------------------------------

def save_screenshot(label: str = "screen") -> Path:
    """Save what's on the screen right now to debug/ (for diagnosing a stuck table)."""
    debug_dir().mkdir(parents=True, exist_ok=True)
    out = debug_dir() / f"{label}_{time.strftime('%H%M%S')}.png"
    if not cv2.imwrite(str(out), desktop.capture_screen()):
        raise BetError(f"couldn't save the screenshot to {out}")
    return out


def snap_region(name: str) -> None:
    """Interactively select a screen region (drag a box) and save it as a
    reference snapshot for CV analysis (color detection, state reading)."""
    snaps_dir().mkdir(parents=True, exist_ok=True)
    out = snaps_dir() / f"{name}.png"
    if name == "board":
        print("  Select the scoreboard bar for 'board' with slurp.")
        print("  Drag a GENEROUS box around it — the bar is found inside the box, so a loose")
        print("  selection survives the page shifting a little; a tight one does not.")
    else:
        print(f"  Select the region for '{name}' with slurp …")
    try:
        geo = desktop.select_region()
    except BetError as e:
        print(f"  Cancelled ({e}).")
        return
    # Save geometry alongside the image so we can re-capture the same region later
    geo_file = snaps_dir() / f"{name}.geo"
    geo_file.write_text(geo)
    cv2.imwrite(str(out), desktop.capture_region(geo))
    img = cv2.imread(str(out))
    if img is not None:
        h, w = img.shape[:2]
        log.info("✓ Saved snap '%s' → %s (%d×%d)  geo=%s", name, out, w, h, geo)


def region_geometry(name: str) -> str:
    geo_file = snaps_dir() / f"{name}.geo"
    if not geo_file.exists():
        raise BetError(f"No region named '{name}'. Select it on the Interface tab "
                       f"(Select a box), or run: python bet.py --snap {name}")
    return geo_file.read_text().strip()


def read_region(name: str) -> np.ndarray:
    """Capture the saved region right now and return it as a BGR array."""
    global SHOTS
    SHOTS += 1
    SHOTS_BY[name] = SHOTS_BY.get(name, 0) + 1
    SHOT_TIMES.append(time.monotonic())
    return desktop.capture_region(region_geometry(name))


def dominant_color(img: np.ndarray) -> tuple[str, tuple[int, int, int]]:
    """Return the dominant color name and BGR value of an image region.
    Useful for detecting game outcomes (e.g. red/blue/green winner)."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    avg_h = float(np.mean(hsv[:, :, 0]))
    avg_s = float(np.mean(hsv[:, :, 1]))
    avg_v = float(np.mean(hsv[:, :, 2]))
    avg_bgr = tuple(int(x) for x in np.mean(img, axis=(0, 1)))

    if avg_s < 40:
        name = "white" if avg_v > 180 else ("gray" if avg_v > 80 else "black")
    elif avg_h < 10 or avg_h > 170:
        name = "red"
    elif avg_h < 25:
        name = "orange"
    elif avg_h < 35:
        name = "yellow"
    elif avg_h < 85:
        name = "green"
    elif avg_h < 130:
        name = "blue"
    elif avg_h < 170:
        name = "purple"
    else:
        name = "red"

    return name, avg_bgr


def region_difference(name: str) -> float | None:
    """How different the region looks now from the picture saved when it was selected:
    the average difference per pixel, 0 (identical) to 255. None when the region or its
    picture isn't there. Plain difference rather than correlation, because the regions
    this is for are often flat -- a coloured button, a bar -- and correlation on a flat
    picture is undefined."""
    ref_path = snaps_dir() / f"{name}.png"
    if not ref_path.exists() or not (snaps_dir() / f"{name}.geo").exists():
        return None
    ref = cv2.imread(str(ref_path), cv2.IMREAD_COLOR)
    if ref is None:
        return None
    now = read_region(name)
    if now.shape != ref.shape:
        now = cv2.resize(now, (ref.shape[1], ref.shape[0]))
    return float(cv2.absdiff(now, ref).mean())


def region_matches_reference(name: str, threshold: float = 0.85) -> float:
    """Compare current screen region against saved reference snapshot.
    Returns match confidence 0–1."""
    ref_path = snaps_dir() / f"{name}.png"
    if not ref_path.exists():
        return 0.0
    ref = cv2.imread(str(ref_path), cv2.IMREAD_COLOR)
    current = read_region(name)
    if ref is None:
        return 0.0
    if ref.shape != current.shape:
        current = cv2.resize(current, (ref.shape[1], ref.shape[0]))
    result = cv2.matchTemplate(current, ref, cv2.TM_CCOEFF_NORMED)
    return float(cv2.minMaxLoc(result)[1])


# The gap before the second look that confirms a value which has just CHANGED (a value
# that repeats the last confirmed one needs no second look). It was 0.04 s: while the
# score counts up after a result, that is up to 25 grabs a second, at the very moment
# the bar has changed and the board is being confirmed too -- the busiest second of
# every hand, and the stream's frames are what pay for it. 0.1 s confirms a change
# 60 ms later and takes well under half the grabs while something is animating.
CONFIRM_GAP = 0.1


SHOTS = 0                       # screenshots taken, for the dashboard's reading rate


SHOTS_BY: dict = {}             # … and by region, for the load meter


SHOT_TIMES: deque = deque(maxlen=4000)   # when each was taken: the busiest second


FAIL_BACKOFF = 0.5              # longest gap between retries of a read that isn't working


FAIL_GRACE = 3                  # … but the first few retries stay quick: a bar mid-animation


                                # is unreadable for a moment and must be caught, not waited out


def shots_taken() -> int:
    return SHOTS


def shots_by_region() -> dict:
    return dict(SHOTS_BY)


def shot_times() -> list[float]:
    return list(SHOT_TIMES)


def _retry_gap(interval: float, fails: int) -> float:
    """How long to wait before trying a read again. A read that came back with a value
    we only want to confirm is retried straight away. A read that failed outright is
    backed off: the region did not become readable in the last 40 ms and it will not in
    the next 40 ms either, and every attempt is a screenshot — which costs the
    compositor a whole frame copy, so hammering a bar that isn't there is the most
    expensive thing this program can do."""
    if fails <= FAIL_GRACE:
        return interval
    return min(FAIL_BACKOFF, interval * (2 ** min(fails - FAIL_GRACE, 6)))
