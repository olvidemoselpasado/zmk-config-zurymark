"""Every screen region the bot reads, what it is for, and what it needs to be usable.

One list, so the Interface tab can show every region whether or not it has been set
up yet -- an empty slot waiting for its box -- with only the steps that region
really takes. They differ completely:

    board          the scoreboard bar     a box, then its digits taught
    score          your balance           a box, then its digits and money format taught
    road           the bead road          a box; read by colour, nothing to teach
    bets_open      where the chips appear a box, then two looks: chips up, chips gone
    success_login  proof you're logged in a box drawn WHILE logged in; its picture is
                                          the reference, there is nothing to teach

A region saved under any other name is not read by anything, and is listed as such.
Some slots answer to an older name too, so a region saved before the slot existed
is still found -- success_login was saved as 'succes_login' and 'login_success'.
"""

from __future__ import annotations

from baccarat.screen.colors import color_stats, trigger_ready
from baccarat.screen.glyphs import digit_stats
from baccarat.screen.sites import snaps_dir

SLOTS: tuple[dict, ...] = (
    {"name": "board", "kind": "board", "title": "Scoreboard bar",
     "what": "The bar with the game number and the player / banker / tie counts. Every "
             "result comes from here.",
     "how": "Drag a generous box around the whole bar — it is found inside the box, so a "
            "loose box survives the page shifting a little. Then teach its digits.",
     "aliases": ()},
    {"name": "score", "kind": "number", "title": "Your balance",
     "what": "The money on the table's screen. With 'Trust the screen score' on, every bet is "
             "checked against it and the balance follows it.",
     "how": "Drag a box around the number, then teach its digits and how the table writes "
            "money. If the number has a colour of its own, 'Read it by colour' lets the box "
            "have room to spare.",
     "aliases": ()},
    {"name": "road", "kind": "colours", "title": "Road (the grid of circles)",
     "what": "The grid of coloured circles. When the bot joins a table it reads the whole "
             "table from here, so it can bet straight away; the table screens use it too.",
     "how": "Drag a box around the grid. It is read by colour — there is nothing to teach.",
     "aliases": ()},
    {"name": "bets_open", "kind": "trigger", "title": "Chips (the go signal)",
     "what": "Where the chips appear when the table takes bets. Used only when Setup says "
             "the betting window starts when the chips appear.",
     "how": "Drag a small box onto the chips themselves. Then press 'Chips are up now' while "
            "they show and 'Chips are gone now' while they don't — two or three of each.",
     "aliases": ()},
    {"name": "success_login", "kind": "picture", "title": "Logged in",
     "what": "Something only on screen while you are logged in — your name, 'Mi Cuenta', the "
             "balance. Before opening a table the bot compares it with its saved picture; if "
             "it doesn't match, it logs in (Setup › Login).",
     "how": "While you ARE logged in, drag a box around it. The picture taken then is what "
            "'logged in' looks like — nothing to teach. 'Check now' tells you if it matches.",
     "aliases": ("succes_login", "login_success")},
)

KINDS = {s["name"]: s["kind"] for s in SLOTS} | {a: s["kind"] for s in SLOTS for a in s["aliases"]}


def slot_of(name: str) -> dict | None:
    return next((s for s in SLOTS if name == s["name"] or name in s["aliases"]), None)


def _selected(name: str) -> bool:
    return (snaps_dir() / f"{name}.geo").exists()


def stored_name(slot: dict | str) -> str:
    """The name the slot's region is saved under: its own, or an older one it answers
    to. Nothing saved yet: its own name, which is what a new box is saved as."""
    s = slot_of(slot) if isinstance(slot, str) else slot
    for n in (s["name"], *s["aliases"]):
        if _selected(n):
            return n
    return s["name"]


def selected_name(slot_name: str) -> str | None:
    """The saved region for this slot, with its picture, or None."""
    n = stored_name(slot_name)
    d = snaps_dir()
    return n if (d / f"{n}.geo").exists() and (d / f"{n}.png").exists() else None


def kind_of(name: str) -> str:
    """board / number / colours / trigger / picture -- or 'unused' for a region no
    part of the bot reads."""
    return KINDS.get(name, "unused")


def _need(slot: dict, settings: dict) -> tuple[str, str]:
    """(needed / optional / unused, why) with these settings."""
    n = slot["name"]
    if n == "board":
        return "needed", "every result is read from it"
    if n == "score":
        return (("needed", "'Trust the screen score' is on: every bet is checked against it")
                if settings.get("hard_score") else
                ("optional", "only with 'Trust the screen score' on (Setup)"))
    if n == "road":
        return "optional", "without it the bot waits for results of its own before betting"
    if n == "bets_open":
        return (("needed", "Setup: the betting window starts when the chips appear")
                if settings.get("bet_start_on") == "chips" else
                ("unused", "only when the betting window starts with the chips (Setup)"))
    if n == "success_login":
        return "optional", "only for logging back in by itself (Setup › Login)"
    return "optional", ""


def _status(slot: dict, name: str) -> tuple[str, str]:
    """(ready / teach / select, what to do next)."""
    if not _selected(name):
        return "select", "select the box"
    kind = slot["kind"]
    if kind in ("board", "number"):
        if not digit_stats(name):
            return "teach", "teach its digits"
        return "ready", ""
    if kind == "trigger":
        if not trigger_ready(name):
            c = color_stats(name)
            missing = [w for w, k in (("chips up", "open"), ("chips gone", "shut")) if not c.get(k)]
            return "teach", "show it " + " and ".join(missing)
        return "ready", ""
    if kind == "picture" and not (snaps_dir() / f"{name}.png").exists():
        return "select", "select the box again (no picture was saved)"
    return "ready", ""


def region_slots(settings: dict, rows: list[dict]) -> list[dict]:
    """Every slot, set up or not, with what it needs; then any region saved under a name
    nothing reads. `rows` is region_list(): what is saved, with its details."""
    by_name = {r["name"]: r for r in rows}
    out = []
    used = set()
    for s in SLOTS:
        name = stored_name(s)
        used.add(name)
        need, why = _need(s, settings)
        status, todo = _status(s, name)
        out.append({"slot": s["name"], "name": name, "kind": s["kind"], "title": s["title"],
                    "what": s["what"], "how": s["how"], "need": need, "why": need_text(why),
                    "status": status, "todo": todo, "region": by_name.get(name)})
    order = {"needed": 0, "optional": 1, "unused": 2}
    out.sort(key=lambda r: order[r["need"]])
    for r in rows:
        if r["name"] not in used:
            out.append({"slot": None, "name": r["name"], "kind": "unused", "title": r["name"],
                        "what": "Nothing in the bot reads a region by this name.",
                        "how": "", "need": "unused", "why": "", "status": "ready", "todo": "",
                        "region": r})
    return out


def need_text(why: str) -> str:
    return why[:1].upper() + why[1:] if why else ""
