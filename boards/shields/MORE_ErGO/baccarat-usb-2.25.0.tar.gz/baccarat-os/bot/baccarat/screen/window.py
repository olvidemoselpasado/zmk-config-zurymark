"""The game window's width: kept with the site's recordings, and put back with one
button.

Every coordinate and region is a point on the SCREEN. They stay right only while
the game's window sits where it did when they were recorded -- and on Hyprland,
closing the browser and opening it again tiles it at whatever width the layout
gives it. Height is never the problem (a tiled window is always full height);
width is.

So the width is saved per site (window.json in the site's folder), and "fit"
puts it back: Hyprland is asked for exactly that width, and moves the split, so
the window beside it (the terminal) takes up the difference. It checks what it
got and corrects it, a couple of times if it must. Where the window starts
matters as much as how wide it is: if it is on the other side of the screen now,
fitting can't fix that, and it says so.

Which window is the game: when saving, the one the scoreboard region (or, before
that is recorded, the first saved coordinate) sits in. When fitting, the window of
the same program with the same title -- or the nearest title, since a page's title
can change -- never the dashboard's own.
"""

from __future__ import annotations

import json
import os
import time

from baccarat.errors import BetError
from baccarat.log import log
from baccarat.screen import desktop
from baccarat.screen.sites import load_coords, site_dir, snaps_dir

DASHBOARD_TITLE = "Baccarat control"     # the dashboard page's <title>
CLOSE_ENOUGH = 2                         # px: Hyprland rounds the split
TRIES = 6                                # nudges, at most
SETTLE = 0.12                            # s for Hyprland to move the split


def window_file():
    return site_dir() / "window.json"


def saved_window() -> dict | None:
    try:
        d = json.loads(window_file().read_text())
    except (OSError, json.JSONDecodeError):
        return None
    return d if isinstance(d, dict) and d.get("w") else None


def forget_window() -> None:
    try:
        window_file().unlink()
    except FileNotFoundError:
        pass


def anchor_point() -> tuple[int, int] | None:
    """A point that is inside the game: the scoreboard's middle, or a recorded click."""
    try:
        x, y, w, h = desktop.parse_geo((snaps_dir() / "board.geo").read_text().strip())
        return x + w // 2, y + h // 2
    except (OSError, BetError):
        pass
    for c in load_coords().values():
        if isinstance(c, dict) and "x" in c and "y" in c:
            return int(c["x"]), int(c["y"])
    return None


def _inside(w: dict, pt) -> bool:
    return pt is not None and w["x"] <= pt[0] < w["x"] + w["w"] and w["y"] <= pt[1] < w["y"] + w["h"]


def _candidates() -> list[dict]:
    return [w for w in desktop.list_windows()
            if w["visible"] and DASHBOARD_TITLE not in w["title"]]


def _common(a: str, b: str) -> int:
    n = 0
    for x, y in zip(a, b):
        if x != y:
            break
        n += 1
    return n


def find_game_window(saved: dict | None = None) -> dict | None:
    """The game's window as it is now. With `saved`: the same program, the closest
    title; without: the window the game's recorded points are in."""
    wins = _candidates()
    pt = anchor_point()
    if saved:
        same = [w for w in wins if w["class"] == saved.get("class")] or wins
        if not same:
            return None
        return max(same, key=lambda w: (w["title"] == saved.get("title"),
                                        _common(w["title"], saved.get("title") or ""),
                                        _inside(w, pt), w["w"] * w["h"]))
    inside = [w for w in wins if _inside(w, pt)]
    return inside[0] if inside else None


def save_game_window() -> dict:
    """Remember the game window's width (and where it starts) as it is right now."""
    w = find_game_window(None)
    if w is None:
        raise BetError("couldn't tell which window is the game: record the scoreboard region "
                       "(or any coordinate) first, with the game where it should be")
    keep = {k: w[k] for k in ("class", "title", "x", "y", "w", "h")}
    keep["saved"] = time.strftime("%Y-%m-%d %H:%M:%S")
    f = window_file()
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(keep, indent=1) + "\n")
    os.replace(tmp, f)
    log.info("Game window saved: %d px wide, starting at x=%d (%s — %s).",
             keep["w"], keep["x"], keep["class"], keep["title"][:60])
    return keep


def window_status() -> dict:
    """What is saved, what the game window is now, and whether they agree."""
    saved = saved_window()
    out = {"saved": saved, "now": None, "fits": None, "same_place": None}
    if not saved:
        return out
    try:
        now = find_game_window(saved)
    except Exception as e:                       # the page asks often: never an error
        return {**out, "error": str(e)}
    if now is None:
        return {**out, "error": "the game's window isn't open on a workspace that is showing"}
    out.update(now={k: now[k] for k in ("class", "title", "x", "y", "w", "h")},
               fits=abs(now["w"] - saved["w"]) <= CLOSE_ENOUGH,
               same_place=abs(now["x"] - saved["x"]) <= CLOSE_ENOUGH)
    return out


def _settled(win_id: str, fallback: dict) -> dict:
    """The window once Hyprland has done with it: read until two looks agree."""
    last = None
    for _ in range(6):
        time.sleep(SETTLE)
        now = next((w for w in desktop.list_windows() if w["id"] == win_id), None)
        if now is None:
            return fallback
        if last and (now["x"], now["w"]) == (last["x"], last["w"]):
            return now
        last = now
    return last or fallback


def _steer(win: dict, target: int) -> tuple[dict, float | None]:
    """Nudge the window's width towards `target`, steering by what each nudge did.

    Hyprland doesn't size a tiled window: it moves the split line beside it. With
    smart_resizing (the default) "+100" moves that line to the right -- which makes a
    window on the LEFT of the split wider, and one on the RIGHT narrower. So nothing
    is assumed: every nudge is measured, and the next one is aimed with what that
    showed (+1: wider with '+', -1: narrower with '+')."""
    gain = None
    for _ in range(TRIES):
        off = target - win["w"]
        if abs(off) <= CLOSE_ENOUGH:
            break
        # never trust a first nudge with the whole distance: half of it shows which way
        # the split moves for this window, and costs nothing if it is the wrong way
        if gain:
            dx = round(off * gain)
        else:                                    # a probe: half the way, at least 8 px
            dx = max(8, abs(off) // 2) * (1 if off > 0 else -1)
            dx = max(-abs(off), min(abs(off), dx))
        width_before = win["w"]
        desktop.set_window_width(win["id"], dx, 0, exact=False)
        win = _settled(win["id"], win)
        moved = win["w"] - width_before
        if moved == 0:
            break                                # at a limit: it won't go further
        if gain is not None and abs(target - win["w"]) > abs(off):
            break                                # aimed, and still the wrong way: stop
        # (the first nudge is allowed to go the wrong way: that is what it is for)
        # only the direction is learnt: Hyprland moves the line by what it is asked,
        # give or take a pixel of rounding, and a pixel of rounding on a small nudge
        # would otherwise read as a huge or tiny gain
        gain = 1.0 if moved * dx > 0 else -1.0
    return win, gain


def fit_game_window() -> dict:
    """Put the game window back to the saved width. → what it did."""
    saved = saved_window()
    if not saved:
        raise BetError("no width saved for this site yet — size the game window by hand once, "
                       "then press 'Save its width'")
    win = find_game_window(saved)
    if win is None:
        raise BetError("the game's window isn't open on a workspace that is showing")
    if win["fullscreen"]:
        raise BetError("the game's window is fullscreen — leave fullscreen first")
    start, target = dict(win), int(saved["w"])
    win, gain = _steer(win, target)
    # whatever happened, never leave it worse than it was found
    if abs(win["w"] - target) > abs(start["w"] - target) + CLOSE_ENOUGH:
        log.warning("Game window: fitting made it %d px (from %d, wanted %d) — putting it back.",
                    win["w"], start["w"], target)
        win, _ = _steer(win, start["w"])
    fits = abs(win["w"] - target) <= CLOSE_ENOUGH
    same_place = abs(win["x"] - int(saved["x"])) <= CLOSE_ENOUGH
    out = {"before": start["w"], "after": win["w"], "target": target, "fits": fits,
           "x": win["x"], "saved_x": saved["x"], "same_place": same_place,
           "changed": start["w"] != win["w"],
           "side": None if gain is None else ("left" if gain > 0 else "right")}
    if not fits:
        log.warning("Game window: asked for %d px, it is %d px — Hyprland wouldn't go further "
                    "(a minimum size on the window beside it?).", target, win["w"])
    elif out["changed"]:
        log.info("Game window: %d px → %d px wide, from x=%d, as saved%s.", start["w"], win["w"],
                 win["x"], " (it is on the right of its split, so the nudges were reversed)"
                 if out["side"] == "right" else "")
    if not same_place:
        log.warning("Game window: it starts at x=%d, but at x=%d when it was saved — the "
                    "coordinates are off by that much. Put it back on the same side "
                    "(swap the two windows) and fit it again.", win["x"], saved["x"])
    return out


def ensure_game_window() -> None:
    """Before a session: if a width is saved and the game window isn't at it, fit it.
    Refuse to start when it can't be made to match -- every click would land off."""
    if not saved_window():
        return
    r = fit_game_window()
    if not r["fits"]:
        raise BetError(f"the game window is {r['after']} px wide and the coordinates were "
                       f"recorded at {r['target']} px — it couldn't be resized to fit")
    if not r["same_place"]:
        raise BetError(f"the game window starts at x={r['x']}, but at x={r['saved_x']} when the "
                       f"coordinates were recorded — put it back on the same side of the screen")
