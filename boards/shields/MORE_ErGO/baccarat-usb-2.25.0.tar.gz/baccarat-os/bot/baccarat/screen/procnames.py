"""Process names, the same on every system: what the load meter matches against.

Kept apart from the backends so both can use it without importing each other."""

from __future__ import annotations

import re


def process_name(comm: str) -> str:
    """A process's name as you would know it. NixOS starts programs through a wrapper,
    so Hyprland runs as '.Hyprland-wrapped' -- and the kernel keeps only 15 characters
    of that, '.Hyprland-wrapp'. Both the dot and the wrapper suffix, whole or cut
    short, are taken off."""
    name = comm.strip().lower().lstrip(".")
    return re.sub(r"-w(r(a(p(p(e(d)?)?)?)?)?)?$", "", name) if "-w" in name else name


def group_of(name: str, groups: dict[str, tuple[str, ...]]) -> str | None:
    """Which group a process name belongs to. A name in a group ending in '*' matches
    every process that starts with it: 'google chrome*' takes in the browser and all
    of its helpers ('Google Chrome Helper (Renderer)', and so on)."""
    for g, names in groups.items():
        for n in names:
            n = n.lower()
            if (n.endswith("*") and name.startswith(n[:-1])) or name == n:
                return g
    return None
