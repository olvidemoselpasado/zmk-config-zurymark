"""macOS: Quartz for pixels, the pointer and the keyboard; Accessibility for focus;
psutil for how busy the machine is.

Reached only through desktop.py. Written for any Mac that runs Python 3.10 -- Intel
or Apple silicon, macOS 11 onwards -- and every macOS call is looked up when it is
first used, so this file imports anywhere (the tests run it on Linux against stand-in
modules) and a missing piece is named rather than crashing at start-up.

Three things a Mac does differently from the Linux this was written on, and how
each is handled:

  Retina. A screen unit is two pixels on most Macs. Clicks and boxes are in screen
  units, and every picture is brought back to one pixel per unit before anything
  reads it -- so digits taught on one screen read the same on any other, and the
  reading code never needs to know.

  Focus. Keys go to the frontmost window, and on a Mac moving the pointer doesn't
  change which one that is. So before a key (reload, the arrows in the lobby) the
  window under the point the bot was told to aim at is brought to the front.

  Permissions. Two, both in System Settings › Privacy & Security, and both given to
  the app the bot is started from (Terminal, iTerm, …), not to Python:
      Screen Recording  without it every picture shows only the desktop
      Accessibility     without it every click and key is silently dropped
  Both are checked before they are first needed, and the error says which one.
"""

from __future__ import annotations

import os
import platform
import random
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import cv2
import numpy as np

from baccarat.errors import BetError
from baccarat.log import log
from baccarat.screen.procnames import group_of, process_name

RELOAD_KEY = "cmd+r"          # every browser on a Mac reloads with ⌘R
YDOTOOL_SOCKET = ""

_MODULES: dict = {}


def _mod(name: str, what: str):
    """Import a macOS framework the first time it is needed."""
    if name not in _MODULES:
        try:
            _MODULES[name] = __import__(name)
        except ImportError:
            raise BetError(f"{what} isn't installed. Run setup_mac.sh in the bot folder "
                           f"(or: pip install -r requirements-mac.txt)") from None
    return _MODULES[name]


def _Q():
    return _mod("Quartz", "pyobjc-framework-Quartz")


def _AX():
    return _mod("ApplicationServices", "pyobjc-framework-ApplicationServices")


def _AK():
    return _mod("AppKit", "pyobjc-framework-Cocoa")


def _settings_path(pane: str) -> str:
    """Where a permission is switched on: the menus moved in macOS 13."""
    try:
        major = int(platform.mac_ver()[0].split(".")[0] or 0)
    except ValueError:
        major = 0
    if major >= 13:
        return f"System Settings › Privacy & Security › {pane}"
    return f"System Preferences › Security & Privacy › Privacy › {pane}"


def _host_app() -> str:
    """The app the bot was started from: that is what the permissions belong to."""
    t = os.environ.get("TERM_PROGRAM", "")
    return {"Apple_Terminal": "Terminal", "iTerm.app": "iTerm",
            "vscode": "Visual Studio Code"}.get(t, t or "the app you start the bot from")


# ---------------------------------------------------------------------------
# Permissions
# ---------------------------------------------------------------------------

def screen_access() -> bool | None:
    """Screen Recording allowed? None on a macOS too old to ask (before 10.15)."""
    f = getattr(_Q(), "CGPreflightScreenCaptureAccess", None)
    return None if f is None else bool(f())


def input_access() -> bool:
    """Accessibility allowed -- may this program click and type?"""
    return bool(_AX().AXIsProcessTrusted())


_SCREEN_OK = False
_INPUT_OK = False


def _need_screen() -> None:
    global _SCREEN_OK
    if _SCREEN_OK:
        return
    if screen_access() is False:
        req = getattr(_Q(), "CGRequestScreenCaptureAccess", None)
        if req:
            req()                           # shows the system's own prompt, once
        raise BetError(
            f"macOS hasn't allowed this program to see the screen. Turn on "
            f"{_host_app()} in {_settings_path('Screen Recording')}, then quit "
            f"{_host_app()} completely (⌘Q) and start the bot again. Until then every "
            f"picture would show only the desktop.")
    _SCREEN_OK = True


def ensure_input() -> None:
    global _INPUT_OK
    if _INPUT_OK:
        return
    if not input_access():
        AX = _AX()
        try:
            AX.AXIsProcessTrustedWithOptions({AX.kAXTrustedCheckOptionPrompt: True})
        except Exception:
            pass
        raise BetError(
            f"macOS hasn't allowed this program to use the mouse and keyboard. Turn on "
            f"{_host_app()} in {_settings_path('Accessibility')}, then quit "
            f"{_host_app()} completely (⌘Q) and start the bot again. Until then every "
            f"click and key would be silently dropped.")
    _INPUT_OK = True


def check_tools() -> None:
    """Everything the bot needs from the Mac is importable."""
    _Q()
    _AX()
    _AK()


# ---------------------------------------------------------------------------
# The pointer
# ---------------------------------------------------------------------------

def _where():
    Q = _Q()
    p = Q.CGEventGetLocation(Q.CGEventCreate(None))
    return float(p.x), float(p.y)


def get_cursor_pos() -> tuple[int, int] | None:
    """Pointer position in screen units, origin top-left of the main display."""
    try:
        x, y = _where()
    except BetError:
        raise
    except Exception as e:
        log.error("Couldn't read the pointer position: %s", e)
        return None
    return int(round(x)), int(round(y))


def move_cursor(x, y) -> None:
    Q = _Q()
    ev = Q.CGEventCreateMouseEvent(None, Q.kCGEventMouseMoved, (float(x), float(y)),
                                   Q.kCGMouseButtonLeft)
    Q.CGEventPost(Q.kCGHIDEventTap, ev)


def mouse_button(down: bool, button: str = "left") -> bool:
    """Press or release a button where the pointer is."""
    Q = _Q()
    kind = {("left", True): Q.kCGEventLeftMouseDown, ("left", False): Q.kCGEventLeftMouseUp,
            ("right", True): Q.kCGEventRightMouseDown,
            ("right", False): Q.kCGEventRightMouseUp}[(button, bool(down))]
    btn = Q.kCGMouseButtonRight if button == "right" else Q.kCGMouseButtonLeft
    try:
        ev = Q.CGEventCreateMouseEvent(None, kind, _where(), btn)
        Q.CGEventSetIntegerValueField(ev, Q.kCGMouseEventClickState, 1)
        Q.CGEventPost(Q.kCGHIDEventTap, ev)
        return True
    except Exception as e:
        log.error("Mouse %s failed: %s", "press" if down else "release", e)
        return False


# ---------------------------------------------------------------------------
# The keyboard
# ---------------------------------------------------------------------------

# Key positions (virtual key codes) on a Mac keyboard. These are places, not letters,
# but the letters used here sit in the same place on QWERTY, Spanish and AZERTY alike.
KEYCODES = {
    "return": 36, "enter": 36, "tab": 48, "space": 49, "delete": 51, "backspace": 51,
    "escape": 53, "esc": 53, "left": 123, "right": 124, "down": 125, "up": 126,
    "pageup": 116, "pagedown": 121, "home": 115, "end": 119, "f5": 96,
    "a": 0, "s": 1, "d": 2, "f": 3, "h": 4, "g": 5, "z": 6, "x": 7, "c": 8, "v": 9,
    "b": 11, "q": 12, "w": 13, "e": 14, "r": 15, "y": 16, "t": 17, "o": 31, "u": 32,
    "i": 34, "p": 35, "l": 37, "j": 38, "k": 40, "n": 45, "m": 46,
    "1": 18, "2": 19, "3": 20, "4": 21, "6": 22, "5": 23, "9": 25, "7": 26, "8": 28,
    "0": 29,
}
MODIFIERS = {  # name → (key code, flag name in Quartz)
    "cmd": (55, "kCGEventFlagMaskCommand"), "command": (55, "kCGEventFlagMaskCommand"),
    "shift": (56, "kCGEventFlagMaskShift"),
    "alt": (58, "kCGEventFlagMaskAlternate"), "option": (58, "kCGEventFlagMaskAlternate"),
    "ctrl": (59, "kCGEventFlagMaskControl"), "control": (59, "kCGEventFlagMaskControl"),
}


def _key_event(code: int, down: bool, flags: int) -> None:
    Q = _Q()
    ev = Q.CGEventCreateKeyboardEvent(None, code, down)
    Q.CGEventSetFlags(ev, flags)
    Q.CGEventPost(Q.kCGHIDEventTap, ev)


def press_key(key: str, label: str = "") -> bool:
    """A key by name -- Return, Tab, Down, Up, F5 -- or a combination: 'cmd+r'."""
    Q = _Q()
    parts = [p.strip().lower() for p in key.split("+") if p.strip()]
    if not parts or parts[-1] not in KEYCODES or any(m not in MODIFIERS for m in parts[:-1]):
        log.warning("%s: don't know the key '%s'", label or "key", key)
        return False
    flags, held = 0, []
    try:
        for m in parts[:-1]:                     # the modifiers go down first …
            code, flag = MODIFIERS[m]
            flags |= getattr(Q, flag)
            _key_event(code, True, flags)
            held.append(code)
            time.sleep(random.uniform(0.02, 0.05))
        code = KEYCODES[parts[-1]]
        _key_event(code, True, flags)
        time.sleep(random.uniform(0.03, 0.07))
        _key_event(code, False, flags)
        for c in reversed(held):                 # … and come up last
            time.sleep(random.uniform(0.02, 0.05))
            _key_event(c, False, 0)
        return True
    except Exception as e:
        log.error("%s failed: %s", label or f"key {key}", e)
        return False


def _type(text: str, gap_ms: int) -> None:
    """Every character as the character itself, whatever the keyboard layout --
    an @ or an ñ comes out as typed."""
    Q = _Q()
    for ch in text:
        units = len(ch.encode("utf-16-le")) // 2
        for down in (True, False):
            ev = Q.CGEventCreateKeyboardEvent(None, 0, down)
            Q.CGEventSetFlags(ev, 0)
            Q.CGEventKeyboardSetUnicodeString(ev, units, ch)
            Q.CGEventPost(Q.kCGHIDEventTap, ev)
        time.sleep(max(0.0, gap_ms / 1000 * random.uniform(0.75, 1.3)))


def type_text(text: str) -> bool:
    try:
        _type(text, 40)
        return True
    except BetError:
        raise
    except Exception as e:
        log.error("typing failed: %s", e)
        return False


def type_private(text: str, label: str = "typing", gap_ms: int = 60) -> bool:
    """Like type_text, but nothing about the text is ever logged -- not even when it
    fails, where only the kind of error is named."""
    try:
        _type(text, gap_ms)
        return True
    except BetError:
        raise
    except Exception as e:
        log.warning("%s failed (%s).", label, type(e).__name__)
        return False


# ---------------------------------------------------------------------------
# Focus: the keyboard goes to the frontmost window, not the one under the pointer
# ---------------------------------------------------------------------------

def window_at(x, y) -> dict | None:
    """The topmost ordinary window under (x, y): its app's pid, title and bounds."""
    Q = _Q()
    opts = Q.kCGWindowListOptionOnScreenOnly | Q.kCGWindowListExcludeDesktopElements
    for w in Q.CGWindowListCopyWindowInfo(opts, Q.kCGNullWindowID) or []:
        if int(w.get("kCGWindowLayer", 0)) != 0:      # menu bar, Dock, overlays
            continue
        b = w.get("kCGWindowBounds") or {}
        bx, by = float(b.get("X", 0)), float(b.get("Y", 0))
        bw, bh = float(b.get("Width", 0)), float(b.get("Height", 0))
        if bx <= x < bx + bw and by <= y < by + bh:
            return {"pid": int(w.get("kCGWindowOwnerPID", 0)),
                    "app": str(w.get("kCGWindowOwnerName", "") or ""),
                    "title": str(w.get("kCGWindowName", "") or ""),
                    "bounds": (bx, by, bw, bh)}
    return None


def focus_point(x, y) -> None:
    """Bring the window under (x, y) to the front, so a key reaches it -- not the
    dashboard, even when both are windows of the same browser."""
    try:
        w = window_at(x, y)
    except BetError:
        raise
    except Exception as e:
        log.debug("couldn't list the windows: %s", e)
        return
    if not w or w["pid"] == os.getpid():
        log.debug("no window under (%s, %s) to focus", x, y)
        return
    try:
        AK = _AK()
        app = AK.NSRunningApplication.runningApplicationWithProcessIdentifier_(w["pid"])
        if app is not None:
            app.activateWithOptions_(AK.NSApplicationActivateIgnoringOtherApps)
    except Exception as e:
        log.debug("couldn't activate %s: %s", w["app"], e)
    if not _raise_window(w):
        log.debug("brought %s forward, but couldn't pick out its window '%s'",
                  w["app"], w["title"])
    time.sleep(0.15)                            # let the window manager catch up


def _ax_get(el, attr):
    err, val = _AX().AXUIElementCopyAttributeValue(el, attr, None)
    return val if err == 0 else None


def _ax_point(val, kind: str):
    AX = _AX()
    # the constant was renamed along the way: kAXValueCGPointType, later kAXValueTypeCGPoint
    t = getattr(AX, f"kAXValueCG{kind}Type", None)
    t = t if t is not None else getattr(AX, f"kAXValueTypeCG{kind}", None)
    if val is None or t is None:
        return None
    ok, v = AX.AXValueGetValue(val, t, None)
    return v if ok else None


def _raise_window(w: dict) -> bool:
    """Raise one window of the app, found by its title or else by where it is."""
    try:
        AX = _AX()
        app = AX.AXUIElementCreateApplication(w["pid"])
        wins = _ax_get(app, AX.kAXWindowsAttribute) or []
        bx, by, bw, bh = w["bounds"]
        pick = None
        for win in wins:
            if w["title"] and _ax_get(win, AX.kAXTitleAttribute) == w["title"]:
                pick = win
                break
            p = _ax_point(_ax_get(win, AX.kAXPositionAttribute), "Point")
            s = _ax_point(_ax_get(win, AX.kAXSizeAttribute), "Size")
            if p is not None and s is not None and abs(p.x - bx) < 2 and abs(p.y - by) < 2 \
                    and abs(s.width - bw) < 2 and abs(s.height - bh) < 2:
                pick = win
        if pick is None:
            return False
        AX.AXUIElementPerformAction(pick, AX.kAXRaiseAction)
        AX.AXUIElementSetAttributeValue(pick, AX.kAXMainAttribute, True)
        return True
    except BetError:
        raise
    except Exception as e:
        log.debug("raising the window failed: %s", e)
        return False


# ---------------------------------------------------------------------------
# Pixels
# ---------------------------------------------------------------------------

_SAID_SCALE = False
_USE_SCREENCAPTURE = False      # set once Quartz has refused, so it isn't asked again


def _cgimage_to_bgr(ref) -> np.ndarray:
    """A CGImage as a BGR array, whatever order its bytes come in."""
    Q = _Q()
    w, h = int(Q.CGImageGetWidth(ref)), int(Q.CGImageGetHeight(ref))
    bpr = int(Q.CGImageGetBytesPerRow(ref))
    if int(Q.CGImageGetBitsPerPixel(ref)) != 32:
        raise BetError(f"unexpected screen picture format ({Q.CGImageGetBitsPerPixel(ref)} "
                       f"bits per pixel)")
    data = bytes(Q.CGDataProviderCopyData(Q.CGImageGetDataProvider(ref)))
    px = np.frombuffer(data, np.uint8)[: h * bpr].reshape(h, bpr)[:, : w * 4].reshape(h, w, 4)
    little = (int(Q.CGImageGetBitmapInfo(ref)) & int(Q.kCGBitmapByteOrderMask)) \
        == int(Q.kCGBitmapByteOrder32Little)
    first = int(Q.CGImageGetAlphaInfo(ref)) in (int(Q.kCGImageAlphaPremultipliedFirst),
                                                int(Q.kCGImageAlphaFirst),
                                                int(Q.kCGImageAlphaNoneSkipFirst))
    if little and first:            # memory B G R A -- what a Mac screen nearly always is
        bgr = px[..., :3]
    elif little:                    # A B G R
        bgr = px[..., 1:4]
    elif first:                     # A R G B
        bgr = px[..., 3:0:-1]
    else:                           # R G B A
        bgr = px[..., 2::-1]
    return np.ascontiguousarray(bgr)


def _quartz_capture(x, y, w, h) -> np.ndarray | None:
    Q = _Q()
    make = getattr(Q, "CGWindowListCreateImage", None)
    if make is None:
        return None
    rect = Q.CGRectInfinite if w is None else Q.CGRectMake(x, y, w, h)
    ref = make(rect, Q.kCGWindowListOptionOnScreenOnly, Q.kCGNullWindowID,
               Q.kCGWindowImageDefault)
    return None if ref is None else _cgimage_to_bgr(ref)


def _screencapture(x, y, w, h) -> np.ndarray:
    """The macOS screencapture tool: slower (a process and a file per picture), but on
    every macOS, including those where Quartz no longer hands out pictures."""
    fd, tmp = tempfile.mkstemp(suffix=".png")
    os.close(fd)
    try:
        cmd = ["screencapture", "-x", "-t", "png"]
        if w is not None:
            cmd.append(f"-R{x},{y},{w},{h}")
        r = subprocess.run(cmd + [tmp], capture_output=True, text=True, timeout=10)
        if r.returncode != 0:
            raise BetError(f"screencapture failed: {(r.stderr or '').strip()}")
        img = cv2.imread(tmp, cv2.IMREAD_COLOR)
    finally:
        Path(tmp).unlink(missing_ok=True)
    if img is None:
        raise BetError("screencapture returned no picture")
    return img


def _grab(x, y, w, h) -> np.ndarray:
    global _USE_SCREENCAPTURE
    _need_screen()
    img = None
    if not _USE_SCREENCAPTURE:
        try:
            img = _quartz_capture(x, y, w, h)
        except BetError:
            raise
        except Exception as e:
            log.debug("Quartz capture failed: %s", e)
        if img is None:
            _USE_SCREENCAPTURE = True
            log.info("Taking pictures with screencapture (this macOS doesn't hand them "
                     "out through Quartz) — it works, a little slower.")
    return img if img is not None else _screencapture(x, y, w, h)


def _to_units(img: np.ndarray, w: int, h: int) -> np.ndarray:
    """One pixel per screen unit. A Retina screen gives two (or more) per unit; the
    reading code was taught on, and is tuned for, one."""
    global _SAID_SCALE
    ih, iw = img.shape[:2]
    if (iw, ih) == (w, h):
        return img
    if not _SAID_SCALE:
        _SAID_SCALE = True
        log.info("This screen has %.3g pixels per screen unit (Retina); pictures are "
                 "read at one per unit.", iw / max(1, w))
    return cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA)


def capture_region(x: int, y: int, w: int, h: int) -> np.ndarray:
    return _to_units(_grab(x, y, w, h), w, h)


def displays() -> list[dict]:
    """Every screen: where it is in screen units, its size in pixels, and its scale."""
    Q = _Q()
    try:
        err, ids, n = Q.CGGetActiveDisplayList(16, None, None)
        ids = list(ids or [])[: int(n or 0)] if err == 0 else []
    except Exception:
        ids = []
    ids = ids or [Q.CGMainDisplayID()]
    out = []
    for d in ids:
        b = Q.CGDisplayBounds(d)
        mode = Q.CGDisplayCopyDisplayMode(d)
        pw = int(Q.CGDisplayModeGetPixelWidth(mode)) if mode is not None else int(b.size.width)
        out.append({"id": int(d), "main": d == Q.CGMainDisplayID(),
                    "x": int(b.origin.x), "y": int(b.origin.y),
                    "w": int(b.size.width), "h": int(b.size.height),
                    "pixels_w": pw, "scale": pw / max(1.0, float(b.size.width))})
    return out


def capture_screen() -> np.ndarray:
    """Every screen together, one pixel per unit, as one picture."""
    ds = displays()
    x0, y0 = min(d["x"] for d in ds), min(d["y"] for d in ds)
    x1 = max(d["x"] + d["w"] for d in ds)
    y1 = max(d["y"] + d["h"] for d in ds)
    return _to_units(_grab(x0, y0, x1 - x0, y1 - y0), x1 - x0, y1 - y0)


def select_region() -> str:
    """A see-through layer over the main screen to drag a box on. It runs as a little
    program of its own: macOS only lets windows be made on a program's main thread,
    and the dashboard asks for this from one of its own threads."""
    # run as a plain file, not as part of the package: it needs nothing but Tk, and
    # starts in a fraction of a second instead of loading the whole bot first
    r = subprocess.run([sys.executable, str(Path(__file__).with_name("select_box.py"))],
                       capture_output=True, text=True)
    if r.returncode == 2:
        raise BetError("Selecting a box needs Tk, which this Python doesn't have. Python "
                       "from python.org has it; with Homebrew: brew install python-tk")
    if r.returncode != 0 or not r.stdout.strip():
        raise BetError("nothing was selected")
    return r.stdout.strip().splitlines()[-1]


def open_url(url: str) -> None:
    """The dashboard in a window of its own, in Firefox or Chrome when there is one, so
    it never lands as a tab in the game's window."""
    for app, args in (("Firefox", ["--new-window", url]),
                      ("Google Chrome", ["--new-window", url])):
        if Path(f"/Applications/{app}.app").exists():
            subprocess.Popen(["open", "-na", app, "--args", *args],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
    subprocess.Popen(["open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# ---------------------------------------------------------------------------
# How busy the machine is (psutil; without it, only the bot's own share is shown)
# ---------------------------------------------------------------------------

def _psutil():
    try:
        import psutil
        return psutil
    except ImportError:
        return None


def find_pids(groups: dict[str, tuple[str, ...]]) -> dict[str, list[int]]:
    out: dict[str, list[int]] = {g: [] for g in groups}
    ps = _psutil()
    if ps is None:
        return out
    me = os.getpid()
    for p in ps.process_iter(["pid", "name"]):
        try:
            if p.info["pid"] == me:
                continue
            g = group_of(process_name(p.info["name"] or ""), groups)
            if g:
                out[g].append(int(p.info["pid"]))
        except Exception:
            continue
    return out


def cpu_seconds(pid: int) -> float | None:
    ps = _psutil()
    if ps is None:
        return None
    try:
        t = ps.Process(pid).cpu_times()
        return float(t.user + t.system)
    except Exception:
        return None


def machine_cpu() -> tuple[float, float] | None:
    ps = _psutil()
    if ps is None:
        return None
    t = ps.cpu_times()
    total = float(sum(t))
    return total - float(t.idle), total


# ---------------------------------------------------------------------------
# The doctor: python -m baccarat.screen --doctor
# ---------------------------------------------------------------------------

def doctor() -> None:
    """Check, in one go, everything the bot needs from this Mac, and print a report
    to paste when asking for help. The pointer moves a little; nothing is clicked or
    typed."""
    problems: list[str] = []

    def line(k, v):
        print(f"  {k:<24} {v}")

    print("=" * 66 + "\n  The bot on this Mac\n" + "=" * 66)
    line("macOS", platform.mac_ver()[0] or "?")
    line("machine", f"{platform.machine()} · {os.cpu_count()} cores")
    line("Python", f"{sys.version.split()[0]} ({sys.executable})")
    if sys.version_info < (3, 10):
        problems.append("Python 3.10 or newer is needed")
    line("started from", _host_app())
    try:
        import numpy
        line("numpy / OpenCV", f"{numpy.__version__} / {cv2.__version__}")
    except Exception as e:
        line("numpy / OpenCV", f"MISSING ({e})")
    for mod, name in (("Quartz", "pyobjc Quartz"), ("ApplicationServices", "pyobjc ApplicationServices"),
                      ("AppKit", "pyobjc Cocoa")):
        try:
            __import__(mod)
            line(name, "ok")
        except ImportError:
            line(name, "MISSING")
            problems.append(f"{name} is missing — run setup_mac.sh")
    line("psutil", "ok" if _psutil() else "missing (the CPU meter will show the bot only)")
    try:
        import tkinter
        line("Tk (Select the box)", f"ok, {tkinter.TkVersion}")
    except Exception:
        line("Tk (Select the box)", "MISSING")
        problems.append("Tk is missing: install Python from python.org, or brew install python-tk")
    if problems and any("pyobjc" in p for p in problems):
        _doctor_end(problems)
        return

    print("\n  Screens")
    for d in displays():
        line(f"  {'main' if d['main'] else 'other'} #{d['id']}",
             f"{d['w']}×{d['h']} units at {d['x']},{d['y']} · {d['pixels_w']} px wide "
             f"· scale {d['scale']:.3g}")

    print("\n  Permissions (given to the app the bot is started from)")
    sa, ia = screen_access(), input_access()
    line("Screen Recording", {True: "allowed", False: "NOT ALLOWED", None: "can't tell (old macOS)"}[sa])
    line("Accessibility", "allowed" if ia else "NOT ALLOWED")
    if sa is False:
        problems.append(f"Screen Recording: turn on {_host_app()} in {_settings_path('Screen Recording')}, then quit it (⌘Q) and reopen")
    if not ia:
        problems.append(f"Accessibility: turn on {_host_app()} in {_settings_path('Accessibility')}, then quit it (⌘Q) and reopen")

    print("\n  Taking pictures")
    if sa is not False:
        main = next((d for d in displays() if d["main"]), displays()[0])
        w, h = 300, 120
        x, y = main["x"] + (main["w"] - w) // 2, main["y"] + (main["h"] - h) // 2
        try:
            t0 = time.perf_counter()
            raw = _grab(x, y, w, h)
            img = _to_units(raw, w, h)
            for _ in range(4):
                _to_units(_grab(x, y, w, h), w, h)
            per = (time.perf_counter() - t0) / 5 * 1000
            line("method", "screencapture" if _USE_SCREENCAPTURE else "Quartz")
            line("a 300×120 box", f"{raw.shape[1]}×{raw.shape[0]} px → read at {img.shape[1]}×{img.shape[0]}")
            line("time per picture", f"{per:.0f} ms")
            # one flat colour in every channel: what a picture looks like when macOS
            # quietly shows only the wallpaper behind the windows
            flat = float(img.reshape(-1, 3).std(axis=0).max()) < 1.0
            line("looks real", "NO — one flat colour" if flat else "yes")
            if flat:
                problems.append("The test picture is one flat colour: Screen Recording may not "
                                "really be on, or that part of the screen is empty")
            from baccarat.screen.sites import debug_dir
            debug_dir().mkdir(parents=True, exist_ok=True)
            out = debug_dir() / "doctor-picture.png"
            cv2.imwrite(str(out), img)
            line("saved", str(out))
        except BetError as e:
            line("picture", f"FAILED: {e}")
            problems.append(f"Taking a picture failed: {e}")
    else:
        line("skipped", "Screen Recording isn't allowed yet")

    print("\n  The pointer")
    pos = get_cursor_pos()
    line("position", pos)
    if ia and pos:
        try:
            move_cursor(pos[0] + 40, pos[1])
            time.sleep(0.15)
            moved = get_cursor_pos()
            move_cursor(*pos)
            ok = moved is not None and abs(moved[0] - pos[0] - 40) <= 1
            line("moved 40 to the right", f"read back {moved} — {'ok' if ok else 'DID NOT MOVE'}")
            if not ok:
                problems.append("The pointer didn't move: Accessibility may not really be on")
        except BetError as e:
            problems.append(str(e))
        w = window_at(*pos) if pos else None
        line("window under it", f"{w['app']} — '{w['title']}'" if w else "none (the desktop)")
    _doctor_end(problems)


def _doctor_end(problems: list[str]) -> None:
    print("\n" + "=" * 66)
    if problems:
        print("  To fix:")
        for p in problems:
            print(f"   • {p}")
    else:
        print("  Everything the bot needs is working.")
    print("  Copy everything above and paste it into the chat if anything is wrong.")
    print("=" * 66)
