"""The command line: python -m baccarat.screen ...

A thin layer. Every command here is one call into the modules above plus the
printing of its result, so the CLI and the dashboard can never drift into
doing the job two different ways."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import cv2


from baccarat.errors import BetError
from baccarat.log import log, setup_logging
from baccarat.screen.board import (
    _board_crops, _save_board_debug, read_board_detailed, READ_FIELDS)
from baccarat.screen.capture import read_region, snap_region
from baccarat.screen.colors import (
    _color_dist, _color_feature, _load_colors, COLOR_MAX_DIST, read_color)
from baccarat.screen.coords import run_pattern
from baccarat.screen import desktop
from baccarat.screen.desktop import check_tools, get_cursor_pos, PLATFORM, YDOTOOL_SOCKET
from baccarat.screen.glyphs import (
    _binarize, _save_debug, _segment, digit_stats, font_of, forget_digits,
    read_number_detailed, set_font)
from baccarat.screen.pointer import _move_cursor, move_mouse
from baccarat.screen.road import read_road_detailed
from baccarat.screen.sites import (
    _load_meta, debug_dir, list_patterns, list_sites, load_coords, site_dir, site_name,
    use_site)
from baccarat.screen.wizards import (
    _step_display, capture_wizard, coords_wizard, teach_board_wizard, teach_color_wizard,
    teach_wizard)


def read_cli(name: str) -> None:
    r = read_number_detailed(name)
    img = read_region(name)
    b = _binarize(img, name)
    p = _save_debug(name, img, b, _segment(b), r["text"])
    per = "  ".join(f"{l}:{c:.2f}" for l, c in r["digits"])
    print(f"\n  {name} = {r['value']}   text={r['text']!r}  min conf={r['conf']:.2f}")
    print(f"  per digit: {per or '-'}\n  preview: {p}\n")


def read_board_cli(name: str = "board") -> None:
    img = read_region(name)
    r = read_board_detailed(name, img)
    crops, icons = _board_crops(img)
    prev = _save_board_debug(name, img, icons,
                             [r["texts"].get(f, "") or "?" for f in READ_FIELDS])
    print(f"\n  icons found: {r['icons']}   min conf {r['conf']:.2f}")
    for f in READ_FIELDS:
        print(f"    {f:12s} {r['texts'].get(f, '') or '?':>6s}")
    v = r["values"]
    if v:
        print(f"    {'tie':12s} {v['tie']:>6d}  (game - player - banker)")
    if r.get("note"):
        print(f"    note: {r['note']}")
    print(f"  → {v}\n  preview: {prev}\n")


def read_road_cli(name: str = "road") -> None:
    img = read_region(name)
    r = read_road_detailed(name, img)
    short = {"player": "P", "banker": "B", "tie": "T"}
    vis = cv2.resize(img, None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST)
    for i, ((x, y, rad), side) in enumerate(zip(r["beads"], r["road"]), 1):
        cv2.circle(vis, (int(x * 3), int(y * 3)), int(rad * 3), (0, 255, 0), 2)
        cv2.putText(vis, str(i), (int(x * 3) - 8, int(y * 3) + 6), cv2.FONT_HERSHEY_SIMPLEX,
                    0.55, (0, 255, 0), 2)
    debug_dir().mkdir(parents=True, exist_ok=True)
    out = debug_dir() / f"{name}_{time.strftime('%H%M%S')}.png"
    cv2.imwrite(str(out), vis)
    seq = " ".join(short[w] for w in r["road"]) or "-"
    counts = {k: r["road"].count(k) for k in short}
    print(f"\n  {len(r['road'])} results: {seq}")
    print(f"  player {counts['player']}  banker {counts['banker']}  tie {counts['tie']}   "
          f"pairs: {sum('player_pair' in p for p in r['pairs'])} player, "
          f"{sum('banker_pair' in p for p in r['pairs'])} banker")
    print(f"  preview (numbered in reading order): {out}\n")


def read_color_cli(name: str) -> None:
    label, d = read_color(name)
    ranking = sorted(((l, _color_dist(_color_feature(read_region(name)), r))
                      for l, r in _load_colors(name)), key=lambda x: x[1])
    best = {}
    for l, dd in ranking:
        best.setdefault(l, dd)
    print(f"\n  {name} = {label}   (distance {d:.1f}, max {COLOR_MAX_DIST:.0f})")
    print("  distances: " + "  ".join(f"{l}:{dd:.1f}" for l, dd in best.items()) + "\n")


# ---------------------------------------------------------------------------
# Show everything
# ---------------------------------------------------------------------------

def check_coords(prefix: str | None = None) -> None:
    """Move the mouse to each saved coordinate in turn, so you can see where they
    really are. Nothing is clicked. Use it to spot a badly recorded spot/chip/redo."""
    coords = load_coords()
    names = sorted(n for n in coords if not prefix or n.startswith(prefix))
    if not names:
        print(f"\nNo coordinates{f" starting with '{prefix}'" if prefix else ""}. "
              "Record them with: python bet.py --coords\n")
        return
    print(f"\n═══ CHECK COORDINATES ({len(names)}) ═══")
    print("  The mouse goes to each one. Nothing is clicked. Watch for any that land")
    print("  somewhere wrong, then re-record that one with --coords.\n")
    start = get_cursor_pos()
    for name in names:
        c = coords[name]
        input(f"  @{name:22s} ({c['x']}, {c['y']})  — Enter for the next one: ")
        move_mouse(c["x"], c["y"])
    if start:
        move_mouse(*start)
    print("\n  Done.\n")


def show_all() -> None:
    coords = load_coords()
    print()
    print("═══ COORDINATES ═══")
    if coords:
        for name, data in sorted(coords.items()):
            print(f"  @{name:20s}  ({data['x']}, {data['y']})  [{data.get('action','click')}]")
    else:
        print("  (none — run --coords)")

    patterns = list_patterns()
    print()
    print("═══ PATTERNS ═══")
    if patterns:
        for display, pd, count in patterns:
            meta = _load_meta(pd)
            print(f"\n  {display}  ({count} steps)")
            for j, s in enumerate(meta["steps"], 1):
                print(f"    {j}. {_step_display(s)}")
    else:
        print("  (none — run --capture)")
    print()


# ---------------------------------------------------------------------------
# Diagnose coordinate mapping
# ---------------------------------------------------------------------------

def diagnose() -> None:
    """Dump everything needed to debug cursor movement. Paste the whole output."""
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:
        pass

    def sh(cmd, max_lines=40):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            out = (r.stdout + r.stderr).strip()
            lines = out.splitlines()
            if len(lines) > max_lines:
                lines = lines[:max_lines] + [f"... ({len(lines) - max_lines} more lines)"]
            return r.returncode, "\n".join(lines)
        except Exception as e:
            return -1, f"<{type(e).__name__}: {e}>"

    def show(title, cmd, max_lines=40):
        rc, out = sh(cmd, max_lines)
        print(f"\n$ {' '.join(cmd)}   [rc={rc}]")
        for line in (out or "<no output>").splitlines():
            print(f"    {line}")
        return rc, out

    def pos():
        rc, out = sh(["hyprctl", "cursorpos"])
        return out

    def sect(t):
        print("\n" + "=" * 60 + f"\n  {t}\n" + "=" * 60)

    sect("ENVIRONMENT")
    for k in ("USER", "WAYLAND_DISPLAY", "XDG_RUNTIME_DIR", "HYPRLAND_INSTANCE_SIGNATURE",
              "YDOTOOL_SOCKET", "XDG_CURRENT_DESKTOP"):
        print(f"  {k} = {os.environ.get(k)!r}")
    print(f"  uid={os.getuid()}  python={sys.version.split()[0]}")
    for t in ("hyprctl", "ydotool", "ydotoold", "grim", "wtype"):
        print(f"  which {t}: {shutil.which(t)}")

    sect("HYPRLAND")
    show("version", ["hyprctl", "version"], 12)
    for opt in ("cursor:no_warps", "cursor:no_hardware_cursors", "cursor:use_cpu_buffer",
                "cursor:inactive_timeout", "cursor:hide_on_key_press",
                "input:sensitivity", "input:accel_profile", "input:force_no_accel"):
        show(opt, ["hyprctl", "getoption", opt], 6)
    rc, out = sh(["hyprctl", "monitors", "-j"])
    print(f"\n$ hyprctl monitors -j   [rc={rc}]")
    mon = None
    try:
        for m in json.loads(out):
            print(f"    {m.get('name')}: {m.get('width')}x{m.get('height')}@{m.get('refreshRate')}"
                  f"  pos=({m.get('x')},{m.get('y')})  scale={m.get('scale')}"
                  f"  transform={m.get('transform')}  focused={m.get('focused')}")
            if mon is None or m.get("focused"):
                mon = m
    except Exception as e:
        print(f"    could not parse: {e}\n    {out[:300]}")
    show("devices", ["hyprctl", "devices"], 60)

    sect("YDOTOOL")
    show("ydotoold proc", ["pgrep", "-a", "ydotoold"])
    show("socket", ["ls", "-l", YDOTOOL_SOCKET])

    # A reachable target near the centre of the focused monitor
    if mon:
        sc = float(mon.get("scale") or 1)
        cx = int(mon["x"] + mon["width"] / sc / 2)
        cy = int(mon["y"] + mon["height"] / sc / 2)
    else:
        cx, cy = 500, 500

    sect("MOVEMENT TESTS  (don't touch the mouse)")
    start = pos()
    print(f"\n  start cursorpos: {start}")

    def test(name, cmd):
        before = pos()
        rc, out = sh(cmd)
        time.sleep(0.25)
        after = pos()
        print(f"\n  [{name}]\n    cmd   : {' '.join(cmd)}\n    rc/out: {rc} {out!r}"
              f"\n    before: {before}\n    after : {after}")

    test("A hyprctl movecursor -> monitor centre",
         ["hyprctl", "dispatch", "movecursor", str(cx), str(cy)])
    test("B hyprctl movecursor -> centre +200,+100",
         ["hyprctl", "dispatch", "movecursor", str(cx + 200), str(cy + 100)])
    test("C hyprctl --batch movecursor -> centre",
         ["hyprctl", "--batch", f"dispatch movecursor {cx} {cy}"])
    test("A2 lua hl.dsp.cursor.move -> centre",
         ["hyprctl", "dispatch", f"hl.dsp.cursor.move({{ x = {cx}, y = {cy} }})"])
    test("B2 lua hl.dsp.cursor.move -> centre +200,+100",
         ["hyprctl", "dispatch", f"hl.dsp.cursor.move({{ x = {cx + 200}, y = {cy + 100} }})"])
    test("D ydotool relative +100,0",
         ["ydotool", "mousemove", "-x", "100", "-y", "0"])
    test("E ydotool relative +10,0",
         ["ydotool", "mousemove", "-x", "10", "-y", "0"])
    test("F ydotool absolute 500,500",
         ["ydotool", "mousemove", "--absolute", "-x", "500", "-y", "500"])

    sect("VISUAL CHECK")
    print("  Watch the cursor. It will jump between two points 3 times via Hyprland's cursor move.")
    input("  Press Enter to start …")
    for _ in range(3):
        _move_cursor(cx - 200, cy)
        time.sleep(0.4)
        _move_cursor(cx + 200, cy)
        time.sleep(0.4)
    print(f"  (used syntax: {getattr(desktop.get_backend(), '_MOVE_SYNTAX', None)})")
    a = input("  Did you SEE the cursor move? [y/n]: ").strip()
    print(f"  answer: {a!r}")
    print("  Now the same with ydotool relative moves.")
    input("  Press Enter to start …")
    for _ in range(3):
        sh(["ydotool", "mousemove", "-x", "-200", "-y", "0"])
        time.sleep(0.4)
        sh(["ydotool", "mousemove", "-x", "200", "-y", "0"])
        time.sleep(0.4)
    b = input("  Did you SEE the cursor move? [y/n]: ").strip()
    print(f"  answer: {b!r}")

    sect("END — paste everything above")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:

    p = argparse.ArgumentParser(
        prog="python -m baccarat.screen",description="Visual Automator – Wayland/Hyprland")
    p.add_argument("--coords", action="store_true", help="Record cursor positions.")
    p.add_argument("--capture", action="store_true", help="Build patterns from coordinates.")
    p.add_argument("--run", "-r", type=str, metavar="PAT", help="Run a pattern.")
    p.add_argument("--snap", type=str, metavar="NAME", help="Select a screen region (e.g. score).")
    p.add_argument("--teach", type=str, metavar="NAME", help="Teach the digits shown in a region.")
    p.add_argument("--font", type=str, metavar="SET",
                   help="With --teach/--snap: share one digit set between regions (e.g. counts).")
    p.add_argument("--read", type=str, metavar="NAME", help="Read the number in a region once.")
    p.add_argument("--read-road", nargs="?", const="road", metavar="NAME",
                   help="Read the bead road (the grid of results) once.")
    p.add_argument("--teach-board", nargs="?", const="board", metavar="NAME",
                   help="Teach the scoreboard bar (default region: board).")
    p.add_argument("--read-board", nargs="?", const="board", metavar="NAME",
                   help="Read the scoreboard bar once.")
    p.add_argument("--teach-color", type=str, metavar="NAME", help="Learn the color states of a region.")
    p.add_argument("--read-color", type=str, metavar="NAME", help="Show which color state a region is in.")
    p.add_argument("--forget-digits", type=str, metavar="NAME",
                   help="Throw away everything taught for a region's digits and start again. "
                        "Worth doing when a few bad examples got in early.")
    p.add_argument("--digits", type=str, metavar="NAME",
                   help="Show how many examples are stored for each character.")
    p.add_argument("--list", "-l", action="store_true", help="Show coordinates + patterns.")
    p.add_argument("--check-coords", nargs="?", const="", metavar="PREFIX",
                   help="Move the mouse to each saved coordinate (no clicks), e.g. --check-coords spot_")
    p.add_argument("--debug", action="store_true", help="Verbose output.")
    p.add_argument("--diagnose", action="store_true", help="Test coordinate mapping between hyprctl and ydotool.")
    p.add_argument("--doctor", action="store_true",
                   help="Check this machine can run the bot: permissions, screen capture, "
                        "mouse and keyboard. Paste the whole output when asking for help.")
    p.add_argument("--site", type=str, metavar="NAME",
                   help="Record for this site (made if it is new). Everything recorded after "
                        "it — coordinates, patterns, regions, digits, colours — goes in "
                        f"sites/NAME/, and it becomes the site in use. Now: {site_name() or '-'}")
    p.add_argument("--sites", action="store_true", help="List the sites and show which is in use.")
    args = p.parse_args()

    setup_logging(args.debug)
    if args.site:
        log.info("Site: %s  (%s)", use_site(args.site), site_dir())
    if args.sites:
        for n in list_sites() or ["(none yet)"]:
            print(f"  {'*' if n == site_name() else ' '} {n}")
        return
    try:
        check_tools()
        _dispatch_cli(p, args)
    except BetError as e:
        log.error("%s", e)
        sys.exit(1)
    except KeyboardInterrupt:
        print()


def _dispatch_cli(p, args) -> None:
    if args.forget_digits:
        n = forget_digits(args.forget_digits)
        print(f"\n  Forgot {n} example(s). Teach again with: "
              f"python bet.py --teach-board {args.forget_digits}\n")
    elif args.digits:
        st = digit_stats(args.digits)
        print(f"\n  '{args.digits}' digit set '{font_of(args.digits)}':")
        print("   " + ("  ".join(f"{k} ×{v}" for k, v in st.items()) if st else "nothing taught yet"))
        missing = [c for c in "0123456789" if c not in st]
        print(f"   missing: {''.join(missing) or 'none'}\n")
    elif args.coords:
        coords_wizard()
    elif args.capture:
        capture_wizard()
    elif args.run:
        run_pattern(args.run)
    elif args.snap:
        snap_region(args.snap)
        if args.font:
            set_font(args.snap, args.font)
    elif args.teach:
        if args.font:
            set_font(args.teach, args.font)
        teach_wizard(args.teach)
    elif args.read:
        read_cli(args.read)
    elif args.read_road:
        read_road_cli(args.read_road)
    elif args.teach_board:
        teach_board_wizard(args.teach_board)
    elif args.read_board:
        read_board_cli(args.read_board)
    elif args.teach_color:
        teach_color_wizard(args.teach_color)
    elif args.read_color:
        read_color_cli(args.read_color)
    elif args.check_coords is not None:
        check_coords(args.check_coords or None)
    elif args.list:
        show_all()
    elif args.diagnose or args.doctor:
        if PLATFORM == "macos":
            from baccarat.screen.macos import doctor
            doctor()
        else:
            diagnose()
    else:
        p.print_help()
