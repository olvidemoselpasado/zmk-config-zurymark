"""screen — everything that touches the actual screen, mouse and keyboard.

This was one 3,300-line file. It is now a layer with an inside and an outside,
and this list is the outside: the operations the rest of the program is allowed
to use. Anything not named here is that layer's own business.

The layer is a DAG, lowest first:

    log, errors           no dependencies
    sites                 where this site's recordings live
    desktop               the OS: hyprctl, grim, ydotool  <- the port lives here
    pointer    capture    input, and pixels
    numbers    glyphs     reading text out of pixels
    board  road  colors   reading the game out of text and colour
    coords                the recorded points and patterns
    window                the game window's width, saved and put back
    wizards               teaching it all, with a person at the terminal
    cli                   python -m baccarat.screen

Nothing lower ever imports anything higher, which is what stops this becoming
one file again.
"""

from __future__ import annotations

# Every import below is a re-export: that is this file's whole job.
# ruff: noqa: F401

# sites — which site is in use, and where its recordings live
from baccarat.screen.sites import (coords_file, debug_dir, DEFAULT_SITE, delete_site,
    forget_login, list_sites, load_coords, load_login, login_summary, save_login, site_dir,
    load_game_url, save_game_url,
    SITE_DIRS, SITE_FILES, site_name, site_slug, snaps_dir, use_site)

# desktop — the operating system — the whole of the porting job
from baccarat.screen.desktop import (cpu_seconds, find_pids, get_cursor_pos, machine_cpu,
                                      PLATFORM, RELOAD_KEY, YDOTOOL_SOCKET)

# pointer — moving and clicking like a hand
from baccarat.screen.pointer import (_hold_off_same_spot, _LAST_PRESS, CLICK_PAUSE,
    CLICK_SPEED, end_click_run, MOVE_CAP, MOVE_CURVE, MOVE_HZ, MOVE_STEPS_MAX,
    MOVE_TIME_MAX, MOVE_TIME_MIN, MOVE_TYPICAL, MOVE_WOBBLE, OVERSHOOT_CHANCE,
    press_key, SAME_SPOT_GAP, SAME_SPOT_PX, same_spot_wait, SCROLL_KEY, scroll_list,
    SCROLL_PAUSE, set_click_speed, set_move_speed, SETTLE_CHANCE, start_click_run,
    type_private, type_text)

# capture — screenshots and the rectangles we read
from baccarat.screen.capture import (_retry_gap, FAIL_BACKOFF, FAIL_GRACE,
    MATCH_THRESHOLD, region_difference, save_screenshot, SHOTS, shots_taken,
    shots_by_region, shot_times)

# regions — every region the bot reads, and what each one needs
from baccarat.screen.regions import region_slots, selected_name, slot_of, SLOTS, stored_name

# numbers — how a table writes money
from baccarat.screen.numbers import (_parse_number, _resolve_separators,
    format_from_example, save_number_format, SEP_CHARS, set_number_format)

# glyphs — reading text by matching characters
from baccarat.screen.glyphs import (_binarize, _ink_distance, _ink_file, _segment,
    _text_rows, forget_digits, forget_ink, GLYPH_BLUR, GLYPH_SIZE, ink_of,
    MAX_SAMPLES, READ_MIN_CONF, READ_MIN_MARGIN, read_number, read_number_stable,
    SAMPLE_DUPLICATE, save_ink, SYMBOLS)

# board — the scoreboard bar: game number and P/B/T
from baccarat.screen.board import (_LAST_BOARD, BOARD_COUNTS, BOARD_FIELDS,
    board_frame, board_present, BOARD_REQUIRED, board_trouble, forget_board,
    ICON_HUES, ICON_MIN_SAT, ICON_MIN_VAL, N_ICONS, PAIR_FIELDS, read_board,
    read_board_detailed, read_board_stable, READ_FIELDS, teach_board_from)

# road — the big road
from baccarat.screen.road import (read_road)

# colors — telling one look of a region from another
from baccarat.screen.colors import (bets_open, COLOR_MAX_DIST, COLOR_NEW_LOOK,
    forget_colors, OPEN_LABEL, SHUT_LABEL, teach_color_sample, TRIGGER_MARGIN,
    trigger_ready, TRIGGER_REGIONS)

# coords — the recorded points, regions and patterns
from baccarat.screen.coords import (click_coord, COLOUR_REGIONS, COORD_ACTIONS,
    coord_list, delete_coord, delete_pattern, delete_region, grab_region,
    nudge_coord, number_frame, pattern_detail, pattern_names, record_coord,
    region_kind, region_list, rename_coord, run_pattern, save_pattern, show_coord,
    teach_number_from)

# window — the game window's width, saved per site and put back with one button
from baccarat.screen.window import (ensure_game_window, find_game_window, fit_game_window,
    forget_window, save_game_window, saved_window, window_status)

# shared by the whole program, not just this layer
from baccarat.log import DEBUG, log, setup_logging
from baccarat.errors import BetError

from baccarat.screen import board, capture, colors, coords, desktop, glyphs
from baccarat.screen import numbers, pointer, road, sites, wizards  # noqa: F401

# `from baccarat.screen import *` skips names that start with an underscore, and
# a few tests reach for those on purpose to pin down the reading. So the list is
# explicit rather than implied.
__all__ = [_n for _n in list(globals()) if not _n.startswith("__")]

# Picking the site happens on import, as it always has: every entry point --
# the CLI, the dashboard, a test -- needs a site chosen before it can read or
# record anything, and having each of them remember to do it is how they end up
# disagreeing. use_site() overrides it at any time.
sites._start_site()

# the score's digits: which were never taught, and learning them from known balances
from baccarat.screen.glyphs import learn_from_known, missing_digits  # noqa: E402,F401
from baccarat.screen.numbers import format_number, number_format  # noqa: E402,F401
