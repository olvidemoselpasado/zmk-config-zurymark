"""Reading the scoreboard bar: the game number and the P/B/T counters.

This is the single most important reading in the program. The strategy decides
from the results, so a misread counter is not a cosmetic problem: it is a bet
placed on a road that never happened.

So it is read defensively. The P/B/T icons are found by their own hues and used
to locate the numbers rather than trusting fixed offsets; each field is read
with a confidence; and _reconcile refuses the whole read rather than return a
half-right one. A value that has changed is confirmed by a second screenshot
before it is believed, while a value that merely repeats what we are already
working from costs one read."""

from __future__ import annotations

import itertools
import time
from pathlib import Path
import cv2
import numpy as np


from baccarat.errors import BetError
from baccarat.log import DEBUG, log
from baccarat.screen import capture
from baccarat.screen.capture import _retry_gap, read_region
from baccarat.screen.glyphs import (
    _binarize, _keep_sample, _load_templates, _match, _normalize_glyph, _read_glyphs,
    _segment, _TEMPLATE_CACHE, digit_stats, font_of, READ_MIN_CONF)
from baccarat.screen.sites import debug_dir, digits_dir


# ---------------------------------------------------------------------------
# Scoreboard bar   "# 30  (P) 13  (B) 13  (T) 4  (o) 0  (o) 1"
#
# The numbers shift left/right as they gain digits, so fixed boxes don't work.
# Instead we capture the WHOLE bar and use the round icons as landmarks:
# each number is whatever sits between one icon and the next.
#
#   --snap board        select the whole bar (just inside its outline)
#   --teach-board       type the 6 numbers you see, a few times
#   --read-board        test
# ---------------------------------------------------------------------------

BOARD_FIELDS = ["game", "player", "banker", "tie", "player_pair", "banker_pair"]


PAIR_FIELDS = ("player_pair", "banker_pair")


N_ICONS = 5                              # the round icons on the bar, when all are there


# Only three numbers are actually read: the game number, player and banker. The ties
# follow from them — the game number counts every hand, so tie = game − player − banker
# — and that is better than reading a fourth number, because it CHECKS the other three:
# a misread digit almost always makes the sum impossible, and an impossible read is
# thrown away instead of being acted on. The pair counts are not used for anything.
READ_FIELDS = ["game", "player", "banker"]


# The P/B/T icons are strongly coloured and the digits are grey, so colour tells them
# apart however small the text is. (OpenCV hue is 0–179; red wraps around 0.)
ICON_HUES = {"player": (95, 135), "banker": (150, 12), "tie": (40, 90)}


ICON_MIN_SAT = 90


ICON_MIN_VAL = 110


def _hue_in(h: float, lo: float, hi: float) -> bool:
    return (lo <= h <= hi) if lo <= hi else (h >= lo or h <= hi)


def _pbt_icons(img: np.ndarray) -> dict | None:
    """Find the blue player, red banker and green tie icons by their colour.
    → {"player": (x,y,w,h), …}, or None when all three aren't clearly there."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    _, S, V = cv2.split(hsv)
    mask = ((S > ICON_MIN_SAT) & (V > ICON_MIN_VAL)).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    found: dict = {}
    for i in range(1, n):
        x, y, w, h, area = (int(v) for v in st[i])
        if area < 10 or w > 0.4 * img.shape[1] or not 0.55 <= w / max(1, h) <= 1.8:
            continue
        pix = hsv[y:y + h, x:x + w][lab[y:y + h, x:x + w] == i]
        if not len(pix):
            continue
        hue = float(np.median(pix[:, 0]))
        for side, (lo, hi) in ICON_HUES.items():
            if _hue_in(hue, lo, hi) and (side not in found or area > found[side][4]):
                found[side] = (x, y, w, h, area)     # biggest blob of each colour wins
    if len(found) != 3:
        return None
    boxes = {k: v[:4] for k, v in found.items()}
    xs = [boxes[k][0] for k in ("player", "banker", "tie")]
    if not xs[0] < xs[1] < xs[2]:            # they must sit in that order on the bar
        return None
    hs = [b[3] for b in boxes.values()]
    if max(hs) > 2.0 * min(hs):              # wildly different sizes: not the icons
        return None
    return boxes


def _bar_region(img: np.ndarray) -> np.ndarray:
    """Find the bar's row band inside the saved region, so the region doesn't have to
    hug the bar pixel-for-pixel: a few pixels of page movement, or a generous
    selection, would otherwise make every read fail. The P/B/T icons are strongly
    coloured, so they can be found whatever surrounds the bar. Falls back to the
    whole region when they can't be found."""
    _, sat, val = cv2.split(cv2.cvtColor(img, cv2.COLOR_BGR2HSV))
    n, _, st, cent = cv2.connectedComponentsWithStats(
        ((sat > 80) & (val > 60)).astype(np.uint8), connectivity=8)
    blobs = [(int(st[i][1]), int(st[i][3]), float(cent[i][1]), int(st[i][0]), int(st[i][2]))
             for i in range(1, n)
             if st[i][4] >= 15 and 0.55 <= st[i][2] / max(1, st[i][3]) <= 1.8]
    if len(blobs) < 2:
        return img
    mid = lambda xs: sorted(xs)[len(xs) // 2]
    ih = mid([b[1] for b in blobs])                       # icon height
    blobs = [b for b in blobs if abs(b[1] - ih) <= 0.4 * ih]
    if len(blobs) < 2:
        return img
    cy = mid([b[2] for b in blobs])
    blobs = [b for b in blobs if abs(b[2] - cy) <= 0.7 * ih]      # icons share a row
    if len(blobs) < 2:
        return img
    top = max(0, int(round(min(b[0] for b in blobs) - 0.15 * ih)))
    bot = min(img.shape[0], int(round(max(b[0] + b[1] for b in blobs) + 0.15 * ih)))
    band = img[top:bot]
    if not band.size:
        return img
    # trim sideways too: the bar's panel colour is whatever fills the strip between
    # the first and last icon, so the bar ends where that colour stops
    x_lo = max(0, min(b[3] for b in blobs))
    x_hi = min(band.shape[1], max(b[3] + b[4] for b in blobs))
    if x_hi - x_lo < 2:
        return band
    # the panel is the commonest colour in the band (a median would be dragged
    # towards the icons and digits sitting on it)
    flat = band.reshape(-1, 3)
    q = (flat // 16).astype(np.int32)
    key = q[:, 0] * 1024 + q[:, 1] * 32 + q[:, 2]
    vals, counts = np.unique(key, return_counts=True)
    panel = flat[key == vals[counts.argmax()]].mean(axis=0)
    near = (np.linalg.norm(band.astype(np.float32) - panel, axis=2) < 45)
    cols = (near.mean(axis=0) > 0.3).astype(np.uint8)
    k = max(3, int(2.5 * ih) | 1)                  # bridge the icons themselves
    cols = cv2.morphologyEx(cols.reshape(1, -1), cv2.MORPH_CLOSE, np.ones((1, k), np.uint8))[0]
    left, right = x_lo, x_hi
    while left > 0 and cols[left - 1]:
        left -= 1
    while right < band.shape[1] and cols[right]:
        right += 1
    return band[:, left:right] if right - left >= x_hi - x_lo else band


def _find_icons(img: np.ndarray) -> list[tuple[int, int, int, int]]:
    """Round icons = the biggest roughly-square blobs that differ from the
    bar's background. Returns boxes (x, y, w, h) left to right."""
    H, W = img.shape[:2]
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB).astype(np.float32)
    bg = np.median(lab.reshape(-1, 3), axis=0)          # background = most of the bar
    mask = (np.linalg.norm(lab - bg, axis=2) > 25).astype(np.uint8)
    n, _, st, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    comps = [tuple(int(v) for v in st[i][:4]) for i in range(1, n)
             if st[i][2] < 0.5 * W and st[i][4] >= 12]
    if not comps:
        return []
    tallest = max(c[3] for c in comps)
    icons = [c for c in comps if c[3] >= 0.75 * tallest and 0.7 <= c[2] / c[3] <= 1.4]
    if len(icons) == N_ICONS:
        return sorted(icons)
    # Too many or too few. A fat digit can look like an icon once the page renders it
    # a shade blurrier, and then the whole bar fails to read. The icons are the thing
    # on this bar that is round, tall and EVENLY SPACED, so when the simple filter is
    # wrong, pick the five that best fit that description.
    loose = [c for c in comps if c[3] >= 0.55 * tallest and 0.55 <= c[2] / c[3] <= 1.8]
    loose = sorted(loose, key=lambda c: -c[2] * c[3])[:10]        # biggest candidates
    if len(loose) < N_ICONS:
        return sorted(icons)
    best, best_cost = None, None
    for combo in itertools.combinations(sorted(loose), N_ICONS):
        mids = [c[0] + c[2] / 2 for c in combo]
        gaps = np.diff(mids)
        if gaps.min() <= 0:
            continue
        spacing = float(np.std(gaps) / np.mean(gaps))             # 0 = perfectly even
        shape = float(np.mean([abs(c[2] / c[3] - 1) for c in combo]))
        size = float(np.std([c[3] for c in combo]) / max(1, np.mean([c[3] for c in combo])))
        cost = 2.0 * spacing + shape + size
        if best_cost is None or cost < best_cost:
            best, best_cost = combo, cost
    if best is None or best_cost > 0.9:              # nothing convincing: say so honestly
        return sorted(icons)
    return sorted(best)


def _board_crops(img: np.ndarray):
    """Split the bar into one crop per READ_FIELD, using the coloured icons as
    separators: the game number sits left of the blue one, the player count between
    blue and red, the banker count between red and green. Nothing right of the green
    icon is read at all, so the grey pair icons can't upset anything.
    → (crops, icons); crops is None when the three icons weren't found."""
    pbt = _pbt_icons(img)
    if pbt is None:
        return None, _find_icons(img)
    pad = 2
    px, _, pw, _ = pbt["player"]
    bx, _, bw, _ = pbt["banker"]
    tx = pbt["tie"][0]
    spans = [(0, px - pad), (px + pw + pad, bx - pad), (bx + bw + pad, tx - pad)]
    crops = [img[:, max(0, s):max(0, e)] for s, e in spans]
    if any(c.shape[1] < 3 for c in crops):
        return None, [pbt[k] for k in ("player", "banker", "tie")]
    return crops, [pbt[k] for k in ("player", "banker", "tie")]


def _last_word(boxes):
    """Keep the last group of glyphs ('# 30' → '30'), split on wide gaps."""
    if len(boxes) < 2:
        return boxes
    tallest = max(b[3] for b in boxes)
    start = 0
    for i in range(1, len(boxes)):
        gap = boxes[i][0] - (boxes[i - 1][0] + boxes[i - 1][2])
        if gap > 0.3 * tallest:
            start = i
    return boxes[start:]


def _read_field(name: str, crop: np.ndarray, field: str):
    if crop.shape[1] < 3:
        return None, "", 0.0
    b = _binarize(crop)
    boxes = [bx for bx in _segment(b) if bx[4] == "digit"]
    has_hash = any(t[0] == "#" for t in _load_templates(name))
    if field == "game" and not has_hash:
        boxes = _last_word(boxes)             # '#' not learned yet: split on the gap
    glyphs = _read_glyphs(name, b, boxes)
    text = "".join(l for l, _ in glyphs).lstrip("#")
    conf = min((c for l, c in glyphs if l.isdigit()), default=0.0)
    value = int(text) if text.isdigit() and conf >= READ_MIN_CONF else None
    return value, text, conf


def _save_board_debug(name, img, icons, texts) -> Path:
    debug_dir().mkdir(parents=True, exist_ok=True)
    k = max(1, round(120 / max(1, img.shape[0])))
    vis = cv2.resize(img, None, fx=k, fy=k, interpolation=cv2.INTER_NEAREST)
    for x, y, w, h in icons:
        cv2.rectangle(vis, (x * k, y * k), ((x + w) * k - 1, (y + h) * k - 1), (0, 200, 0), 2)
    bar = np.full((28, vis.shape[1], 3), 255, np.uint8)
    cv2.putText(bar, f"icons: {len(icons)}/3   " + "  ".join(texts), (4, 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 1)
    out = debug_dir() / f"{name}_{time.strftime('%H%M%S')}.png"
    cv2.imwrite(str(out), np.vstack([bar, vis]))
    return out


# The bar checks itself: the game number is exactly how many hands have been played,
# so   game == player + banker + tie   always. That one fact does a lot of work:
#   • any one of those four can be WORKED OUT from the other three, so a digit that
#     won't read doesn't have to sink the whole bar;
#   • and when all four do read, a set that breaks the sum is a misread, caught before
#     it can be believed — which no amount of per-digit confidence can tell you.
# The pair counters take no part in it; nothing is bet on them.
BOARD_COUNTS = ("game", "player", "banker", "tie")


BOARD_REQUIRED = ("game", "player", "banker")


def _reconcile(values: dict, confs: dict) -> tuple[dict, str]:
    """Use game == player + banker + tie to fill a gap or catch a misread.
    → (values, note). values is {} when it cannot be made to add up."""
    v = {f: values.get(f) for f in BOARD_COUNTS}
    missing = [f for f in BOARD_COUNTS if v[f] is None]

    def derive(f):
        if f == "game":
            return v["player"] + v["banker"] + v["tie"]
        return v["game"] - sum(v[o] for o in BOARD_COUNTS[1:] if o != f)

    if len(missing) == 1:
        f = missing[0]
        got = derive(f)
        if got < 0:
            return {}, f"{f} would have to be {got}"
        v[f] = got
        return v, f"{f} worked out from the others ({got})"
    if missing:
        return {}, f"{', '.join(missing)} unreadable"
    if v["game"] == v["player"] + v["banker"] + v["tie"]:
        return v, ""
    # all four read but they do not add up: the least certain one is the suspect
    suspect = min(BOARD_COUNTS, key=lambda f: confs.get(f, 0.0))
    was, v[suspect] = v[suspect], None
    got = derive(suspect)
    v[suspect] = got
    if got < 0 or confs.get(suspect, 0.0) > 0.95:
        return {}, (f"{v['player']}+{v['banker']}+{v['tie']} is not game {values['game']}")
    return v, (f"{suspect} read {was} but the others say {got} — taking {got}")


def read_board_detailed(name: str = "board", img: np.ndarray | None = None) -> dict:
    """{"values": {"game":30,"player":13,…} or None, "texts": {...}, "conf": float, "icons": n}"""
    if not any(t[0].isdigit() for t in _load_templates(name)):
        raise BetError(f"No digits taught for '{name}' yet. Interface tab → the '{name}' "
                       f"region → Teach digits, or run: python bet.py --teach-board {name}")
    if img is None:
        img = read_region(name)
    img = _bar_region(img)                  # locate the bar inside the saved region
    crops, icons = _board_crops(img)
    if crops is None:
        if DEBUG:
            log.debug("board: found %d icons, expected 5 → %s", len(icons),
                      _save_board_debug(name, img, icons, []))
        return {"values": None, "texts": {}, "conf": 0.0, "icons": len(icons)}
    values, texts, confs = {}, {}, {}
    for field, crop in zip(READ_FIELDS, crops):
        v, t, c = _read_field(name, crop, field)
        values[field], texts[field], confs[field] = v, t, c
    counts, note = _reconcile(values, confs)
    out = dict(counts)
    for f in PAIR_FIELDS:                   # decoration: never worth failing a read for
        out[f] = values.get(f) if values.get(f) is not None else 0
    ok = bool(counts) and all(out.get(f) is not None for f in BOARD_REQUIRED)
    if note:
        (log.debug if ok else log.debug)("board: %s", note)
    if not ok and DEBUG:
        log.debug("board read incomplete %s (%s) → %s", texts, note,
                  _save_board_debug(name, img, icons, [texts[f] or "?" for f in READ_FIELDS]))
    return {"values": out if ok else None, "texts": texts, "note": note,
            "conf": min(confs.get(f, 0.0) for f in BOARD_REQUIRED), "icons": len(icons)}


def board_present(img: np.ndarray | None = None, name: str = "board") -> bool:
    """Is a table on screen right now? This looks only for the bar's three coloured
    icons, never at the digits, so it answers even before anything has been taught —
    which is what makes it safe to ask 'is the lobby showing, or a table?'"""
    if img is None:
        try:
            img = read_region(name)
        except (BetError, Exception):
            return False
    try:
        return _pbt_icons(_bar_region(img)) is not None
    except Exception:
        return False


def board_trouble(name: str = "board") -> tuple[str, Path | None]:
    """Why the bar can't be read right now, plus a picture of what the region caught.
    Saves the picture in debug/ so it can be shown on the dashboard."""
    try:
        img = read_region(name)
    except BetError as e:
        return str(e), None
    bar = _bar_region(img)
    crops, icons = _board_crops(bar)
    shot = _save_board_debug(name, bar, icons, [])
    if crops is None:
        return ("couldn't find the blue, red and green icons — the bar looks covered, off "
                "the edge of the region, or the region needs selecting again "
                "(Interface tab, Select again)"), shot
    r = read_board_detailed(name, img)
    if r["values"] is not None:
        return "it reads now — that was a passing glitch", shot
    read = "  ".join(f"{f} {r['texts'].get(f) or '?'}" for f in READ_FIELDS)
    if r.get("note"):
        return f"read {read} — {r['note']}", shot
    never = [c for c in "0123456789" if c not in digit_stats(name)]
    tail = (f" The bar is showing a digit that has never been taught: no examples of "
            f"{', '.join(never)} yet, and '?' means a character it couldn't place. Teach it "
            f"on THIS hand — the numbers change every game, so a digit can only be learned "
            f"while it is on screen."
            if never else
            " Every digit has examples, so this is one awkward rendering. Teaching this hand "
            "too gives it another example of that shape.")
    return f"read {read} (confidence {r['conf']:.2f}).{tail}", shot


def read_board(name: str = "board") -> dict | None:
    """All numbers of the bar: {"game", "player", "banker", "tie",
    "player_pair", "banker_pair"} or None if anything was unreadable."""
    return read_board_detailed(name)["values"]


_LAST_BOARD: dict = {}          # region name → the last value we accepted


def forget_board(name: str = "board") -> None:
    """Drop what we think the bar says — after changing table, for instance."""
    _LAST_BOARD.pop(name, None)


def read_board_stable(name: str = "board", samples: int = 2, interval: float | None = None,
                      timeout: float = 3.0) -> dict | None:
    """Read until `samples` consecutive reads agree. None on timeout.

    A read that says exactly what the last accepted read said is taken at once. The
    point of reading twice is to avoid acting on a half-drawn frame, and a frame that
    repeats the value we are already working from is not asking us to act on anything.
    Only a value that has *changed* is confirmed with a second capture. On a table
    where nothing moves for ten seconds at a stretch, this is about half the
    screenshots — and a screenshot costs the compositor a whole frame copy, which is
    what makes the game stutter."""
    interval = capture.CONFIRM_GAP if interval is None else interval
    end = time.monotonic() + timeout
    last, streak, fails = None, 0, 0
    while time.monotonic() < end:
        v = read_board(name)
        if v is not None and v == _LAST_BOARD.get(name):
            return v                                    # unchanged: nothing to confirm
        fails = 0 if v is not None else fails + 1
        streak = streak + 1 if (v is not None and v == last) else (1 if v else 0)
        last = v
        if streak >= samples:
            _LAST_BOARD[name] = v
            return v
        time.sleep(_retry_gap(interval, fails))
    return None


def board_frame(name: str = "board") -> dict:
    """One look at the bar, for teaching from somewhere other than a terminal:
    a picture of what was caught, what it reads right now, and what has been taught.
    The frame itself comes back too, so the digits can be learned from the very same
    pixels that were shown rather than from a later, different one."""
    img = read_region(name)
    bar = _bar_region(img)
    crops, icons = _board_crops(bar)
    texts, values, note = {}, None, ""
    if crops is not None and any(x[0].isdigit() for x in _load_templates(name)):
        r = read_board_detailed(name, img)
        texts, values, note = r["texts"], r["values"], r.get("note", "")
    shot = _save_board_debug(name, bar, icons,
                             [texts.get(f) or "?" for f in READ_FIELDS] if texts else [])
    return {"frame": img, "shot": shot, "ready": crops is not None,
            "icons": len(icons), "texts": texts, "values": values, "note": note,
            "digits": digit_stats(name),
            "glyphs": None if crops is None else
                      [len([bx for bx in _segment(_binarize(c)) if bx[4] == "digit"])
                       for c in crops]}


def teach_board_from(name: str, img: np.ndarray, typed: dict) -> dict:
    """Learn the digits of one captured frame from what a person says it says.
    typed = {"game": "30", "player": "13", "banker": "13"} — the three numbers left of
    the green icon. → {"kept": n, "fields": [...], "problems": [...], "digits": {...}}"""
    crops, _ = _board_crops(_bar_region(img))
    if crops is None:
        raise BetError("the blue, red and green icons weren't all in that picture")
    font = font_of(name)
    d = digits_dir() / font
    d.mkdir(parents=True, exist_ok=True)
    kept, fields, problems = 0, [], []
    # the three numbers have to make sense together, or something was mistyped: every
    # hand is a player win, a banker win or a tie, so there can't be more wins than hands
    nums = {f: str(typed.get(f, "")).strip() for f in READ_FIELDS}
    if all(v.isdigit() for v in nums.values()):
        g, pl, bk = (int(nums[f]) for f in READ_FIELDS)
        if pl + bk > g:
            return {"kept": 0, "fields": [], "digits": digit_stats(name),
                    "problems": [f"{pl} player + {bk} banker is more than {g} hands — "
                                 f"check the numbers before I learn them"]}
    known = _load_templates(name)
    for field, crop in zip(READ_FIELDS, crops):
        want = nums[field]
        if not want:
            continue
        if not want.isdigit():
            problems.append(f"{field}: '{want}' is not a whole number")
            continue
        b = _binarize(crop)
        boxes = [bx for bx in _segment(b) if bx[4] == "digit"]
        chars = want
        if field == "game" and len(boxes) == len(want) + 1:
            chars = "#" + want                    # the '#' before the game number
        if len(boxes) != len(chars):
            problems.append(f"{field}: you typed {want} but I can see "
                            f"{len(boxes)} character(s) there")
            continue
        # don't let a slip overwrite what is already known: a character the templates
        # already recognise with near-certainty, being taught as something else, is a
        # typo far more often than it is a correction
        clash = ""
        if known:
            for ch, bx in zip(chars, boxes):
                lab, c = _match(_normalize_glyph(b, bx), known)
                if lab != ch and c >= 0.95:
                    clash = (f"{field}: that character is already a clear '{lab}' and you "
                             f"typed '{ch}'. If the old one is wrong, use Forget digits first")
                    break
        if clash:
            problems.append(clash)
            continue
        kept += sum(_keep_sample(d, ch, _normalize_glyph(b, bx))
                    for ch, bx in zip(chars, boxes))
        fields.append(field)
    _TEMPLATE_CACHE.pop(font, None)
    log.info("Board teaching: learned from %s — %d new example(s). Stored: %s",
             ", ".join(fields) or "nothing", kept, digit_stats(name))
    return {"kept": kept, "fields": fields, "problems": problems, "digits": digit_stats(name)}
