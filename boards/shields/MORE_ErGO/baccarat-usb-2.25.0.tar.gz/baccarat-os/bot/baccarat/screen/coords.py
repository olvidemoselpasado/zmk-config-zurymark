"""The recorded coordinates, regions and click patterns -- the CRUD behind the
dashboard's Interface tab.

A coordinate is one point and one action. A region is a rectangle that gets
read. A pattern is several steps in order, for the things one click cannot do
(opening a table, closing it, scrolling a lobby). All of it is editable from
the dashboard without re-recording from scratch, which is the difference
between a setup you can fix and one you have to redo."""

from __future__ import annotations

import random
import re
import shutil
import time
import cv2
import numpy as np


from baccarat.errors import BetError
from baccarat.log import log
from baccarat.screen.capture import read_region
from baccarat.screen.colors import color_stats, trigger_ready
from baccarat.screen.regions import kind_of
from baccarat.screen import desktop
from baccarat.screen.desktop import get_cursor_pos
from baccarat.screen.glyphs import (
    _binarize, _keep_sample, _load_templates, _match, _normalize_glyph, _save_debug,
    _segment, _TEMPLATE_CACHE, digit_stats, font_of, ink_of, READ_MIN_CONF,
    read_number_detailed)
from baccarat.screen.numbers import number_format
from baccarat.screen.pointer import click, move_mouse, type_text
from baccarat.screen.sites import (
    _load_meta, _pattern_dir, _save_meta, _slug, digits_dir, list_patterns, load_coords,
    save_coords, snaps_dir)


# ---------------------------------------------------------------------------
# Run a pattern
# ---------------------------------------------------------------------------

def run_pattern(name: str) -> None:
    pd = _pattern_dir(name)
    meta = _load_meta(pd)
    steps = meta["steps"]
    coords = load_coords()

    if not steps:
        raise BetError(f"Pattern '{name}' not found or empty.")

    desktop.ensure_input()

    display = _slug(name).replace("_", " ")
    log.info("Running '%s' (%d steps)", display, len(steps))

    for i, step in enumerate(steps, 1):
        action = step.get("action", "click")
        coord_name = step.get("coord", "")
        desc = step.get("desc") or coord_name

        if coord_name and coord_name not in coords:
            raise BetError(f"Step {i}: coordinate '@{coord_name}' not found. Run --coords to add it.")

        if coord_name:
            cx, cy = coords[coord_name]["x"], coords[coord_name]["y"]

        if action == "click":
            log.info("  Step %d/%d: click @%s (%d,%d)", i, len(steps), desc, cx, cy)
            click(cx, cy)
        elif action == "type":
            text = step.get("text", "")
            enter = step.get("enter", False)
            if coord_name:
                log.info("  Step %d/%d: click @%s then type '%s'", i, len(steps), coord_name, desc)
                click(cx, cy)
                time.sleep(random.uniform(0.05, 0.1))
            log.info("  Step %d/%d: type '%s'%s", i, len(steps), text[:30], " + Enter" if enter else "")
            type_text(text, enter=enter)

        time.sleep(random.uniform(0.08, 0.2))

    log.info("✓ Done.")


def click_coord(name: str, button: str = "left") -> None:
    """Click a saved coordinate by name (see --coords)."""
    coords = load_coords()
    if name not in coords:
        raise BetError(f"Coordinate '@{name}' not found. Run --coords to add it.")
    click(coords[name]["x"], coords[name]["y"], button)


def pattern_names() -> list[str]:
    """Names of all saved patterns."""
    return [d.name for _, d, _ in list_patterns()]


# ---------------------------------------------------------------------------
# Editing the set-up from somewhere other than a terminal
#
# The wizards above talk to a person through input() and print(). These do the
# same jobs as plain calls that return data, so the dashboard can offer the whole
# set-up without anyone opening a console. Both write the same files.
# ---------------------------------------------------------------------------

COORD_ACTIONS = ("click", "right_click", "type")


def coord_list() -> list[dict]:
    """Every saved coordinate, as rows: {"name", "x", "y", "action", …}."""
    return [{"name": n, **d} for n, d in sorted(load_coords().items())]


def record_coord(name: str, action: str = "click", delay: float = 3.0,
                 text: str = "", enter: bool = True) -> dict:
    """Wait `delay` seconds — time to put the pointer where it belongs — then save
    wherever it ended up under `name`. Nothing is clicked."""
    name = (name or "").strip()
    if not name:
        raise BetError("give the coordinate a name, e.g. spot_player_1")
    if action not in COORD_ACTIONS:
        raise BetError(f"unknown action '{action}' (one of {', '.join(COORD_ACTIONS)})")
    time.sleep(max(0.0, float(delay)))
    pos = get_cursor_pos()
    if pos is None:
        raise BetError("couldn't read the cursor position — is hyprctl on PATH?")
    coords = load_coords()
    row = {"x": pos[0], "y": pos[1], "action": action}
    if action == "type":
        row["text"], row["enter"] = text, bool(enter)
    coords[name] = row
    save_coords(coords)
    log.info("Coordinate '%s' saved at (%d, %d) → %s", name, pos[0], pos[1], action)
    return {"name": name, **row}


def delete_coord(name: str) -> None:
    coords = load_coords()
    if name not in coords:
        raise BetError(f"there is no coordinate called '{name}'")
    del coords[name]
    save_coords(coords)
    log.info("Coordinate '%s' deleted.", name)


def rename_coord(old: str, new: str) -> None:
    new = (new or "").strip()
    coords = load_coords()
    if old not in coords:
        raise BetError(f"there is no coordinate called '{old}'")
    if not new:
        raise BetError("the new name can't be empty")
    if new != old and new in coords:
        raise BetError(f"'{new}' is taken")
    coords[new] = coords.pop(old)
    save_coords(coords)
    log.info("Coordinate '%s' renamed to '%s'.", old, new)


def nudge_coord(name: str, dx: int = 0, dy: int = 0) -> dict:
    """Shift a saved coordinate by a few pixels, for fixing one that is slightly off."""
    coords = load_coords()
    if name not in coords:
        raise BetError(f"there is no coordinate called '{name}'")
    coords[name]["x"] = int(coords[name]["x"]) + int(dx)
    coords[name]["y"] = int(coords[name]["y"]) + int(dy)
    save_coords(coords)
    return {"name": name, **coords[name]}


def show_coord(name: str) -> dict:
    """Move the pointer onto a saved coordinate so you can see where it really is.
    Nothing is clicked."""
    coords = load_coords()
    if name not in coords:
        raise BetError(f"there is no coordinate called '{name}'")
    x, y = int(coords[name]["x"]), int(coords[name]["y"])
    move_mouse(x, y)
    return {"name": name, "x": x, "y": y}


# What a region holds decides how (and whether) it can be taught: the scoreboard bar
# holds three numbers side by side, the score holds one, the road is a grid of coloured
# circles with no text in it at all, the chips are told apart by how they look, and
# the logged-in box is compared with its own picture. The list is in regions.py; a
# name not on it is read by nothing, and used to be offered 'Teach digits' anyway.
COLOUR_REGIONS = ("road",)


def region_kind(name: str) -> str:
    return kind_of(name)


def _why_not_a_number(name: str, r: dict) -> str:
    """In words, why a reading was refused — the format it is held to, or the characters
    that couldn't be placed."""
    if not r["text"]:
        return "nothing readable in it yet"
    if "?" in r["text"]:
        return f"read '{r['text']}' — ? is a character it couldn't place"
    if r["conf"] < READ_MIN_CONF:
        return f"read '{r['text']}' but only at {r['conf']:.2f} confidence"
    fmt = number_format(name)
    want = []
    if fmt.get("symbol") and any(x[0] == fmt["symbol"] for x in _load_templates(name)):
        want.append(f"have {fmt['symbol']} at the {fmt.get('symbol_at', 'start')}")
    if fmt.get("decimals") is not None:
        want.append(f"show exactly {fmt['decimals']} decimal place(s)")
    hint = ""
    if ink_of(name) is None and name != "board":
        hint = (". If the number is a colour of its own (a golden score, say), press "
                "'Read it by colour' — the box can then be drawn with room to spare, which "
                "matters once the score grows a digit, and anything else inside it is ignored")
    return (f"read '{r['text']}', which doesn't fit how a {name} is expected to look"
            + (" — it should " + " and ".join(want) if want else "") + hint)


def number_frame(name: str) -> dict:
    """One look at a plain number region (the score), for teaching from the dashboard."""
    img = read_region(name)
    b = _binarize(img, name)
    boxes = _segment(b)
    text, note = "", ""
    if any(x[0].isdigit() for x in _load_templates(name)):
        r = read_number_detailed(name, img)
        text = r["text"]
        note = "" if r["value"] is not None else _why_not_a_number(name, r)
    shot = _save_debug(name, img, b, boxes, text)
    fmt = number_format(name)
    ink = ink_of(name)
    return {"frame": img, "shot": shot, "ready": bool(boxes), "glyphs": [len(boxes)],
            "texts": {"number": text}, "values": None, "note": note,
            "digits": digit_stats(name),
            "ink": {"on": ink is not None,
                    "bgr": (ink or {}).get("bgr"), "tol": (ink or {}).get("tol")},
            "format": {"example": fmt.get("example", ""),
                       "reads": fmt.get("reads") or _describe_format(fmt)}}


def _describe_format(fmt: dict) -> str:
    bits = []
    if fmt.get("decimals") is not None:
        bits.append(f"decimal separator '{fmt['decimal']}', {fmt['decimals']} place(s)")
    else:
        bits.append("no decimals expected")
    if fmt.get("thousands"):
        bits.append(f"thousands separator '{fmt['thousands']}'")
    if fmt.get("symbol"):
        bits.append(f"'{fmt['symbol']}' at the {fmt.get('symbol_at', 'start')}")
    return ", ".join(bits)


def teach_number_from(name: str, img: np.ndarray, typed: str) -> dict:
    """Learn a plain number region from what a person says it says, e.g. '1,250.50'."""
    sym = number_format(name).get("symbol") or ""
    typed = re.sub(fr"[^0-9.,$#{re.escape(sym)}]", "", str(typed or "")).strip()
    if not typed:
        return {"kept": 0, "fields": [], "digits": digit_stats(name),
                "problems": ["type the number exactly as it appears"]}
    b = _binarize(img, name)
    boxes = _segment(b)
    kinds = "".join("d" if bx[4] == "digit" else "s" for bx in boxes)
    want = "".join("s" if c in ".," else "d" for c in typed)   # $ and # are full-height
    if kinds != want:
        seen = "".join("9" if k == "d" else "." for k in kinds)
        return {"kept": 0, "fields": [], "digits": digit_stats(name),
                "problems": [f"I can see {seen} there (9 = a digit or $, . = a dot or comma) "
                             f"but you typed {typed}"]}
    known = _load_templates(name)
    font = font_of(name)
    d = digits_dir() / font
    d.mkdir(parents=True, exist_ok=True)
    for ch, bx in zip(typed, boxes):
        lab, c = _match(_normalize_glyph(b, bx), known) if known else ("", 0.0)
        if lab and lab != ch and c >= 0.95:
            return {"kept": 0, "fields": [], "digits": digit_stats(name),
                    "problems": [f"that character is already a clear '{lab}' and you typed "
                                 f"'{ch}'. If the old one is wrong, use Forget digits first"]}
    kept = sum(_keep_sample(d, ch, _normalize_glyph(b, bx)) for ch, bx in zip(typed, boxes))
    _TEMPLATE_CACHE.pop(font, None)
    log.info("Learned '%s' for '%s' — %d new example(s). Stored: %s",
             typed, name, kept, digit_stats(name))
    return {"kept": kept, "fields": ["number"], "problems": [], "digits": digit_stats(name)}


def region_list() -> list[dict]:
    """The screen regions that have been selected, with their size."""
    out = []
    if not snaps_dir().is_dir():
        return out
    for geo in sorted(snaps_dir().glob("*.geo")):
        name = geo.stem
        png = snaps_dir() / f"{name}.png"
        kind = region_kind(name)
        row = {"name": name, "geo": geo.read_text().strip(), "image": png.exists(),
               "font": (snaps_dir() / f"{name}.font").exists(), "kind": kind,
               "digits": digit_stats(name) if kind in ("board", "number") else {},
               "ink": ink_of(name) is not None}
        if kind == "trigger":
            row["colors"] = color_stats(name)
            row["ready"] = trigger_ready(name)
        if png.exists():
            img = cv2.imread(str(png))
            if img is not None:
                row["w"], row["h"] = int(img.shape[1]), int(img.shape[0])
            row["at"] = int(png.stat().st_mtime)
        out.append(row)
    return out


def delete_region(name: str) -> None:
    files = [snaps_dir() / f"{name}{ext}" for ext in (".geo", ".png", ".font")]
    if not any(f.exists() for f in files):
        raise BetError(f"there is no region called '{name}'")
    for f in files:
        f.unlink(missing_ok=True)
    log.info("Region '%s' deleted.", name)


def grab_region(name: str, geo: str | None = None) -> dict:
    """Select a region by dragging a box (slurp), or re-grab one already selected by
    passing its geometry. The picture and the geometry are saved together."""
    name = (name or "").strip()
    if not name:
        raise BetError("give the region a name, e.g. board")
    snaps_dir().mkdir(parents=True, exist_ok=True)
    if not geo:
        geo = desktop.select_region()
    desktop.parse_geo(geo)                      # refuses anything that isn't a box
    png = snaps_dir() / f"{name}.png"
    img = desktop.capture_region(geo)
    (snaps_dir() / f"{name}.geo").write_text(geo)
    cv2.imwrite(str(png), img)
    h, w = (img.shape[:2] if img is not None else (0, 0))
    log.info("Region '%s' saved — %d×%d at %s", name, w, h, geo)
    return {"name": name, "geo": geo, "w": int(w), "h": int(h), "at": int(time.time())}


def pattern_detail(name: str) -> dict:
    """One pattern's steps, ready to edit."""
    d = _pattern_dir(name)
    return {"name": _slug(name), "steps": _load_meta(d).get("steps", []) if d.is_dir() else []}


def save_pattern(name: str, steps: list) -> dict:
    """Write a pattern's steps. Every step is {action, coord, text?, enter?, desc?}."""
    name = _slug(name or "")
    if not name:
        raise BetError("give the pattern a name, e.g. close_table")
    coords = load_coords()
    clean = []
    for i, s in enumerate(steps or [], 1):
        action = str(s.get("action") or "click")
        if action not in ("click", "type"):
            raise BetError(f"step {i}: unknown action '{action}'")
        coord = str(s.get("coord") or "").strip()
        if coord and coord not in coords:
            raise BetError(f"step {i}: there is no coordinate called '{coord}'")
        if action == "click" and not coord:
            raise BetError(f"step {i}: a click needs a coordinate")
        step = {"action": action, "coord": coord, "desc": str(s.get("desc") or "")}
        if action == "type":
            step["text"] = str(s.get("text") or "")
            step["enter"] = bool(s.get("enter"))
        clean.append(step)
    if not clean:
        raise BetError("a pattern needs at least one step")
    d = _pattern_dir(name)
    d.mkdir(parents=True, exist_ok=True)
    _save_meta(d, {**_load_meta(d), "steps": clean})
    log.info("Pattern '%s' saved — %d step%s.", name, len(clean), "" if len(clean) == 1 else "s")
    return {"name": name, "steps": clean}


def delete_pattern(name: str) -> None:
    d = _pattern_dir(name)
    if not d.is_dir():
        raise BetError(f"there is no pattern called '{name}'")
    shutil.rmtree(d)
    log.info("Pattern '%s' deleted.", _slug(name))
