"""How a table writes money, and reading a number back out of it.

The format is worked out once from a single example you type ($12,633.96) and
remembered, because it is a fact about the table: which character groups the
thousands, which marks the decimals, how many decimals there are, where the
currency symbol sits.

The awkward part is that a full stop and a comma are a couple of pixels apart
in a small font. They are not told apart by how they look -- that fails -- but
by where they sit: 12,633.96 can only be grouped one way, so a reading of
12,633,96 is repaired rather than thrown away."""

from __future__ import annotations

import re

import json


from baccarat.errors import BetError
from baccarat.log import log
from baccarat.screen.sites import snaps_dir


# Number format. Default: 1,250.50  (comma = thousands, dot = decimals)
_DEFAULT_FORMAT = {"decimal": ".", "thousands": ",", "decimals": None, "symbol": None,
                   "symbol_at": "start"}


_FORMATS: dict[str, dict] = {}


def number_format(name: str) -> dict:
    """How region `name` writes its numbers. A format saved with the region (and so with
    the site) wins over the built-in default, because every table writes money its own
    way: 1,250.50 on one, 1000,10 $ on the next."""
    f = snaps_dir() / f"{name}.format"
    if f.exists():
        try:
            return {**_DEFAULT_FORMAT, **json.loads(f.read_text())}
        except (OSError, json.JSONDecodeError):
            pass
    return _FORMATS.get(name, _DEFAULT_FORMAT)


def format_number(value: float, fmt: dict) -> str | None:
    """A value written the way `fmt` writes it ($10,558.96), spaces left out (the reader
    never sees them). None when the format can't say how (decimals unknown)."""
    if value is None or value < 0:
        return None
    dec = fmt.get("decimals")
    if dec is None:
        if value != int(value):
            return None
        dec = 0
    whole, _, frac = f"{value:,.{dec}f}".partition(".")
    whole = whole.replace(",", fmt.get("thousands") or "")
    body = whole + ((fmt.get("decimal") or ".") + frac if dec else "")
    sym = fmt.get("symbol") or ""
    return sym + body if fmt.get("symbol_at", "start") == "start" else body + sym


def format_from_example(example: str) -> dict:
    """Work out how a table writes money from one example of it, e.g.
        1,250.50   → thousands , decimal . 2 decimals
        1000,10 $  → no thousands, decimal , 2 decimals, $ at the end
        $1.250     → thousands . no decimals, $ at the front
    → a format dict with a plain-English 'reads' line to show back."""
    s = str(example or "").strip()
    if not s:
        raise BetError("write an example of the number, exactly as the table shows it")
    symbol, at = None, "start"
    for ch in s:
        if not ch.isdigit() and ch not in " .,":
            symbol = ch
            break
    if symbol:
        at = "start" if s.index(symbol) < len(s) / 2 else "end"
    body = "".join(c for c in s if c.isdigit() or c in ".,")
    if not body or not body[0].isdigit() or not body[-1].isdigit():
        raise BetError(f"'{example}' doesn't look like a number with digits at both ends")
    seps = [c for c in body if c in ".,"]
    decimal, thousands, decimals = ".", "", None
    if len(set(seps)) >= 2:
        decimal = seps[-1]                       # the last kind is the decimal point
        thousands = next(c for c in seps if c != decimal)
    elif seps:
        c = seps[0]
        tail = body.rsplit(c, 1)[1]
        if len(tail) == 3 and len(seps) >= 1 and len(body.split(c)[0]) <= 3 and len(seps) > 1:
            thousands = c
        elif len(tail) == 3 and len(seps) == 1:
            thousands = c                        # 1,250 — a thousands group, not .250 of a unit
        else:
            decimal = c
    if decimal and decimal in body:
        decimals = len(body.rsplit(decimal, 1)[1])
    fmt = {"decimal": decimal, "thousands": thousands, "decimals": decimals,
           "symbol": symbol, "symbol_at": at, "example": s}
    bits = [f"decimal separator '{decimal}'" if decimals is not None else "no decimals"]
    if thousands:
        bits.append(f"thousands separator '{thousands}'")
    if decimals:
        bits.append(f"always {decimals} decimal place(s)")
    if symbol:
        bits.append(f"'{symbol}' at the {at}")
    fmt["reads"] = ", ".join(bits)
    return fmt


def save_number_format(name: str, example: str) -> dict:
    """Remember how this region's numbers are written, for this site."""
    fmt = format_from_example(example)
    snaps_dir().mkdir(parents=True, exist_ok=True)
    (snaps_dir() / f"{name}.format").write_text(json.dumps(fmt, indent=1) + "\n")
    log.info("Number format for '%s': %s", name, fmt["reads"])
    return fmt


def set_number_format(name: str, decimal: str = ".", thousands: str = ",",
                      decimals: int | None = None, symbol: str | None = None) -> None:
    """Configure how region `name` writes numbers.
    decimal/thousands: separator characters (e.g. decimal=",", thousands="." for 1.250,50).
    decimals: if the number ALWAYS shows N decimal places (e.g. 2 for money), set it —
              then a read where the decimal point wasn't seen is rejected instead of
              silently becoming 100× too big.
    symbol:   a sign always shown before the number (e.g. "$"). A read only counts
              when that sign was recognised, so a $ misread as a digit is rejected
              instead of adding a digit to the value. Teach it with --teach."""
    _FORMATS[name] = {"symbol_at": "start",
                      "decimal": decimal, "thousands": thousands, "decimals": decimals,
                      "symbol": symbol}


SEP_CHARS = ".,"        # the two a small font can't keep apart


def _resolve_separators(text: str, fmt: dict) -> str:
    """Decide which separator is which from where they sit, not from how they look.

    At the size these scores are drawn, a full stop and a comma are a couple of
    pixels apart — the comma's tail is often a single row, and it is the first thing
    to go when the text is rescaled. Telling them apart by shape is a coin toss, so
    don't: a number written 12,633.96 can only be grouped one way. Whichever glyph
    sits in front of the last `decimals` digits is the decimal separator, and the
    rest are thousands separators, whatever the matcher called them.

    Only applied when the format uses two different separators and a fixed number of
    decimals — anything less and there is nothing to deduce. If the layout doesn't
    fit the format, the text is handed back untouched so the usual checks can
    reject it."""
    dec, th, ndec = fmt.get("decimal"), fmt.get("thousands"), fmt.get("decimals")
    at = [i for i, c in enumerate(text) if c in SEP_CHARS]
    if not at:
        return text
    if dec and not th:
        # this table groups nothing, so every separator it draws is the decimal one
        return "".join(dec if i in at else c for i, c in enumerate(text))
    if not (dec and th and dec != th and ndec):
        return text
    if len(text) - at[-1] - 1 != ndec:
        return text                              # no tail of the right length: leave it
    out = list(text)
    for i in at[:-1]:
        out[i] = th
    out[at[-1]] = dec
    return "".join(out)


def parse_shown(text: str, fmt: dict) -> int | float | None:
    """A number as a person copies it off the screen: '$10,752.96', '10.752,96 €',
    ' 10,752.96 ' → its value. The currency sign and spaces around it don't count."""
    s = str(text or "").strip()
    s = re.sub(r"^[^0-9]+|[^0-9]+$", "", s)            # $, €, #, 'USD', spaces at the ends
    s = s.replace(" ", "").replace("\u00a0", "")
    return _parse_number(_resolve_separators(s, fmt), fmt) if s else None


def _parse_number(text: str, fmt: dict) -> int | float | None:
    """'1,250.50' → 1250.5 ; '1,250' → 1250 ; malformed → None."""
    dec, th, ndec = fmt["decimal"], fmt["thousands"], fmt["decimals"]
    if not text or not text[0].isdigit() or not text[-1].isdigit():
        return None
    parts = text.split(dec)
    if len(parts) > 2:
        return None
    ipart = parts[0]
    if th and th in ipart:
        groups = ipart.split(th)
        if not (1 <= len(groups[0]) <= 3) or any(len(g) != 3 for g in groups[1:]):
            return None                          # 12,34 → misread, reject
        ipart = "".join(groups)
    if not ipart.isdigit():
        return None
    if len(parts) == 2:
        if not parts[1].isdigit() or (ndec is not None and len(parts[1]) != ndec):
            return None
        return float(f"{ipart}.{parts[1]}")
    if ndec:                                     # expected decimals but saw none
        return None
    return int(ipart)
