"""Reading text off the screen by matching each character against samples.

No OCR engine: a casino's font is one font, and a few examples of each
character beat a general-purpose reader on the only font that matters.

    1. find the text in the box -- by its COLOUR when that has been learnt
       (save_ink), otherwise by brightness
    2. cut it into characters (_segment), each normalised to a fixed square
    3. match each one against the samples (_match)

Step 1 is why the box can be drawn with room to spare. A box cut tight around
$1,250.50 has no room when the score reaches $12,633.96, and a box drawn large
enough catches other chrome -- which the colour gate then ignores."""

from __future__ import annotations

import json
import time
from pathlib import Path
import cv2
import numpy as np


from baccarat.errors import BetError
from baccarat.log import DEBUG, log
from baccarat.screen import capture
from baccarat.screen.capture import _retry_gap, read_region
from baccarat.screen.numbers import _parse_number, _resolve_separators, number_format
from baccarat.screen.sites import debug_dir, digits_dir, snaps_dir


# ---------------------------------------------------------------------------
# Number reading  (score, game number …)
#
# Works like a tiny OCR trained on YOUR game's font:
#   1. --snap NAME   select the region around the number
#   2. --teach NAME  the script splits the number into digits and asks you
#                    what it says; each digit image is saved as a template.
#                    Repeat over a few games until all 10 digits are known.
#   3. read_number(NAME) matches each digit against the templates.
# Much more reliable than Tesseract for small, styled game numbers,
# and needs no extra packages.
# ---------------------------------------------------------------------------

GLYPH_SIZE = 28          # templates are normalised to GLYPH_SIZE × GLYPH_SIZE


READ_MIN_CONF = 0.62     # below this a read is rejected (returns None)


READ_MIN_MARGIN = 0.05   # ...and the best match must beat the runner-up by this much
# While some digits have never been taught, a glyph of one of THOSE has nothing to lose
# to: an 8 can only come out as the nearest digit there is -- a 3 -- and the margin
# check can't see it. So until all ten are known, a digit is taken only on a near-perfect
# match; anything less is "?" (unreadable, which is safe) rather than a wrong number.
READ_INCOMPLETE_CONF = 0.92
LEARN_CONF = 0.90        # the known characters must match this well before new ones are learnt


GLYPH_BLUR = 0.9         # softens both glyph and template before comparing: tiny text


                         # lands on different pixels each time the page redraws, and a
                         # hard pixel-for-pixel comparison punishes that far too much
MAX_SAMPLES = 24         # samples kept per character (was 5 — teaching more did nothing)


SAMPLE_DUPLICATE = 0.985 # a new sample this close to one already kept adds nothing


_TEMPLATE_CACHE: dict[str, list[tuple[str, np.ndarray]]] = {}


_SEP_FILE = {".": "dot", ",": "comma", "#": "hash", "$": "dollar"}   # template file names


SYMBOLS = "#$"      # learnable symbols that are never part of the value


_SEP_LABEL = {v: k for k, v in _SEP_FILE.items()}


def _ink_file(name: str) -> Path:
    return snaps_dir() / f"{name}.ink"


def ink_of(name: str | None) -> dict | None:
    """The colour this region's text is written in, if it has been learnt."""
    if not name:
        return None
    f = _ink_file(name)
    if not f.exists():
        return None
    try:
        d = json.loads(f.read_text())
        return d if "lab" in d and "tol" in d else None
    except (OSError, json.JSONDecodeError):
        return None


def _ink_distance(img: np.ndarray, ink: dict) -> np.ndarray:
    """Per-pixel distance from the text colour — by colour alone, ignoring brightness.

    Lab splits a pixel into how light it is (L) and what colour it is (a, b). Only a
    and b are used here, and that is the whole point: a golden score is golden whether
    it is on a bright cell or a dark one, while grey chrome, white labels and a black
    background are all colourless and sit far away whatever their brightness. Taking L
    into account instead puts mid-grey closer to gold than black is, and then anything
    pale in the box gets read as part of the number."""
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB).astype(np.float32)
    ref = np.array(ink["lab"], np.float32)[1:].reshape(1, 1, 2)
    return np.linalg.norm(lab[:, :, 1:] - ref, axis=2)


def _otsu_text(img: np.ndarray) -> np.ndarray:
    """Text as white, by brightness alone — the fallback when no colour is known."""
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, b = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    border = np.concatenate([b[0], b[-1], b[:, 0], b[:, -1]])
    if border.mean() > 127:          # background came out white → invert
        b = 255 - b
    return b


def _text_rows(mask: np.ndarray) -> int:
    """How tall the text actually is inside the box — not how tall the box is."""
    rows = np.where(mask.max(axis=1) > 0)[0]
    return int(rows[-1] - rows[0] + 1) if len(rows) else 0


def save_ink(name: str, img: np.ndarray | None = None) -> dict:
    """Learn the colour this region's text is written in, from what is on screen now.

    The pixels are found the usual way first (brightest against the background) and
    their average colour is kept. After this the region is read by colour rather than
    by brightness, which is what lets the box be drawn generously: a score that grows
    from 1,250.50 to 12,633.96 needs more room than it did, and a box cut to fit the
    small one clips the big one. Colour also ignores whatever else is in the box."""
    if img is None:
        img = read_region(name)
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB).astype(np.float32)
    # How colourful each pixel is, regardless of how light it is. Black, white and
    # every grey sit at zero; the golden number does not. Brightness is no use for
    # finding the text here — the whole reason for drawing a roomy box is that it
    # catches other bright things, and they would be sampled as if they were the
    # number. Colourfulness picks out the number and nothing else.
    chroma = np.linalg.norm(lab[:, :, 1:] - 128.0, axis=2)
    strong = chroma >= max(12.0, float(np.percentile(chroma, 97)) * 0.5)
    if int(strong.sum()) < 12:
        raise BetError("Nothing in that box has a colour of its own — this only helps when "
                       "the number does (a golden or coloured score). It will go on being "
                       "read by brightness.")
    rough = strong.astype(np.uint8) * 255
    pts = img[strong]
    core = lab[strong]
    core = core[core[:, 0] >= np.percentile(core[:, 0], 40)]   # drop the blended edges
    ref = core.mean(axis=0)
    # The tolerance is a boundary, not a guess at the spread. Measure how far the text
    # pixels really stray from that colour (the edges of a stroke stray a long way, and
    # a thin comma is almost all edge), measure where the background sits, and put the
    # line between the two. Too tight and the separators vanish — which is exactly the
    # kind of misread that turns 12,633.96 into something else.
    ink = {"lab": [round(float(v), 1) for v in ref]}
    dist = _ink_distance(img, ink)
    # p90, not p98: the outer pixels of a stroke are half background and their colour
    # has already bled towards it, so the top few per cent say more about the edge than
    # about the ink.
    far_text = float(np.percentile(dist[rough > 0], 90))
    background = float(np.median(dist[rough == 0])) if (rough == 0).any() else far_text * 3
    if background <= max(12.0, far_text * 1.4):
        raise BetError("The number isn't a different colour from what is around it — this "
                       "only helps when it is (a golden or coloured score on a plain "
                       "background). It will go on being read by brightness.")
    tol = max(far_text * 1.1, min(background * 0.7, (far_text + background) / 2))
    d = {"lab": ink["lab"], "tol": round(float(tol), 1),
         "text_to": round(far_text, 1), "background_at": round(background, 1),
         "bgr": [int(v) for v in np.median(pts, axis=0)], "pixels": int(len(pts))}
    snaps_dir().mkdir(parents=True, exist_ok=True)
    _ink_file(name).write_text(json.dumps(d, indent=1) + "\n")
    log.info("Learnt the text colour of '%s' from %d pixels (tolerance %.0f).",
             name, len(pts), tol)
    return d


def forget_ink(name: str) -> None:
    _ink_file(name).unlink(missing_ok=True)


def _binarize(img: np.ndarray, name: str | None = None) -> np.ndarray:
    """Region → black/white with the TEXT as white, upscaled for the matcher.

    When the region's text colour has been learnt, the pixels are picked by colour
    instead of brightness. Two things follow: anything in the box that isn't that
    colour disappears, so the box can be drawn with room to spare; and the upscale is
    worked out from the height of the text rather than the height of the box, so that
    spare room doesn't shrink the glyphs and ruin the matching."""
    ink = ink_of(name)
    if ink is not None:
        dist = _ink_distance(img, ink)
        mask = (dist <= ink["tol"]).astype(np.uint8) * 255
        text_h = _text_rows(mask)
        if text_h >= 4:
            scale = max(1, round(120 / text_h))
            if scale > 1:
                # threshold first, then grow the shapes. Upscaling the distances
                # instead lets cubic ringing push parts of a stroke over the line and
                # breaks glyphs into pieces.
                up = cv2.resize(mask, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
                mask = (up > 127).astype(np.uint8) * 255
            return mask
        log.debug("Colour gate for '%s' found no text (%d rows) — falling back to brightness.",
                  name, text_h)
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    scale = max(1, round(120 / max(1, g.shape[0])))   # small text: upscale a lot
    if scale > 1:
        g = cv2.resize(g, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    _, b = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    border = np.concatenate([b[0], b[-1], b[:, 0], b[:, -1]])
    if border.mean() > 127:          # background came out white → invert
        b = 255 - b
    return b


def _split_wide(b: np.ndarray, comps: list) -> list:
    """Tiny fonts: neighbouring digits can touch and form one wide blob.
    Split such blobs at the thinnest columns into digit-width pieces."""
    normal = [c for c in comps if c[3] >= 5 and 0.3 <= c[2] / c[3] <= 1.0]
    tallest = max((c[3] for c in comps), default=0)
    out = []
    for c in comps:
        x, y, w, h, area = c
        # only digit-height blobs can be touching digits (never split a . or ,)
        if h < 5 or h < 0.55 * tallest or w / h <= 1.05:
            out.append(c)
            continue
        same_h = [n for n in normal if abs(n[3] - h) <= 0.2 * h]
        dw = float(np.median([n[2] for n in same_h])) if same_h else 0.62 * h
        k = int(round(w / dw))
        if k < 2:
            out.append(c)
            continue
        col = (b[y:y + h, x:x + w] > 0).sum(axis=0)
        cuts = [0]
        for i in range(1, k):
            guess = int(i * w / k)
            lo, hi = max(1, guess - int(dw * 0.3)), min(w - 1, guess + int(dw * 0.3))
            cuts.append(lo + int(np.argmin(col[lo:hi + 1])) if hi > lo else guess)
        cuts.append(w)
        for a, e in zip(cuts, cuts[1:]):
            piece = b[y:y + h, x + a:x + e] > 0
            if piece.any():
                rows = np.where(piece.any(axis=1))[0]
                out.append([x + a, y + int(rows[0]), e - a, int(rows[-1] - rows[0] + 1),
                            int(piece.sum())])
    return out


def _segment(b: np.ndarray) -> list[tuple[int, int, int, int, str]]:
    """Find glyph boxes (x, y, w, h, kind) left to right.
    kind = "digit" or "sep" (a dot/comma between digits). Drops noise."""
    n, _, stats, _ = cv2.connectedComponentsWithStats(b, connectivity=8)
    H, W = b.shape
    comps = []
    for i in range(1, n):
        x, y, w, h, area = (int(v) for v in stats[i])
        if area < 4 or w > W * 0.9 or (h > H * 0.98 and w < 3):   # specks, frame lines
            continue
        comps.append([x, y, w, h, area])
    comps = _split_wide(b, comps)
    big = [c for c in comps if c[3] >= 5 and 0.08 <= c[2] / c[3] <= 1.3]
    if not big:
        return []
    tallest = max(c[3] for c in big)
    digits = sorted([c[:4] for c in big if c[3] >= 0.55 * tallest], key=lambda c: c[0])

    # merge pieces of the same digit (overlapping horizontally)
    merged = [digits[0]]
    for c in digits[1:]:
        m = merged[-1]
        overlap = min(m[0] + m[2], c[0] + c[2]) - max(m[0], c[0])
        if overlap > 0.5 * min(m[2], c[2]):
            x0, y0 = min(m[0], c[0]), min(m[1], c[1])
            x1 = max(m[0] + m[2], c[0] + c[2]); y1 = max(m[1] + m[3], c[1] + c[3])
            merged[-1] = [x0, y0, x1 - x0, y1 - y0]
        else:
            merged.append(c)
    boxes = [(*c, "digit") for c in merged]

    # separators: small, in the lower half of the digit band, between digits
    top = min(c[1] for c in merged); bottom = max(c[1] + c[3] for c in merged)
    mid = (top + bottom) / 2
    left, right = merged[0][0], merged[-1][0] + merged[-1][2]
    min_area = 0.008 * tallest * tallest
    for x, y, w, h, area in comps:
        if h >= 0.55 * tallest or area < min_area or h > 0.5 * tallest:
            continue
        cx = x + w / 2
        if y + h / 2 < mid or not (left < cx < right):
            continue
        if any(bx[0] <= cx <= bx[0] + bx[2] for bx in merged):   # inside a digit
            continue
        boxes.append((x, y, w, h, "sep"))
    boxes.sort(key=lambda c: c[0])
    return boxes


def _normalize_glyph(b: np.ndarray, box) -> np.ndarray:
    """Crop a glyph, pad to square keeping its shape, resize to GLYPH_SIZE."""
    x, y, w, h = box[:4]
    g = b[y:y + h, x:x + w]
    side = max(w, h)
    sq = np.zeros((side, side), np.uint8)
    ox, oy = (side - w) // 2, (side - h) // 2
    sq[oy:oy + h, ox:ox + w] = g
    return cv2.resize(sq, (GLYPH_SIZE, GLYPH_SIZE), interpolation=cv2.INTER_AREA)


def font_of(name: str) -> str:
    """Which digit set a region uses (default: its own name)."""
    f = snaps_dir() / f"{name}.font"
    return f.read_text().strip() if f.exists() else name


def set_font(name: str, font: str) -> None:
    """Make region `name` use the digit set `font`, so regions with the same
    font (e.g. the P/B/T counters) share what was taught."""
    snaps_dir().mkdir(parents=True, exist_ok=True)
    (snaps_dir() / f"{name}.font").write_text(font + "\n")


def _keep_sample(d, ch: str, glyph) -> bool:
    """Store one more example of a character, unless we have plenty or this one is
    nearly identical to an example already kept. Tiny text lands on slightly different
    pixels every time the page redraws, and it is exactly those variants that make a
    read reliable — so teaching the same number again IS worth something, as long as
    what gets kept is the variety rather than fifty copies of the same frame."""
    key = _SEP_FILE.get(ch, ch)
    have = sorted(d.glob(f"{key}_*.png"))
    if len(have) >= MAX_SAMPLES:
        return False
    old = [cv2.imread(str(f), cv2.IMREAD_GRAYSCALE) for f in have]
    old = [o for o in old if o is not None]
    if old:
        s = _unit_rows(np.stack([glyph])) @ _unit_rows(np.stack(old)).T
        if float(s.max()) >= SAMPLE_DUPLICATE:
            return False                     # we have this one already
    n = 0
    while (d / f"{key}_{n}.png").exists():
        n += 1
    cv2.imwrite(str(d / f"{key}_{n}.png"), glyph)
    return True


def digit_stats(name: str) -> dict:
    """How many examples are stored for each character of a region's digit set."""
    d = digits_dir() / font_of(name)
    out: dict = {}
    if d.is_dir():
        for f in d.glob("*.png"):
            key = f.name.split("_")[0]
            out[_SEP_LABEL.get(key, key)] = out.get(_SEP_LABEL.get(key, key), 0) + 1
    return dict(sorted(out.items()))


def forget_digits(name: str) -> int:
    """Throw away everything taught for this digit set and start again. Worth doing
    when a few bad examples got in early: they never expire on their own."""
    d = digits_dir() / font_of(name)
    files = sorted(d.glob("*.png")) if d.is_dir() else []
    for f in files:
        f.unlink()
    _TEMPLATE_CACHE.pop(font_of(name), None)
    log.info("Forgot %d example(s) for '%s'.", len(files), font_of(name))
    return len(files)


def _load_templates(name: str) -> list[tuple[str, np.ndarray]]:
    name = font_of(name)
    if name in _TEMPLATE_CACHE:
        return _TEMPLATE_CACHE[name]
    out = []
    d = digits_dir() / name
    if d.is_dir():
        for f in sorted(d.glob("*.png")):
            t = cv2.imread(str(f), cv2.IMREAD_GRAYSCALE)
            if t is not None:
                key = f.name.split("_")[0]
                out.append((_SEP_LABEL.get(key, key), t))
    _TEMPLATE_CACHE[name] = out
    return out


def _unit_rows(a: np.ndarray) -> np.ndarray:
    """Zero-mean, unit-length rows: then a dot product == TM_CCOEFF_NORMED.
    Each glyph is softened first (see GLYPH_BLUR), which is what makes a digit
    rendered half a pixel to the left still count as the same digit."""
    a = np.asarray(a, np.float32)
    if GLYPH_BLUR and a.ndim == 3:
        a = np.stack([cv2.GaussianBlur(g, (0, 0), GLYPH_BLUR) for g in a])
    a = a.reshape(len(a), -1).astype(np.float32)
    a -= a.mean(axis=1, keepdims=True)
    n = np.linalg.norm(a, axis=1, keepdims=True)
    return a / np.maximum(n, 1e-6)


_MAT_CACHE: dict[int, tuple[list, list[str], np.ndarray]] = {}


def _match_many(glyphs: list[np.ndarray], templates) -> list[tuple[str, float]]:
    """Best template for every glyph at once (one matrix multiply)."""
    if not glyphs or not templates:
        return [("?", -1.0)] * len(glyphs)
    c = _MAT_CACHE.get(id(templates))
    if c is None or c[0] is not templates:          # keep a ref → ids can't be reused
        c = (templates, [l for l, _ in templates],
             _unit_rows(np.stack([t for _, t in templates])))
        _MAT_CACHE[id(templates)] = c
    _, labels, T = c
    S = _unit_rows(np.stack(glyphs)) @ T.T
    best = S.argmax(axis=1)
    out = []
    for i, j in enumerate(best):
        top = float(S[i, j])
        # the runner-up has to be a DIFFERENT character: five samples of the same
        # digit all scoring well is agreement, not confusion
        other = [float(v) for k, v in enumerate(S[i]) if labels[k] != labels[j]]
        out.append((labels[j], top, top - max(other, default=-1.0)))
    return out


def _match(glyph: np.ndarray, templates) -> tuple[str, float]:
    label, top, _ = _match_many([glyph], templates)[0]
    return label, top


def _guess_sep(box, digit_bottom: int) -> str:
    """No separator templates yet: tell comma from dot by shape.
    A comma is taller than wide or hangs below the digits' baseline."""
    x, y, w, h = box[:4]
    return "," if (h > 1.4 * w or y + h > digit_bottom + 0.15 * h + 1) else "."


def _save_debug(name: str, img: np.ndarray, b: np.ndarray, boxes, text: str) -> Path:
    debug_dir().mkdir(parents=True, exist_ok=True)
    vis = cv2.cvtColor(b, cv2.COLOR_GRAY2BGR)
    for i, (x, y, w, h, *_) in enumerate(boxes):
        cv2.rectangle(vis, (x, y), (x + w - 1, y + h - 1), (0, 0, 255), 1)
        if i < len(text):
            cv2.putText(vis, text[i], (x, max(10, y - 2)), cv2.FONT_HERSHEY_SIMPLEX,
                        0.4, (0, 255, 0), 1)
    big = cv2.resize(img, (vis.shape[1], vis.shape[0]), interpolation=cv2.INTER_NEAREST)
    out = debug_dir() / f"{name}_{time.strftime('%H%M%S')}.png"
    cv2.imwrite(str(out), np.vstack([big, vis]))
    return out


_SPLIT_CACHE: dict[int, tuple[list, list, list]] = {}


def _read_glyphs(name, b, boxes):
    templates = _load_templates(name)
    c = _SPLIT_CACHE.get(id(templates))
    if c is None or c[0] is not templates:
        c = (templates,
             [t for t in templates if t[0] not in ".,"],     # digits (+ '#')
             [t for t in templates if t[0] in ".,"])
        _SPLIT_CACHE[id(templates)] = c
    _, dig_t, sep_t = c
    strict = not set("0123456789") <= {t[0] for t in dig_t}       # some digit never taught
    digit_bottom = max((bx[1] + bx[3] for bx in boxes if bx[4] == "digit"), default=0)
    glyphs = [_normalize_glyph(b, bx) for bx in boxes]
    d_idx = [i for i, bx in enumerate(boxes) if bx[4] == "digit"]
    s_idx = [i for i, bx in enumerate(boxes) if bx[4] != "digit"]
    out: list = [None] * len(boxes)
    def settle(label, top, margin):
        # a clear winner is trusted even when the absolute score is middling; an
        # unclear one is refused however high it scored, because a wrong digit is
        # worse than no digit
        return (label, top) if margin >= READ_MIN_MARGIN else ("?", min(top, 0.0))
    for i, r in zip(d_idx, _match_many([glyphs[i] for i in d_idx], dig_t)):
        out[i] = settle(*r)
        if strict and out[i][0] != "?" and out[i][1] < READ_INCOMPLETE_CONF:
            out[i] = ("?", 0.0)
    if sep_t:
        for i, r in zip(s_idx, _match_many([glyphs[i] for i in s_idx], sep_t)):
            out[i] = settle(*r)
    else:
        for i in s_idx:
            out[i] = (_guess_sep(boxes[i], digit_bottom), 1.0)
    return out


def read_number_detailed(name: str, img: np.ndarray | None = None) -> dict:
    """Read the number in region `name`.
    Returns {"value": int|float|None, "text": str, "conf": float, "digits": [(label, conf)…]}.
    value is an int for whole numbers, a float when there are decimals, and None
    when nothing was found, a glyph is below READ_MIN_CONF, or the text is malformed."""
    if not any(t[0].isdigit() for t in _load_templates(name)):
        raise BetError(f"No digit templates for '{name}'. Run: python bet.py --teach {name}")
    if img is None:
        img = read_region(name)
    b = _binarize(img, name)
    boxes = _segment(b)
    glyphs = _read_glyphs(name, b, boxes)
    text = "".join(l for l, _ in glyphs)
    conf = min((c for (l, c) in glyphs if l.isdigit()), default=0.0)
    fmt = number_format(name)
    number = text.strip().strip(SYMBOLS)            # "$1,250.50" or "1000,10 $" → the digits
    sym, at = fmt.get("symbol"), fmt.get("symbol_at", "start")
    # Insist on the symbol only if this table actually shows one — i.e. if it has ever
    # been taught. Otherwise a table that writes its score without a $ could never be
    # read at all, which is worse than not having the check.
    in_place = (text.startswith(sym) if at == "start" else text.endswith(sym)) if sym else True
    if sym and any(x[0] == sym for x in _load_templates(name)) and not in_place:
        value = None                                # the symbol wasn't where it should be
    else:
        number = _resolve_separators(number, fmt)
        value = _parse_number(number, fmt) if conf >= READ_MIN_CONF else None
    if value is None and DEBUG:
        p = _save_debug(name, img, b, boxes, text)
        log.debug("read '%s' rejected (text=%r conf=%.2f) → %s", name, text, conf, p)
    return {"value": value, "text": text, "conf": conf, "digits": glyphs}


def read_number(name: str) -> int | float | None:
    """Read the number in region `name` once. None if unreadable."""
    return read_number_detailed(name)["value"]


_LAST_NUMBER: dict = {}         # region name → the last value confirmed


def read_number_stable(name: str, samples: int = 2, interval: float | None = None,
                       timeout: float = 3.0) -> int | float | None:
    """Read until `samples` consecutive reads agree — skips frames where the
    number is mid-animation. None if it never stabilises within `timeout`.

    A read that says exactly what the last confirmed read said is taken at once, as
    the bar's is: a second look is for a value that has just changed, and the score
    sits unchanged for most of every hand. That used to be two grabs per look."""
    interval = capture.CONFIRM_GAP if interval is None else interval
    end = time.monotonic() + timeout
    last, streak, fails = None, 0, 0
    while time.monotonic() < end:
        v = read_number(name)
        if v is not None and v == _LAST_NUMBER.get(name):
            return v                                    # unchanged: nothing to confirm
        fails = 0 if v is not None else fails + 1
        if v is not None and v == last:
            streak += 1
        else:
            streak = 1 if v is not None else 0
        last = v
        if streak >= samples:
            _LAST_NUMBER[name] = v
            return v
        time.sleep(_retry_gap(interval, fails))
    return None


def wait_for_change(name: str, old_value: int | None, timeout: float = 120.0,
                    interval: float = 0.3) -> int | None:
    """Block until region `name` shows a stable number different from
    `old_value` (e.g. wait for the next game). None on timeout."""
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        v = read_number_stable(name, timeout=min(3.0, max(0.5, end - time.monotonic())))
        if v is not None and v != old_value:
            return v
        time.sleep(interval)
    return None


def missing_digits(name: str) -> str:
    """The digits a region's set has never been taught, e.g. '478'."""
    have = {t[0] for t in _load_templates(name)}
    return "".join(d for d in "0123456789" if d not in have)


def learn_from_known(name: str, expected: str, img: np.ndarray | None = None) -> str:
    """The bot knows what the region must say (its books, just settled): learn the
    characters it has never been taught, from the screen as it is. Only when every
    character it DOES know is right where the expected text puts it, and clearly so --
    a screen that hasn't caught up, or books that are off, teach nothing.
    → the characters learnt ('' for none)."""
    templates = _load_templates(name)
    known = {t[0] for t in templates}
    if not expected or not known or all(c in known for c in expected):
        return ""
    if img is None:
        img = read_region(name)
    b = _binarize(img, name)
    boxes = _segment(b)
    kinds = "".join("d" if bx[4] == "digit" else "s" for bx in boxes)
    if kinds != "".join("s" if c in ".," else "d" for c in expected):
        return ""
    glyphs = [_normalize_glyph(b, bx) for bx in boxes]
    new = []
    for ch, g, (label, top, _) in zip(expected, glyphs, _match_many(glyphs, templates)):
        if ch in known:
            if label != ch or top < LEARN_CONF:
                return ""
        elif label in known and label not in ".," and top >= LEARN_CONF:
            return ""                    # it plainly IS a digit we know: the books are off
        else:
            new.append((ch, g))
    d = digits_dir() / font_of(name)
    d.mkdir(parents=True, exist_ok=True)
    kept = "".join(sorted({ch for ch, g in new if _keep_sample(d, ch, g)}))
    _TEMPLATE_CACHE.pop(font_of(name), None)
    _MAT_CACHE.clear()
    _SPLIT_CACHE.clear()
    if kept:
        log.info("Learned %s for '%s' from the screen, against the books (%s). Still never "
                 "seen: %s.", ", ".join(f"'{c}'" for c in kept), name, expected,
                 missing_digits(name) or "none — all ten digits known")
    return kept
