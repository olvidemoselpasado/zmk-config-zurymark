"""python -m baccarat.screen  —  set up and check the screen reading."""

from baccarat.screen.cli import main

if __name__ == "__main__":
    main()
