"""Linux, on Wayland with Hyprland: hyprctl over its UNIX socket for the pointer,
grim for pixels, slurp for selecting a box, ydotool for the mouse buttons and wtype
for the keyboard; /proc for how busy the machine is.

Reached only through desktop.py, which picks this or macos.py."""

from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import tempfile
from pathlib import Path
import cv2
import numpy as np


from baccarat.errors import BetError
from baccarat.log import DEBUG, log
from baccarat.screen.procnames import group_of, process_name


YDOTOOL_SOCKET = os.environ.get("YDOTOOL_SOCKET", "/tmp/.ydotool_socket")


# ---------------------------------------------------------------------------
# Wayland tools
# ---------------------------------------------------------------------------

def check_tools() -> None:
    missing = [t for t in ("grim", "slurp", "wtype", "hyprctl") if not shutil.which(t)]
    if missing:
        raise BetError("Missing tools: " + ", ".join(missing))


_YDOTOOL_OK = False


def ensure_input() -> None:
    """Make sure clicks and keys can be sent: on Linux, that ydotoold is reachable."""
    _ensure_ydotoold()


def _ensure_ydotoold() -> None:
    global _YDOTOOL_OK
    if _YDOTOOL_OK:
        return
    # Relative move of 0,0: tests the daemon socket WITHOUT moving the cursor
    r = subprocess.run(["ydotool", "mousemove", "-x", "0", "-y", "0"],
                       capture_output=True, text=True)
    if r.returncode == 0:
        _YDOTOOL_OK = True
        return
    running = subprocess.run(["pgrep", "-x", "ydotoold"], capture_output=True).returncode == 0
    if running:
        raise BetError("ydotoold running but unreachable. Fix:\n"
                       "  sudo pkill ydotoold\n"
                       f"  sudo ydotoold --socket-path {YDOTOOL_SOCKET} --socket-perm 0666 &")
    raise BetError("ydotoold not running. Start it:\n"
                   f"  sudo ydotoold --socket-path {YDOTOOL_SOCKET} --socket-perm 0666 &")


def _run(cmd, label=""):
    r = subprocess.run(cmd, capture_output=True, text=True)
    out = (r.stdout.strip() + " " + r.stderr.strip()).strip()
    if DEBUG:
        log.debug("  CMD: %s  -> rc=%d %r", " ".join(cmd), r.returncode, out)
    elif r.returncode != 0 or (cmd[:2] == ["hyprctl", "dispatch"] and out != "ok"):
        log.warning("%s: %s -> rc=%d %r", label or cmd[0], " ".join(cmd), r.returncode, out)
    return r


def _run_private(cmd: list[str], stdin: str, label: str) -> bool:
    """Run a command that carries something secret on stdin -- a password being typed.
    Unlike _run, nothing about the command, its input or its output is ever logged,
    not even with --debug: a failure says which step and the exit code, and that is
    all. The secret goes on stdin rather than the command line, so it never shows up
    in the process list either."""
    try:
        r = subprocess.run(cmd, input=stdin, capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired) as e:
        log.warning("%s failed (%s).", label, type(e).__name__)
        return False
    if r.returncode != 0:
        log.warning("%s failed (exit %d).", label, r.returncode)
        return False
    return True


def _find_hypr_socket() -> str | None:
    his = os.environ.get("HYPRLAND_INSTANCE_SIGNATURE")
    if not his:
        return None
    for base in (os.environ.get("XDG_RUNTIME_DIR", ""), "/tmp"):
        p = Path(base) / "hypr" / his / ".socket.sock"
        if p.exists():
            return str(p)
    return None


_HYPR_SOCK = _find_hypr_socket()


def hypr_request(cmd: str) -> str:
    """Send one command to Hyprland (same as `hyprctl <cmd>`), return its reply.
    Talks to Hyprland's IPC socket directly — ~100× faster than spawning hyprctl.
    Falls back to the hyprctl binary if the socket isn't usable."""
    global _HYPR_SOCK
    if _HYPR_SOCK:
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sk:
                sk.settimeout(1.0)
                sk.connect(_HYPR_SOCK)
                sk.sendall(cmd.encode())
                chunks = []
                while True:
                    b = sk.recv(8192)
                    if not b:
                        break
                    chunks.append(b)
            return b"".join(chunks).decode(errors="replace").strip()
        except OSError as e:
            log.warning("Hyprland socket failed (%s) — falling back to hyprctl (slower)", e)
            _HYPR_SOCK = None
    verb, _, rest = cmd.partition(" ")
    argv = ["hyprctl", verb] + ([rest] if rest else [])
    r = subprocess.run(argv, capture_output=True, text=True)
    return (r.stdout + r.stderr).strip()


def hypr_json(what: str):
    """`hyprctl -j <what>` (clients, monitors …) as Python data."""
    if _HYPR_SOCK:
        reply = hypr_request(f"j/{what}")
    else:
        try:
            r = subprocess.run(["hyprctl", "-j", what], capture_output=True, text=True,
                               timeout=5)
        except (OSError, subprocess.TimeoutExpired) as e:
            raise BetError(f"couldn't ask Hyprland about its windows ({e})") from None
        reply = r.stdout
    try:
        return json.loads(reply)
    except json.JSONDecodeError:
        raise BetError(f"Hyprland didn't answer 'hyprctl -j {what}': {reply[:120]!r}") from None


def list_windows() -> list[dict]:
    """Every window Hyprland has, with where it is and whether it is on a workspace
    that is showing right now."""
    showing = {m.get("activeWorkspace", {}).get("id") for m in hypr_json("monitors")}
    out = []
    for c in hypr_json("clients"):
        ws = (c.get("workspace") or {}).get("id")
        out.append({"id": c.get("address"), "class": c.get("class") or "",
                    "title": c.get("title") or "", "x": c["at"][0], "y": c["at"][1],
                    "w": c["size"][0], "h": c["size"][1],
                    "floating": bool(c.get("floating")), "fullscreen": bool(c.get("fullscreen")),
                    "visible": ws in showing and c.get("mapped", True) and not c.get("hidden")})
    return out


def _resize_cmd(win_id: str, width: int, height: int, exact: bool, syntax: str) -> str:
    """The dispatch that resizes a window, in the syntax this Hyprland speaks.
    Lua (>= 0.55): hl.dsp.window.resize({ x, y, relative, window }) -- see
    src/config/lua/bindings/LuaBindingsDispatchers.cpp in Hyprland. An exact size
    needs both sides at least 1; a relative one is the change."""
    w, h = int(width), int(height)
    if syntax == "lua":
        if exact:
            return (f'dispatch hl.dsp.window.resize({{ x = {w}, y = {max(1, h)}, '
                    f'relative = false, window = "address:{win_id}" }})')
        return (f'dispatch hl.dsp.window.resize({{ x = {w}, y = 0, relative = true, '
                f'window = "address:{win_id}" }})')
    how = f"exact {w} {h}" if exact else f"{w} 0"
    return f"dispatch resizewindowpixel {how},address:{win_id}"


def set_window_width(win_id: str, width: int, height: int, exact: bool = True) -> None:
    """Make a window `width` wide, keeping its height. Tiled, Hyprland moves the split,
    so the window beside it gives up (or takes) the difference. exact=False: `width`
    is how much to add, and may be negative. Speaks whichever dispatch syntax this
    Hyprland takes -- the same one the pointer found, or it finds out here."""
    global _MOVE_SYNTAX
    order = [_MOVE_SYNTAX] if _MOVE_SYNTAX else ["lua", "legacy"]
    replies = []
    for syntax in order:
        reply = hypr_request(_resize_cmd(win_id, width, height, exact, syntax)).strip()
        if reply == "ok":
            _MOVE_SYNTAX = syntax
            return
        replies.append(f"{syntax}: {reply[:160]}")
    raise BetError("Hyprland wouldn't resize the window — " + " | ".join(replies))


def get_cursor_pos() -> tuple[int, int] | None:
    """Current cursor position in Hyprland logical (layout) coordinates.
    Returns None (and logs why) instead of silently pretending it's (0,0)."""
    if not os.environ.get("HYPRLAND_INSTANCE_SIGNATURE"):
        log.error("HYPRLAND_INSTANCE_SIGNATURE is not set — are you running "
                  "under sudo or outside the Hyprland session?")
        return None
    out = ""
    try:
        out = hypr_request("cursorpos")
        x, y = out.split(",")[:2]
        return int(float(x)), int(float(y))
    except FileNotFoundError:
        log.error("hyprctl not found in PATH")
    except ValueError:
        log.error("Unexpected cursorpos reply: %r", out)
    return None


# Hyprland >= 0.55 (Lua config): dispatch takes a Lua expression.
# Hyprland <= 0.54 (hyprlang):     dispatch movecursor X Y
_MOVE_SYNTAX = None  # "lua" | "legacy", detected on first use


def _move_cmd(x, y, syntax):
    x, y = int(x), int(y)
    if syntax == "lua":
        return f"dispatch hl.dsp.cursor.move({{ x = {x}, y = {y} }})"
    return f"dispatch movecursor {x} {y}"


def move_cursor(x, y) -> None:
    """Warp the cursor to (x, y) in the SAME coordinate space cursorpos
    reports. No pointer acceleration, no scale ratio, exact positioning."""
    global _MOVE_SYNTAX
    if _MOVE_SYNTAX is None:
        for syntax in ("lua", "legacy"):
            reply = hypr_request(_move_cmd(x, y, syntax))
            if reply == "ok":
                _MOVE_SYNTAX = syntax
                log.debug("Cursor move syntax: %s  (socket: %s)", syntax, bool(_HYPR_SOCK))
                return
            log.debug("  %s syntax rejected: %r", syntax, reply)
        raise BetError("Hyprland rejected both cursor-move syntaxes — run --diagnose")
    reply = hypr_request(_move_cmd(x, y, _MOVE_SYNTAX))
    if reply != "ok":
        log.warning("cursor move to (%d,%d) failed: %r", x, y, reply)


def mouse_button(down: bool, button: str = "left") -> bool:
    """Press or release a mouse button where the pointer is."""
    code = {("left", True): "0x40", ("left", False): "0x80",
            ("right", True): "0x41", ("right", False): "0x81"}[(button, bool(down))]
    return _run(["ydotool", "click", code], "press" if down else "release").returncode == 0


# Keys go to whichever window holds the keyboard. With Hyprland's focus-follows-mouse,
# parking the pointer over the game hands it the keyboard, so there is nothing else to do.
RELOAD_KEY = "F5"


def focus_point(x, y) -> None:
    """Give the keyboard to the window under (x, y). Focus follows the mouse here."""


def press_key(key: str, label: str = "") -> bool:
    """One key, by its name: Return, Tab, Down, Up, F5 …"""
    return _run(["wtype", "-k", key], label or f"key {key}").returncode == 0


def type_text(text: str) -> bool:
    return _run(["wtype", text], "wtype").returncode == 0


def type_private(text: str, label: str = "typing", gap_ms: int = 60) -> bool:
    """Text that must never be written down anywhere: wtype reads it from stdin ('-'),
    so it isn't on a command line, and nothing about it is logged."""
    return _run_private(["wtype", "-d", str(gap_ms), "-"], text, label)


# ---------------------------------------------------------------------------
# Pixels
# ---------------------------------------------------------------------------

def capture_region(x: int, y: int, w: int, h: int) -> np.ndarray:
    """The rectangle, as a BGR picture, one pixel per screen unit."""
    geo = f"{x},{y} {w}x{h}"
    r = subprocess.run(["grim", "-g", geo, "-t", "ppm", "-"], capture_output=True)
    if r.returncode != 0:
        raise BetError(f"grim failed for {geo}: {r.stderr.decode().strip()}")
    img = cv2.imdecode(np.frombuffer(r.stdout, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise BetError(f"Could not decode a screenshot of {geo}")
    return img


def capture_screen() -> np.ndarray:
    """The whole screen, as a BGR picture."""
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        tmp = f.name
    try:
        r = subprocess.run(["grim", tmp], capture_output=True)
        if r.returncode != 0:
            raise BetError(f"grim failed: {r.stderr.decode().strip()}")
        img = cv2.imread(tmp, cv2.IMREAD_COLOR)
    finally:
        Path(tmp).unlink(missing_ok=True)
    if img is None:
        raise BetError("grim screenshot empty")
    return img


def take_screenshot() -> np.ndarray:
    return capture_screen()


def select_region() -> str:
    """Let you drag a box on the screen; → its geometry, 'x,y wxh'."""
    try:
        return subprocess.run(["slurp"], capture_output=True, text=True,
                              check=True).stdout.strip()
    except FileNotFoundError:
        raise BetError("slurp isn't installed — it's what draws the selection box") from None
    except subprocess.CalledProcessError:
        raise BetError("nothing was selected") from None


def open_url(url: str) -> None:
    """Open the dashboard in its OWN window, so it never replaces the game's tab."""
    import webbrowser
    try:
        if shutil.which("firefox"):
            subprocess.Popen(["firefox", "--new-window", url], stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
        else:
            webbrowser.open_new(url)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# How busy the machine is (Linux /proc). Read-only, and cheap: the process list is
# scanned rarely, and in between only the few processes being watched are read.
# Elsewhere these return nothing and the load meter shows only the bot's own share.
# ---------------------------------------------------------------------------

_TICK = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100


def find_pids(groups: dict[str, tuple[str, ...]]) -> dict[str, list[int]]:
    """Every running process whose name (/proc/PID/comm) is in a group's names."""
    out: dict[str, list[int]] = {g: [] for g in groups}
    try:
        entries = os.listdir("/proc")
    except OSError:
        return out
    me = os.getpid()
    for e in entries:
        if not e.isdigit() or int(e) == me:
            continue
        try:
            with open(f"/proc/{e}/comm") as f:
                name = process_name(f.read())
        except OSError:
            continue
        g = group_of(name, groups)
        if g:
            out[g].append(int(e))
    return out


def cpu_seconds(pid: int) -> float | None:
    """CPU time a process has used so far (user + system), in seconds."""
    try:
        with open(f"/proc/{pid}/stat") as f:
            fields = f.read().rsplit(")", 1)[1].split()
        return (int(fields[11]) + int(fields[12])) / _TICK
    except (OSError, IndexError, ValueError):
        return None


def machine_cpu() -> tuple[float, float] | None:
    """(busy, total) CPU seconds for the whole machine, all cores together."""
    try:
        with open("/proc/stat") as f:
            v = [int(x) for x in f.readline().split()[1:]]
    except (OSError, ValueError):
        return None
    idle = v[3] + (v[4] if len(v) > 4 else 0)
    total = sum(v[:8])
    return (total - idle) / _TICK, total / _TICK
