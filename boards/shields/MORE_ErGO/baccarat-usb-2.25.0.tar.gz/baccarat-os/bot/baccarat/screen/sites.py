"""Which gaming site is being played, and where its recordings live.

Everything that describes ONE site -- where its buttons are, what its
scoreboard bar looks like, how its digits are drawn, its session settings --
lives in sites/<name>/, so a second site can be set up without disturbing the
first.

The per-site folders are functions, not constants, and that is deliberate: see
the note above them."""

from __future__ import annotations

import json
import os
import re
import shutil
from pathlib import Path
from baccarat.store import paths


from baccarat.errors import BetError
from baccarat.log import log


# ---------------------------------------------------------------------------
# Sites
#
# Everything that describes ONE gaming site — where its buttons are, what its
# scoreboard bar looks like, how its digits are drawn, its session settings —
# lives in sites/<name>/, so a second site can be set up without disturbing the
# first. Which one is in use is remembered in site.json, so every entry point
# agrees, whichever you run.
#
# Shared on purpose: debug screenshots, the recorded tables and the run history.
# Those are what HAPPENED, not how a site is laid out, and a losing run needs
# the same number of lives wherever it was played.
#
# Note these are functions, not constants. They used to be module globals that
# use_site() rebound. That works in one file and nowhere else: any module doing
# `from bet import SNAPS_DIR` captures whichever site happened to be current at
# import time and then writes the next site's templates into the first site's
# folder. Asking each time is what lets this file be broken up at all.
# ---------------------------------------------------------------------------

SITE_FILES = ("coords.json", "settings.json")     # what belongs to a site


SITE_DIRS = ("patterns", "snaps", "digits", "colors")


DEFAULT_SITE = "default"


_SITE = ""                     # the site in use; set by use_site() below


def site_name() -> str:
    return _SITE


def site_slug(name: str) -> str:
    """A folder name that is still recognisably what you typed: siteA stays siteA."""
    s = re.sub(r"[^A-Za-z0-9._ -]+", "", str(name)).strip()
    s = re.sub(r"[ .]+", "_", s).strip("_-")
    return s[:40]


def site_dir(name: str | None = None) -> Path:
    return paths.sites_dir() / (site_slug(name) if name else _SITE)


# The per-site folders. One line each, asked for at the moment they are used.
def coords_file() -> Path:  return site_dir() / "coords.json"


def patterns_dir() -> Path: return site_dir() / "patterns"


def snaps_dir() -> Path:    return site_dir() / "snaps"


def digits_dir() -> Path:   return site_dir() / "digits"


def colors_dir() -> Path:   return site_dir() / "colors"


def login_file(name: str | None = None) -> Path:
    """The email and password for this site. Its own file, readable only by you,
    never in the settings, the log, the dashboard's state or Copy report."""
    return site_dir(name) / "login.json"


def load_login(name: str | None = None) -> dict:
    try:
        d = json.loads(login_file(name).read_text())
    except (OSError, json.JSONDecodeError):
        return {}
    return {"email": str(d.get("email") or ""), "password": str(d.get("password") or "")}


def save_login(email: str | None = None, password: str | None = None) -> dict:
    """Change what is given; leave the rest. An empty password keeps the saved one, so
    the page never has to send it back to change the email."""
    cur = load_login()
    if email is not None:
        cur["email"] = email.strip()
    if password:
        cur["password"] = password
    f = login_file()
    f.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(f, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as out:
        json.dump(cur, out)
    os.chmod(f, 0o600)                  # an older file may have been made more open
    return login_summary()


def forget_login() -> dict:
    login_file().unlink(missing_ok=True)
    return login_summary()


def login_summary() -> dict:
    """What the page may know: whether each part is there. Never the password."""
    d = load_login()
    return {"email": d.get("email", ""), "has_password": bool(d.get("password"))}


def game_url_file(name: str | None = None) -> Path:
    """The page the game is played on, for this site: what the USB stick opens in the
    game's window when it starts."""
    return site_dir(name) / "game.json"


def load_game_url(name: str | None = None) -> str:
    try:
        return str(json.loads(game_url_file(name).read_text()).get("url") or "")
    except (OSError, json.JSONDecodeError, AttributeError):
        return ""


def save_game_url(url: str) -> str:
    url = (url or "").strip()
    if url and not re.match(r"^https?://[^\s/]+", url):
        raise BetError("the game's page must be a web address: https://…")
    f = game_url_file()
    if not url:
        f.unlink(missing_ok=True)
        return ""
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps({"url": url}, indent=1) + "\n")
    return url


def debug_dir() -> Path:
    """Screenshots kept to explain a decision. Shared: they are what happened."""
    return paths.debug_dir()


def list_sites() -> list[str]:
    d = paths.sites_dir()
    if not d.is_dir():
        return []
    return sorted((x.name for x in d.iterdir() if x.is_dir()), key=str.lower)


def use_site(name: str, remember: bool = True) -> str:
    """Play this site from now on, making its folder if it's new."""
    global _SITE
    slug = site_slug(name) or DEFAULT_SITE
    (paths.sites_dir() / slug).mkdir(parents=True, exist_ok=True)
    _SITE = slug
    if remember:
        try:
            paths.site_file().write_text(json.dumps({"site": slug}, indent=1) + "\n")
        except OSError:
            pass
    return slug


def delete_site(name: str) -> None:
    """Remove a site's folder. The one in use is never deleted."""
    slug = site_slug(name)
    if not slug or slug == _SITE:
        raise BetError("that's the site being played — switch to another one first")
    d = paths.sites_dir() / slug
    if not d.is_dir():
        raise BetError(f"there is no site called '{name}'")
    shutil.rmtree(d)
    log.info("Site '%s' deleted.", slug)


def _adopt_old_layout(d: Path) -> list[str]:
    """First run after the update: the files that used to sit loose in the data
    folder are moved into the first site, so nothing has to be recorded again."""
    moved = []
    for n in (*SITE_FILES, *SITE_DIRS):
        old = paths.data_dir() / n
        if old.exists() and not (d / n).exists():
            old.rename(d / n)
            moved.append(n)
    return moved


def _start_site() -> None:
    """Pick the site to start on: the remembered one, else the only one there is,
    else a new 'default' that adopts whatever was lying loose in the data folder."""
    want = ""
    try:
        want = str(json.loads(paths.site_file().read_text()).get("site") or "")
    except (OSError, json.JSONDecodeError, AttributeError):
        pass
    have = list_sites()
    fresh = not have and not want
    # not remembered: this runs on import, and importing the program must not write to
    # your data. The choice is the same next time anyway -- the remembered one, else
    # the first there is. Only picking a site on purpose (use_site) saves it.
    use_site(want or (have[0] if have else DEFAULT_SITE), remember=False)
    if fresh:
        moved = _adopt_old_layout(site_dir())
        if moved:
            log.info("Your set-up has moved into sites/%s/ (%s). Record another site with "
                     "--site NAME, or pick one on the dashboard.", _SITE, ", ".join(moved))


# ---------------------------------------------------------------------------
# Coordinates store
# ---------------------------------------------------------------------------

def load_coords() -> dict:
    if coords_file().exists():
        return json.loads(coords_file().read_text())
    return {}


def save_coords(coords: dict) -> None:
    coords_file().write_text(json.dumps(coords, indent=2) + "\n")


# ---------------------------------------------------------------------------
# Pattern store  (meta.json per pattern)
# ---------------------------------------------------------------------------

def _slug(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", name.strip().lower()).strip("_")


def _pattern_dir(name: str) -> Path:
    return patterns_dir() / _slug(name)


def _load_meta(d: Path) -> dict:
    f = d / "meta.json"
    return json.loads(f.read_text()) if f.exists() else {"steps": []}


def _save_meta(d: Path, m: dict) -> None:
    (d / "meta.json").write_text(json.dumps(m, indent=2) + "\n")


def list_patterns() -> list[tuple[str, Path, int]]:
    if not patterns_dir().is_dir():
        return []
    out = []
    for d in sorted(patterns_dir().iterdir()):
        if d.is_dir():
            m = _load_meta(d)
            out.append((d.name.replace("_", " "), d, len(m["steps"])))
    return out
