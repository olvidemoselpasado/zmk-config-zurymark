"""Drag a box on the screen; print its geometry. The macOS stand-in for slurp.

    python select_box.py      → prints 'x,y wxh' (screen units)

A see-through layer over the main screen. Press, drag, let go: the box is printed
and the layer closes. Esc, a right-click, or a minute without a box cancels.

It runs as a program of its own because macOS only lets a program open windows on
its main thread, and the dashboard asks for a box from one of its own threads.

Exit codes: 0 = a box was printed, 1 = cancelled, 2 = Tk isn't available.
"""

from __future__ import annotations

import sys


def main() -> int:
    try:
        import tkinter as tk
    except Exception:
        print("Tk isn't available in this Python", file=sys.stderr)
        return 2
    try:
        root = tk.Tk()
    except Exception as e:
        print(f"Tk couldn't open a window: {e}", file=sys.stderr)
        return 2
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.overrideredirect(True)                 # no title bar: the layer is the screen
    root.geometry(f"{sw}x{sh}+0+0")
    root.attributes("-topmost", True)
    try:
        root.attributes("-alpha", 0.28)        # see the game through it
    except tk.TclError:
        pass
    c = tk.Canvas(root, width=sw, height=sh, bg="#101418", highlightthickness=0,
                  cursor="crosshair")
    c.pack(fill="both", expand=True)
    c.create_text(sw // 2, sh // 2, fill="#ffffff", font=("Helvetica", 22, "bold"),
                  text="Drag a box around it  ·  Esc to cancel")
    state = {"start": None, "rect": None, "result": None}

    def press(e):
        state["start"] = (e.x_root, e.y_root, e.x, e.y)
        if state["rect"]:
            c.delete(state["rect"])
        state["rect"] = c.create_rectangle(e.x, e.y, e.x, e.y, outline="#3fe61d", width=2)

    def drag(e):
        if state["start"]:
            _, _, x0, y0 = state["start"]
            c.coords(state["rect"], x0, y0, e.x, e.y)

    def release(e):
        if not state["start"]:
            return
        x0, y0, _, _ = state["start"]
        x, y = min(x0, e.x_root), min(y0, e.y_root)
        w, h = abs(e.x_root - x0), abs(e.y_root - y0)
        if w >= 4 and h >= 4:                   # a click, not a box: keep waiting
            state["result"] = f"{int(x)},{int(y)} {int(w)}x{int(h)}"
            root.destroy()
        else:
            state["start"] = None

    def cancel(_e=None):
        root.destroy()

    c.bind("<ButtonPress-1>", press)
    c.bind("<B1-Motion>", drag)
    c.bind("<ButtonRelease-1>", release)
    c.bind("<ButtonPress-2>", cancel)          # right button on a Mac is 2 in Tk
    c.bind("<ButtonPress-3>", cancel)
    root.bind("<Escape>", cancel)
    root.after(60_000, cancel)
    root.after(50, lambda: (root.lift(), root.focus_force()))
    root.mainloop()
    if state["result"]:
        print(state["result"])
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
