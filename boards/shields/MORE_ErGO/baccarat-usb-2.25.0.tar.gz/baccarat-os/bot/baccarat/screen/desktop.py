"""The only door to the operating system.

Everything the program does to a machine it does not own goes through here: taking
a picture of the screen, letting you drag a box, moving the real pointer, pressing
a real button or key, typing, telling how busy the machine is. The reading, the
strategy and the betting never learn which machine they are on.

Behind the door is one backend per system, picked once, when the program starts:

    linux.py    Wayland with Hyprland: hyprctl, grim, slurp, ydotool, wtype, /proc
    macos.py    Quartz for pixels and input, Accessibility for focus, psutil

BACCARAT_DESKTOP=linux|macos overrides the choice (for testing one on the other).
Every function here calls the backend at the moment it is used, never a copy of it,
so a test can stand in for any one piece.

Coordinates are screen units everywhere: what the pointer reports and where a click
lands. On a Retina Mac one unit is two pixels; pictures come back at one pixel per
unit all the same, so everything taught on one screen reads the same on any other.
"""

from __future__ import annotations

import os
import re
import sys

from baccarat.errors import BetError
from baccarat.screen.procnames import group_of, process_name  # noqa: F401  (re-exported)

PLATFORM = (os.environ.get("BACCARAT_DESKTOP") or
            ("macos" if sys.platform == "darwin" else "linux")).strip().lower()

if PLATFORM == "macos":
    from baccarat.screen import macos as backend
else:
    from baccarat.screen import linux as backend


# the key that reloads the page: F5 on Linux, ⌘R on a Mac
RELOAD_KEY = backend.RELOAD_KEY
YDOTOOL_SOCKET = getattr(backend, "YDOTOOL_SOCKET", "")


def parse_geo(geo: str) -> tuple[int, int, int, int]:
    """'x,y wxh' → (x, y, w, h)."""
    m = re.match(r"^\s*(-?\d+),(-?\d+)\s+(\d+)x(\d+)\s*$", geo or "")
    if not m:
        raise BetError(f"that doesn't look like a region: {geo!r}")
    x, y, w, h = (int(v) for v in m.groups())
    if w <= 0 or h <= 0:
        raise BetError(f"a region has to have a size: {geo!r}")
    return x, y, w, h


# -- what can be done here ------------------------------------------------------------
def check_tools() -> None:
    backend.check_tools()


def ensure_input() -> None:
    """Make sure clicks and keys will arrive. Raises with what to do when they won't."""
    backend.ensure_input()


# -- the pointer ----------------------------------------------------------------------
def get_cursor_pos() -> tuple[int, int] | None:
    return backend.get_cursor_pos()


def move_cursor(x, y) -> None:
    backend.move_cursor(x, y)


def mouse_button(down: bool, button: str = "left") -> bool:
    return backend.mouse_button(down, button)


# -- the keyboard ---------------------------------------------------------------------
def focus_point(x, y) -> None:
    """Hand the keyboard to the window under (x, y), so a key goes to the game and not
    to the dashboard."""
    backend.focus_point(x, y)


def press_key(key: str, label: str = "") -> bool:
    """One key by name (Return, Tab, Down, Up, F5), or a combination such as 'cmd+r'."""
    return backend.press_key(key, label)


def type_text(text: str) -> bool:
    return backend.type_text(text)


def type_private(text: str, label: str = "typing", gap_ms: int = 60) -> bool:
    """Type something that must never be written down: never logged, never on a
    command line."""
    return backend.type_private(text, label, gap_ms)


# -- pixels ---------------------------------------------------------------------------
def capture_region(geo: str):
    """The region 'x,y wxh' as a BGR picture, one pixel per screen unit."""
    return backend.capture_region(*parse_geo(geo))


def capture_screen():
    return backend.capture_screen()


def select_region() -> str:
    """Let you drag a box; → its geometry 'x,y wxh'. BetError if nothing was."""
    geo = backend.select_region()
    parse_geo(geo)
    return geo


def open_url(url: str) -> None:
    backend.open_url(url)


# -- windows ----------------------------------------------------------------------------
def list_windows() -> list[dict]:
    """[{id, class, title, x, y, w, h, floating, fullscreen, visible}] — every window."""
    fn = getattr(backend, "list_windows", None)
    if fn is None:
        raise BetError("sizing the game window is only done on Hyprland so far")
    return fn()


def set_window_width(win_id: str, width: int, height: int, exact: bool = True) -> None:
    fn = getattr(backend, "set_window_width", None)
    if fn is None:
        raise BetError("sizing the game window is only done on Hyprland so far")
    fn(win_id, width, height, exact)


# -- how busy the machine is ------------------------------------------------------------
def find_pids(groups: dict[str, tuple[str, ...]]) -> dict[str, list[int]]:
    return backend.find_pids(groups)


def cpu_seconds(pid: int) -> float | None:
    return backend.cpu_seconds(pid)


def machine_cpu() -> tuple[float, float] | None:
    return backend.machine_cpu()


# -- what the old names were, for the Linux diagnostics and older callers --------------
def get_backend():
    return backend
