"""Reading the big road -- the grid of red and blue circles.

Read as colour rather than as text: the dots have no glyphs to match. Columns
are found, then each column's dots top to bottom, which gives the results in
order regardless of how many hands the table has shown."""

from __future__ import annotations

import cv2
import numpy as np


from baccarat.screen.capture import read_region
from baccarat.screen.sites import snaps_dir


# ---------------------------------------------------------------------------
# Bead road: the grid of colored circles showing every result of the table
#
#   blue = player, red = banker, green = tie; filled top→bottom, then left→right.
#   A small blue dot at a circle's top-left = player pair, red dot bottom-right = banker pair
#   (only reported when the dot's colour differs from its circle's).
#
#   --snap road      select the grid (just the circles area; the settings icon may stay)
#   --read-road      test it
# No teaching needed: circles are found by their color.
# ---------------------------------------------------------------------------

def _road_masks(img: np.ndarray) -> dict[str, np.ndarray]:
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    sat = (s > 90) & (v > 60)
    return {"banker": sat & ((h <= 10) | (h >= 165)),
            "player": sat & (h >= 95) & (h <= 118),        # frames are often blue-purple (≈120+)
            "tie":    sat & (h >= 40) & (h <= 90)}


def _odd(x: float) -> int:
    return max(3, int(round(x)) | 1)


def read_road_detailed(name: str = "road", img: np.ndarray | None = None) -> dict:
    """→ {"road": ["player", "banker", …], "pairs": [[…], …], "beads": [(x, y, r), …]}
    in table order (oldest first)."""
    if img is None:
        img = read_region(name)
    scale = 1 if min(img.shape[:2]) >= 200 else 2          # small grids: more pixels per circle
    if scale > 1:
        img = cv2.resize(img, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    masks = {k: m.astype(np.uint8) for k, m in _road_masks(img).items()}
    raw = {k: m.astype(bool) for k, m in masks.items()}      # untouched, for the small pair dots
    empty = {"road": [], "pairs": [], "beads": []}

    # 1. drop thin shapes (frames, grid lines): circles are thick. Judge thickness after
    #    closing the digit strokes, so a thin ring around a big white digit still counts.
    stroke = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (_odd(3.5 * scale), _odd(3.5 * scale)))
    for k, m in masks.items():
        cm = cv2.morphologyEx(m, cv2.MORPH_CLOSE, stroke)
        thick = cv2.distanceTransform(cm, cv2.DIST_L2, 3)
        n, lab = cv2.connectedComponents(cm)
        for i in range(1, n):
            part = lab == i
            if thick[part].max() < 3.0 * scale:
                m[part] = 0

    # 2. circle radius: thickest point of each shape filled from its outline
    #    (the white digits inside would otherwise make circles look thin)
    maxes = []
    for m in masks.values():
        contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        f = np.zeros_like(m)
        cv2.drawContours(f, contours, -1, 1, thickness=cv2.FILLED)
        d = cv2.distanceTransform(f, cv2.DIST_L2, 5)
        n, lab, st, _ = cv2.connectedComponentsWithStats(f)
        maxes += [float(d[lab == i].max()) for i in range(1, n) if st[i][4] > 30 * scale]
    maxes = [x for x in maxes if 3 * scale <= x < 1e6]
    if not maxes:
        return empty
    r = float(np.median(maxes))

    # 3. per colour: fill the digit strokes, then find circle centres (candidates)
    close_k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (_odd(0.45 * r), _odd(0.45 * r)))
    peak_k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (_odd(1.2 * r), _odd(1.2 * r)))
    closed, cand = {}, []
    for side, m in masks.items():
        c = cv2.morphologyEx(m, cv2.MORPH_CLOSE, close_k)
        # fill small holes left inside (the loops of 8, 9, 6 …), not the gaps between circles
        contours, hier = cv2.findContours(c, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
        if hier is not None:
            for idx, h in enumerate(hier[0]):
                if h[3] >= 0 and cv2.contourArea(contours[idx]) < 0.18 * np.pi * r * r:
                    cv2.drawContours(c, contours, idx, 1, thickness=cv2.FILLED)
        closed[side] = c
        d = cv2.distanceTransform(c, cv2.DIST_L2, 5)
        peaks = ((d >= cv2.dilate(d, peak_k) - 0.5) & (d >= 0.75 * r)).astype(np.uint8)
        n, _, _, cents = cv2.connectedComponentsWithStats(peaks)
        cand += [(float(x), float(y)) for x, y in cents[1:]]
    if not cand:
        return empty

    # 4. the road is a regular grid: get its spacing and alignment from the candidates,
    #    then look at every cell centre (so touching circles or frames can't confuse it)
    pts = np.array(cand)
    if len(pts) >= 2:
        dd = np.sqrt(((pts[:, None, :] - pts[None, :, :]) ** 2).sum(-1))
        np.fill_diagonal(dd, np.inf)
        nn = dd.min(axis=1)
        pitch = float(np.median(nn[nn < 3.2 * r])) if (nn < 3.2 * r).any() else 2.1 * r
    else:
        pitch = 2.1 * r
    pitch = min(max(pitch, 1.9 * r), 2.6 * r)
    def phase(v):                                   # grid offset that best fits the candidates
        ang = 2 * np.pi * v / pitch
        a = np.arctan2(np.sin(ang).mean(), np.cos(ang).mean())
        return (a / (2 * np.pi) * pitch) % pitch
    H, W = next(iter(masks.values())).shape
    x0, y0 = phase(pts[:, 0]), phase(pts[:, 1])
    while x0 - pitch >= 0.6 * r:
        x0 -= pitch
    while x0 < 0.6 * r:
        x0 += pitch
    while y0 - pitch >= 0.6 * r:
        y0 -= pitch
    while y0 < 0.6 * r:
        y0 += pitch
    yy, xx = np.mgrid[0:H, 0:W]
    found = []                                      # (x, y, side, col, row)
    col, cx = 0, x0
    while cx <= W - 0.6 * r:
        row, cy = 0, y0
        while cy <= H - 0.6 * r:
            disk = (xx - cx) ** 2 + (yy - cy) ** 2 <= (0.55 * r) ** 2
            area = disk.sum()
            counts = {sd: int((cm.astype(bool) & disk).sum()) for sd, cm in closed.items()}
            side = max(counts, key=counts.get)
            if area and counts[side] >= 0.6 * area:
                found.append((cx, cy, side, col, row))
            row, cy = row + 1, cy + pitch
        col, cx = col + 1, cx + pitch
    if not found:
        return empty

    # 4. pairs: a small dot on the circle's corner (not part of a neighbouring circle)
    edge = 0.3 * r                                  # the frame sits along the border
    inner_area = (xx > edge) & (yy > edge) & (xx < W - edge) & (yy < H - edge)
    beads = []
    for cx, cy, side, gcol, grow in found:
        d2 = (xx - cx) ** 2 + (yy - cy) ** 2
        ring = (d2 > (0.88 * r) ** 2) & (d2 <= (1.35 * r) ** 2)
        for ox, oy, *_ in found:                             # not inside another circle
            if (ox, oy) != (cx, cy):
                ring &= (xx - ox) ** 2 + (yy - oy) ** 2 > (1.08 * r) ** 2
        tl = ring & (xx < cx - 0.35 * r) & (yy < cy - 0.35 * r)
        br = ring & (xx > cx + 0.35 * r) & (yy > cy + 0.35 * r)
        # Only dots that contrast with their circle are reported (blue on red, red on
        # blue): a same-colour dot can't be told apart from the circle's edge or a frame.
        # The scoreboard bar's pair counters stay the source for pair totals.
        tl &= inner_area
        br &= inner_area
        pairs = []
        if side != "player" and (raw["player"] & tl).sum() > 0.05 * r * r:
            pairs.append("player_pair")
        if side != "banker" and (raw["banker"] & br).sum() > 0.05 * r * r:
            pairs.append("banker_pair")
        beads.append((cx, cy, side, pairs, gcol, grow))

    # 5. reading order: columns left → right, each top → bottom
    ordered = sorted(beads, key=lambda b: (b[4], b[5]))
    return {"road": [b[2] for b in ordered], "pairs": [b[3] for b in ordered],
            "beads": [(b[0] / scale, b[1] / scale, r / scale) for b in ordered]}


def read_road(name: str = "road") -> list[str] | None:
    """The table's results so far, oldest first. None if there's no road region."""
    if not (snaps_dir() / f"{name}.geo").exists():
        return None
    return read_road_detailed(name)["road"]
