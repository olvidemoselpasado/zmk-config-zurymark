"""Reading the Setup form: every number the dashboard can send, and what is
wrong with it.

One validator per group of fields, each returning either the values or a
sentence saying what cannot be done. click_budget_problem is the one that
matters most: it refuses a configuration whose biggest possible bet could never
be clicked inside the betting window, which the program used to accept and then
discover at the table with money on the line."""

from __future__ import annotations

import math
from baccarat import screen as bet
from baccarat.core.tablekind import EXCEPTIONAL_AT, REGULAR_BELOW, WHOLE_TABLE_AFTER
from baccarat.core import bets as betting
from baccarat import core as strategies
from baccarat.core.rules import build_rules
from baccarat.core.strategy import STRATEGIES


from baccarat.play.actions import set_leave_way
from baccarat.play import tuning


# ---------------------------------------------------------------------------
# Settings shared by the command line and the dashboard
# ---------------------------------------------------------------------------

def parse_target(text, budget: float) -> tuple[float | None, float | None]:
    """How much to win → (ceiling, target).
    '60' → win 60: stop at budget + 60. '=380' → stop at exactly 380 (target = 380 − budget).
    '' / None → no target."""
    if text is None or str(text).strip() == "":
        return None, None
    t = str(text).strip().replace(",", "").lstrip("+")
    absolute = t.startswith("=")
    try:
        value = float(t[1:]) if absolute else float(t)
    except ValueError:
        raise ValueError(f"'{text}' isn't a number — write how much to win, e.g. 60 "
                         "(or =380 for a fixed balance)") from None
    ceiling = value if absolute else budget + value
    target = round(ceiling - budget, 2)
    if target <= 0:
        raise ValueError(f"the target must be more than 0 (a balance of {ceiling:,.2f} is not "
                         f"above the budget of {budget:,.2f})")
    return ceiling, target


def _num(body: dict, key: str, label: str, positive=True, integer=False, optional=False):
    v = body.get(key)
    if v is None or str(v).strip() == "":
        if optional:
            return None
        raise ValueError(f"{label} is required")
    try:
        x = int(str(v)) if integer else float(str(v).replace(",", ""))
    except ValueError:
        raise ValueError(f"{label} must be a {'whole ' if integer else ''}number") from None
    if positive and x <= 0:
        raise ValueError(f"{label} must be more than 0")
    return x


def screen_params(body: dict, params: dict) -> dict:
    """Setup form → the road patterns to walk away from, and how much of a table's
    history has to be visible before they are allowed to judge it."""
    screens = strategies.build_patterns(body.get("screens") or [])
    least = _num(body, "screen_min", "Results needed to judge a table",
                 integer=True, optional=True)
    least = 20 if least is None else int(least)
    if screens and least and params.get("table_hands") and least >= params["table_hands"]:
        raise ValueError(f"asking for {least} results before judging a table leaves no "
                         f"room to play one of {params['table_hands']} hands")
    if screens and not body.get("open_patterns"):
        raise ValueError("to skip a bad table the bot needs somewhere to go — tick at "
                         "least one open_table action, or untick the patterns")
    if screens and not (body.get("wait_hands") or params.get("table_hands")):
        raise ValueError("a table that is turned down is left alone for the hands its "
                         "shoe has left, so set 'hands a table usually lasts'")
    return {"screens": screens, "screen_min": least}


def cycle_params(body: dict, params: dict) -> dict:
    """Settings for unattended repeats (reach the ceiling N times, table by table)."""
    cycles = int(_num(body, "cycles", "Times to reach the ceiling", integer=True, optional=True) or 1)
    switching = params.get("at_cutoff") == "switch"
    chosen = [n for n in (body.get("open_patterns") or []) if str(n).strip()]
    known = set(bet.pattern_names()) | set(bet.load_coords())
    missing = [n for n in chosen if n not in known]
    if missing:
        raise ValueError(f"nothing named {', '.join(missing)} — record it on the Interface "
                         "tab (Name, then Record)")
    hand_seconds = _num(body, "hand_seconds", "Seconds per hand", optional=True) or tuning.HAND_SECONDS
    wait_hands = _num(body, "wait_hands", "Hands a table usually lasts", integer=True, optional=True)
    if wait_hands and params.get("table_hands") and wait_hands < params["table_hands"]:
        raise ValueError(f"'hands a table usually lasts' ({wait_hands}) can't be less than the "
                         f"hands per table ({params['table_hands']})")
    extra_wait = _num(body, "extra_wait", "Extra wait", positive=False, optional=True)
    extra_wait = tuning.CYCLE_EXTRA if extra_wait is None else extra_wait
    if cycles <= 1 and not switching:
        # no repeats and no switching: the open actions are still used to reopen a
        # table that stops moving
        return {"cycles": 1, "ceiling_step": None, "open_patterns": chosen,
                "hand_seconds": hand_seconds, "extra_wait": extra_wait, "wait_hands": wait_hands}
    what = "to move to another table" if switching and cycles <= 1 else "to repeat"
    if cycles > 1 and params.get("ceiling") is None:
        raise ValueError("to repeat, set how much to win — each cycle plays until it's won")
    if not params["table_hands"]:
        raise ValueError(f"{what}, set the hands per table — the wait for the table to "
                         "finish is worked out from it")
    if not chosen:
        raise ValueError(f"{what}, tick at least one open_table action")
    step = _num(body, "ceiling_step", "Win per cycle", optional=True)   # carried on after an update
    return {"cycles": cycles,
            "ceiling_step": step or (params.get("target")
                             or (round(params["ceiling"] - params["budget"], 2)
                                 if params.get("ceiling") is not None else None)),
            "open_patterns": chosen,
            "hand_seconds": hand_seconds, "extra_wait": extra_wait, "wait_hands": wait_hands}


def _unknown_action(action: str, known: tuple) -> ValueError:
    """An action the page asked for that this main.py has never heard of means the two
    files are out of step — almost always dashboard.html copied across without main.py."""
    return ValueError(f"unknown action '{action}'. This main.py knows: {', '.join(known)}. "
                      f"If the page just asked for something newer, copy main.py and bet.py "
                      f"across too — the footer shows the date of each.")


def login_params(body: dict) -> dict:
    """How hard to try to log in. The email and password are not here: they are saved
    on their own, per site, and never travel with the rest of the settings."""
    tries = _num(body, "login_tries", "Login tries", integer=True, optional=True)
    tries = tuning.LOGIN_TRIES if tries is None else int(tries)
    if not 1 <= tries <= 10:
        raise ValueError("login tries has to be between 1 and 10")
    wait = _num(body, "login_wait", "Login wait", optional=True)
    wait = tuning.LOGIN_WAIT if wait is None else float(wait)
    if not 10 <= wait <= 600:
        raise ValueError("the wait for a login has to be between 10 s and 600 s")
    return {"login_tries": tries, "login_wait": wait,
            "login_enter": bool(body.get("login_enter", True))}


def kind_params(body: dict) -> dict:
    """Judging what kind of table this is: on or off, what a table must make to count
    as exceptional and as good, and -- with no majority window -- how many results
    the whole-table pattern needs before a table is judged."""
    exc = _num(body, "kind_exceptional", "Exceptional table", optional=True)
    reg = _num(body, "kind_regular", "Good table", optional=True)
    after = _num(body, "kind_after", "Results before judging", integer=True, optional=True)
    exc = EXCEPTIONAL_AT if exc is None else float(exc)
    reg = REGULAR_BELOW if reg is None else float(reg)
    after = WHOLE_TABLE_AFTER if after is None else int(after)
    if reg <= 0:
        raise ValueError("a good table has to make something — set it above 0")
    if exc <= reg:
        raise ValueError(f"an exceptional table ({exc:,.0f}) has to make more than a good "
                         f"one ({reg:,.0f})")
    if not 4 <= after <= 60:
        raise ValueError("judge the whole table after between 4 and 60 results")
    return {"on": bool(body.get("kind_on", True)), "exceptional_at": exc,
            "regular_below": reg, "whole_after": after}


def timing_params(body: dict) -> dict:
    """The clock settings: how long the table takes bets, and how fast a click is."""
    window = _num(body, "bet_window", "Betting window", optional=True) or tuning.BET_WINDOW[1]
    lo = _num(body, "click_min", "Fastest click", optional=True) or tuning.CLICK_SPEED[0]
    hi = _num(body, "click_max", "Slowest click", optional=True) or tuning.CLICK_SPEED[1]
    if hi < lo:
        raise ValueError("the slowest click can't be quicker than the fastest one")
    if hi > 2:
        raise ValueError("a click taking more than 2 s would never fit a betting window")
    if window <= lo:
        raise ValueError(f"a betting window of {window:g} s can't fit even one click")
    move = _num(body, "move_speed", "Pointer travel", optional=True)
    move = 0.26 if move is None else float(move)
    if not 0.06 <= move <= 0.8:
        raise ValueError("pointer travel has to be between 0.06 s and 0.8 s per 1000 px — "
                         "below that it jumps, above it the bet takes too long to place")
    mismatch = str(body.get("on_mismatch") or "carry_on")
    if mismatch not in tuning.MISMATCH_WAYS:
        raise ValueError("when the screen disagrees: choose carry on, pause or stop")
    quiet = _num(body, "quiet_poll", "Screen reads while waiting", optional=True)
    quiet = tuning.QUIET_POLL if quiet is None else float(quiet)
    if not tuning.POLL <= quiet <= 3.0:
        raise ValueError(f"the quiet gap between screen reads has to be between {tuning.POLL:g} s "
                         "and 3 s — below that it isn't quiet, above it a result could be "
                         "noticed too late to bet on the next hand")
    set_leave_way(str(body.get("leave") or "close"))      # how a table is left
    return {"bet_window": window, "click_speed": (lo, hi),
            "hard_score": bool(body.get("hard_score")), "quiet_poll": quiet,
            "move_speed": move, "on_mismatch": mismatch,
            "stake_on_place": bool(body.get("stake_on_place", True)),
            "bet_start_on": "chips" if body.get("bet_start_on") == "chips" else "game"}


def click_cost(params: dict, timing: dict) -> dict:
    """How long the longest bet this configuration can produce would take to click,
    against the betting window it has to fit into."""
    if not hasattr(betting, "worst_bet"):
        raise ValueError("betting.py is out of date — it has no worst_bet, so the biggest "
                         "bet can't be checked against the betting window. Copy the latest "
                         "betting.py across; every file of this program has to come from "
                         "the same version.")
    values = betting.chip_values(bet.load_coords())
    has_redo = bool(betting.redo_names(bet.load_coords()))
    clicks, stake, acts = betting.worst_bet(values, params["base"], params.get("max_steps"),
                                            params["budget"], has_redo) if values else (0, 0, [])
    per = timing["click_speed"][1] + float(timing.get("move_speed") or 0.26) * 1.1
    repeats = betting.repeat_clicks(acts, bet.load_coords(), "player", bet.SAME_SPOT_PX)
    need = tuning.BET_MARGIN + clicks * per + repeats * bet.same_spot_wait()
    return {"chips": values, "clicks": clicks, "stake": stake, "per_click": per,
            "repeats": repeats,
            "needs": need, "window": timing["bet_window"], "fits": clicks == 0 or need <= timing["bet_window"],
            "how": betting.describe(acts, "player", short=True) if acts else ""}


def click_budget_problem(params: dict, timing: dict) -> str | None:
    """Refuse a set-up whose biggest bet can never be clicked in time. Finding this
    out hand by hand, after the session has started, is no use to anybody: the bet is
    simply skipped and the strategy is left betting nothing at the worst moment."""
    c = click_cost(params, timing)
    if c["fits"]:
        return None
    return (f"the biggest bet this set-up can reach is {c['stake']:,.0f}, which takes "
            f"{c['clicks']} clicks ({c['how']}). At {c['per_click']:.2f} s a click that is "
            f"{c['needs']:.1f} s, and the betting window is only {c['window']:.0f} s — so that "
            f"bet could never be placed. Any of these fixes it: raise 'Betting window' to "
            f"{math.ceil(c['needs'])} s or more; lower the doubling limit so the ladder stops "
            f"sooner; record bigger chips so fewer clicks make the stake; or lower 'Slowest "
            f"click' and 'Pointer travel'.")


def session_params(body: dict) -> dict:
    """Validate the Setup form → keyword arguments for a session."""
    strategy = body.get("strategy") or "streak_or_chop"
    if strategy not in STRATEGIES and strategy != "all":
        raise ValueError(f"unknown strategy '{strategy}'")
    budget = _num(body, "budget", "Budget")
    base = _num(body, "base", "Base bet")
    if base > budget:
        raise ValueError("the base bet can't be more than the budget")
    max_steps = _num(body, "max_steps", "Doubling limit", integer=True, optional=True)
    if max_steps is not None and not 1 <= max_steps <= 20:
        # a count of losses: 20 already means a bet a million times the base. A larger
        # number is something else typed in the wrong field (the budget, usually).
        raise ValueError(f"Doubling limit {max_steps:,} isn't a number of losses: it is after "
                         "how many losses a run is given up and the bet goes back to the base "
                         "(1 to 20), or empty for 'as far as the budget goes'. Was it meant "
                         "for another field?")
    ceiling, target = parse_target(body.get("target", body.get("ceiling")), budget)
    rules = body.get("rules") or []
    build_rules(rules)                          # validates names and numbers
    table_hands = _num(body, "table_hands", "Hands per table", integer=True, optional=True)
    at_cutoff = body.get("at_cutoff") or "wait"
    if at_cutoff not in ("wait", "switch", "stop"):
        raise ValueError("near the table's end: choose 'wait', 'switch' or 'stop'")
    margin = int(_num(body, "cutoff_margin", "Hands kept at the end",
                      integer=True, optional=True) or tuning.CUTOFF_MARGIN)
    if table_hands and margin >= table_hands:
        raise ValueError(f"keeping {margin} hands of a {table_hands}-hand table leaves no room "
                         "to start a run at all")
    unit = _num(body, "shadow_unit", "Shadow bet", positive=False, optional=True) or 0.0
    after = int(_num(body, "shadow_after", "Shadow after N losses",
                     integer=True, optional=True) or 2)
    floor = int(_num(body, "shadow_min_lives", "Shadow lives floor",
                     integer=True, optional=True) or 5)
    if unit < 0:
        raise ValueError("the shadow bet can't be negative")
    if unit and floor <= after:
        raise ValueError(f"the lives floor ({floor}) has to be more than the {after} losses "
                         "the shadow waits for, or it could never join a run")
    if unit and unit < base:
        raise ValueError(f"a shadow of {unit:,.0f} is smaller than the base bet ({base:,.0f}) "
                         "— it would hardly change anything")
    extra = {"extra_every": 0, "extra_strict": 2, "extra_after": 6, "extra_for": 20}
    if body.get("extra_on"):
        def whole(key, label, default):
            v = _num(body, key, label, integer=True, optional=True)
            return default if v is None else int(v)
        extra = {"extra_every": whole("extra_every", "Extra life: one in", 3),
                 "extra_strict": whole("extra_strict", "Extra life: strict, one in", 2),
                 "extra_after": whole("extra_after", "Extra life: strict at life", 6),
                 "extra_for": whole("extra_for", "Extra life: strict for N losses", 20)}
        if extra["extra_every"] < 1 or extra["extra_strict"] < 1:
            raise ValueError("the extra life is bought on one first loss in at least 1 "
                             "(1 = every one)")
        if extra["extra_strict"] > extra["extra_every"]:
            raise ValueError(f"strict means more often: one in {extra['extra_strict']} is less "
                             f"often than the usual one in {extra['extra_every']}")
        if extra["extra_after"] < 2:
            raise ValueError("it goes strict at life 2 or later (life 1 is the base bet itself)")
        if max_steps and extra["extra_after"] > max_steps:
            raise ValueError(f"a run can't reach life {extra['extra_after']} with a doubling "
                             f"limit of {max_steps} — it would never go strict")
        if extra["extra_for"] < 1:
            raise ValueError("it has to stay strict for at least 1 loss")
    return {"strategy": strategy, "budget": budget, "base": base,
            "max_steps": max_steps, "ceiling": ceiling, "target": target, "rules": rules,
            "table_hands": table_hands, "at_cutoff": at_cutoff, "cutoff_margin": margin,
            "shadow_unit": unit, "shadow_after": after, "shadow_min_lives": floor,
            **extra}
