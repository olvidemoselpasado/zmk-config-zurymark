"""python -m baccarat"""

import sys

from baccarat.cli import main

if __name__ == "__main__":
    sys.exit(main())
