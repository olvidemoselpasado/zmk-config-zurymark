"""The numbers that decide how the bot behaves at a table.

All of them in one place, each with the reason it is what it is. They are
mostly seconds, and most of them were arrived at by watching a real table
rather than by reasoning -- which is why the comment matters more than the
value. Several are overridden per session from Setup; these are the defaults."""

from __future__ import annotations





PAIRS = ("player_pair", "banker_pair")


COUNT_WAIT = 4.0        # s to keep re-reading if the counters update late


SCORE_WAIT = 3.0        # s to wait for the score to show the round's result (live)


SCORE_GLANCE = 0.6      # … but only this long while the next betting window is running


MISMATCH_WAYS = ("carry_on", "pause", "stop")   # what to do when the screen disagrees


SCORE_RECHECK = 0.6     # s between further looks, taken during time we'd be waiting anyway
                        # (was 0.3: up to 3 grabs a second through the betting window, just
                        # as the pointer starts moving -- for a figure that is not urgent)


POLL = 0.15             # s between checks once a result is really due


QUIET_POLL = 0.8        # s between checks early in a hand, when none can be due yet


QUIET_UNTIL = 0.55      # … for this fraction of the shortest hand seen so far


CLOSE_FROM = 0.90       # from here on, watch at full speed


CHIP_FLOOR_GUESS = 1.0  # s before the chips can plausibly be up, until it is measured


IDLE_STOP = 300         # give up when nothing changes for this long and nothing can be reopened


# When the table freezes (the bar still reads, but the game number stops changing) and an
# open_table action is set: close and reopen the SAME table, waiting longer each attempt.
STALL_AFTER = 75        # s without a new hand → the table looks stuck


RECOVER_WAIT = 30       # s before the first retry; ×1.8 each further attempt


MAX_RECOVERIES = 5      # give up after this many retries in a row


CUTOFF_MARGIN = 20      # hands kept free at the end of a table for a run to finish in


WAIT_FALLBACK_HANDS = 3    # when a table is already past its expected end: wait this many hands


REFRESH_TABLES = (4, 12)   # refresh the lobby after this many tables (picked at random each time)


LOBBY_WAIT = (6.0, 12.0)   # s to let the lobby load after a refresh


# Live mode: when a game ends the table takes bets for ~9 s. The bet is placed at a
# random moment inside this window (seconds after the game number changed), and its
# clicks must be done before the window closes.
BET_WINDOW = (2.0, 6.0)   # (start betting after, window closes at) — the end is in Setup


CHIP_REGION = "bets_open" # the region watched when the window starts with the chips


CHIP_TIMEOUT = 45.0       # s to wait for the chips before giving the hand up


CHIP_POLL = 0.2           # s between looks for the chips once they are due


CLICK_SPEED = (0.10, 0.30)  # s one click takes, fastest to slowest — also in Setup


BET_MARGIN = 0.5        # s: clicks finish at least this long before the window closes


# Confirming the bet went on, from the score. The table takes the stake off the balance
# the moment it is placed; when the site is slow it can refuse the bet afterwards (the
# "not confirmed" notice) and hand the stake back. So once the clicks are done the score
# is looked at, in time spent waiting for the result anyway, until a little after the
# window closes -- which is when a refusal arrives. Never inside the betting window.
STAKE_LOOK = 0.75       # s between looks at the score while a fresh bet is being confirmed


STAKE_WATCH = 5.0       # s after the betting window closes to keep watching for a refund


STAKE_CONFIRM = 2       # readings in a row showing the stake back before it counts as refused


# Before the repeat button is pressed, the chips must have shown on the balance: on an
# empty table that button repeats LAST round's bet, side and size and all.
CHIP_CONFIRM_WAIT = 0.8 # s to wait for the chips to come off the balance; set aside in the
                        # betting window for every bet that uses the repeat button


CHIP_CONFIRM_POLL = 0.08  # s between looks while waiting for them


# A refused bet now and then is the site having a slow moment. Two close together means
# it is still slow, and the next bet may go the same way -- so stop betting for a while.
REJECT_LIMIT = 2        # refusals …


REJECT_WINDOW = 600.0   # … within this many seconds → cool off


REJECT_COOLOFF = 300.0  # s to stay away the first time; ×REJECT_GROWTH each time after


REJECT_GROWTH = 1.8


REJECT_MAX_COOLOFFS = 3 # still refusing after this many cool-offs in a row → stop


# Unattended repeats: after a ceiling, close the table, wait for it to finish, open the next.
HAND_SECONDS = 15.0     # how long one hand takes, to work out the wait


CYCLE_EXTRA = 10.0      # extra wait on top (always a bit more; 1× to 1.5× at random)


BOARD_TIMEOUT = 60.0    # s to wait for a freshly opened table's bar to be readable


# After closing a table the old bar can stay on screen for a moment, and a freshly
# opened one often shows the previous table's numbers before it redraws. So: wait for
# the bar to GO before opening the next table, and ignore any read that matches the one
# we just left until it has had time to change.
GONE_TIMEOUT = 15.0     # s to wait for the closed table's bar to disappear


TABLE_SETTLE = 2.0      # s to let a freshly opened table draw before the first read


STALE_WINDOW = 12.0     # s during which a board identical to the last one is distrusted


ROAD_TRIES = 5          # attempts at a clean read before giving up on the road


ROAD_GAP = 0.6          # seconds between the two reads of an attempt


# Logging in. The tries and the wait are in Setup; these are the defaults and the rest.
LOGIN_TRIES = 3          # attempts before giving up, each after a reload but the first


LOGIN_WAIT = 60.0        # s to wait for 'success_login' after submitting -- the site is slow


LOGIN_FORM_WAIT = 1.5    # s after clicking 'login' before typing: the form has to open


LOGIN_POLL = 1.0         # s between looks at 'success_login' while waiting


LOGIN_RELOAD_WAIT = 8.0  # s to let the page come back after a reload


LOGIN_MATCH = 25.0       # average difference per pixel (0-255) from the saved picture of
                         # 'success_login' still counted as showing it. The log says the
                         # figure each time, so this can be set from what your screen does
