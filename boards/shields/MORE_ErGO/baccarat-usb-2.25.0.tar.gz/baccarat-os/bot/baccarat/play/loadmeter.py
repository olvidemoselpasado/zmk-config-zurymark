"""How hard the machine is working, hand by hand, and who is doing the work.

The bot shares the machine with the game it is watching: the browser decoding the
live stream, and the compositor drawing it. When one of them is starved the stream
stutters, the reading gets worse, and the bot reads harder -- the loop that once
took the CPU to 86%. So "the CPU is high" is not enough to act on. This says, for
every hand, which process it was, how high it went, and how many screen grabs the
bot took to cause it:

    load: 88 grabs (board 70, score 18; busiest second 9) · CPU % of one core,
          average/peak: bot 6/31 · grim+ydotool 4/12 · compositor 18/55 ·
          browser 44/80 · machine 22/41% of 8 cores · busiest: browser, during
          the clicks

Sampled once a second on a thread of its own, so the busiest second is caught
wherever it falls -- the clicks, the result, the wait. Each sample reads a couple of
dozen small files, and the process list is only walked every PID_RESCAN seconds.
"""

from __future__ import annotations

import os
import threading
import time
from baccarat import screen as bet

SAMPLE = 1.0          # s between samples
PID_RESCAN = 15.0     # s between walks of the process list (browsers start and stop tabs)

GROUPS = {
    # Linux compositors; on a Mac the one process that draws every window
    "compositor": ("hyprland", "sway", "kwin_wayland", "gnome-shell", "xwayland", "xorg",
                   "weston", "river", "labwc", "wayfire", "windowserver"),
    # browsers and their helper processes. A name ending in * takes in everything that
    # starts with it: Chrome on a Mac is 'Google Chrome' plus a dozen 'Google Chrome
    # Helper (Renderer)', and Safari draws pages in 'com.apple.WebKit.WebContent'
    "browser": ("firefox", "firefox-bin", "librewolf", "floorp", "zen", "web content",
                "isolated web co", "isolated servic", "webextensions", "gpu process",
                "rdd process", "socket process", "utility process", "privileged cont",
                "chrome", "chromium", "chromium-browse", "brave", "brave-browser", "msedge",
                "opera", "vivaldi-bin", "thorium", "plugin-container",
                "google chrome*", "brave browser*", "microsoft edge*", "opera*", "vivaldi*",
                "arc*", "safari", "com.apple.webkit.*", "firefox gpu helper"),
}
LABELS = {"bot": "bot", "helpers": "grim+ydotool", "compositor": "compositor",
          "browser": "browser"}


class LoadMeter:
    def __init__(self):
        self.ncpu = os.cpu_count() or 1
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._pids: dict[str, list[int]] = {}
        self._scanned = 0.0
        self._prev: dict | None = None
        self._hand_start = time.monotonic()
        self._grabs_at_start = bet.shots_by_region()
        self._acc: dict[str, float] = {}      # CPU seconds this hand, per group
        self._peak: dict[str, float] = {}     # busiest second this hand, % of one core
        self._wall = 0.0
        self.last: dict | None = None         # the summary of the last whole hand
        self.phase = "starting"               # what the bot is doing: set by the bot
        self._peak_at: dict[str, str] = {}    # … when each busiest second happened

    # -- sampling ---------------------------------------------------------------
    def start(self) -> None:
        if self._thread:
            return
        self._prev = self._sample()
        self._thread = threading.Thread(target=self._run, name="load-meter", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        while not self._stop.wait(SAMPLE):
            try:
                self.tick()
            except Exception:                 # a meter must never take the bot down
                pass

    def _sample(self) -> dict:
        now = time.monotonic()
        if now - self._scanned > PID_RESCAN:
            self._pids = bet.find_pids(GROUPS)
            self._scanned = now
        t = os.times()
        s = {"t": now, "bot": t.user + t.system, "helpers": t.children_user + t.children_system,
             "pids": {}}
        for group, pids in self._pids.items():
            for pid in pids:
                v = bet.cpu_seconds(pid)
                if v is not None:
                    s["pids"][pid] = (group, v)
        m = bet.machine_cpu()
        if m:
            s["machine"] = m
        return s

    def tick(self) -> None:
        cur = self._sample()
        prev, self._prev = self._prev, cur
        if not prev:
            return
        dt = cur["t"] - prev["t"]
        if dt <= 0:
            return
        used = {"bot": cur["bot"] - prev["bot"], "helpers": cur["helpers"] - prev["helpers"]}
        for pid, (group, v) in cur["pids"].items():
            before = prev["pids"].get(pid)
            if before is not None:                # a process seen for the first time is
                used[group] = used.get(group, 0.0) + max(0.0, v - before[1])  # counted next time
        if "machine" in cur and "machine" in prev:
            busy = cur["machine"][0] - prev["machine"][0]
            total = cur["machine"][1] - prev["machine"][1]
            # as seconds of one core, like the others; shown as % of all cores
            used["machine"] = busy / total * dt * self.ncpu if total > 0 else 0.0
        with self._lock:
            self._wall += dt
            for k, v in used.items():
                self._acc[k] = self._acc.get(k, 0.0) + v
                if v / dt * 100 > self._peak.get(k, -1.0):
                    self._peak[k] = v / dt * 100
                    self._peak_at[k] = self.phase

    # -- a hand's worth -----------------------------------------------------------
    def hand_done(self) -> dict | None:
        """Close the hand: what it cost, and start counting the next one."""
        now = time.monotonic()
        grabs = bet.shots_by_region()
        with self._lock:
            wall, acc, peak, peak_at = self._wall, self._acc, self._peak, self._peak_at
            start, before = self._hand_start, self._grabs_at_start
            self._wall, self._acc, self._peak, self._peak_at = 0.0, {}, {}, {}
            self._hand_start, self._grabs_at_start = now, grabs
        by = {k: v - before.get(k, 0) for k, v in grabs.items() if v - before.get(k, 0)}
        times = [x for x in bet.shot_times() if x >= start]
        busiest, j = 0, 0
        for i, x in enumerate(times):                 # most grabs in any one second
            while times[j] < x - 1.0:
                j += 1
            busiest = max(busiest, i - j + 1)
        cpu, when = {}, {}
        for k in ("bot", "helpers", "compositor", "browser", "machine"):
            if k in acc and wall > 0:
                avg, top = acc[k] / wall * 100, peak.get(k, 0.0)
                if k == "machine":                    # % of the whole machine
                    avg, top = avg / self.ncpu, top / self.ncpu
                cpu[k] = (round(avg), round(top))
                when[k] = peak_at.get(k, "?")
        self.last = {"seconds": round(now - start, 1), "grabs": sum(by.values()),
                     "by_region": by, "busiest_second": busiest, "cpu": cpu, "peak_when": when,
                     "cores": self.ncpu, "watching": {g: len(p) for g, p in self._pids.items()}}
        return self.last


def describe(d: dict | None) -> str:
    if not d:
        return "no measurement yet"
    regions = ", ".join(f"{k} {v}" for k, v in sorted(d["by_region"].items(), key=lambda x: -x[1]))
    out = f"{d['grabs']} grabs" + (f" ({regions}; busiest second {d['busiest_second']})"
                                   if regions else "")
    cpu = d.get("cpu") or {}
    parts = [f"{LABELS[k]} {cpu[k][0]}/{cpu[k][1]}" for k in LABELS if k in cpu]
    if parts:
        out += " · CPU % of one core, average/peak: " + " · ".join(parts)
    if "machine" in cpu:
        out += f" · machine {cpu['machine'][0]}/{cpu['machine'][1]}% of {d['cores']} cores"
    when = d.get("peak_when") or {}
    top = max((k for k in cpu if k != "machine"), key=lambda k: cpu[k][1], default=None)
    if top and cpu[top][1] >= 20:
        out += f" · busiest: {LABELS[top]}, during {when.get(top, '?')}"
    missing = [LABELS[g] for g, n in (d.get("watching") or {}).items() if not n]
    if missing and cpu:
        out += f" ({', '.join(missing)} not found by name)"
    return out
