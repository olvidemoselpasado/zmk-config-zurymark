"""How fast to look at the screen.

Every look is a screenshot, and screenshots are the one thing that makes the
game itself stutter -- which then makes the reading worse, which is the loop
that took CPU to 86%. So the rate is adaptive: slow early in a hand when no
result can be due, full speed near the end of one.

The floors are measured from the table rather than assumed, and measured
defensively: the SECOND-smallest time seen, not the smallest, because one
freak-fast hand would otherwise drag the floor down and put the bot back to
polling flat out."""

from __future__ import annotations



from baccarat.play import tuning


def poll_step(waited: float, floor: float, quiet: float, fast: float = tuning.POLL) -> float:
    """How long to wait before looking at the screen again, this far into the wait.

    Three gears. Early on the thing we are waiting for cannot have happened, so it
    looks rarely. Around the time it becomes likely it looks more often. Once it is
    really due it watches at `fast`, so the betting window is never eaten into.
    `floor` is the quickest this has ever taken on this table — 0 while there isn't
    enough to be sure, which keeps it at full speed throughout."""
    if floor <= 0:
        return fast
    done = waited / floor
    if done < tuning.QUIET_UNTIL:
        return max(fast, quiet)
    if done < tuning.CLOSE_FROM:
        return max(fast, quiet * 0.45)
    return fast
