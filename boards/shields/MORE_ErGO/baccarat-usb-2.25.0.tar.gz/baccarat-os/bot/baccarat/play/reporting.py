"""What the dashboard is shown, and what goes in the log.

Separate from the playing because it must never change it: everything here
reads the Player's state and writes it outwards. If a method in this file
changes how the session plays, it is in the wrong file.

The Player state this is responsible for:

    dash, status, bet_reason, history, read_ms, read_fails, started,
    prior_count, run_stats, last, board, estimator, estimate, _estimating
"""

from __future__ import annotations

from collections import Counter

import math
import threading
import time
from baccarat import screen as bet
from baccarat.log import log
from baccarat.core import patterns
from baccarat.core.game import SIDES
from baccarat.core.staking import lives
from baccarat.store.history import note_run
from baccarat.play.reading import (
    Board, total)
from baccarat.play.stop import PAUSE
from baccarat.play import tuning
from baccarat.util.clock import _hms
from baccarat.util.show import blue, green, money, red


class Reporting:
    """Mixed into Player. See the module docstring."""

    # -- dashboard -----------------------------------------------------------
    def push(self) -> None:
        s = self.s
        seq, fail = lives(s.balance, s.staking)
        # lives already lost in the run going on now. Once the money has run out the
        # doubling carries on virtually, so count only the ones really paid for.
        paid = s.lives_used if (s.watching or s.watch_over) else s.staking.step
        lost = [s.staking.base * 2 ** i for i in range(paid)]
        wins, losses = s.count("WIN"), s.count("LOSS")
        b, t = self.board, self.table
        on_table = self.stake_down if self.current_bet else 0.0
        self.dash.update(
            mode=self.mode, status=self.status, stopped=self.stopped, started=self.started,
            stopped_with=self.stopped_with,
            pattern=({**self.pattern, "leave": self.pattern_leave,
                      "track": patterns.track(s.config)} if self.pattern else None),
            strategy={"name": s.strategy.name, "description": s.strategy.description,
                      "needs": s.strategy.n},
            rules=[{"name": r.name, "label": r.label, "active": r.active,
                    "holding": r.holding, "stats": r.stats(),
                    "text": r.active_text() if (r.active or r.holding) else "",
                    "streak": getattr(r, "streak", None), "n": getattr(r, "n", None),
                    "triggered": r.triggered, "rescued": r.rescued} for r in s.rules],
            base=s.staking.base, max_steps=s.staking.max_steps,
            # the site takes the stake off the balance the moment it is placed, so the
            # balance shown does the same; the settled figure is sent alongside
            budget=s.budget, balance=round(s.balance - on_table, 2), settled=s.balance,
            on_table=on_table, net=s.net,
            score=(round(self.score - on_table, 2) if self.score is not None else None),
            refused=self.refusals_report(), bet_notice=self.bet_notice, load=self.load.last,
            estimate=self.estimate_report(), kind=self.kind_report(),
            ahead=s.ladder_ahead(self.current_bet[1] if self.current_bet else None),
            extra=({"after": s.extra_after, "for": s.extra_for, "active": s.extra_active,
                    "every": s.extra_every, "strict": s.extra_strict, "rhythm": s.extra_rhythm,
                    "until": s.extra_until,
                    "quiet": s.extra_quiet, "buy_next": s.extra_buy_next, "held": s.extra_held,
                    "bought": s.extra_bought, "cost": s.extra_cost, "ons": s.extra_ons,
                    "finished": s.extra_finished, "saves": s.extra_saves[-10:],
                    "saved": len(s.extra_saves),
                    "at_risk": round(sum(x["at_risk"] for x in s.extra_saves), 2)}
                   if s.extra_every else None),
            ceiling=s.ceiling, remaining=s.remaining, wins_needed=s.wins_needed,
            lives={"seq": seq, "fail": fail, "lost": lost}, stake=s.staking.amount,
            bet=({"side": self.current_bet[0], "amount": self.current_bet[1],
                  "game": self.bet_game, "by": s.decided_by,
                  "rule": s.active_rule.label if s.active_rule else None}
                 if self.current_bet else None),
            bet_reason=self.bet_reason,
            last=self.last, history=self.history[-600:],
            road=s.road, prior_count=self.prior_count,
            table={"name": t.name if t else None,
                   "game": b["game"] if b else None,
                   "counts": {k: b[k] for k in SIDES} if b else None,
                   "pairs": [b["player_pair"], b["banker_pair"]] if b else None,
                   "rounds": len(t.data["rounds"]) if t else 0,
                   "hand": total(b) if b else None, "hands": s.table_hands,
                   "cutoff": s.cutoff_hand(), "margin": s.hands_needed(),
                   "lives_affordable": s.lives_affordable(),
                   "done": s.table_done, "in_run": s.in_run,
                   "complete": t.data["complete"] if t else False,
                   "joined_at": t.data["joined_at_game"] if t else None},
            stats={"W": wins, "L": losses, "push": s.count("PUSH"), "skipped": s.count("NO BET"),
                   "rate": wins / (wins + losses) if wins + losses else None,
                   "max_bet": s.max_bet, "max_drawdown": s.max_drawdown,
                   "max_losing_streak": s.max_losing_streak},
            read_ms=self.read_ms, read_fails=self.read_fails, shots=self.shots,
            mismatch=self.mismatch,
            corrections={"count": len(self.s.corrections), "total": self.s.corrected,
                         "rows": self.s.corrections[-6:]} if self.s.corrections else None,
            skipped={"tables": self.skipped,
                     "screens": [f"{sc['name']} ({sc['pattern']})" for sc in self.screens],
                     "min": self.screen_min} if self.screens else None,
            screen={"per_hand": self.shots_per_hand, "rate": self.shot_rate,
                    "total": bet.shots_taken(), "gap": self.quiet_poll,
                    "floor": round(self.hand_floor(), 1)},
            timing={"window": self.bet_end, "start": self.bet_start,
                    "start_on": self.bet_start_on, "chip_waits": self.chip_waits,
                    "click": list(self.click_speed), "late_skips": self.late_skips,
                    "hard_score": self.hard_score, "stake_on_place": self.deducts,
                    "quiet_poll": self.quiet_poll, "move_speed": self.move_speed,
                    "on_mismatch": self.on_mismatch,
                    "spot": {k: self.spot[k] for k in ("looks", "agreed", "apart", "last")}
                    if not self.hard_score else None},
            cycle={"now": self.cycle, "total": self.cycles,
                   "step": self.ceiling_step} if self.cycles > 1 else None,
            watch=({"on": s.watching, "over": s.watch_over, "won": s.watch_won,
                    "bets": s.watch_bets, "stakes": s.watch_stakes, "used": s.lives_used,
                    "needed": s.lives_needed, "text": s.watch_result}
                   if s.watching or s.watch_over else None),
            runs={"config": s.config, "session": s.runs[-40:], "worst": s.worst_run,
                  "history": self.run_stats, "count": len(s.runs),
                  "lives": dict(Counter(r["lives"] for r in s.runs)),
                  "not_won": sum(not r["won"] for r in s.runs)},
            played=self.tables_played[-30:],
            session={"started": self.started, "hands": len(s.results),
                     "bets": sum(1 for r in s.results if r.side), "peak": s.peak,
                     "lives_now": len(seq), "lost_now": len(lost)},
            alarm=self.alarm, paused=PAUSE.is_set(),
            waiting=self.countdowns(),
            lobby={"scroll": self.scroll_at,
                   "of": {n: int(self.open_scroll.get(n, 0) or 0) for n in self.open_patterns}},
            shadow=({"unit": s.shadow_unit, "now": s.shadow_now, "level": s.shadow_level,
                     "after": s.shadow_after, "on": s.shadow_on, "stake": s.shadow_stake,
                     "wins": s.shadow_wins, "losses": s.shadow_losses,
                     "blocked": s.shadow_blocked, "capped": s.shadow_capped,
                     "staked": s.shadow_staked, "floor": s.shadow_min_lives,
                     "ladder": s.shadow_ladder_stakes(s.shadow_min_lives)}
                    if s.shadow_unit else None),
        )

    # -- what the target really takes ----------------------------------------------
    def refresh_estimate(self, why: str = "") -> None:
        """Work out again what one win is worth, on a thread of its own: it replays
        every recorded table, which takes a moment, and must never hold up a hand."""
        if self.estimator is None or self._estimating:
            return
        self._estimating = True

        def work():
            try:
                v = self.estimator()
            except Exception as e:                 # an estimate is never worth an error
                log.debug("couldn't estimate the value of a win: %s", e)
                v = None
            finally:
                self._estimating = False
            if v and v.get("per_win") is not None:
                first = self.estimate is None
                self.estimate = v
                self.s.per_win, self.s.hands_per_win = v["per_win"], v["hands_per_win"]
                if first:
                    self.say_estimate()
                self.push()
        threading.Thread(target=work, name="estimate", daemon=True).start()

    def estimate_report(self) -> dict | None:
        """For the dashboard: the measurement, plus what it means for the target now."""
        v = self.estimate
        if not v:
            return None
        wins = self.s.wins_needed
        chance = None
        if wins and v.get("beyond_per_run") is not None:
            chance = 1 - (1 - v["beyond_per_run"]) ** wins
        return {**{k: v.get(k) for k in ("source", "per_win", "hands_per_win", "tables",
                                          "hands", "wins", "banker_share", "player_win",
                                          "banker_win", "cover", "worst", "loss_rate")},
                "hand_seconds": round(self.hand_pace()[0], 1),
                "cut_short": None if chance is None else round(chance, 4),
                "base": self.s.staking.base}

    def say_estimate(self) -> None:
        s, v = self.s, self.estimate
        if s.remaining is None or not v:
            return
        e = self.estimate_report() or {}
        wins = s.wins_needed
        if wins is None:
            log.warning("Target: %s to go — but a win doesn't make money on average with "
                        "this setup (%s each), so there is no number of wins that gets there.",
                        money(s.remaining), money(v["per_win"]))
            return
        hands = wins * (v["hands_per_win"] or 0)
        secs = hands * e.get("hand_seconds", 0)
        where = (f"replaying this setup over your {v['tables']} recorded tables"
                 if v["source"] == "replay" else
                 f"replaying this setup over {v['tables']} tables dealt from the game's odds "
                 f"(too few of your own recorded yet)")
        log.info("Target: %s to go ≈ %d wins, not %d — a win nets %s on average, not %s "
                 "(banker pays 0.95, and the longer the run before it the more that costs). "
                 "About %d hands, ~%s of play. Measured by %s.", money(s.remaining), wins,
                 math.ceil(s.remaining / s.staking.base), money(v["per_win"]),
                 money(s.staking.base), round(hands), _hms(secs), where)
        if e.get("cut_short") is not None:
            log.info("   On the way, the chance of a run needing more than the %d bets in a "
                     "row your balance covers: about %.0f%%.", v["cover"], e["cut_short"] * 100)

    def on_read(self, board: Board | None, ms: float) -> None:
        self.read_ms = ms
        # the gap between hands is twenty-odd idle seconds; a settlement that was slow
        # to land is seen arriving here, which is the difference between "it was late"
        # and "it never happened"
        if self.bet_watch:
            self.watch_stake(board)             # one look serves the stake and the last result
        elif self.score_check and time.monotonic() - self._score_looked >= tuning.SCORE_RECHECK:
            self._score_looked = time.monotonic()
            self.check_score_now()
        if board:
            self.board, self.read_fails = board, 0
        else:
            self.read_fails += 1
            if self.read_fails in (3, 30, 300):     # each try is a ~3 s attempt
                reason, shot = "", None
                try:
                    reason, shot = bet.board_trouble()
                except Exception as e:              # never let diagnosing stop the session
                    reason = f"(couldn't work out why: {e})"
                log.warning("Can't read the scoreboard bar (%d tries): %s", self.read_fails, reason)
                if shot is not None:
                    self.shots = (self.shots + [{
                        "file": shot.name, "when": time.strftime("%H:%M:%S"),
                        "why": f"what the board region caught — {reason}"}])[-6:]
                if self.read_fails == 3:
                    self.snapshot("board-unreadable", "the bar couldn't be read — "
                                                      "this is the whole screen at that moment")
        self.push()

    # -- losing runs, kept per configuration ---------------------------------
    def note_finished_run(self) -> None:
        """A losing run just ended: remember how many lives it took, so Setup can show
        the worst this configuration has ever needed."""
        run = self.s.last_run
        if not run:
            return
        try:
            self.run_stats = note_run(self.s.config, run["lives"], run["won"],
                                      run["virtual"], self.mode,
                                      self.table.name if self.table else None)
        except Exception as e:                  # a history file is never worth stopping for
            log.debug("Couldn't store the run: %s", e)
            return
        if run["lives"] >= 2:
            log.info("   Run of %d %s %s. Worst for '%s' so far: %d lives (%d runs).",
                     run["lives"], "bets" if run["lives"] != 1 else "bet",
                     green("won") if run["won"] else red("not won"), self.s.config,
                     self.run_stats.get("max_lives", 0), self.run_stats.get("runs", 0))

    def end_watch(self, reason: str) -> None:
        """Stop following the run for free (the table ended, the session stopped …)."""
        self.s.end_watch(reason)
        self.report_watch()

    def report_watch(self) -> None:
        """Say how many lives the run would have needed. Said once."""
        s = self.s
        if not s.watch_over or self._said_watch:
            return
        self._said_watch = True
        (log.info if s.watch_won else log.warning)("Watching finished: %s", s.watch_result)
        if s.watch_won:
            log.info("The money ran out %d %s short of the win: %s lives in all were needed, "
                     "and a budget of %s at a base bet of %s pays for %d.",
                     s.watch_bets, "life" if s.watch_bets == 1 else "lives",
                     green(str(s.lives_needed)), green(money(s.budget)),
                     blue(money(s.staking.base)), s.lives_used)
        else:
            log.warning("It was still losing when the watch had to stop, so this run needed more "
                        "than %d lives.", s.lives_used + s.watch_bets)
        self.note_finished_run()
        h = self.run_stats or {}
        if h.get("runs"):
            log.info("Worst run ever for '%s': %d lives, over %d runs stored.",
                     s.config, h.get("max_lives", 0), h["runs"])
        self.status = (f"Lost everything — {s.watch_bets} lives short of the win"
                       if s.watch_won else "Lost everything — the watch couldn't finish")
        self.bet_reason = s.watch_result
        self.push()
