"""Watching the money: the score on screen, the stake on the table, the alarm.

The score is not the point and must never hold up a bet. What matters is that
the RESULTS are read correctly, because that is what the strategy decides from;
the score is a second opinion on the arithmetic. So the check is done in the gap
between hands, never in front of the betting window, and a score that has not
caught up yet is waited for rather than complained about.

When the screen and our own books really do disagree, that is not papered over.
The difference is reported, kept out of the profit figure, and the person is
asked what to do -- carry on, hold, or stop -- because a discrepancy that is
quietly re-synced is a discrepancy you will never find out about.

stake_down and deducts are here because tables differ: some take the stake off
the displayed balance the moment it is placed and some only when the hand
settles. Which one this table does is learnt rather than configured, and without
it every single hand looks like money going missing.

The Player state this is responsible for:

    score, score_check, _score_looked, _score_read, hard_score, stake_down, deducts, stray,
    mismatch, mismatch_id, on_mismatch, alarm, alarm_id, alarm_armed,
    alarm_wanted
"""

from __future__ import annotations

import time
from baccarat import screen as bet
from baccarat.log import log
from baccarat.core.staking import lives, settle
from baccarat.play.reading import (
    wait_for_score)
from baccarat.play.stop import PAUSE, STOP
from baccarat.play import tuning
from baccarat.util.show import blue, green, money


class MoneyWatch:
    """Mixed into Player. See the module docstring."""

    # -- last-life alarm -----------------------------------------------------
    def check_alarm(self, game: int, side: str, amount: float) -> None:
        """About to bet the last stake the balance can cover → make a noise on the
        dashboard until it's silenced. Nothing is held up: the bet goes on as usual."""
        s = self.s
        left, fail = lives(s.balance, s.staking)
        last = len(left) <= 1                   # this bet, and then nothing
        if not last:
            self.alarm_armed = True             # off the edge again: ready to warn once more
            if self.alarm:
                self.alarm = None
            return
        if not self.alarm_wanted or self.alarm or not self.alarm_armed:
            return
        self.alarm_id += 1
        self.alarm = {
            "id": self.alarm_id, "kind": "last life", "game": game,
            "side": side, "amount": amount, "balance": s.balance,
            "next": fail, "mode": self.mode, "at": time.strftime("%H:%M:%S"),
            "text": (f"Last life: {amount:,.0f} on {side}, game {game}. "
                     f"If it loses, {fail:,.0f} is needed next and the balance is "
                     f"{s.balance:,.2f}."),
        }
        log.warning("🔔 LAST LIFE — betting %s on %s (game %d). A loss ends it: the next "
                    "double would be %s against a balance of %s. Silence the alarm on the "
                    "dashboard.", blue(f"{amount:,.0f}"), side.upper(), game,
                    blue(money(fail or 0)), green(money(s.balance)))

    def silence(self, body: dict | None = None) -> dict:
        """The dashboard's Silence button (or any key on the page)."""
        if self.alarm:
            log.info("Alarm silenced.")
        self.alarm, self.alarm_armed = None, False
        self.push()
        return {"silenced": True}

    def mismatch_seen(self, body: dict | None = None) -> dict:
        """You've seen the notice. Carrying on clears it; stopping ends the session."""
        what = str((body or {}).get("do") or "seen")
        if what == "stop":
            log.warning("Stopped from the dashboard after the screen disagreed.")
            self.status = "Stopped: you chose to stop after a screen mismatch"
            STOP.set()
        elif what == "always":
            self.on_mismatch = "carry_on"
            log.info("Carrying on past screen mismatches without asking again.")
        self.mismatch = None
        self.push()
        return {"ok": True}

    def result_after(self, winner: str | None) -> str | None:   # noqa: D401
        """Live: look at the score after a result. Returns WIN/LOSS/PUSH worked out from
        the score change — needed only when the counters couldn't say who won.

        This must not sit here waiting. The betting window for the *next* hand opens the
        moment the result lands, so every second spent here is a second taken off it: a
        score that never reaches the expected figure used to hold this up for three full
        seconds, and the next hand was then skipped as too late to bet. So when the
        winner is already known the score is glanced at, and any disagreement is carried
        forward to be settled during the wait before the next bet — time that was going
        to be spent idle anyway."""
        self.end_bet_watch()                   # the score is settling now: stop reading it
        if not self.hard_score:
            self.stake_down = 0.0
            return None            # the score is off: the counters decide, and nothing waits
        self.finish_score_check(fresh=False)   # the screen has already moved on
        self.stake_down = 0.0                  # the hand is over: nothing of ours is down
        expected = None
        if self.current_bet and winner and self.score is not None:
            expected = round(self.score + settle(*self.current_bet, winner)[1], 2)
        if self.current_bet and not winner:
            new = wait_for_score(None)     # here the score IS the result: worth the wait
        else:
            new = bet.read_number_stable("score", timeout=tuning.SCORE_GLANCE)
        if new is not None:
            self._score_read = (new, time.monotonic())
        stray, self.stray = self.stray, None
        if stray and not self.current_bet:
            # money of ours was on the table that wasn't the bet we placed: the side is
            # unknown, so nothing was settled. The table's own figure decides: open a
            # check against our books; it closes quietly if the money came back even,
            # and otherwise puts the balance right and says so.
            self.score_check = {"expected": self.score, "saw": new, "game": stray["game"],
                                "since": time.monotonic(), "stray": True}
            self._score_looked = time.monotonic()
            log.info("   Game %s had %s of ours on the table that wasn't the bet placed — "
                     "the balance is now taken from what the table paid.", stray["game"],
                     money(stray["taken"]) if stray.get("taken") else "maybe some")
            return None
        hint = None
        if self.current_bet and not winner and self.score is not None and new is not None:
            d = new - self.score
            hint = "WIN" if d > 0 else "LOSS" if d < 0 else "PUSH"
        if expected is not None and (new is None or abs(new - expected) >= 0.01):
            # not settled on screen yet, or not by the amount we expected. Don't take
            # this reading as the new baseline and don't cry about it here — look again
            # while we wait for the betting moment.
            self.score_check = {"expected": expected, "saw": new, "game": self.bet_game,
                                "since": time.monotonic()}
            self._score_looked = time.monotonic()
        elif new is not None:
            self.score = new
        return hint

    def settle_open_check(self, saw: float) -> None:
        """The screen read `saw` as the settled balance at a moment with nothing of ours
        on the table -- just before a bet's clicks. That is the last word on whatever is
        still open from earlier: the same as expected closes it quietly, anything else
        corrects our books to the screen and says so on the page.

        The bug this exists for: the check that a new stake went on used to close an
        open check by simply adopting the screen's figure, so a hand settled wrongly
        (39 out, on a live table) was put right in the score and never in the balance,
        and nobody was told."""
        c = self.score_check
        if not c:
            self.score = saw
            return
        if abs(saw - c["expected"]) < 0.01:
            self.score, self.score_check = saw, None
            return
        c["saw"] = saw
        log.warning("Before this bet the screen read %s, but our books say %s after game "
                    "%s.", money(saw), money(c["expected"]), c.get("game"))
        down, self.stake_down = self.stake_down, 0.0    # `saw` has none of ours in it
        try:
            self.finish_score_check(fresh=False)
        finally:
            self.stake_down = down

    def look_at_score(self) -> None:
        """One reading of the score just before the clicks, so the bet is checked
        against what the screen really showed rather than against our books."""
        if not self.hard_score:
            self.spot_check_score()
            return
        if self.score_check:
            self.check_score_now()              # reads it, and may close the check
            return
        self.teach_score_from_books()
        try:
            v = bet.read_number("score")
        except Exception:
            return
        if v is not None:
            self._score_read = (v, time.monotonic())

    SPOT_EVERY = 10          # bets between looks while 'Trust the screen score' is off

    def spot_check_score(self) -> None:
        """'Trust the screen score' off: nothing is corrected from the screen -- but every
        10 bets, just before the clicks (nothing of ours on the table), one look at it.
        What the screen's balance has done since the first look is compared with what the
        books have done: the budget typed may differ from the casino's balance, the
        change may not. Two looks in a row the same amount apart (not one misread, not a
        slow payout) and it is said loudly: bets may not be going on as the bot thinks.
        Never a correction, never a wait: one quick read."""
        sp = self.spot
        sp["bets"] += 1
        due = sp["suspect"] is not None or sp["base"] is None or sp["bets"] >= self.SPOT_EVERY
        if not due:
            return
        try:
            v = bet.read_number("score")
        except Exception:
            v = None
        if v is None:
            return
        sp["bets"] = 0
        books = self.s.balance
        if sp["base"] is None:
            sp["base"] = (v, books, time.strftime("%H:%M"))
            log.info("   Screen score %s noted (Trust the screen score is off: it is looked at "
                     "every %d bets, to notice bets that don't go on — nothing is corrected).",
                     money(v), self.SPOT_EVERY)
            return
        v0, b0, since = sp["base"]
        apart = round((v - v0) - (books - b0), 2)
        sp["looks"] += 1
        sp["last"] = apart
        if abs(apart) < 0.01:
            sp["agreed"] += 1
            sp["suspect"] = None
            return
        if sp["suspect"] is None or abs(sp["suspect"] - apart) >= 0.01:
            sp["suspect"] = apart              # one look apart: look again at the next bet
            return
        sp["suspect"] = None
        sp["apart"] += 1
        sp["base"] = (v, books, time.strftime("%H:%M"))     # warn again only on new drift
        log.warning("The screen's balance moved %s since %s, the bot's books %s — %s apart, "
                    "twice in a row. If the screen is right, bets are not going on as the bot "
                    "thinks (or were taken twice). Check the casino's balance. 'Trust the "
                    "screen score' (Setup) checks every bet and keeps the books right.",
                    money(v - v0), since, money(books - b0), money(apart))
        self.bet_reason = (f"The screen's balance and the bot's books have drifted "
                           f"{money(apart)} apart — check the casino's balance.")
        self.push()

    def teach_score_from_books(self) -> None:
        """Just before the clicks nothing of ours is on the table, so the score shows
        exactly what our books say. While some of its digits have never been taught,
        that is a free lesson: the ones it doesn't know are learnt from the screen --
        only if every digit it does know agrees, and only while nothing has made the
        books doubtful this session (a correction, an open check)."""
        if getattr(self, "_score_digits_done", False):
            return
        try:
            if not bet.missing_digits("score"):
                self._score_digits_done = True
                return
            if self.s.corrections or self.score_check or self.stake_down:
                return
            text = bet.format_number(self.s.balance, bet.number_format("score"))
            if text:
                bet.learn_from_known("score", text)
        except Exception as e:                       # a lesson missed is no reason to stop
            log.debug("score lesson skipped: %s", e)

    def raise_mismatch(self, off: float, was: float, now: float,
                       expected: float, saw: float) -> None:
        """Money went somewhere we can't account for. Say so on the page, quietly but
        unmissably, and do whatever Setup says to do about it — which by default is
        to carry on, because a half-finished run left sitting there is its own risk."""
        self.mismatch_id += 1
        self.mismatch = {
            "id": self.mismatch_id, "by": off, "was": was, "now": now,
            "expected": expected, "saw": saw, "at": time.strftime("%H:%M:%S"),
            "count": len(self.s.corrections), "total": self.s.corrected,
            "doing": self.on_mismatch,
        }
        self.push()
        if self.on_mismatch == "stop":
            log.warning("Setup says to stop when the screen disagrees — stopping.")
            self.status = "Stopped: the screen disagreed with our balance"
            STOP.set()
        elif self.on_mismatch == "pause":
            log.warning("Setup says to hold when the screen disagrees — pausing. "
                        "Press Resume on the dashboard to carry on.")
            PAUSE.set()

    def check_score_now(self) -> bool:
        """One look at the score, for use while we are waiting anyway.
        True = it agrees with what we expected, so there is nothing to chase.

        Two figures can be right. Before the next bet goes on, the screen should read
        the settled balance. Once it is on, a table that takes the stake out of your
        money the moment you place it reads that much less — and the hand lasts twenty
        seconds, nearly all of it with the stake down, so this is the reading we
        usually get. Seeing it is also the one solid proof that the stake really went
        on and at the size we meant, which is the thing we actually want to know."""
        c = self.score_check
        if not c:
            return True
        try:
            v = bet.read_number("score")
        except Exception:
            return False
        if v is None:
            return False
        self._score_read = (v, time.monotonic())
        c["saw"] = v
        down = self.stake_down
        settled = abs(v - c["expected"]) < 0.01
        with_stake = bool(down) and abs(v - (c["expected"] - down)) < 0.01
        if with_stake:
            # the settled figure, less the stake we have on the table: both halves of
            # the sum check out, so the stake went on and at the size we meant
            if self.deducts is None:
                self.deducts = True
                log.info("This table takes the stake out of your balance the moment the bet "
                         "is placed. The score is read with that in mind from now on, and "
                         "seeing it is proof the stake went on.")
            self.score = c["expected"]
            self.score_check = None
            c["confirmed"] = down
            return True
        if settled:
            if down and self.deducts:
                self.stake_missing(v, down)        # our money is not on the table
                return True
            self.score = v                         # settled, with nothing of ours down
            self.score_check = None
            return True
        return False

    def stake_missing(self, saw: float, stake: float) -> None:
        """The table takes the stake when a bet is placed, and it hasn't taken ours.
        The money is not down, so the hand is not ours — caught while it is still
        running, which is the whole point: the bet is called off rather than the
        balance being patched up afterwards. Nothing is won or lost on this hand and
        no doubling follows from it, because nothing was staked."""
        self.score, self.score_check = saw, None
        self.stake_down = 0.0
        side, amount = self.current_bet or ("?", stake)
        self.current_bet = None                    # it was never on: record it as no bet
        self.placer.last = None                    # so the repeat button can't be trusted
        self.late_skips += 1
        log.warning("The screen still reads %s with %s of ours supposed to be on %s — this "
                    "table takes the stake as soon as the bet is placed, so it never went "
                    "on. A click was dropped. This hand counts as no bet: nothing is won or "
                    "lost on it and the stake doesn't move.", money(saw), money(amount), side)
        self.bet_reason = (f"The {amount:,.0f} on {side} never reached the table — "
                           f"a dropped click. Counted as no bet.")
        self.mismatch_id += 1
        self.mismatch = {"id": self.mismatch_id, "by": 0.0, "was": saw, "now": saw,
                         "expected": saw, "saw": saw, "at": time.strftime("%H:%M:%S"),
                         "count": len(self.s.corrections), "total": self.s.corrected,
                         "doing": self.on_mismatch, "lost_bet": f"{amount:,.0f} on {side}"}
        self.push()
        if self.on_mismatch == "stop":
            STOP.set()
        elif self.on_mismatch == "pause":
            PAUSE.set()

    def finish_score_check(self, fresh: bool = True) -> None:
        """Give the verdict on an outstanding check.

        Only called once there has been time for the money to move: the whole gap
        between hands. A settlement that was merely slow has arrived by then and the
        check closed itself quietly. One still open here really didn't happen — the
        stake never went on, or it went on at the wrong size — so it is worth saying,
        and the screen's figure is the one to trust from here.

        `fresh` is False when the next result has already landed: the screen is moving
        again and a reading now would describe the new hand, not the one in question."""
        c = self.score_check
        if not c:
            return
        if fresh and self.check_score_now():
            return
        self.score_check = None
        saw = c["saw"]
        if saw is None:
            log.warning("Couldn't read the score to confirm the last bet went on.")
            return
        off = round(saw - c["expected"], 2)
        if abs(off) < 0.01:
            self.score = saw
            return
        # Nothing is corrected from a reading we can't account for. If a stake was on
        # the table for most of this hand and we have never seen this table take one
        # out of the balance, then we don't know which of the two figures the screen
        # was showing, and a guess here would make a right balance wrong.
        if self.deducts is None and self.stake_down:
            log.info("Couldn't confirm the score this hand: the screen read %s against %s "
                     "settled, and there was %s of ours on the table. Nothing changed — it "
                     "isn't yet clear whether this table takes the stake when it is placed.",
                     money(saw), money(c["expected"]), money(self.stake_down))
            return
        log.warning("Screen score %s ≠ expected %s (%s%s) after %.0f s — %s",
                    money(saw), money(c["expected"]), "+" if off > 0 else "", money(off),
                    time.monotonic() - c["since"],
                    "what the table paid for the money of ours that wasn't the bet placed."
                    if c.get("stray") else
                    "the stake didn't go on as staked (a dropped click), or PAYOUT in "
                    "strategies.py is wrong for this table.")
        self.score = saw
        was = self.s.balance
        now = self.s.correct_balance(off, "the screen disagreed with what we staked")
        self.raise_mismatch(off, was, now, c["expected"], saw)
        log.warning("   balance corrected to the screen: %s → %s. Every stake from here is "
                    "worked out from the real money, not from what we thought we had.",
                    money(was), money(now))

    # -- the screen score --------------------------------------------------------
    def check_score(self) -> None:
        """With 'Trust the screen score' on, the score on screen IS the money, so the
        budget you typed has to match it before a single click is made. With it off the
        score is never read at all — no waiting for it, no warnings."""
        if not self.hard_score:
            self.score = None
            log.info("Screen score: off. Results come from the P/B/T counters, and nothing "
                     "waits for the score. (Turn on 'Trust the screen score' in Setup once "
                     "the score region reads your real balance.)")
            return
        self.score = bet.read_number_stable("score")
        if self.score is None:
            raise bet.BetError(
                "'Trust the screen score' is on but the score can't be read. Fix it with "
                "python bet.py --snap score  and  python bet.py --teach score — or turn the "
                "setting off to play from the counters alone.")
        if abs(self.score - self.s.budget) >= 0.01:
            raise bet.BetError(
                f"The screen shows {money(self.score)} but the budget you set is "
                f"{money(self.s.budget)}. They have to match before starting, or every "
                f"balance the bot reports will be wrong. Set the budget to "
                f"{self.score:,.2f}, or turn 'Trust the screen score' off.")
        log.info("Screen score %s matches the budget — starting.", green(money(self.score)))
