"""Player -- the loop that actually plays.

One hand at a time: wait for the result, record it, ask the session what to bet,
wait for the betting window, place it, check the money. Then the table-level
work around that: open a table, judge whether it is worth playing, leave when
the shoe runs out, open the next.

The parts of it live in the modules beside this one, each of which says at the
top which of the Player's state it owns:

    pacing      measuring the table's speed, and how often to look
    money       the score, the stake on the table, the mismatch alarm
    confirming  making sure the bet went on; a break when the site refuses them
    login       logging back in when the site has dropped the session
    navigate    finding, opening, and leaving tables
    tablekind   what kind of table this is, and whether that call was right
    screening   turning a table down before sitting at it
    placing     the betting window, and getting the clicks in
    reporting   what the dashboard is shown"""

from __future__ import annotations

import random
import sys
import time
from baccarat.core import patterns
from baccarat import screen as bet
from baccarat.log import log
from baccarat.core import bets as betting
from baccarat.web.server import NoDashboard
from baccarat.web import updatestatus
from baccarat.core.session import Session
from baccarat.store.history import run_history, shoe_lengths, TableLog


from baccarat.play.confirming import Confirming
from baccarat.play.loadmeter import describe as describe_load, LoadMeter
from baccarat.play.login import LoggingIn
from baccarat.play.money import MoneyWatch
from baccarat.play.navigate import Navigating
from baccarat.play.pacing import Pacing
from baccarat.play.placing import Placing
from baccarat.play.reporting import Reporting
from baccarat.play.screening import Screening
from baccarat.play.tablekind import TableKinds
from baccarat.play.actions import (
    check_live_setup, pattern_variants, run_close_pattern)
from baccarat.play.reading import (
    ask_road, Board, detect_winner, fmt_board, road_and_board, total, wait_next_game)
from baccarat.play.stop import check_stop, Stopped, STOP
from baccarat.play import tuning
from baccarat.util.show import blue, colored_report, green, money, red, signed, summary_line


# ---------------------------------------------------------------------------
# Watching the real table
# ---------------------------------------------------------------------------

class Player(Confirming, LoggingIn, MoneyWatch, Navigating, Pacing, Placing, Reporting, Screening,
             TableKinds):
    def __init__(self, session: Session, road: list[str] | None, dash=None,
                 ask=None, cycles: int = 1, ceiling_step: float | None = None,
                 open_patterns: list[str] | None = None, hand_seconds: float = tuning.HAND_SECONDS,
                 extra_wait: float = tuning.CYCLE_EXTRA, wait_hands: int | None = None,
                 alarm: bool = True, hard_score: bool = False,
                 bet_window: float = tuning.BET_WINDOW[1], click_speed=tuning.CLICK_SPEED,
                 bet_start_on: str = "game", quiet_poll: float = tuning.QUIET_POLL,
                 move_speed: float = 0.26, on_mismatch: str = "carry_on",
                 open_scroll: dict | None = None,
                 screens: list | None = None, screen_min: int = 20,
                 stake_on_place: bool = False, login_tries: int = tuning.LOGIN_TRIES,
                 login_wait: float = tuning.LOGIN_WAIT, login_enter: bool = True,
                 estimator=None, kind_judge=None, kind_after: int = 12,
                 pattern_leave: bool = False):
        """Every piece of a Player's state is set up here, in one place, on
        purpose: this is the only view of what a player IS.

        Which module is responsible for each group is in that module's
        docstring -- pacing, money, navigate, screening, placing, reporting --
        and the groups below are in that order.
        """
        self.s = session
        # the table's pattern, judged after every hand with what all bots have seen
        # (core/patterns.py); with pattern_leave, a table whose pattern is BAD is left once
        # the run in progress is won
        self.pattern_leave = bool(pattern_leave)
        self.pattern: dict | None = None
        self._pattern_said = None
        self.ask = ask or ask_road          # how to ask for the road when joining mid-table
        self.placer = betting.BetPlacer(bet.click_coord, bet.load_coords)
        self.mode = "live"
        self.road_arg = road
        self.dash = dash or NoDashboard()
        self.score: float | None = None
        # a score that hasn't caught up with the last result yet: {expected, saw, game}.
        # Settled in the gap before the next bet, never in front of it.
        self.score_check: dict | None = None
        self._score_looked = 0.0
        # money the screen says went somewhere we can't account for
        self.mismatch: dict | None = None
        self.mismatch_id = 0
        self.on_mismatch = "carry_on"
        # 'Trust the screen score' off: a look at the screen every few bets anyway, to
        # notice bets that aren't going on (money.spot_check_score). Never corrects.
        self.spot: dict = {"looks": 0, "agreed": 0, "apart": 0, "base": None, "suspect": None,
                           "bets": 0, "last": None}
        self.stake_down = 0.0        # money of ours sitting on the table right now
        # does this table take the stake when it is placed? Setup can say so; otherwise
        # it is learnt from the first bet seen going on
        self.deducts: bool | None = True if stake_on_place else None
        self._score_read: tuple[float, float] | None = None   # last screen score, and when
        # money of ours on the table that isn't the bet we placed (wrong size, or a bet
        # stopped before its repeats): settled from the screen once the hand is over
        self.stray: dict | None = None
        # confirming the bet went on, and a break when the site keeps refusing them
        self.bet_watch: dict | None = None      # the score being watched for the stake
        self.rejections: list[float] = []       # when bets were refused, recent ones
        self.rejected_bets = 0                  # this session, for the dashboard
        self.cooloffs = 0                       # breaks taken in a row
        self.cooloff_due = False                # take one once this hand is recorded
        self.cooloff_ended: float | None = None
        self.sit_out_until: float | None = None  # a break taken at the table: no bets till then
        self._said_no_confirm = False
        self._said_no_chip_check = False
        self._chip_check: dict | None = None    # what the chip check saw, for the log
        self.load = LoadMeter()                 # CPU and screen grabs, hand by hand
        # what a win is really worth: a function from the layer above that replays this
        # configuration over the recorded tables (study/expect.py); None = one base bet
        self.estimator = estimator
        self.estimate: dict | None = None
        self._estimating = False
        # what kind of table this is, judged once per table from the recorded ones
        # (study/tablekinds.py, handed in from above like the estimator); None = off
        self.setup_kinds(kind_judge, kind_after)
        # logging in when the site has dropped us: how often to try, how long the site
        # gets to show 'success_login', and whether Enter submits the form
        self.login_tries = max(1, int(login_tries))
        self.login_wait = float(login_wait)
        self.login_enter = bool(login_enter)
        self._said_no_login = False
        self.login_checked = False              # checked once, before the first table
        self.bet_notice: dict | None = None     # "a bet wasn't accepted", on the dashboard
        self.bet_notice_id = 0
        self.table: TableLog | None = None
        self.current_bet: tuple[str, float] | None = None
        self.bet_game: int | None = None
        # unattended repeats
        self.cycles = max(1, int(cycles or 1))
        self.cycle = 1                       # the one being played now
        self.ceiling_step = ceiling_step
        self.open_patterns = list(open_patterns or [])
        self.open_index = 0
        self.hand_seconds = hand_seconds
        self.extra_wait = extra_wait
        # hands per table used only to guess when a table ends (for the wait between
        # tables). The cutoff uses the session's own, lower, table_hands.
        self.wait_hands = wait_hands
        self.hand_times: list[float] = []     # measured seconds between hands (recent)
        # screenshots: the one thing that makes the game itself stutter, so it is counted
        self._shots_at = 0
        self.shots_per_hand: int | None = None
        self.shot_rate: float | None = None
        self._last_game_at: float | None = None
        self.game_seen: float | None = None     # when the current game started (monotonic)
        self.bets_open_at: float | None = None  # when the chips appeared, if we watch for them
        self.chip_waits = 0                     # hands where the chips never showed up
        self.chip_times: list[float] = []       # how long the chips took, recent hands
        self._cutoff_table: str | None = None   # table whose cutoff was already logged
        self.want_switch = False                # cutoff reached and we move to another table
        self.recoveries = 0                     # retries in a row after a stuck table
        self.shots: list[dict] = []             # screenshots of a stuck table
        self.late_arrivals = 0                  # opened tables that had no room left
        self.tables_closed = 0                  # tables closed since the last lobby refresh
        self.tables_played: list[dict] = []     # every table of this session, in a line
        self.refresh_at = random.randint(*tuning.REFRESH_TABLES)
        self._said_no_reload = False
        self._said_no_trigger = False
        self._said_no_road = False
        # for the dashboard
        self.started = time.time()
        self.status = "Starting"
        self.stopped = False
        self.stopped_with: dict | None = None   # a bet / a run left unfinished by a stop
        self.bet_reason = ""
        self.board: Board | None = None
        self.last: dict | None = None
        self.history: list[dict] = []
        self.read_ms: float | None = None
        self.read_fails = 0
        self.prior_count = 0
        # what past runs with this exact strategy + rules needed (updated as runs finish)
        self.run_stats: dict = run_history(session.config)
        # timing: the table takes bets for `bet_window` seconds after the game changes,
        # and one click is assumed to take up to click_speed[1]
        # Where the betting window starts counting: the moment the game number changed,
        # or the moment the chips appear on screen. The second is the honest answer on a
        # table that doesn't open the betting at a fixed interval — it asks the screen
        # instead of assuming.
        self.bet_start_on = "chips" if bet_start_on == "chips" else "game"
        # how long to leave between screenshots early in a hand, before a result is due
        self.quiet_poll = max(tuning.POLL, float(quiet_poll or tuning.QUIET_POLL))
        self.move_speed = float(move_speed or 0.26)
        self.on_mismatch = on_mismatch if on_mismatch in tuning.MISMATCH_WAYS else "carry_on"
        self.bet_end = float(bet_window)
        self.bet_start = min(tuning.BET_WINDOW[0], max(0.0, self.bet_end - 1.0))
        self.click_speed = (float(click_speed[0]), float(click_speed[1]))
        # hard score: the screen score is the truth. Off = it is ignored completely
        # (no waiting for it, no warnings) — for testing the clicks with a dud region.
        self.hard_score = bool(hard_score)
        self.late_skips = 0                     # bets missed because the clicks wouldn't fit
        self.click_cost: float | None = None    # s one click really takes here (measured)
        self.stop_after_result = False          # Stop pressed with a bet on the table
        # scrolling the lobby: how many arrow presses each open action sits at, and
        # where the lobby is scrolled to now. Tables side by side share a position.
        self.open_scroll: dict = dict(open_scroll or {})
        self.scroll_at = 0
        # tables found with no room: action name → when its shoe should be over
        self.table_ready: dict = {}
        # screening: the road shapes that beat this strategy. A table showing one is
        # left alone until its shoe has run out — the same countdown a table with no
        # room gets — and the bot opens the next one instead.
        self.screens = list(screens or [])
        self.screen_min = max(0, int(screen_min or 0))
        self.skipped: list[dict] = []           # what was turned down, for the dashboard
        self.screen_checks: list[dict] = []     # the last table's full report card
        self._said_no_screen_road = False
        self._last_open: str | None = None      # so it doesn't reopen the same tab twice
        self.current_open: str | None = None    # the action that opened the table in play
        self._said_bust = False                 # "the money has run out" is said once
        self._said_watch = False                # so is the result of watching
        # last-life alarm: the dashboard makes a noise until you silence it
        self.alarm_wanted = bool(alarm)
        self.alarm: dict | None = None          # the alarm sounding now
        self.alarm_id = 0                       # a new number = a new noise on the page
        self.alarm_armed = True                 # False once silenced, until the balance recovers
        self.dash.route("/api/silence", self.silence)
        self.dash.route("/api/mismatch", self.mismatch_seen)
        self.dash.route("/api/bet-notice", self.bet_notice_seen)

    def judge_pattern(self) -> None:
        """What the table's pattern says now; said in the log when it changes to something
        worth saying, and, if asked for, the table is left once the run is won."""
        v = patterns.judge(self.s.config, self.s.road)
        self.pattern = v
        said = (v["verdict"], v.get("pattern"))
        if said != self._pattern_said and v["verdict"] in ("bad", "good", "leaning bad", "leaning good"):
            (log.warning if v["verdict"] == "bad" else log.info)("Table %s.", patterns.describe(v))
        self._pattern_said = said
        self.s.leave_for = (f"the table's pattern {v['pattern']} is bad for this set-up — "
                            f"{v['rate'] * 100:.0f}% of {v['n']} bets won after it"
                            if self.pattern_leave and v["verdict"] == "bad" else None)

    SHOES_NEEDED = 5            # full shoes seen before their length is trusted

    def fit_table_end(self) -> None:
        """Where a table really ends, from the shoes this bot has watched to the end:
        the length 4 in 5 of them reached. Setup's 'Hands per table' is a guess; a
        shoe that really runs 44 hands, cut off at 40, gives up 4 hands at every table
        (and one that ends sooner than set risks a run cut off by the shoe)."""
        s = self.s
        if not s.table_hands:
            return
        try:
            seen = sorted(shoe_lengths(site=bet.site_name() or None))
        except Exception as e:
            log.debug("couldn't measure the shoes: %s", e)
            return
        if len(seen) < self.SHOES_NEEDED:
            return
        sure = seen[len(seen) // 5]                  # 4 in 5 shoes lasted at least this
        if sure == s.table_hands:
            return
        log.info("Table end: the %d shoes watched to the end lasted %d–%d hands (4 in 5 at "
                 "least %d) — using %d instead of the %d set in Setup.", len(seen), seen[0],
                 seen[-1], sure, sure, s.table_hands)
        s.table_hands = sure

    def halt_status(self) -> str:
        """What the dashboard says once the session has stopped at the base bet."""
        if self.s.halt_resume:
            return f"Paused for {self.s.halt_for} — it carries on by itself"
        return "Stopped after the run, as asked — at the base bet, nothing on the table"

    def update_due(self) -> bool:
        """Is an update for this stick downloaded and waiting for the session? Then the
        session ends as soon as it is back at the base bet (the run in progress is played
        out), the update installs, and the session starts again by itself."""
        if self.s.halt_for:
            return True
        st = updatestatus.read()
        if not st or st.get("stale") or st.get("state") != "waiting":
            return False
        self.s.halt_for = f"update {st.get('version') or '?'}"
        self.s.halt_resume = True
        log.info("Update %s is downloaded: the run in progress is played out, then the "
                 "session stops at the base bet for it to install, and carries on by itself.",
                 st.get("version") or "?")
        return True

    def record(self, game: int, winner, pairs, board, hint=None) -> None:
        road_before = list(self.s.road)
        r = self.s.record(winner, self.current_bet, game, outcome_hint=hint)
        if r.side:
            # with the verdict that stood before this bet: the judge's own track record
            patterns.observe(self.s.config, road_before, r.outcome, r.side,
                             (self.pattern or {}).get("verdict"))
        self.judge_pattern()
        self.update_due()
        if self.stop_after_result:
            log.info("The result of the bet that was on the table is in — stopping now, as asked.")
            STOP.set()
        self.table.add(game, winner, pairs, board, r)
        pair_txt = " +" + "+".join(p.replace("_", " ") for p in pairs) if pairs else ""
        if r.side:
            bet_txt = f"bet {blue(f'{r.amount:,.0f}')} on {r.side}"
            res = f"{r.outcome} {signed(r.profit)}"
            if r.outcome == "LOSS":
                res = red(f"LOSS {r.profit:+,.2f}")
        elif r.virtual:                       # watching after the money ran out
            v = r.virtual
            stake_txt = blue(f"{v['amount']:,.0f}")
            bet_txt = f"would have bet {stake_txt} on {v['side']}"
            res = f"{v['outcome']} (nothing staked)"
            if v["outcome"] == "LOSS":
                res = red("LOSS (nothing staked)")
        else:
            bet_txt, res = "no bet", ""
        log.info("Game %d: %s%s │ %s → %s", game, (winner or "unknown").upper(), pair_txt,
                 bet_txt, res or "-")
        log.info("   %s   road: %s", summary_line(self.s), self.s.road_str())
        for msg in self.s.events:
            log.info("   ⚑ %s", msg[:1].upper() + msg[1:])
        log.info("   load: %s", describe_load(self.load.hand_done()))
        self.note_finished_run()
        self.report_watch()                   # the virtual bet may have just won
        self.last = {"game": game, "winner": winner, "pairs": pairs, "side": r.side,
                     "amount": r.amount, "outcome": r.outcome, "profit": r.profit, "by": r.by,
                     "virtual": r.virtual}
        self.history.append({"g": game, "b": self.s.balance,
                             "o": r.virtual["outcome"] + "-V" if r.virtual else r.outcome})
        self.current_bet = None
        self.board = board or self.board
        self.follow_kind(r)                   # the table that was judged: one more result
        self.maybe_judge_table()              # … or judge it, once it has a pattern

    def wait(self, seconds: float, what: str, interrupt=None) -> None:
        """Wait, showing a countdown on the dashboard. Stop still works; so does
        `interrupt` (looked at every 10 s: true = stop waiting)."""
        end = time.monotonic() + seconds
        self.dash.update(scheduled={"ts": time.time() + seconds, "label": what})
        looked = time.monotonic()
        while True:
            left = end - time.monotonic()
            if left <= 0:
                break
            if interrupt and time.monotonic() - looked >= 10:
                looked = time.monotonic()
                if interrupt():
                    break
            self.status = f"{what} in {left:.0f} s"
            self.push()
            end += check_stop()                   # paused time doesn't tick the countdown
            time.sleep(min(1.0, left))
        self.dash.update(scheduled=None)

    # -- main loop -----------------------------------------------------------
    def note_unfinished(self) -> None:
        """Stopped with a bet on the table, or partway through a losing run: the casino
        settles the bet anyway, but this session's numbers can't include it, and the run's
        losses so far are not won back. Said once, kept for the Copy report."""
        s = self.s
        lost = [s.staking.base * 2 ** i for i in range(s.staking.step)] if s.staking.step else []
        on = self.current_bet
        if not on and not lost:
            return
        self.stopped_with = {"side": on[0] if on else None, "amount": on[1] if on else 0,
                             "lost": len(lost), "lost_total": round(sum(lost), 2)}
        parts = []
        if on:
            parts.append(f"{on[1]:,.0f} on {on[0]} was on the table — its result wasn't seen "
                         "(the casino settles it all the same; it isn't in these numbers)")
        if lost:
            parts.append(f"the run in progress had lost {len(lost)} bet(s), {sum(lost):,.0f} in "
                         "all, not won back")
        log.warning("Stopped %s: %s.", "in the middle of a run" if lost else "with a bet on the table",
                    "; ".join(parts))

    def run(self) -> None:
        bet.set_click_speed(*self.click_speed)
        bet.set_move_speed(self.move_speed)
        log.info("Timing: the bet goes on between %.1f s and %.1f s into the game; the press "
                 "takes %.2f–%.2f s and the pointer about %.2f s to travel to each spot "
                 "(it hurries only if the window is running out).",
                 self.bet_start, self.bet_end, *self.click_speed, bet.MOVE_TYPICAL)
        check_live_setup()
        self.fit_table_end()
        self.load.start()
        self.refresh_estimate("starting")
        if not pattern_variants("close"):
            log.warning("Nothing named 'close' (a click or a pattern) — the table won't be "
                        "closed when the session ends (record one on the Interface tab)")

        board = self.first_table()
        if board is None:
            self.stopped = True
            self.push()
            return
        # the score lives on the table, so it is checked once one is open — still
        # before a single bet is placed
        self.check_score()
        if self.score is None and self.hard_score:
            log.warning("Can't read the score — results will come from the counters only.")
        self.say_how_bets_are_confirmed()
        self.board = board
        seen = None
        if self.road_arg is None and total(board):
            # join on the counters the road agrees with, not the ones we walked up
            # with: if a result landed while the road was being read, the two are a
            # hand apart and that hand would go into the road twice
            seen, board = road_and_board(board)
            self.board = board
        if self.road_arg is not None:
            prior = self.road_arg
        elif seen is not None:
            prior = seen
            log.info("Loaded the whole table from the screen: %d results (%s%s).", len(seen),
                     "… " if len(seen) > 20 else "",
                     " ".join({"player": "P", "banker": "B", "tie": "T"}[w] for w in seen[-20:]))
        else:
            prior = self.ask(board, self.s.strategy.n)
            if not prior and total(board) >= self.s.strategy.n:
                log.info("This table already has %d results, but they aren't loaded, so "
                         "%s has to wait for %d of its own before its first bet. A 'road' "
                         "region (Interface tab — a box around the grid of coloured circles) "
                         "would read the lot and start it betting straight away.",
                         total(board), self.s.strategy.name, self.s.strategy.n)
                self._said_no_road = True
        self.open_table(board, prior, complete=True if seen is not None else None)
        self.history.append({"g": board["game"], "b": self.s.balance, "o": "START"})
        if self.cycles > 1:
            log.info("Unattended: %d cycles, winning %s each, opening %s in order.", self.cycles,
                     green(money(self.ceiling_step or 0)), ", ".join(self.open_patterns))
        elif self.s.ceiling is not None:
            log.info("One cycle: plays until the balance reaches %s, then stops.",
                     green(money(self.s.ceiling)))
        log.info("%s │ strategy %s │ budget %s │ base bet %s", self.mode.upper(),
                 self.s.strategy.name, green(money(self.s.budget)), blue(money(self.s.staking.base)))
        log.info("Joined at game %d (%s)%s", board["game"], fmt_board(board),
                 f" — known road: {self.s.road_str()}" if prior else "")

        # Game in progress: we don't know if bets are still open → watch it.
        # With a known road, the first bet goes on the very next game.
        game = board["game"]
        log.info("Game %d already running — watching it.", game)
        self.status = f"Watching game {game} (joined mid-game)"
        self.bet_reason = "Joined during this game; the first bet goes on the next one."
        self.push()
        try:
            while True:
                # while watching for free the table is never reopened: it's this table's
                # run we're following, so give it the long timeout instead
                can_reopen = bool(self.open_patterns) and not self.s.watching
                if not self.bet_watch:
                    self.load.phase = "the wait for the result"
                new = wait_next_game(game, board, self.on_read,
                                     timeout=tuning.STALL_AFTER if can_reopen else tuning.IDLE_STOP,
                                     floor=self.hand_floor(), quiet=self.quiet_poll,
                                     fast=self.board_poll())
                if new is None:
                    if self.s.watching:        # the table stopped: don't reopen, just finish
                        self.end_watch("the table stopped")
                        break
                    if not can_reopen:
                        log.warning("Nothing changed for %d s — stopping. (Set an open_table "
                                    "action in Setup and it can reopen the table instead.)",
                                    tuning.IDLE_STOP)
                        break
                    if not self.recover():
                        break
                    board, game = self.board, self.board["game"]
                    continue
                self.game_seen = time.monotonic()        # the betting window opens now
                self.load.phase = "the result"
                self._note_hand_time()
                self.recoveries = 0                      # the table is moving again
                if not self.s.table_done:                # a table with room: the last late
                    self.late_arrivals = 0               # arrivals are water under the bridge
                winner, pairs, after, reset = detect_winner(board, new)

                if reset and self.s.watching:
                    # the table we were following is over: nothing more to learn here
                    self.end_watch("the table ended")
                    break
                if reset:
                    self.close_table("counters reset — new table")
                    log.info("═══ New table ═══  %s", fmt_board(after))
                    self.open_table(after)
                    if winner:                         # new table already has its 1st result
                        hint = self.result_after(winner)
                        self.record(after["game"], winner, pairs, after, hint)
                    elif self.current_bet:
                        log.info("Our bet (%s on %s) carries over to the new table's first game.",
                                 blue(f"{self.current_bet[1]:,.0f}"), self.current_bet[0])
                else:
                    hint = self.result_after(winner)
                    self.record(game, winner, pairs, after, hint)

                board, game = after, after["game"]
                if self.cooloff_due:                    # the site keeps refusing bets
                    if not self.cool_off():
                        break
                    board, game = self.board, self.board["game"]
                    continue
                if self.current_bet is None and not self.decide(game):
                    if (self.s.reached_ceiling and self.cycle < self.cycles
                            and self.open_patterns and not self.s.busted):
                        if not self.next_table(target_reached=True):
                            break
                        board, game = self.board, self.board["game"]
                        continue
                    break
                if self.want_switch:                    # no room left on this table
                    self.want_switch = False
                    if not self.next_table(target_reached=False):
                        break
                    board, game = self.board, self.board["game"]
                    continue
        except KeyboardInterrupt:
            print()
            self.status = "Stopped by you (Ctrl+C)"
        except Stopped:
            log.info("Stopped from the dashboard.")
            self.status = "Stopped from the dashboard"
        finally:
            self.load.stop()
            self.note_unfinished()
            self.end_watch("the session stopped")      # nothing to lose by saying how far it got
            self.close_table("stopped")
            run_close_pattern()                 # close the game
            self.stopped, self.current_bet = True, None
            if self.status.startswith(("Watching", "Bet", "Starting")):
                self.status = "Stopped"
            self.push()
        print("\n" + colored_report(self.s), file=sys.stderr)
