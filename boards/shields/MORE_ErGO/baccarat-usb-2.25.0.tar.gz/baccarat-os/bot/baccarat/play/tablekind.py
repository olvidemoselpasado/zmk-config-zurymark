"""Judging what kind of table this is, following it, and saying afterwards
whether each call was right.

The moment the table has a pattern (the majority window has filled, or with no
window enough of the whole table is in), the road is handed to the judge from
the layer above (study/tablekinds.py). It is judged again every few results
after that (rejudge_every), because the window moves and a table that looked
ordinary at hand 11 can look quite different at hand 20. Each judgement runs on
a thread of its own and waits until this hand's bet is in: it replays every
recorded table, and must never take time from the clicks.

The table is followed all the way: what each call has made since it was made,
and the deepest run. The moment a run gets down to the last two lives the
balance pays for, the table IS bad by definition -- whatever it was called --
and the dashboard says so at once.

When the table is closed every call made on it is compared with what the table
turned out to be from that hand on, written to the log (in full when it was
wrong) and kept in data/table_calls.json: the pattern, its four numbers, what
tables of each kind had looked like, and the closest tables it was compared
with. That is what to read to calibrate it. A table you stopped is still
counted when it had already turned bad: stopping can't undo that.

The Player state this is responsible for:

    kind_judge, kind, kind_open, kind_table, kind_calls, kind_every,
    _kind_busy, _kind_last, _kind_window
"""

from __future__ import annotations

import threading
import time

from baccarat.log import log
from baccarat.core.staking import lives
from baccarat.core.tablekind import TIERS, describe, penultimate, ready, tier, window_of
from baccarat.store.tablecalls import calibration, is_right, save_call
from baccarat.play.reading import total
from baccarat.util.show import money

SAY = {"good": "GOOD", "bad": "BAD", "ordinary": "ORDINARY"}


def _pct(x: float) -> str:
    return f"{x * 100:.0f}%"


def spectrum_text(spec: dict) -> str:
    return ", ".join(f"{_pct(spec[t])} {t}" for t in TIERS)


def call_text(k: dict) -> str:
    """'BAD', or 'ORDINARY, leaning bad' when it leans but not far enough to call."""
    lean = k.get("lean")
    return SAY[k["call"]] + (f", leaning {lean}" if k["call"] == "ordinary" and lean else "")


class TableKinds:
    """Mixed into Player. See the module docstring."""

    def setup_kinds(self, judge, whole_after: int) -> None:
        self.kind_judge = judge
        self.kind_whole_after = int(whole_after)
        self._kind_window = window_of(self.s.rules)
        # judged again after this many more results: half a window, at least 3
        self.kind_every = max(3, (self._kind_window or self.kind_whole_after) // 2)
        self.kind: dict | None = None            # the latest call on the table in play
        self.kind_open: list[dict] = []          # every call on this table, each followed
        self.kind_table: dict | None = None      # the table itself: deepest run, turned bad
        self._kind_busy = False
        self._kind_last: tuple[str, int] | None = None   # (table, results) at the last call
        try:
            self.kind_calls = calibration(self.s.config) if judge else None
        except Exception as e:                   # a damaged file is never worth stopping for
            log.debug("couldn't read the table calls: %s", e)
            self.kind_calls = None

    # -- the call ----------------------------------------------------------------
    def maybe_judge_table(self) -> None:
        """Judge the table in play as soon as it has a pattern, and again every
        `kind_every` results after that."""
        t = self.table
        if not self.kind_judge or t is None or self._kind_busy:
            return
        road, window = list(self.s.road), self._kind_window
        if not ready(road, window, self.kind_whole_after):
            return
        last = self._kind_last
        if last and last[0] == t.name and (last[1] < 0 or len(road) - last[1] < self.kind_every):
            return
        hand = total(self.board) if self.board else len(road)
        cut = self.s.cutoff_hand()
        if self.s.table_done or (cut is not None and hand > cut):
            return       # past the last hand a run may start: what is left is too short to judge
        if not window and len(road) < hand:
            self._kind_last = (t.name, -1)       # never, on this table
            log.info("Table kind: not judged — the whole table is the pattern (no majority "
                     "window), and the first %d of its %d results weren't seen.",
                     hand - len(road), hand)
            return
        self._kind_last = (t.name, len(road))
        self._kind_busy = True
        balance = self.s.balance
        # follow the table from this hand at once: the judgement takes a moment, and
        # the hands that land meanwhile belong to what it turns out to be
        track = {"table": t.name, "hand": hand, "profit": 0.0, "deepest": 0,
                 "results": 0, "bets": 0, "bad_at": None}
        name = t.name

        def work():
            try:
                self._kind_wait_for_bet()
                k = self.kind_judge(road=road, hand=hand, exclude=(name,), budget=balance)
            except Exception as e:               # an opinion is never worth an error
                log.warning("Couldn't judge this table's kind: %s", e)
                k = None
            finally:
                self._kind_busy = False
            if (k is None or self.table is None or self.table.name != name
                    or self.table.data.get("ended")):
                return                           # the table changed (or closed) while it was thinking
            k["table"] = name
            before = self.kind
            self.kind = k
            if k.get("ready"):
                self.kind_open.append({"k": k, "track": track})
            self.say_kind(k, before)
            self.push()
        threading.Thread(target=work, name="table-kind", daemon=True).start()

    def _kind_wait_for_bet(self) -> None:
        """Hold the judgement until this hand's betting window is over: the clicks and
        the check that the bet went on come first."""
        until = (self.game_seen or 0.0) + self.bet_end + 1.0
        while time.monotonic() < until and not self.stopped:
            time.sleep(0.2)

    def say_kind(self, k: dict, before: dict | None = None) -> None:
        where = (f"last {k['window']} results" if k["window"] else "the whole table so far")
        if not k.get("ready"):
            log.info("Table kind at hand %d — pattern %s (%s). Not judged: %s.", k["hand"],
                     k["pattern"] or "—", where, k.get("why", ""))
            return
        again = bool(before and before.get("ready") and before.get("table") == k["table"])
        if again and before["call"] == k["call"] and before.get("lean") == k.get("lean"):
            log.info("Table kind at hand %d: still %s — %s; bad %s (tables in general %s).",
                     k["hand"], call_text(k), k["pattern"], _pct(k["spectrum"]["bad"]),
                     _pct(k["general"]["bad"]))
            return
        # One line: what it looks like, what tables like it did, and whether such calls
        # have ever been right here (the details are in the Copy report's table kinds).
        rec = k.get("record") or {}
        proven = any((rec.get("proven") or {}).values())
        log.info("Table kind at hand %d: %s%s — %s; tables like it: %s bad, %s good+ (in general "
                 "%s, %s); typically %s from here · %s.",
                 k["hand"], call_text(k),
                 f" (was {call_text(before)} at hand {before['hand']})" if again else "",
                 k["pattern"], _pct(k["spectrum"]["bad"]),
                 _pct(k["spectrum"]["good"] + k["spectrum"]["exceptional"]),
                 _pct(k["general"]["bad"]),
                 _pct(k["general"]["good"] + k["general"]["exceptional"]),
                 money(k["typical"]["median"]),
                 "proven on your tables" if proven else "unproven: such calls haven't been "
                 "right more often than chance here")

    # -- following the table ------------------------------------------------------------
    def follow_kind(self, r) -> None:
        """One more result on the table in play."""
        if not self.kind_judge or not self.table:
            return
        name = self.table.name
        if not self.kind_table or self.kind_table["table"] != name:
            self.kind_table = {"table": name, "deepest": 0, "bad_at": None, "lives_left": None}
        tb = self.kind_table
        run = self.s.last_run["lives"] if self.s.last_run else 0
        tb["deepest"] = max(tb["deepest"], self.s.run_bets, run)
        hand = total(self.board) if self.board else len(self.s.road)
        for c in self.kind_open:
            tr = c["track"]
            if tr["table"] != name:
                continue
            tr["results"] += 1
            if r.side:
                tr["bets"] += 1
                tr["profit"] = round(tr["profit"] + r.profit, 2)
            tr["deepest"] = max(tr["deepest"], self.s.run_bets, run)
        # down to the last two lives the balance pays for: the table is bad, now
        if self.s.in_run and tb["bad_at"] is None:
            left = len(lives(self.s.balance, self.s.staking)[0])
            if left <= 2:
                tb.update(bad_at=hand, lives_left=left)
                for c in self.kind_open:
                    if c["track"]["table"] == name and c["track"]["bad_at"] is None:
                        c["track"]["bad_at"] = hand
                k = self.kind
                log.warning("Table kind: this table has turned BAD at hand %d — the run is %d "
                            "bets deep and the balance pays for %d more%s.", hand,
                            self.s.run_bets, left,
                            f" (it was called {call_text(k)} at hand {k['hand']})"
                            if k and k.get("ready") and k.get("table") == name else "")

    def kind_report(self) -> dict | None:
        """For the dashboard."""
        if not self.kind_judge:
            return None
        name = self.table.name if self.table else None
        k = self.kind if self.kind and self.kind.get("table") == name else None
        mine = [c for c in self.kind_open if c["track"]["table"] == name]
        tb = self.kind_table if self.kind_table and self.kind_table["table"] == name else None
        return {"window": self._kind_window, "whole_after": self.kind_whole_after,
                "every": self.kind_every, "busy": self._kind_busy, "now": k,
                "track": mine[0]["track"] if mine else None,     # since the first call
                "history": [{"hand": c["k"]["hand"], "call": c["k"]["call"],
                             "lean": c["k"].get("lean")} for c in mine],
                "table": tb, "calls": self.kind_calls}

    # -- when the table is over -------------------------------------------------------------
    def settle_kind(self, reason: str) -> None:
        """The table is closed: what it turned out to be, against every call made on it."""
        name = self.table.name if self.table else None
        calls = [c for c in self.kind_open if c["track"]["table"] == name]
        self.kind, self.kind_open, self.kind_table = None, [], None
        stored = 0
        for c in calls:
            stored += self._settle_one(c["k"], c["track"], reason)
        if stored:
            try:
                self.kind_calls = calibration(self.s.config)
            except Exception as e:
                log.debug("couldn't read the table calls: %s", e)
                return
            log.info("   %s", calls_summary(self.kind_calls))

    def _settle_one(self, k: dict, tr: dict, reason: str) -> int:
        if tr["results"] == 0:
            return 0                             # nothing happened after the call
        deepest = max(tr["deepest"], penultimate(k["cover"]) if tr["bad_at"] else 0)
        got = tier(tr["profit"], deepest, k["cover"], k["exceptional_at"], k["regular_below"])
        # stopping can't undo a table that already went bad; anything else is unfinished
        partial = reason == "stopped" and got != "bad"
        call = {"config": self.s.config, "table": k["table"],
                "when": time.strftime("%Y-%m-%d %H:%M:%S"), "hand": k["hand"],
                "window": k["window"], "pattern": k["pattern"], "features": k["features"],
                "call": k["call"], "lean": k.get("lean"), "spectrum": k["spectrum"],
                "general": k["general"], "record": k.get("record"), "uses": k["uses"],
                "examples": k["examples"], "nearest": k["nearest"], "by_tier": k.get("by_tier"),
                "base": self.s.staking.base,
                "outcome": {"tier": got, "profit": tr["profit"], "deepest": tr["deepest"],
                            "bad_at": tr["bad_at"], "cover": k["cover"],
                            "results": tr["results"], "bets": tr["bets"], "reason": reason,
                            "partial": partial}}
        right = is_right(call)
        how = "RIGHT" if right else "WRONG"
        log.info(
            "Table kind: called %s at hand %d — %s %s: made %s over the %d results after "
            "(%d bets), deepest run %d of %d lives%s%s.", call_text(k), k["hand"],
            "it was" if not partial else "stopped early; so far",
            got.upper(), money(tr["profit"]), tr["results"], tr["bets"], tr["deepest"],
            k["cover"], f", down to the last two lives at hand {tr['bad_at']}"
            if tr["bad_at"] else "", "" if partial else f" — the call was {how}")
        if not right and not partial:
            self.explain_wrong_call(k, got)
        try:
            save_call(call)
        except Exception as e:
            log.debug("couldn't store the table call: %s", e)
            return 0
        return 1

    def explain_wrong_call(self, k: dict, got: str) -> None:
        """What made it look the way it did, for calibrating. Logged as information, not
        a warning: a wrong call is something to learn from, not something wrong with
        the session -- and the Copy report's warnings stay about real problems."""
        near = ", ".join(f"{n['table']} {n['tier']}" for n in k.get("nearest", [])[:3])
        log.info("   It was %s: %s; judged on %s; closest: %s.", got.upper(),
                 describe(k["pattern"], k["features"]), ", ".join(k["uses"]), near or "—")


def record_text(rec: dict | None) -> str:
    """What calls like this would have been worth on your own tables."""
    if not rec or not rec.get("n"):
        return "Track record: not enough tables yet."
    parts = []
    for name, what, rate in (("bad", "bad", rec["bad_rate"]), ("good", "good", rec["good_rate"])):
        row = rec["calls"][name]
        if not row["n"]:
            parts.append(f"it would never have called one {SAY[name]}")
            continue
        parts.append(f"of the {row['n']} it would have called {SAY[name]}, "
                     f"{_pct(row[what] / row['n'])} were {what} (all tables: {_pct(rate)})"
                     + (" — proven" if rec["proven"][name] else " — not proven"))
    tail = ("" if any(rec["proven"].values()) else
            " So far the shape of the road hasn't told good tables from bad ones here: "
            "treat the call as unproven.")
    return f"Track record on your {rec['n']} tables: " + "; ".join(parts) + "." + tail


def calls_summary(c: dict | None) -> str:
    """'Calls so far: GOOD 5 (3 right), BAD 4 (1 right), ORDINARY 9 (6 right) …'."""
    if not c or not c.get("n"):
        return "No table calls with an outcome yet."
    parts = []
    for name in ("good", "bad", "ordinary"):
        row = c["calls"][name]
        if row["n"]:
            parts.append(f"{SAY[name]} {row['n']} ({row['right']} right, {_pct(row['right'] / row['n'])})")
    every = c["tiers"]
    return (f"Calls so far for this configuration: {', '.join(parts)}. All {c['n']} judged tables "
            f"turned out: {', '.join(f'{every[t]} {t}' for t in TIERS)}.")
