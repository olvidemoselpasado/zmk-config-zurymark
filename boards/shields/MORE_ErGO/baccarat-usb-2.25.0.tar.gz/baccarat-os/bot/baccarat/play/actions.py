"""The recorded things the bot does to the browser: open a table, close it,
reload, scroll the lobby.

Each is a name that may be a single coordinate or a multi-step pattern; the
same name works either way, so a site that needs three clicks to leave a table
is set up the same way as one that needs one."""

from __future__ import annotations

import random
import re
from baccarat import screen as bet
from baccarat.log import log
from baccarat.core import bets as betting




# ---------------------------------------------------------------------------
# Placing a bet
# ---------------------------------------------------------------------------

def check_live_setup() -> None:
    errors, warnings = betting.setup_problems(bet.load_coords())
    if errors:
        raise bet.BetError("Live mode can't start: " + "; ".join(errors) +
                           ".\n  Add them on the Interface tab (Name, then Record)")
    for w in warnings:
        log.warning("Live mode: %s", w)
    # every coordinate is a point on the screen: the game window has to be as wide, and
    # start where, it did when they were recorded. Fitted here if it has moved.
    bet.ensure_game_window()


def pattern_variants(base: str) -> list[str]:
    """Everything named `base` or `base_1`, `base_2` … — a saved coordinate (one click)
    or a pattern (several steps). One is picked at random each time."""
    rx = re.compile(rf"^{re.escape(base)}(?:_\d+)?$")
    return sorted({n for n in bet.pattern_names() if rx.match(n)}
                  | {n for n in bet.load_coords() if rx.match(n)})


def run_action(name: str) -> None:
    """Run `name`: a pattern if one exists with that name, otherwise click the coordinate."""
    if name in bet.pattern_names():
        bet.run_pattern(name)
    else:
        bet.click_coord(name)


def action_kind(name: str) -> str:
    return "pattern" if name in bet.pattern_names() else "click"


# How a table is left. Some sites open each table in its own tab, which is closed to
# get back to the lobby; others load the table into the same page, where there is no tab
# to close — the page is reloaded instead and comes back at the lobby.
LEAVE_WAYS = ("close", "reload")


RELOAD_KEY = bet.RELOAD_KEY        # F5 on Linux, ⌘R on a Mac


LEAVE_WAY = "close"          # set from Setup / --leave


def set_leave_way(way: str) -> str:
    global LEAVE_WAY
    LEAVE_WAY = way if way in LEAVE_WAYS else "close"
    return LEAVE_WAY


def reload_focus() -> tuple | None:
    """Where to park the mouse so the key reaches the game and not this dashboard:
    a 'lobby_focus' coordinate if there is one, else any open_table coordinate."""
    coords = bet.load_coords() or {}
    spot = coords.get("lobby_focus")
    if spot is None:
        spot = next((coords[n] for n in sorted(coords) if n.startswith("open_table")), None)
    return (spot["x"], spot["y"]) if spot else None


def run_close_pattern(what: str = "Session over") -> None:
    """Leave the table: close its tab, or reload the page, depending on the site."""
    if LEAVE_WAY == "reload":
        names = pattern_variants("reload")
        if names:
            name = random.choice(names)
            log.info("%s — reloading with %s '%s'.", what, action_kind(name), name)
            try:
                run_action(name)
                return
            except Exception as e:
                log.error("'%s' failed: %s — falling back to the %s key.", name, e, RELOAD_KEY)
        over = reload_focus()
        if over is None:
            log.warning("%s — nothing named 'reload' and no coordinate to aim at, so the "
                        "%s key would go to whatever window has the keyboard. Record "
                        "'lobby_focus' (a harmless spot on the game page) on the Interface "
                        "tab.", what, RELOAD_KEY)
            return
        log.info("%s — reloading the page (%s over %d,%d).", what, RELOAD_KEY, *over)
        try:
            bet.press_key(RELOAD_KEY, over, "reload")
        except Exception as e:
            log.error("reload failed: %s", e)
        return
    names = pattern_variants("close")
    if not names:
        log.warning("Nothing named 'close' — the game window stays open "
                    "(record a coordinate on the Interface tab, or a pattern with --capture). "
                    "If this site opens tables in the same page, set Leaving a table to "
                    "'reload the page' in Setup.")
        return
    name = random.choice(names)
    try:
        log.info("%s — running %s '%s'.", what, action_kind(name), name)
        run_action(name)
    except Exception as e:
        log.error("'%s' failed: %s", name, e)
