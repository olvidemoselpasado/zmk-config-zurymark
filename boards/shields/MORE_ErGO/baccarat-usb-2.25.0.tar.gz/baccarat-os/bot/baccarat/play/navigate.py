"""Finding a table, opening it, leaving it, and finding the next one.

Most of the fiddly real-world work is here: a table that opens showing the last
table's numbers, a bar that lingers after the table has closed, a lobby that
needs scrolling, a table that freezes with the bar still readable, a shoe with
no room left to finish a run in. Each of those is a comment next to the code
that handles it.

The Player state this is responsible for:

    cycles, cycle, open_patterns, open_index, open_scroll, scroll_at,
    table_ready, tables_closed, refresh_at, _last_open, current_open,
    late_arrivals, recoveries, shots, want_switch, _cutoff_table,
    ceiling_step, extra_wait, wait_hands
"""

from __future__ import annotations

import random
import time
from baccarat import screen as bet
from baccarat.log import log
from baccarat.store.history import TableLog
from baccarat.play.actions import (
    action_kind, LEAVE_WAY, pattern_variants, run_action,
    run_close_pattern)
from baccarat.play.reading import (
    Board, fmt_board, road_and_board, same_board, total)
from baccarat.play.stop import check_stop, nap
from baccarat.play import tuning
from baccarat.util.clock import _hms
from baccarat.util.show import blue, green, money


def table_summary(name: str, data: dict, reason: str) -> dict:
    """One table of this session, in a line: for the Copy report."""
    bets = [r for r in data.get("rounds", []) if r.get("side")]
    deepest = streak = 0
    for r in bets:
        if r.get("outcome") == "LOSS":
            streak += 1
            deepest = max(deepest, streak)
        elif r.get("outcome") == "WIN":
            streak = 0
    return {"name": name, "started": (data.get("started") or "")[11:16],
            "ended": (data.get("ended") or "")[11:16], "rounds": len(data.get("rounds", [])),
            "bets": len(bets), "won": sum(r.get("outcome") == "WIN" for r in bets),
            "lost": sum(r.get("outcome") == "LOSS" for r in bets),
            "net": round(sum(r.get("profit") or 0 for r in bets), 2),
            "deepest": deepest, "biggest": max((r.get("stake") or 0 for r in bets), default=0),
            "joined": data.get("joined_at_game"), "reason": reason}


class Navigating:
    """Mixed into Player. See the module docstring."""

    # -- helpers -------------------------------------------------------------
    def open_table(self, board: Board, prior: list[str] | None = None,
                   complete: bool | None = None) -> None:
        self.table = TableLog(board, self.mode, self.s.strategy.name, prior, complete,
                              site=bet.site_name())
        self.s.new_table(prior)
        self.prior_count = len(prior or [])

    def close_table(self, reason: str) -> None:
        # once only: a table opened and turned away (too far along, turned down) was never
        # this table -- closing "it" used to close the previous one a second time, listing
        # it twice and overwriting why it really ended
        if self.table and not self.table.data.get("ended"):
            n = len(self.table.data["rounds"])
            self.table.close(reason)
            self.tables_played.append(table_summary(self.table.name, self.table.data, reason))
            self.settle_kind(reason)                        # was the call on it right?
            log.info("Table stored: %s (%d rounds seen, %s)", self.table.path.name, n, reason)
            self.refresh_estimate("a table was stored")     # one more table to learn from

    def wait_for_board(self, avoid: Board | None = None) -> Board | None:
        """After opening a table: wait until its bar can be read again.
        `avoid` is the board of the table we just closed — an identical read in the first
        seconds is the old bar still on screen, not a coincidence, so it is ignored until
        tuning.STALE_WINDOW has passed."""
        start = time.monotonic()
        end = start + tuning.BOARD_TIMEOUT
        self.status = "Waiting for the new table to load"
        self.push()
        said = False
        nap(tuning.TABLE_SETTLE)                             # let it draw before looking
        while time.monotonic() < end:
            end += check_stop()
            b = bet.read_board_stable()
            if b:
                if avoid and same_board(b, avoid) and time.monotonic() - start < tuning.STALE_WINDOW:
                    if not said:
                        said = True
                        log.info("The bar still reads the table we just closed (%s) — waiting "
                                 "for the new one to draw.", fmt_board(b))
                    nap(0.5)
                    continue
                return b
            nap(0.5)
        return None

    def wait_for_board_gone(self, timeout: float = tuning.GONE_TIMEOUT) -> bool:
        """After closing: wait until the bar can no longer be read, so the next table's
        first read can't be the old one's numbers. False = it never went away."""
        start = time.monotonic()
        end = start + timeout
        said = False
        while time.monotonic() < end:
            end += check_stop()
            if bet.read_board_stable(timeout=1.0) is None:
                if said:
                    log.info("The bar has gone after %.0f s — the table is closed.",
                             time.monotonic() - start)
                return True
            if not said and time.monotonic() - start > 2.0:
                said = True
                self.status = "Waiting for the closed table to disappear"
                self.push()
                log.info("The scoreboard bar still reads after closing — waiting for it to "
                         "go (up to %.0f s).", timeout)
            nap(0.3)
        log.warning("The scoreboard bar is STILL readable %.0f s after closing. Either the "
                    "close didn't work, or the board region overlaps something in the lobby "
                    "that looks like a scoreboard. Check: python bet.py --read-board with the "
                    "lobby showing.", timeout)
        return False

    def open_until_loaded(self, name: str, same_table: bool = False,
                          avoid: Board | None = None) -> tuple:
        """Scroll to the action, click it and wait for the bar to read. Retries a blank
        tab, waiting longer each time, and may switch to another action to do it.
        → (board, the action that actually loaded). (None, name) = give up and stop."""
        tries = 0
        while True:
            self.ensure_lobby("reloading")      # the tiles only exist when the lobby is up
            self.scroll_to(name)
            log.info("Opening a table with %s '%s'.%s", action_kind(name), name,
                     f"  (try {tries + 1} of {tuning.MAX_RECOVERIES})" if tries else "")
            self.status = f"Opening a table ({name})"
            self.push()
            try:
                run_action(name)
            except bet.BetError as e:
                log.error("'%s' failed: %s — stopping.", name, e)
                return None, name
            board = self.wait_for_board(avoid)
            if board is not None:
                log.info("Table loaded (%s).", fmt_board(board))
                return board, name
            tries += 1
            self.snapshot("not-loaded", f"'{name}' opened but the bar was still unreadable "
                                        f"{tuning.BOARD_TIMEOUT:.0f} s later (try {tries})")
            if tries >= tuning.MAX_RECOVERIES:
                log.error("The table didn't load after %d tries — stopping. The screenshots on "
                          "the dashboard show what was on screen.", tries)
                self.status = "Stopped: the table never loaded — see the screenshots"
                return None, name
            pause = tuning.RECOVER_WAIT * (1.8 ** (tries - 1))
            log.warning("The table didn't load within %.0f s (try %d of %d) — closing it and "
                        "clicking again in %.0f s.", tuning.BOARD_TIMEOUT, tries, tuning.MAX_RECOVERIES, pause)
            self.leave_table("Closing the tab that didn't load")
            self.refresh_lobby("the table didn't load")   # a stale lobby is the usual cause
            self.scroll_at = 0                           # a refresh puts the lobby back on top
            self.tables_closed = 0
            self.refresh_at = random.randint(*tuning.REFRESH_TABLES)
            # a table that won't load is often a session that has ended: the casino
            # logged out (a time limit, a "still playing?" check). The lobby is up now --
            # the place to see that -- so it is looked at before clicking again.
            if not self.ensure_logged_in("the table didn't load"):
                return None, name
            self.wait(pause, "Trying again")
            if len(self.open_patterns) > 1:
                # another table: this one may be the problem. Free ones first.
                now = time.monotonic()
                other = [n for n in self.open_patterns if n != name]
                free = [n for n in other if self.table_ready.get(n, 0.0) <= now]
                name = random.choice(free or other)
                log.info("Trying a different open action this time: '%s'.", name)

    def start_video(self) -> bool:
        videos = pattern_variants("play_video")
        if not videos:
            log.warning("Nothing named play_video… — skipping that step.")
            return True
        video = random.choice(videos)
        log.info("Starting the video (%s '%s'%s).", action_kind(video), video,
                 f", picked at random from {len(videos)}" if len(videos) > 1 else "")
        try:
            run_action(video)
        except bet.BetError as e:
            log.error("'%s' failed: %s — stopping.", video, e)
            return False
        return True

    def has_room(self, board: Board | None) -> bool:
        """Is there space on this table for a losing run to play itself out?"""
        s = self.s
        if not s.table_hands:
            return True
        return (s.table_hands - total(board)) > s.hands_needed()

    def hunt_for_table(self, same_table: bool = False) -> Board | None:
        """Open tables until one has room for a losing run. A table that turns out to be
        too far along is noted with the time its shoe should end and closed, and the next
        one is tried — so several countdowns run at once and the bot takes whichever frees
        up first. It never gives up: a shoe always ends. None = the session was stopped,
        or a table would not load at all."""
        s = self.s
        rounds = 0
        left_board = self.board if not same_table else None   # what the closed table read
        while True:
            rounds += 1
            now = time.monotonic()
            log.info("Looking for a table (round %d). %s", rounds, " │ ".join(
                f"{n}: " + ("never tried" if n not in self.table_ready
                            else "worth a look" if self.table_ready[n] <= now
                            else f"busy {_hms(self.table_ready[n] - now)}")
                for n in self.open_patterns) or "no open actions set!")
            if same_table and rounds == 1:
                # the table that was just closed: its own name (open_index already points
                # at the one after it -- reopening "the same table" used to open another,
                # busy one, and never let go of it)
                name = self.current_open or self.open_patterns[
                    (self.open_index - 1) % len(self.open_patterns)]
                hold = 0.0
            else:
                name, hold = self.pick_open_action()
            if hold > 0:
                self.dash.update(waiting=self.countdowns())
                others = [f"{c['name']} {_hms(c['in'])}" for c in self.countdowns()[1:]]
                log.info("Every table is still running. '%s' should finish first, in %s.%s",
                         name, _hms(hold),
                         f"  Then: {', '.join(others)}." if others else "")
                self.wait(hold, f"'{name}' should be free",
                          interrupt=lambda: not s.in_run and self.update_due())
                if not s.in_run and self.update_due():
                    log.info("Waiting for a table at the base bet: stopping here for %s.",
                             s.halt_for)
                    self.status = self.halt_status()
                    return None
            self._last_open = name
            self.open_index = self.open_patterns.index(name) + 1
            log.info("Trying '%s' now.", name)
            # the lobby is showing: the one place the session can be checked for, and
            # the last moment before a table tile is clicked on what may be a login page.
            # At the start of the session, after a table got stuck, and after one that
            # didn't load -- never in the middle of play.
            # And again after a table got stuck: a session that ended (logged out, a
            # "still playing?" box) is the usual reason a table stops moving.
            if not self.login_checked or (same_table and rounds == 1):
                if not self.ensure_logged_in("before the first table" if not self.login_checked
                                             else "the table got stuck"):
                    return None
                self.login_checked = True
            wanted = name
            board, name = self.open_until_loaded(name, same_table, avoid=left_board)
            if board is None:
                return None
            if name != wanted:
                same_table = False              # another table loaded: it needs room too
            if not self.start_video():
                return None
            board = bet.read_board_stable() or board
            log.info("'%s' is at hand %d of %d — %s.", name, total(board), s.table_hands or 0,
                     "room for a run" if self.has_room(board) else "no room")
            bad = self.judge_table(board, name)
            if bad:
                self.turn_down_table(name, bad, board)
                self.close_table("turned down by the table screens")
                self.leave_table("Leaving a table that was turned down")
                left_board = board
                same_table = False
                continue
            if same_table or self.has_room(board):
                self.table_ready.pop(name, None)
                self.current_open = name
                self.dash.update(waiting=self.countdowns())
                self.late_arrivals = 0
                return board
            # too far along: note when its shoe should end and try another one
            left = self.table_wait_left(board)
            self.table_ready[name] = time.monotonic() + left
            self.late_arrivals += 1
            log.info("'%s' is too far along for a run: closing it; its shoe should be over "
                     "in %s.", name, _hms(left))
            self.dash.update(waiting=self.countdowns())
            self.status = (f"Looking for a table with room "
                           f"({self.late_arrivals} too far along so far)")
            self.push()
            self.close_table("opened too late — no room")
            self.leave_table("Closing a table with no room")
            left_board = board
            same_table = False
            # every full pass with nothing free, refresh the lobby: a stale list is a
            # common reason the hands look wrong
            if rounds % max(2, len(self.open_patterns)) == 0:
                log.info("No table with room after %d opens — refreshing the lobby and "
                         "carrying on. Countdowns: %s", rounds,
                         ", ".join(f"{c['name']} {_hms(c['in'])}" for c in self.countdowns()))
                if self.refresh_lobby("still looking for a table with room"):
                    self.scroll_at = 0
                    self.tables_closed = 0
                    self.refresh_at = random.randint(*tuning.REFRESH_TABLES)

    def first_table(self) -> Board | None:
        """At the start of a session: get onto a table without you having to open one.
        A table already on screen is used when it still has room; otherwise it is closed
        and the bot opens one itself. None = stop."""
        board = bet.read_board_stable()
        if board is not None and (self.has_room(board) or not self.open_patterns):
            bad = self.judge_table(board, None)
            if not bad:
                log.info("A table is already open (%s) — starting on it.", fmt_board(board))
                self.current_open = None        # we didn't open it, so we can't name it
                return board
            self.turn_down_table(None, bad, board)
            if not self.open_patterns:
                log.warning("There's no open_table action set, so there's nowhere else to "
                            "go — playing this table anyway. Tick one in Setup to let the "
                            "bot move on from a table like this.")
                self.current_open = None
                return board
            self.leave_table("Leaving a table that was turned down")
            self.status = "Looking for a table worth playing"
            self.push()
            return self.hunt_for_table()
        if not self.open_patterns:
            raise bet.BetError(
                "Can't read the scoreboard bar, and no open_table action is set. Either open "
                "a table yourself, or tick one in Setup so the bot can open its own — check "
                "the reading with: python bet.py --read-board")
        if board is not None:
            log.info("The open table is at hand %d of %d — too far along to start on. "
                     "Leaving it and opening another.", total(board), self.s.table_hands)
            self.leave_table("The open table has no room")
        elif bet.board_present():
            # a table IS up, we just can't read its numbers yet. Don't click a lobby tile
            # at it — step off first, exactly as if it had been too far along.
            log.info("A table is on screen but its numbers can't be read yet (the digits "
                     "may not be taught). Leaving it and opening a fresh one.")
            self.leave_table("Leaving a table that can't be read")
        else:
            log.info("No table on screen — opening one (%s).", ", ".join(self.open_patterns))
        self.status = "Opening the first table"
        self.push()
        return self.hunt_for_table()

    def next_table(self, target_reached: bool, same_table: bool = False,
                   wait_seconds: float | None = None) -> bool:
        """Close this table and get onto one with room. Tables that turn out to be too
        far along are noted with the time their shoe should end, and the bot moves to
        the next open action rather than sitting there — so several countdowns can be
        running at once and it takes whichever comes up first. False = stop."""
        s = self.s
        if target_reached:
            log.info("Cycle %d of %d done: balance %s (target %s reached).", self.cycle,
                     self.cycles, green(money(s.balance)), green(money(s.ceiling)))
            self.close_table(f"cycle {self.cycle} finished")
            self.leave_table("Cycle finished")
        elif same_table:
            self.close_table("table stuck — reopening")
            self.leave_table("Closing the table")
        elif s.leave_for:
            log.info("Leaving this table: %s. The run was won; moving to another one.", s.leave_for)
            self.close_table("bad pattern")
            self.leave_table("Leaving a table with a bad pattern")
        else:
            log.info("No room left on this table (%s) — moving to another one; still "
                     "cycle %d of %d, target %s.", s.skip_reason, self.cycle, self.cycles,
                     green(money(s.ceiling)) if s.ceiling is not None else "none")
            self.close_table("no room left for a new run")
            self.leave_table("Closing the table")

        # The table we have just left is busy until its shoe ends. That is a countdown
        # for THAT table, not a reason to sit still: the others may be free right now, so
        # note it and go straight to the hunt.
        if wait_seconds is not None:
            self.wait(wait_seconds, "Table opens")          # a stuck-table retry
        elif self.current_open:
            left = self.table_wait_left(self.board)
            self.table_ready[self.current_open] = time.monotonic() + left
            others = [n for n in self.open_patterns if n != self.current_open]
            log.info("'%s' has ~%d of its ~%d hands left (%s), so it is out for about %s. "
                     "%s", self.current_open,
                     max(0, (self.wait_hands or s.table_hands or 0) - total(self.board)),
                     self.wait_hands or s.table_hands or 0, self.hand_pace()[1], _hms(left),
                     f"Looking at {', '.join(others)} now." if others
                     else "It is the only table set, so waiting for it.")
            self.dash.update(waiting=self.countdowns())

        self.tables_closed += 1
        if self.tables_closed >= self.refresh_at:
            if self.refresh_lobby(f"{self.tables_closed} tables since the last refresh"):
                self.scroll_at = 0
                self.tables_closed = 0
                self.refresh_at = random.randint(*tuning.REFRESH_TABLES)
                log.info("Next refresh after %d more tables.", self.refresh_at)

        if not self.s.in_run and self.update_due():
            log.info("Off the table and at the base bet: stopping here for %s.", self.s.halt_for)
            self.status = self.halt_status()
            return False
        board = self.hunt_for_table(same_table)
        if board is None:
            return False

        # a finished cycle aims at the next target; a switch keeps the current one
        if not target_reached:
            self.status = f"Cycle {self.cycle} of {self.cycles} on a new table"
        else:
            self.cycle += 1
            s.reached_ceiling = False
        if target_reached and self.ceiling_step:
            # chain the targets: 320 → 380 → 440 …  (a win that overshoots doesn't
            # shift the next target, unless it already passed it)
            nxt = round((s.ceiling or s.balance) + self.ceiling_step, 2)
            if nxt <= s.balance:
                nxt = round(s.balance + self.ceiling_step, 2)
            s.ceiling = nxt
            log.info("Cycle %d of %d: next target %s.", self.cycle, self.cycles,
                     green(money(s.ceiling)))
        seen = []
        if total(board):
            seen, board = road_and_board(board)      # the road and its own counters
        self.board = board
        if seen:
            log.info("The new table already has %d results — loaded them from the screen.", len(seen))
        self.open_table(board, seen or None,        # fresh table (plus anything already played)
                        complete=True if seen is not None else None)
        self.placer.last = None                     # redo can't repeat a bet from another table
        self.history.append({"g": board["game"], "b": s.balance, "o": "TABLE"})
        self.current_bet = None
        self.game_seen = time.monotonic()
        self._last_game_at = None
        self.status = f"Cycle {self.cycle} of {self.cycles} on a new table"
        self.push()
        return True

    def leave_table(self, what: str) -> None:
        """Get off the table we are on. Closing a tab is instant; reloading the page is
        not — the lobby has to come back before anything on it can be clicked, so the
        wait is part of leaving rather than something a caller might forget."""
        run_close_pattern(what)
        bet.forget_board()              # the next table's bar is nothing like this one's
        self.wait_for_board_gone()
        if LEAVE_WAY == "reload":
            self.scroll_at = 0                  # a reload puts the lobby back at the top
            self.wait(random.uniform(*tuning.LOBBY_WAIT), "Lobby loads")

    def ensure_lobby(self, why: str = "Back to the lobby") -> None:
        """Only for sites that load the table into the page you are already on: while a
        table is showing, the lobby is NOT, so clicking where a table tile lives would
        land on the game instead. Reload first, then the tiles are really there."""
        if LEAVE_WAY != "reload":
            return
        if not bet.board_present():
            return                              # the lobby is already on screen
        log.info("A table is still on screen — %s before opening another.", why.lower())
        self.status = "Reloading to get back to the lobby"
        self.push()
        self.leave_table(why)

    def scroll_to(self, name: str) -> None:
        """Put the lobby where this open action lives. Only the difference is scrolled,
        so two tables at the same place cost nothing the second time.

        The mouse is parked over the lobby first — moved, not clicked — so the arrow
        keys go there instead of to the dashboard's browser window."""
        want = int(self.open_scroll.get(name, 0) or 0)
        if want == self.scroll_at:
            return
        move = want - self.scroll_at
        coords = bet.load_coords() or {}
        spot = coords.get(name) or coords.get("lobby_focus")
        if spot is None:
            log.warning("'%s' has a scroll of %d but no coordinate to hover over, and there "
                        "is no 'lobby_focus' either — the arrow keys would go to whatever "
                        "window has focus. Record one on the Interface tab (Name, then Record)",
                        name, want)
            return
        log.info("Scrolling the lobby %d × %s for '%s' (mouse parked at %d,%d).", abs(move),
                 "Down" if move > 0 else "Up", name, spot["x"], spot["y"])
        try:
            bet.scroll_list(move, (spot["x"], spot["y"]))
        except bet.BetError as e:
            log.warning("Couldn't scroll: %s", e)
            return
        self.scroll_at = want

    def table_wait_left(self, board: Board | None) -> float:
        """Seconds until this table's shoe should be over, so it is worth opening again."""
        ends_at = self.wait_hands or self.s.table_hands or 0
        hands_left = max(0, ends_at - total(board))
        return hands_left * self.hand_pace()[0] + self.extra_wait

    def pick_open_action(self) -> tuple[str, float]:
        """The open action to try next, and how long to wait first. Whichever table's
        shoe ends soonest wins; one never tried counts as free now. The table just
        looked at goes to the back while any other one is already free, so the bot
        doesn't keep reopening the same tab."""
        now = time.monotonic()
        ready = lambda n: self.table_ready.get(n, 0.0)
        order = sorted(self.open_patterns, key=lambda n: (ready(n), self.open_patterns.index(n)))
        if len(order) > 1 and order[0] == self._last_open and ready(order[1]) <= now:
            order = order[1:] + order[:1]
        return order[0], max(0.0, ready(order[0]) - now)

    def countdowns(self) -> list:
        """What the page shows while it is hunting for a table with room."""
        now = time.monotonic()
        return sorted(({"name": n, "in": max(0.0, ts - now),
                        "ts": time.time() + max(0.0, ts - now)}
                       for n, ts in self.table_ready.items()), key=lambda d: d["in"])

    def refresh_lobby(self, why: str) -> bool:
        """Click the reload action and give the lobby time to come back."""
        names = pattern_variants("reload")
        if not names:
            if not self._said_no_reload:
                self._said_no_reload = True
                log.warning("Nothing named 'reload' — the lobby is never refreshed. Record the "
                            "lobby's reload button as 'reload' on the Interface tab (Name, then Record).")
            return False
        name = random.choice(names)
        log.info("Refreshing the lobby (%s '%s') — %s.", action_kind(name), name, why)
        self.status = "Refreshing the lobby"
        self.push()
        try:
            run_action(name)
        except bet.BetError as e:
            log.error("'%s' failed: %s", name, e)
            return False
        self.wait(random.uniform(*tuning.LOBBY_WAIT), "Lobby reloads")
        return True

    def snapshot(self, label: str, why: str) -> None:
        """Save what's on the screen and show it on the dashboard."""
        try:
            path = bet.save_screenshot(label)
        except Exception as e:
            log.warning("Couldn't take a screenshot: %s", e)
            return
        self.shots = (self.shots + [{"file": path.name, "why": why,
                                     "when": time.strftime("%H:%M:%S")}])[-6:]
        log.info("Screenshot saved: %s (also shown on the dashboard)", path)
        self.push()

    def recover(self) -> bool:
        """The table stopped moving: close it and open the same one again, waiting a bit
        longer on each attempt. False = give up and stop the session."""
        self.recoveries += 1
        self.snapshot("stuck", f"attempt {self.recoveries}: no new hand for {tuning.STALL_AFTER:.0f} s")
        if self.recoveries > tuning.MAX_RECOVERIES:
            log.error("The table still isn't moving after %d attempts — stopping. The "
                      "screenshots on the dashboard show what was on screen.", tuning.MAX_RECOVERIES)
            self.status = "Stopped: the table stopped moving — see the screenshots"
            return False
        wait = tuning.RECOVER_WAIT * (1.8 ** (self.recoveries - 1))
        log.warning("No new hand for %.0f s (attempt %d of %d) — closing and reopening the "
                    "table, waiting %.0f s first.", tuning.STALL_AFTER, self.recoveries,
                    tuning.MAX_RECOVERIES, wait)
        self.status = f"Table stuck — retry {self.recoveries} of {tuning.MAX_RECOVERIES}"
        self.push()
        if self.current_bet:
            log.warning("A bet of %s on %s was placed for game %s — if the table took it, the "
                        "result is unknown; it won't be counted.", blue(f"{self.current_bet[1]:,.0f}"),
                        self.current_bet[0], self.bet_game)
            self.current_bet = None
        return self.next_table(target_reached=False, same_table=True, wait_seconds=wait)
