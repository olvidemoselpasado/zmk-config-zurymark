"""Logging in to the site, when the session has been lost.

Three things set up per site:

    login           a coordinate (or a pattern of that name) that puts the cursor in
                    the email field -- the login button, or the field itself
    success_login   a region, selected while logged in: something that is only on the
                    screen when you are (your balance, the account button). Its saved
                    picture is what "logged in" looks like
    the details     the email and password, saved on the Setup tab into the site's own
                    login.json -- readable only by you, and never in the log, the
                    settings, the dashboard's state or Copy report

Once per session, before the first table is opened from the lobby, the bot looks
at success_login -- and never again during play. Showing: on
it goes. Not showing: click 'login', type the email, Tab, the password, Enter, and
wait up to LOGIN_WAIT seconds for success_login, because the site is slow. Still not
there: reload the page and try again, up to LOGIN_TRIES times. Then the session stops
and says so, rather than clicking table tiles on a login page.

Not set up -- any of the three missing -- and this does nothing at all, so a site that
never logs you out is played exactly as before. (A region saved as 'succes_login' or
'login_success' is the same one.)

The Player state this is responsible for:

    login_tries, login_wait, login_enter, _said_no_login, login_checked
"""

from __future__ import annotations

import time
from baccarat import screen as bet
from baccarat.log import log
from baccarat.play.actions import reload_focus, run_action
from baccarat.play.stop import check_stop
from baccarat.play import tuning
from baccarat.util.clock import _hms

LOGIN_COORD = "login"


def success_region() -> str | None:
    """The name the region was saved under, if it was: success_login, or one of the
    older names it answers to (succes_login, login_success)."""
    return bet.selected_name("success_login")


def login_missing() -> list[str]:
    """What isn't set up yet, in words. Empty = ready."""
    out = []
    if LOGIN_COORD not in bet.load_coords() and LOGIN_COORD not in bet.pattern_names():
        out.append("a 'login' coordinate (Interface tab)")
    if success_region() is None:
        out.append("a 'success_login' region, selected while logged in (Interface tab)")
    d = bet.load_login()
    if not d.get("email") or not d.get("password"):
        out.append("the email and password (Setup tab, Login)")
    return out


def looks_logged_in() -> tuple[bool | None, float | None]:
    """(logged in?, difference). Two looks that must agree, so a page mid-redraw
    isn't taken for either answer. None = the region couldn't be read."""
    name = success_region()
    if name is None:
        return None, None
    seen = []
    for i in range(2):
        try:
            diff = bet.region_difference(name)
        except Exception:
            diff = None
        if diff is None:
            return None, None
        seen.append(diff)
        if i == 0:
            time.sleep(0.3)
    shows = [d <= tuning.LOGIN_MATCH for d in seen]
    if shows[0] != shows[1]:
        return None, max(seen)
    return shows[0], max(seen)


class LoggingIn:
    """Mixed into Player. See the module docstring."""

    def ensure_logged_in(self, why: str = "") -> bool:
        """True = logged in (or logging in isn't set up, so there is nothing to do).
        False = it couldn't log in after every try: stop."""
        missing = login_missing()
        if missing:
            if not self._said_no_login:
                self._said_no_login = True
                log.info("Logging in isn't set up for this site (missing %s), so the bot "
                         "doesn't check for it.", "; ".join(missing))
            return True
        ok, diff = looks_logged_in()
        if ok:
            log.debug("Logged in (success_login %.1f from its picture).", diff)
            return True
        log.warning("Not logged in%s — success_login %s. Logging in.",
                    f" ({why})" if why else "",
                    "can't be read" if diff is None else
                    f"is {diff:.1f} from its saved picture (counted as showing up to "
                    f"{tuning.LOGIN_MATCH:g})")
        self.snapshot("logged-out", "success_login wasn't showing")
        tries = max(1, int(self.login_tries))
        for attempt in range(1, tries + 1):
            if attempt > 1:
                if self.reload_for_login(attempt, tries):
                    return True                 # a slow login finished during the reload
            if self.try_login(attempt, tries):
                return True
        log.error("Couldn't log in after %d tr%s — stopping. The screenshots on the "
                  "dashboard show what was on screen.", tries, "y" if tries == 1 else "ies")
        self.status = f"Stopped: couldn't log in after {tries} tries"
        self.bet_reason = "The site never showed success_login after logging in."
        self.push()
        return False

    def try_login(self, attempt: int, tries: int) -> bool:
        d = bet.load_login()
        self.status = f"Logging in (try {attempt} of {tries})"
        self.push()
        log.info("Logging in, try %d of %d: '%s', then the email, Tab, the password%s.",
                 attempt, tries, LOGIN_COORD, ", Enter" if self.login_enter else "")
        run_action(LOGIN_COORD)
        self.login_pause(tuning.LOGIN_FORM_WAIT)
        ok = bet.type_private(d["email"], "typing the email")
        bet.press_key("Tab", None, "tab")
        time.sleep(0.15)
        ok = bet.type_private(d["password"], "typing the password") and ok
        if self.login_enter:
            time.sleep(0.2)
            bet.press_key("Return", None, "enter")
        if not ok:
            log.warning("Typing didn't work (see above) — is wtype installed and up to date?")
        started = time.monotonic()
        end = started + float(self.login_wait)
        last = None
        while time.monotonic() < end:
            end += self.login_pause(tuning.LOGIN_POLL)
            shows, last = looks_logged_in()
            if shows:
                log.info("Logged in after %s (try %d of %d; success_login %.1f from its "
                         "picture).", _hms(time.monotonic() - started), attempt, tries, last)
                self.status = "Logged in"
                self.push()
                return True
            left = end - time.monotonic()
            self.status = (f"Logging in (try {attempt} of {tries}) — waiting for the site, "
                           f"{max(0, left):.0f} s left")
            self.push()
        log.warning("No success_login %s after try %d of %d (last look: %s).",
                    _hms(float(self.login_wait)), attempt, tries,
                    "unreadable" if last is None else f"{last:.1f} from its picture")
        self.snapshot("login-failed", f"try {attempt} of {tries}: no success_login after "
                                      f"{_hms(float(self.login_wait))}")
        return False

    def reload_for_login(self, attempt: int, tries: int) -> bool:
        """Reload the page before another try. True = it turned out to be logged in."""
        over = reload_focus()
        if over is None:
            c = bet.load_coords().get(LOGIN_COORD)
            over = (c["x"], c["y"]) if c else None
        log.info("Reloading the page before try %d of %d.", attempt, tries)
        self.status = f"Reloading before logging in again (try {attempt} of {tries})"
        self.push()
        bet.press_key(bet.RELOAD_KEY, over, "reload")
        self.login_pause(tuning.LOGIN_RELOAD_WAIT)
        shows, diff = looks_logged_in()
        if shows:
            log.info("Logged in after all — the last try just took longer than %s.",
                     _hms(float(self.login_wait)))
            return True
        return False

    def login_pause(self, seconds: float) -> float:
        """Sleep, but Stop still works and a Pause doesn't eat the wait. → time paused."""
        held, end = 0.0, time.monotonic() + seconds
        while time.monotonic() < end:
            p = check_stop()
            held += p
            end += p
            time.sleep(min(0.2, max(0.0, end - time.monotonic())))
        return held
