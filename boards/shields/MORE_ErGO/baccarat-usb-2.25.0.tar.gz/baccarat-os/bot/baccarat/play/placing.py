"""Getting the bet on the table inside the betting window.

The window is a few seconds long and the clicks take a measurable amount of
time, so the question is never just what to bet but whether it can still be
placed. A bet that cannot be placed in full is not placed at all -- half a stake
on the table is worse than none.

Where the window starts counting is a setting, because tables differ: from the
moment the game number changed, or from the moment the chips actually appear.
The second asks the screen instead of assuming, which is the honest answer on a
table that does not open its betting at a fixed interval.

The Player state this is responsible for:

    placer, current_bet, bet_game, bet_start_on, bet_start, bet_end,
    click_speed, late_skips
"""

from __future__ import annotations

import math
import random
import time
from baccarat import screen as bet
from baccarat.log import log
from baccarat.core import bets as betting
from baccarat.play.pace import poll_step
from baccarat.play.reading import (
    total)
from baccarat.play.stop import check_stop, stop_now, Stopped
from baccarat.play import tuning
from baccarat.util.show import blue, green, money


def checks_chips_first(plan: list[tuple]) -> bool:
    """Does this bet press the repeat button after putting chips down? Then the chips
    are confirmed on the balance before the first press, and the window pays for it."""
    seen_spot = False
    for a in plan:
        if a[0] == "spot":
            seen_spot = True
        elif a[0] == "redo" and seen_spot:
            return True
    return False


class Placing:
    """Mixed into Player. See the module docstring."""

    def stopped_mid_bet(self, game: int, side: str, amount: float) -> None:
        """Stop was pressed in the middle of the clicks: the rest weren't made. Say
        exactly how far it got, because some of the bet may be on the table."""
        cut = self.placer.interrupted or {}
        done, of = cut.get("clicks", 0), cut.get("of", 0)
        if done == 0:
            log.info("Stopped before the first click of %s on %s (game %d) — nothing was put "
                     "on the table.", money(amount), side, game)
        else:
            log.warning("STOPPED in the middle of the bet — %d of the %d clicks for %s on %s "
                        "(game %d) were made, so part of it may be on the table. Its result "
                        "isn't counted here: check the table's own balance.", done, of,
                        money(amount), side, game)
        self.current_bet = None

    def decide(self, game: int) -> bool:
        """Pick the bet for `game` and put it on the table. False = stop."""
        if self.stop_after_result:
            # Stop was pressed while a bet was down; its result is in: no next bet at all
            self.current_bet = None
            raise Stopped()
        hand = total(self.board) + 1 if self.board else None    # this game's hand on the table
        self.current_bet = self.s.next_bet(hand=hand)
        self.bet_game = game
        # the money ran out: the table stays open and the run is followed for free,
        # so we learn how many more lives it would have taken (nothing is staked)
        if self.s.watching:
            s = self.s
            if not self._said_bust:             # it has just run out
                self._said_bust = True
                log.warning("The money has run out: the next bet (%s) is more than the balance "
                            "(%s), after %d %s.", blue(money(s.bust_stake)),
                            green(money(s.bust_balance)), s.lives_used,
                            "life" if s.lives_used == 1 else "lives")
                log.info("Not closing yet — watching this same table without betting, to see how "
                         "many more lives the run would have needed. The table is closed as soon "
                         "as that's clear.")
            v = s.virtual_bet
            if v:
                log.info("Game %d → would have bet %s on %s (nothing staked — life %d past the "
                         "money)", game, blue(f"{v[1]:,.0f}"), v[0].upper(), s.watch_bets + 1)
            else:
                log.info("Game %d → watching (nothing to bet on this hand)", game)
            self.bet_reason = (f"The money ran out after {s.lives_used} lives. Following the same "
                               f"run for free: {s.watch_bets} more bets so far, nothing staked.")
            self.status = f"Watching game {game} for free ({s.watch_bets} lives past the money)"
            self.push()
            return True
        if self.s.watch_over:
            self.report_watch()                 # in case the watch ended somewhere quiet
            log.info("Closing the table and stopping — %s", self.s.watch_result)
            return False
        if self.s.finished and self.s.halt_for:
            log.info("The run is won and the next bet is the base bet: stopping here — %s.",
                     self.s.halt_for)
            self.status = self.halt_status()
            self.bet_reason = ("Stopped at the base bet so the update can install; the session "
                               "starts again by itself with the same set-up and balance."
                               if self.s.halt_resume else
                               "Stopped at the base bet after the run, as asked.")
            return False
        if self.s.finished:
            log.info("Table end: %s — ending the session.", self.s.skip_reason)
            self.status, self.bet_reason = "Ended: too few hands left on the table", self.s.skip_reason
            return False
        if self.s.table_done and not self.current_bet:
            # waiting on an open table risks being logged out for inactivity, so whenever
            # a table can be opened again we close and reopen instead of sitting there
            if self.open_patterns and self.s.at_cutoff != "stop":
                self.want_switch = True                 # the loop closes and opens the next table
                return True
            if self._cutoff_table != (self.table.name if self.table else None):
                self._cutoff_table = self.table.name if self.table else None
                log.info("Table end: %s — no new runs on this table; waiting for the next one.",
                         self.s.skip_reason)
            self.bet_reason = f"No new runs near the table's end ({self.s.skip_reason}). Waiting for the next table."
            self.status = f"Watching game {game} (waiting for the next table)"
            self.push()
            return True
        if self.s.reached_ceiling and self.cycle >= self.cycles:
            if self.cycles > 1:
                log.info("That was cycle %d of %d — the last one.", self.cycle, self.cycles)
            elif not self.open_patterns:
                log.info("Target reached. (Set 'Times to reach the ceiling' above 1, with an "
                         "open_table action, to carry on with another table.)")
            log.info("Target reached: balance %s ≥ %s — stopping.",
                     green(money(self.s.balance)), green(money(self.s.ceiling)))
            self.status, self.bet_reason = "Ceiling reached, betting stopped", "Ceiling reached."
            return False
        if self.s.reached_ceiling:
            if not self.open_patterns:      # can't open another table: stop and say so
                log.warning("Target reached on cycle %d of %d, but no open_table action is set — "
                            "stopping.", self.cycle, self.cycles)
                return False
            return False                    # the loop opens the next table
        if self.s.busted:
            log.warning("Stopping: the next doubled bet (%s) is more than the balance (%s).",
                        blue(money(self.s.bust_stake or self.s.staking.amount)),
                        green(money(self.s.bust_balance)))
            self.status = "Stopped: the next doubled bet is more than the balance"
            self.bet_reason = "Balance can't cover the next doubled bet."
            return False
        if self.current_bet and self.sitting_out(game):
            side, amount = self.current_bet
            log.info("Game %d → no bet (%s on %s): taking a break after refused bets.",
                     game, blue(f"{amount:,.0f}"), side.upper())
            self.current_bet = None
            self.push()
            return True
        if self.current_bet:
            side, amount = self.current_bet
            self.bet_reason = ""                     # a reason not to bet is no longer one
            log.info("Game %d → bet %s on %s   %s", game, blue(f"{amount:,.0f}"),
                     side.upper(), self.why_this_bet())
            self.check_alarm(game, side, amount)    # noise first, so it starts before the clicks
            self.status = f"Bet {amount:,.0f} on {side} placed for game {game}"
            self.push()
            if not self.wait_for_chips(game):
                self.current_bet = None                 # bets never opened: skip this hand
                self.push()
                return True
            self.load.phase = "the betting window"
            if not self.wait_for_bet_moment(game, side, amount, hand):
                self.current_bet = None                 # too late for this game: skip it
                self.push()
                return True
            if True:
                t0 = time.monotonic()
                opened = self.bets_open_at or self.game_seen or t0
                plan = self.placer.plan(side, amount, self.s.staking.base, hand,
                                        self.table.name if self.table else None)
                # how long the whole burst has: the pointer takes its own time while
                # that is comfortable and only hurries when the window is running out
                self.load.phase = "the clicks"
                bet.start_click_run(self.bet_end - tuning.BET_MARGIN - (t0 - opened), len(plan))
                try:
                    how = self.placer.place(side, amount, self.s.staking.base, hand,
                                            self.table.name if self.table else None,
                                            confirm=self.chip_landed if self.hard_score
                                            else None, check=stop_now)
                except Stopped:
                    self.stopped_mid_bet(game, side, amount)
                    raise
                finally:
                    bet.end_click_run()
                done = time.monotonic() - opened
                log.info("   clicks: %s  — done %.1f s into the game", how, done)
                self.learn_click_cost(len(plan), done - (t0 - opened))
                if self.placer.cut_short is not None:
                    self.bet_cut_short(side, amount, self.placer.cut_short)
                    self.push()
                    return True
                self.stake_down = float(amount)     # our money is on the table now
                self.push()                         # the balance shows the stake gone at once
                if done > self.bet_end + 0.5:
                    log.warning("   The bet finished %.1f s into the game (window ends at %.0f s) — "
                                "it may not have been accepted. Raise 'Click speed' if this "
                                "repeats.", done, self.bet_end)
                self.start_bet_watch(side, amount, opened)   # did the table keep it?
        else:
            known = len([w for w in self.s.road if w != "tie"])
            need = self.s.strategy.n
            if known < need:
                try:
                    has_road = any(r.get("name") == "road" for r in bet.region_list())
                except Exception:
                    has_road = False
                self.bet_reason = (f"Waiting for {need} results on this table (have {known})"
                                   + (" — they come with the next hands." if has_road else
                                      ". The counters only give totals, not the order — a "
                                      "'road' region would load the whole table and it could "
                                      "bet now."))
                log.info("Game %d → skip (%s needs %d results in order, has %d)%s",
                         game, self.s.strategy.name, need, known,
                         "" if self._said_no_road else
                         ". The P/B/T counters give totals, not the order, so it can't know "
                         "what came before you joined. Select a 'road' region on the Interface "
                         "tab (a box around the grid of coloured circles) and the whole table "
                         "is loaded the moment you join.")
                self._said_no_road = True
            else:
                self.bet_reason = f"The last {need} results don't match the strategy's pattern."
                log.info("Game %d → skip", game)
            self.status = f"Watching game {game}"
        self.push()
        return True

    def why_this_bet(self) -> str:
        """Who chose this bet and on what. Without it, 'why did it bet player when banker
        is ahead?' can't be answered from the log: a rule in charge and the strategy
        taking over again look exactly the same on screen."""
        s = self.s
        by = s.decided_by
        rule = next((r for r in s.rules if r.name == by), None)
        if rule is None:
            return f"(chosen by the strategy, {by})"
        st = rule.stats() or {}
        if st:
            where = (f"in all {st['seen']} so far" if st.get("seen", 0) < (st.get("window") or 0)
                     else f"in the last {st['window']}" if st.get("window")
                     else f"in {st['seen']} on this table")
            lead = ("level, so staying with the last winner" if st["player"] == st["banker"] else
                    f"{'player' if st['player'] > st['banker'] else 'banker'} ahead by "
                    f"{abs(st['player'] - st['banker'])}")
            return (f"(rule {rule.name}: {st['player']}P {st['banker']}B {where} — {lead})")
        return f"(rule {rule.name})"

    def wait_for_chips(self, game: int) -> bool:
        """Hold until the chips are on screen, i.e. until the table is really taking bets.
        False = they never appeared, so this hand is skipped rather than bet into a
        closed window. The window is then counted from the moment they showed up."""
        self.bets_open_at = None
        if self.bet_start_on != "chips":
            return True
        if not bet.trigger_ready(tuning.CHIP_REGION):
            if not self._said_no_trigger:
                self._said_no_trigger = True
                log.warning("'Betting starts when the chips appear' is on, but the "
                            "'%s' region isn't taught yet (it needs one example with the "
                            "chips showing and one without). Falling back to the clock.",
                            tuning.CHIP_REGION)
            return True
        started = time.monotonic()
        end = started + tuning.CHIP_TIMEOUT
        said, certain = False, False
        while time.monotonic() < end:
            end += check_stop()
            now = bet.bets_open(tuning.CHIP_REGION)
            certain = certain or now is not None
            if now:
                self.bets_open_at = time.monotonic()
                waited = self.bets_open_at - (self.game_seen or self.bets_open_at)
                if waited > 0:
                    self.chip_times = (self.chip_times + [waited])[-8:]
                log.info("   chips are up %.1f s after the result — betting window opens now.",
                         max(0.0, waited))
                return True
            if not said and time.monotonic() > end - tuning.CHIP_TIMEOUT + 3.0:
                said = True
                self.status = f"Waiting for the chips to appear (game {game})"
                self.push()
            time.sleep(poll_step(time.monotonic() - started, self.chip_floor(),
                                 self.quiet_poll, fast=tuning.CHIP_POLL))
        self.chip_waits += 1
        why = ("" if certain else
               " It never got a clear answer either way, which means the two looks it was "
               "shown are too close together: press 'Chips are up now' again on a hand where "
               "they really are showing, and 'Chips are gone now' in between.")
        log.warning("Game %d: the chips never appeared within %.0f s — skipping this hand. "
                    "That is %d missed.%s", game, tuning.CHIP_TIMEOUT, self.chip_waits, why)
        self.status = f"Skipped game {game}: the chips never appeared"
        self.bet_reason = "The table never showed the chips, so bets were never open."
        self.push()
        return False

    def learn_click_cost(self, clicks: int, seconds: float) -> None:
        """Keep what one click of a burst really takes (bursts of 3 and more say it
        best): the next bet's time plan uses it when it is more than the estimate."""
        if clicks < 3 or seconds <= 0:
            return
        per = seconds / clicks
        before = self.click_cost
        self.click_cost = per if before is None else (0.7 * before + 0.3 * per
                                                      if per < before else 0.4 * before + 0.6 * per)
        if before is None or abs(self.click_cost - before) > 0.05:
            log.info("   clicks take %.2f s each here (%d in %.1f s) — bets are planned on it.",
                     self.click_cost, clicks, seconds)

    def wait_for_bet_moment(self, game: int, side: str, amount: float, hand: int) -> bool:
        """Live: wait until a random moment inside BET_WINDOW (counted from when the
        game number changed), leaving time for the clicks. False = too late, skip."""
        start = self.bets_open_at or self.game_seen or time.monotonic()
        plan = self.placer.plan(side, amount, self.s.staking.base, hand,
                                self.table.name if self.table else None)
        clicks = len(plan)
        # one click is the press plus the travel to it; the pointer moves like a hand,
        # which takes far longer than the press does. A click that lands on the button
        # the one before it used costs more again: it has to be held back past the
        # double-click window, or the page takes one press and drops the other.
        per_click = self.click_speed[1] + bet.MOVE_TYPICAL
        held = betting.repeat_clicks(plan, bet.load_coords(), side, bet.SAME_SPOT_PX)
        need = clicks * per_click + held * bet.same_spot_wait()
        if self.click_cost:
            # what clicks really take on this computer (the system's own delays, a
            # busy browser): a plan on paper alone let 8-click bets run past the window
            need = max(need, clicks * self.click_cost * 1.15)
        if self.hard_score and checks_chips_first(plan):
            need += tuning.CHIP_CONFIRM_WAIT        # the chips are seen before the repeats
        latest = self.bet_end - tuning.BET_MARGIN - need      # last moment to start clicking
        now = time.monotonic() - start
        if now > latest:
            self.late_skips += 1
            room = latest
            log.warning("Game %d: too late to bet (%.1f s in, %d clicks need %.1f s and must "
                        "start by %.1f s) — skipping. That is %d missed this session.%s",
                        game, now, clicks, need, latest, self.late_skips,
                        (f" This bet can never fit: {clicks} clicks need "
                         f"{need:.1f} s of a {self.bet_end:.0f} s window. Raise "
                         f"'Betting window' to {math.ceil(tuning.BET_MARGIN + need)} s, "
                         f"lower the doubling limit, or record bigger chips.") if room < 0 else
                        (" The chips came up too late this hand; it should fit next time."
                         if self.bet_start_on == "chips" else
                         " The window is counted from the moment the result lands, so "
                         "whatever happened between the result and here came out of it."))
            self.status = f"Skipped game {game}: too late to place the bet"
            self.bet_reason = (f"Too little time left: {clicks} clicks need {need:.1f} s "
                               f"and the bot was only ready {now:.1f} s into the game.")
            self.push()
            return False
        floor = min(self.bet_start, latest)
        at = random.uniform(max(floor, now), max(floor, latest))
        if clicks >= 5 or self.s.staking.step >= 5:
            # a big bet (many clicks, or life 6 and on): no idle moment first --
            # it goes on as early as it may, with all the room left for the clicks
            at = max(floor, now)
        self.status = f"Placing {amount:,.0f} on {side} at {at:.1f} s into game {game}"
        self.push()
        looked = 0.0
        while time.monotonic() - start < at:
            if check_stop():                      # paused mid-window: this game is gone
                self.late_skips += 1
                log.warning("Game %d: paused while the betting window was open — skipping it.",
                            game)
                self.status = f"Skipped game {game}: paused during the betting window"
                self.bet_reason = "The pause covered this game's betting window."
                return False
            # the last result's score is confirmed here, in the gap before the bet goes
            # on, rather than ahead of it where it would come out of this very window
            if self.score_check and time.monotonic() - looked >= tuning.SCORE_RECHECK:
                looked = time.monotonic()
                self.check_score_now()
            time.sleep(min(0.1, max(0.0, at - (time.monotonic() - start))))
        self.look_at_score()                      # one more look before our bet moves it
        return True
