"""Making sure the bet really went on, and backing off when the site is refusing them.

This table takes the stake off the balance the moment the bet is placed. When the
site is slow it can refuse the bet a moment later -- the "not confirmed" notice --
and give the stake back. Nothing in the clicks shows that: the bot pressed the right
buttons and the money briefly moved. Left alone, the hand would then be settled as
if our stake had been on it, and the doubling would carry on from a result that was
never ours.

So the score is watched from the moment the clicks are done until a little after the
betting window closes, which is when a refusal lands. `before` is what the screen read
just before the clicks when there is such a reading, because that is the figure the
table takes the stake from -- even when our books disagree with it:

    before - stake    the stake is on
    before            the stake is back (refused), or never left (not on). Never-left
                      is only judged after the window has closed, from readings taken
                      after the close, and only on a table known to take the stake when
                      a bet is placed -- Setup says so, or it has been seen doing it
    anything less     some of ours is down but not the stake. The score can't say on which
                      side -- a missed chip click followed by the repeat button puts last
                      round's bet down, often on the other side -- so no side is guessed:
                      the hand counts as no bet, and the balance follows the table

Each look is one read of the score, taken from the time spent waiting for the result
anyway: never in front of the clicks, and only on hands with a bet on. The watch ends
as soon as the result lands, because from then on the score is settling and a tie
handing back a stake looks exactly like a refusal.

A refused bet is called off: no win, no loss, no doubling, and the repeat button is
not trusted for the next bet. One refusal is a slow moment. REJECT_LIMIT of them
within REJECT_WINDOW means the site is still slow, so the bot stays away for a while:
it closes the table, waits and reopens it when it can, which also reloads the road --
or, with no open_table action to come back with, keeps watching without betting so
the road stays complete.

The Player state this is responsible for:

    bet_watch, rejections, rejected_bets, cooloffs, cooloff_due, cooloff_ended,
    sit_out_until, bet_notice, bet_notice_id, _said_no_confirm, _said_no_chip_check,
    _chip_check
"""

from __future__ import annotations

import time
from baccarat import screen as bet
from baccarat.log import log
from baccarat.play.reading import Board, total
from baccarat.play.stop import STOP
from baccarat.play import tuning
from baccarat.util.clock import _hms
from baccarat.util.show import blue, money


class Confirming:
    """Mixed into Player. See the module docstring."""

    def say_how_bets_are_confirmed(self) -> None:
        if not self.hard_score:
            log.warning("Bets are NOT confirmed: 'Trust the screen score' is off, so a bet the "
                        "site refuses will be settled as if it went on.")
        elif self.deducts:
            log.info("Bets are confirmed from the score: the site takes the stake off the "
                     "balance the moment a bet is placed (Setup), so every bet is checked "
                     "for that after its clicks.")
        else:
            log.info("Bets are confirmed from the score once this table has been seen taking "
                     "a stake when a bet is placed. (Tick 'The site takes the stake off the "
                     "balance…' in Setup if it does, and every bet is checked from the first.)")
        if self.hard_score:
            try:
                miss = bet.missing_digits("score")
            except Exception:
                miss = ""
            if miss:
                log.warning("The score's digits %s have never been taught. Until they are, a "
                            "reading that isn't near-perfect counts as unreadable (left as "
                            "placed) rather than risk a wrong number — and the bot learns them "
                            "itself from the screen as the balance shows them. Quicker: "
                            "Interface → score, or Budget → From the screen when the balance "
                            "has them.", ", ".join(miss))

    # -- watching the stake -------------------------------------------------------
    def start_bet_watch(self, side: str, amount: float, opened: float) -> None:
        """The clicks are done: start watching the score for the stake.
        `opened` is when the betting window started counting (monotonic)."""
        self.bet_watch = None
        if not self.hard_score or self.score is None:
            if not self._said_no_confirm:
                self._said_no_confirm = True
                log.warning("   Not confirming this bet: %s.",
                            "'Trust the screen score' is off" if not self.hard_score
                            else "the score can't be read")
            return
        # The balance the stake comes off. Best is what the screen itself read since this
        # hand began, because that is the figure the table will take the stake from --
        # even when it disagrees with our books, which is exactly when it matters (a
        # previous bet that never went on). Failing that, our settled figure.
        read = self._score_read
        if read and read[1] >= (self.game_seen or 0) - 0.5:
            before, src = read[0], "the screen just before the clicks"
        elif self.score_check:
            before, src = self.score_check["expected"], "the settled balance (expected)"
        else:
            before, src = self.score, "the settled balance"
        now = time.monotonic()
        b = self.board
        self.bet_watch = {
            "side": side, "stake": float(amount), "before": round(float(before), 2),
            "game": b["game"] if b else None, "total": total(b) if b else None,
            "opened": opened, "placed": now, "closes": opened + self.bet_end,
            "until": max(opened + self.bet_end, now) + tuning.STAKE_WATCH,
            "on": False, "on_at": None, "off": 0, "off_after": 0,
            "odd": None, "odd_n": 0, "reported": False,
            "looked": 0.0, "seen": None, "trace": [],
        }
        self.load.phase = "the check that the bet went on"
        log.info("   confirming: %s should take the score from %s (%s) to %s; a refusal "
                 "is looked for until %.1f s into the game",
                 money(amount), money(before), src, money(before - amount),
                 self.bet_watch["until"] - opened)

    def watch_stake(self, board: Board | None) -> None:
        """One look at the score, if one is due. Called after every read of the bar,
        with what the bar said, so it knows whether the result has landed yet."""
        w = self.bet_watch
        if not w:
            return
        now = time.monotonic()
        landed = board is not None and w["game"] is not None and (
            board["game"] != w["game"] or total(board) != w["total"])
        if landed or now > w["until"]:
            self.end_bet_watch(landed=landed)
            return
        if board is None or now - w["looked"] < tuning.STAKE_LOOK:
            return                              # not due, or can't tell what the table is doing
        w["looked"] = now
        try:
            v = bet.read_number("score")
        except Exception:
            v = None
        w["trace"].append((now - w["opened"], v))
        if v is None:
            return
        w["seen"] = v
        before, stake = w["before"], w["stake"]
        closed = now >= w["closes"]
        if abs(v - (before - stake)) < 0.01:            # the stake is down
            w["off"] = w["off_after"] = w["odd_n"] = 0
            if not w["on"]:
                w["on"], w["on_at"] = True, now
                if self.deducts is None:
                    log.info("   This table takes the stake out of your balance the moment "
                             "the bet is placed — every bet is confirmed by seeing that.")
                self.deducts = True
                self.settle_open_check(before)  # and the last hand's money, against the screen
        elif abs(v - before) < 0.01:                    # the stake isn't down
            w["off"] += 1
            w["odd_n"] = 0
            if closed:
                w["off_after"] += 1
            if w["on"] and w["off"] >= tuning.STAKE_CONFIRM:
                # taken and handed back: the site refused it
                self.bet_refused(v, now - w["on_at"])
            elif not w["on"] and self.deducts and w["off_after"] >= tuning.STAKE_CONFIRM:
                # the window has closed and the balance still has our stake in it,
                # look after look: it never went on. Not judged before the close, so a
                # stake that is slow to show isn't mistaken for one that isn't there.
                self.bet_refused(v, None)
        else:
            w["off"] = w["off_after"] = 0
            taken = round(before - v, 2)
            if closed and taken > 0 and not w["reported"]:
                # some of ours is down, but not the stake: half a bet, or a press counted
                # twice. Two readings alike after the close, so a number mid-animation
                # isn't taken for one.
                w["odd_n"] = w["odd_n"] + 1 if w["odd"] == v else 1
                w["odd"] = v
                if w["odd_n"] >= tuning.STAKE_CONFIRM:
                    self.wrong_size(taken)
            else:
                w["odd_n"] = 0                  # mid-animation, or a win already paid

    def end_bet_watch(self, landed: bool = True) -> None:
        """The result has landed (or is landing: called from result_after), or the watch
        has run its course. Says what the score did, in one line."""
        w, self.bet_watch = self.bet_watch, None
        if self.load.phase == "the check that the bet went on":
            self.load.phase = "the wait for the result"
        if not w:
            return
        if not w["on"] and not w["reported"] and self.deducts \
                and w["off_after"] >= tuning.STAKE_CONFIRM:
            self.bet_watch = w                  # (normally caught as it happens)
            self.bet_refused(w["seen"], None, screenshot=not landed)
            return
        trace = fmt_trace(w["trace"])
        if w["on"]:
            log.info("   confirmed: the %s went on (%.1f s into the game). Score: %s",
                     money(w["stake"]), w["on_at"] - w["opened"], trace)
        elif w["reported"]:
            log.info("   score after the clicks: %s", trace)
        elif w["seen"] is None:
            log.warning("   NOT confirmed: the score couldn't be read after the clicks (%s). "
                        "Left as placed.", trace or "no looks")
        elif not self.deducts:
            log.info("   not confirmed: this table hasn't been seen taking a stake yet, so a "
                     "score of %s (the balance before the bet) can't be told from a bet "
                     "that is on. Left as placed. Score: %s", money(w["before"]), trace)
        else:
            log.warning("   NOT confirmed: the score read %s — neither %s (on) nor %s (not "
                        "on). Left as placed. Score: %s", money(w["seen"]),
                        money(w["before"] - w["stake"]), money(w["before"]), trace)

    def bet_refused(self, saw: float, after: float | None, screenshot: bool = True) -> None:
        """The stake is not on the table: call the hand off and count it.
        `after` = seconds between seeing the stake taken and seeing it back; None when
        it never left the balance at all. No screenshot once the result is in: it would
        show the next hand, and would come out of that hand's betting window."""
        w, self.bet_watch = self.bet_watch, None
        side, amount = self.current_bet or ((w or {}).get("side", "?"), (w or {}).get("stake", 0))
        self.current_bet = None                 # never on: the hand is recorded as no bet
        self.stake_down = 0.0
        self.settle_open_check(saw)             # nothing of ours is down: `saw` is settled
        self.forget_last_bet()
        self.rejected_bets += 1
        how = (f"the table took it and gave it back {after:.1f} s later — the site refused "
               f"the bet" if after is not None else
               "it never came off the balance — the bet didn't go on")
        trace = fmt_trace((w or {}).get("trace", []))
        log.warning("BET NOT ACCEPTED — game %s: the %s on %s is not on the table: %s. This "
                    "hand counts as no bet: nothing won or lost, and the stake doesn't move. "
                    "Score: %s", self.bet_game, blue(f"{amount:,.0f}"), side.upper(), how, trace)
        self.bet_reason = (f"The {amount:,.0f} on {side} wasn't accepted "
                           f"({'refused by the site' if after is not None else 'never taken'}). "
                           f"Counted as no bet.")
        self.status = f"Bet on game {self.bet_game} not accepted — counted as no bet"
        self.raise_bet_notice("refused" if after is not None else "never", side, amount,
                              0.0, saw, trace)
        if screenshot:
            self.snapshot("bet-refused", f"the {amount:,.0f} on {side} wasn't accepted")
        self.note_refusal()
        self.push()

    def wrong_size(self, taken: float) -> None:
        """Some of ours is on the table, but not the stake. The score says how much went
        down and never where, and the two ways this happens put it on the OTHER side: a
        missed chip click followed by the repeat button repeats last round's bet. So no
        side is guessed. The hand counts as no bet for the strategy and the doubling,
        and once it is over the balance is set to whatever the table paid."""
        w = self.bet_watch
        w["reported"] = True
        side, amount = self.current_bet or (w["side"], w["stake"])
        self.deducts = True
        self.settle_open_check(w["before"])     # the last hand first, against the screen
        self.current_bet = None
        self.stake_down = taken
        self.stray = {"taken": taken, "planned": amount, "side": side, "game": self.bet_game}
        self.forget_last_bet()
        self.rejected_bets += 1
        trace = fmt_trace(w["trace"])
        log.warning("BET NOT PLACED AS MEANT — game %s: %s of ours went on the table, not the "
                    "%s on %s that was clicked (the score went from %s to %s). The score "
                    "can't say which side it is on, and it may well be the other one, so "
                    "none is guessed: this hand counts as no bet for the strategy and the "
                    "doubling, and the balance is set to what the table pays. Score: %s",
                    self.bet_game, blue(f"{taken:,.0f}"), blue(f"{amount:,.0f}"), side.upper(),
                    money(w["before"]), money(w["before"] - taken), trace)
        self.bet_reason = (f"{taken:,.0f} of ours is on the table instead of {amount:,.0f} on "
                           f"{side}, side unknown. Counted as no bet; the balance follows the "
                           f"table.")
        self.raise_bet_notice("partial" if taken < amount else "extra", side, amount,
                              taken, w["before"] - taken, trace)
        self.snapshot("bet-wrong-size", self.bet_reason)
        self.note_refusal()
        self.push()

    def chip_landed(self, staked: float) -> bool:
        """Asked by the placer after the chips and before the repeat button: has the
        balance dropped by `staked`? Measured from the reading taken just before the
        clicks. With no such reading there is nothing to measure from, and the bet goes
        on as it always did -- said once, so it isn't a surprise."""
        read = self._score_read
        if not self.hard_score or read is None or read[1] < (self.game_seen or 0) - 0.5:
            if not self._said_no_chip_check:
                self._said_no_chip_check = True
                log.warning("   Can't check the chips before the repeat button: no score "
                            "reading from just before the clicks.")
            return True
        before, want = read[0], read[0] - staked
        t0 = time.monotonic()
        seen = []
        while time.monotonic() - t0 < tuning.CHIP_CONFIRM_WAIT:
            try:
                v = bet.read_number("score")
            except Exception:
                v = None
            seen.append((time.monotonic() - t0, v))
            if v is not None and abs(v - want) < 0.01:
                return True
            time.sleep(tuning.CHIP_CONFIRM_POLL)
        self._chip_check = {"before": before, "staked": staked, "trace": seen}
        return False

    def bet_cut_short(self, side: str, amount: float, staked: float) -> None:
        """The chips never showed on the balance, so the repeat button wasn't pressed.
        Most likely nothing of ours is on the table; if the chip landed late, `staked`
        is, on `side`. Either way it isn't the bet: no bet for the strategy and the
        doubling, and the balance follows the table."""
        c = self._chip_check or {}
        trace = ", ".join(f"{'unreadable' if v is None else money(v)} ({t:.2f} s)"
                          for t, v in c.get("trace", [])[-4:])
        self.current_bet = None
        self.stake_down = 0.0
        self.stray = {"taken": None, "planned": amount, "side": side, "game": self.bet_game}
        self.forget_last_bet()
        self.rejected_bets += 1
        log.warning("BET STOPPED — game %s: the %s chip on %s didn't show on the balance "
                    "within %.1f s (from %s; looks: %s), so the repeat button was NOT "
                    "pressed — on an empty table it repeats last round's bet. If the chip "
                    "landed late, %s of ours is on %s. Either way this hand counts as no bet "
                    "for the strategy and the doubling, and the balance follows the table.",
                    self.bet_game, blue(f"{staked:,.0f}"), side.upper(),
                    tuning.CHIP_CONFIRM_WAIT, money(c.get("before", 0)), trace or "none",
                    money(staked), side)
        self.bet_reason = (f"The chip for the {amount:,.0f} on {side} didn't show, so the "
                           f"repeats weren't pressed. Counted as no bet.")
        self.status = f"Bet on game {self.bet_game} stopped before the repeat button"
        self.raise_bet_notice("stopped", side, amount, staked, c.get("before", 0.0), trace)
        self.snapshot("bet-stopped", self.bet_reason)
        self.note_refusal()
        self.push()

    def forget_last_bet(self) -> None:
        """After a bet that didn't go on as clicked, nothing the placer remembers about
        the table can be trusted: not what the repeat button would repeat, and not
        which chip is selected -- the press that selected it may be the one that missed."""
        self.placer.last = None
        self.placer.chip = None

    # -- the notice on the dashboard ----------------------------------------------
    def raise_bet_notice(self, kind: str, side: str, amount: float, taken: float,
                         saw: float, trace: str) -> None:
        self.bet_notice_id += 1
        self.bet_notice = {
            "id": self.bet_notice_id, "kind": kind, "game": self.bet_game, "side": side,
            "amount": amount, "taken": taken, "saw": saw, "trace": trace,
            "at": time.strftime("%H:%M:%S"), "count": self.rejected_bets,
            "recent": len([r for r in self.rejections
                           if time.monotonic() - r <= tuning.REJECT_WINDOW]) + 1,
            "limit": tuning.REJECT_LIMIT,
        }

    def bet_notice_seen(self, body: dict | None = None) -> dict:
        """The notice's buttons: OK, or stop the session."""
        if str((body or {}).get("do") or "") == "stop":
            log.warning("Stopped from the dashboard after a bet wasn't accepted.")
            self.status = "Stopped: you chose to stop after a bet wasn't accepted"
            STOP.set()
        self.bet_notice = None
        self.push()
        return {"ok": True}

    # -- too many, too close together ---------------------------------------------
    def note_refusal(self) -> None:
        now = time.monotonic()
        if self.cooloffs and self.cooloff_ended is not None \
                and now - self.cooloff_ended > tuning.REJECT_WINDOW:
            self.cooloffs = 0                   # it was fine for a good while after the last one
        self.rejections = [t for t in self.rejections
                           if now - t <= tuning.REJECT_WINDOW] + [now]
        n = len(self.rejections)
        if n >= tuning.REJECT_LIMIT:
            self.cooloff_due = True
            log.warning("That is %d bets not accepted in %s — the site is slow. Stopping "
                        "betting for a while once this hand is over.", n,
                        _hms(now - self.rejections[0]))
        else:
            log.info("   %d not accepted in the last %s; %d would mean a break.", n,
                     _hms(tuning.REJECT_WINDOW), tuning.REJECT_LIMIT)

    def cool_off(self) -> bool:
        """Stay away from betting for a while. False = stop the session."""
        self.cooloff_due = False
        self.rejections = []
        self.cooloffs += 1
        if self.cooloffs > tuning.REJECT_MAX_COOLOFFS:
            log.error("Bets are still being refused after %d breaks — stopping.",
                      tuning.REJECT_MAX_COOLOFFS)
            self.status = "Stopped: the site kept refusing bets"
            self.bet_reason = "Bets kept being refused after every break."
            return False
        wait = tuning.REJECT_COOLOFF * tuning.REJECT_GROWTH ** (self.cooloffs - 1)
        self.bet_reason = (f"The site refused {tuning.REJECT_LIMIT} bets close together. "
                           f"Break {self.cooloffs} of {tuning.REJECT_MAX_COOLOFFS}: "
                           f"{_hms(wait)}.")
        if self.open_patterns and not self.s.watching:
            log.warning("Break %d of %d: closing the table for %s, then opening it again. "
                        "The balance and the stake carry on from where they are.",
                        self.cooloffs, tuning.REJECT_MAX_COOLOFFS, _hms(wait))
            ok = self.next_table(target_reached=False, same_table=True, wait_seconds=wait)
            self.cooloff_ended = time.monotonic()
            return ok
        log.warning("Break %d of %d: watching without betting for %s (there is no "
                    "open_table action to come back with, so the table stays open and "
                    "the road stays complete).", self.cooloffs, tuning.REJECT_MAX_COOLOFFS,
                    _hms(wait))
        self.sit_out_until = time.monotonic() + wait
        self.push()
        return True

    def sitting_out(self, game: int) -> bool:
        """True while a break is on and this hand must not be bet."""
        if self.sit_out_until is None:
            return False
        left = self.sit_out_until - time.monotonic()
        if left <= 0:
            self.sit_out_until = None
            self.cooloff_ended = time.monotonic()
            log.info("Break over — betting again.")
            return False
        self.status = f"Break: watching game {game} without betting ({_hms(left)} left)"
        return True

    def refusals_report(self) -> dict | None:
        """For the dashboard."""
        if not self.rejected_bets and self.sit_out_until is None:
            return None
        left = (self.sit_out_until - time.monotonic()) if self.sit_out_until else None
        return {"count": self.rejected_bets, "recent": len(self.rejections),
                "limit": tuning.REJECT_LIMIT, "breaks": self.cooloffs,
                "break_left": max(0.0, left) if left is not None else None}


def fmt_trace(trace) -> str:
    """The score readings after the clicks, runs of the same value collapsed:
    '11,014.96 ×2 (5.3–6.1 s) → 10,994.96 ×6 (6.8–10.6 s)'. Times are seconds into
    the game, the same clock as the 'done N s into the game' line."""
    runs: list[list] = []
    for t, v in trace:
        if runs and runs[-1][0] == v:
            runs[-1][2], runs[-1][3] = t, runs[-1][3] + 1
        else:
            runs.append([v, t, t, 1])
    return " → ".join(
        f"{'unreadable' if v is None else money(v)}"
        + (f" ×{n} ({a:.1f}–{b:.1f} s)" if n > 1 else f" ({a:.1f} s)")
        for v, a, b, n in runs)
