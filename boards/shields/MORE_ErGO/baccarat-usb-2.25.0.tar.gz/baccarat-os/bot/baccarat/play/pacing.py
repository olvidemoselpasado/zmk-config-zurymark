"""Measuring how fast this table runs, and deciding how often to look at it.

Every look is a screenshot and screenshots make the game itself stutter, so the
rate is earned rather than assumed: the table is timed, and the floors come out
of what it actually did.

The floors are taken from the SECOND-smallest time seen, not the smallest. One
freak-fast hand -- a result that was already on screen when we looked -- would
otherwise drag the floor to near zero and put the bot back to polling flat out,
which is the behaviour this was written to stop.

The Player state this is responsible for:

    hand_times, hand_seconds, quiet_poll, chip_times, chip_waits,
    bets_open_at, game_seen, _last_game_at, _shots_at, shots_per_hand,
    shot_rate
"""

from __future__ import annotations

import statistics
import time
from baccarat import screen as bet
from baccarat.play import tuning


class Pacing:
    """Mixed into Player. See the module docstring."""

    def _note_hand_time(self) -> None:
        """Remember how long the last hand took, and how many screenshots it cost."""
        now = time.monotonic()
        shots = bet.shots_taken()
        if self._last_game_at is not None:
            gap = now - self._last_game_at
            if 5 <= gap <= 90:                       # skip pauses (table switches, shuffles)
                self.hand_times = (self.hand_times + [gap])[-20:]
                self.shot_rate = ((shots - self._shots_at) / gap) if gap > 0 else None
                self.shots_per_hand = shots - self._shots_at
        self._last_game_at = now
        self._shots_at = shots

    def hand_pace(self) -> tuple[float, str]:
        """Seconds per hand: measured on this table's games when possible."""
        if len(self.hand_times) >= 3:
            return float(statistics.median(self.hand_times)), "measured"
        return self.hand_seconds, "setting"

    @staticmethod
    def _quickest(times: list[float], need: int = 4) -> float:
        """A safe 'this never happens sooner than' from what we've measured.

        Not the average — an average is wrong half the time, and being late for a
        result costs a bet. Not the plain minimum either: one freak short gap (a
        shuffle, a misread, two results arriving together) would drag it down and
        throw the saving away for the rest of the session. The second-smallest of the
        recent ones ignores a single outlier and is still well under the truth, and
        the gears leave another 10% margin on top."""
        if len(times) < need:
            return 0.0                        # not enough to be sure: watch closely
        return max(0.0, sorted(times)[1])

    def board_poll(self) -> float:
        """How closely the bar is watched once a result is really due.

        When the betting window is timed from the chips appearing, nothing depends on
        catching the result to a tenth of a second: the chips take seconds to come up
        and the window is counted from them. Noticing the result half a second later
        changes nothing, and halves the screenshots in the busiest phase. When the
        window is timed from the clock, the result *is* the start signal, so it stays
        sharp."""
        return tuning.POLL if self.bet_start_on == "game" else tuning.POLL * 2

    def chip_floor(self) -> float:
        """The quickest the chips have ever come up after a result. Until there are
        measurements, a second — no table puts the chips up instantly, and looking
        for them in that first second is wasted."""
        return self._quickest(self.chip_times) or tuning.CHIP_FLOOR_GUESS

    def hand_floor(self) -> float:
        """The quickest hand this table has produced.

        Until there are enough hands to know, half the pace set in Setup is used.
        Waiting for four hands before saving anything means a short session — or one
        that keeps changing table — never saves anything at all, which is exactly
        when the screen is busiest. Half is conservative enough that a hand arriving
        twice as fast as expected is still caught at full speed."""
        return self._quickest(self.hand_times) or max(0.0, self.hand_seconds * 0.7)
