"""Deciding a table is not worth sitting at before any money is on it.

Every strategy has shapes of road that beat it. The road is read first and
checked against the patterns written down in the library; enough of them and the
table is turned down with a screenshot showing which shape was found where, a
countdown to when its shoe should be over, and the next table opened instead.

The Player state this is responsible for:

    screens, screen_min, skipped, screen_checks, _said_no_screen_road
"""

from __future__ import annotations

import time
from baccarat import screen as bet
from baccarat.log import log
from baccarat import core as strategies
from baccarat.play.reading import (
    Board, road_from_screen,
    total)
from baccarat.util.clock import _hms


class Screening:
    """Mixed into Player. See the module docstring."""

    def screen_road(self, board: Board | None) -> list[str] | None:
        """The results this table has already produced, for the screens to judge.
        None = we can't see them, so no table can be judged."""
        road = road_from_screen(board) if board and total(board) else None
        if road is None:
            try:
                road = bet.read_road()
            except Exception as e:
                log.warning("Couldn't read the road to screen this table: %s", e)
                return None
        if road is None and not self._said_no_screen_road:
            self._said_no_screen_road = True
            log.warning("Tables can't be screened without a 'road' region: the screens need "
                        "the order of the results, and the counters only give totals. "
                        "Interface tab → Regions → add 'road' around the grid of circles.")
        return road

    def judge_table(self, board: Board | None, name: str | None) -> str | None:
        """Is this table one of the ones that take this strategy apart? Returns the
        reason to walk away, or None to sit down. A table turned down is left alone
        for the hands its shoe has left, so the hunt moves on and comes back to it
        later, by which time it is a new shoe.

        Nothing in here may end a session: screening is an opinion about a table, and
        a session that is already running is worth more than the opinion. Anything
        unexpected is logged and the table is played."""
        if not self.screens:
            return None
        try:
            road = self.screen_road(board)
            if road is None:
                return None
            verdict = strategies.screen_table(road, self.screens, self.screen_min)
            self.screen_checks = verdict["checks"]
            if not verdict["bad"]:
                log.info("Table screening: %d results, none of the patterns here.%s",
                         verdict["hands"], "".join(f"\n    ✓ {c['name']} — {c['why']}"
                                                   for c in verdict["checks"]))
                return None
            return verdict["why"]
        except Exception as e:
            log.exception("Couldn't screen this table (%s) — playing it rather than "
                          "stopping. The patterns are not being applied.", e)
            return None

    def turn_down_table(self, name: str | None, why: str, board: Board | None) -> None:
        """Note why a table was turned down, photograph it, and leave it alone until
        its shoe has run out — the shape we didn't like belongs to this shoe, so the
        wait is the hands it has left, not a flat number of minutes."""
        left = self.table_wait_left(board)
        ends_at = self.wait_hands or self.s.table_hands or 0
        hands_left = max(0, ends_at - total(board)) if ends_at else 0
        log.warning("Skipping this table — %s. Leaving it for its last %d hand%s (about %s).",
                    why, hands_left, "" if hands_left == 1 else "s", _hms(left))
        self.snapshot("bad-table", f"table turned down: {why}")
        if name:
            self.table_ready[name] = time.monotonic() + left
        self.skipped = (self.skipped + [{
            "name": name or "the open table", "why": why,
            "hands": total(board) if board else 0,
            "hands_left": hands_left, "ends_at": ends_at,
            "back_at": time.time() + left,
            "when": time.strftime("%H:%M:%S"),
            "shot": self.shots[-1]["file"] if self.shots else None,
            "checks": self.screen_checks}])[-8:]
        self.status = f"Skipped a table: {why[:60]}"
        self.dash.update(waiting=self.countdowns())
        self.push()
