"""Stop and pause, and the one exception that unwinds a session.

Every waiting loop in the program goes through check_stop() or wait_until(),
which is what makes the dashboard's Stop button take effect in the middle of a
40-second wait between tables instead of whenever the wait happens to end."""

from __future__ import annotations

import threading
import time
from baccarat.log import log


from baccarat.util.clock import _duration, _hms


# Set by the dashboard's Stop button; every waiting loop checks it.
STOP = threading.Event()


PAUSE = threading.Event()        # set = held, for a dropped connection or a coffee


PAUSE_POLL = 0.25


class Stopped(Exception):
    pass


def check_stop() -> float:
    """Called from every waiting loop. Raises when you stop, blocks while you pause.
    Returns the seconds spent paused, so a loop can push its own deadline back by
    that much — a ten-minute pause must not make a table look stuck."""
    if STOP.is_set():
        raise Stopped()
    if not PAUSE.is_set():
        return 0.0
    t0 = time.monotonic()
    while PAUSE.is_set():
        if STOP.is_set():
            raise Stopped()
        time.sleep(PAUSE_POLL)
    held = time.monotonic() - t0
    log.info("Resumed after %s paused.", _hms(held))
    return held


def stop_now() -> None:
    """Raise if Stop was pressed -- and nothing else: unlike check_stop() it never sits
    out a pause, so it is safe in the middle of the clicks, which can't wait."""
    if STOP.is_set():
        raise Stopped()


def nap(seconds: float) -> None:
    """time.sleep that Stop cuts short: the Stop button takes effect within 0.1 s."""
    end = time.monotonic() + max(0.0, seconds)
    while True:
        stop_now()
        left = end - time.monotonic()
        if left <= 0:
            return
        time.sleep(min(0.1, left))


def wait_until(ts: float, label: str, on_tick=None) -> None:
    """Sleep until `ts` (epoch seconds), checking the Stop flag. Logs every 10 minutes."""
    log.info("Scheduled: starting at %s (in %s).", label, _duration(ts - time.time()))
    next_log = time.time() + 600
    while time.time() < ts:
        check_stop()
        if on_tick:
            on_tick()
        if time.time() >= next_log:
            log.info("Starting at %s (in %s).", label, _duration(ts - time.time()))
            next_log += 600
        time.sleep(min(0.5, max(0.0, ts - time.time())))
    log.info("Scheduled time reached (%s) — starting.", label)
