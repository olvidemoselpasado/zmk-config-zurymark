"""Turning what the screen says into what happened.

Waiting for the next hand, working out who won from the counters moving, and
reading the road -- with the one rule that caused a real misread: a road and
the counters have to come from the SAME moment. road_and_board returns the
counters the road agrees with, because validating a fresh road against a stale
board put the bot a hand ahead of the table and it bet on a road that had not
happened yet."""

from __future__ import annotations

import sys
import time
from baccarat import screen as bet
from baccarat.log import log
from baccarat.core.game import SIDES


from baccarat.play.pace import poll_step
from baccarat.play.stop import check_stop
from baccarat.play import tuning


Board = dict[str, int]


# ---------------------------------------------------------------------------
# Reading the table
# ---------------------------------------------------------------------------

def total(b: Board | None) -> int:
    return sum(b[k] for k in SIDES) if b else 0


def same_board(a: Board | None, b: Board | None) -> bool:
    """Same numbers on the bar — used to spot a stale read of the table just closed."""
    if not a or not b:
        return False
    return all(a.get(k) == b.get(k) for k in (*SIDES, *tuning.PAIRS, "game"))


def fmt_board(b: Board | None) -> str:
    if not b:
        return "P? B? T?"
    # the pair counts are no longer read off the bar, so there is nothing to show for them
    return f"#{b['game']} P{b['player']} B{b['banker']} T{b['tie']}"


def wait_next_game(game_no: int, prev: Board, on_read=None,
                   timeout: float = tuning.IDLE_STOP, floor: float = 0.0,
                   quiet: float = tuning.QUIET_POLL, fast: float = tuning.POLL) -> Board | None:
    """Poll the bar until the game number changes or the counters reset.
    None = nothing happened within `timeout`.
    on_read(board, ms) is called after every read (for the dashboard).

    Every read is a screenshot, and a screenshot makes the compositor copy a whole
    frame — do it ten times a second and the game itself starts to stutter. A result
    cannot land in the first few seconds of a hand, so the early part is watched
    slowly and the pace picks up as the result becomes due. `floor` is the shortest
    hand seen on this table; the slow phase always ends well before it, so nothing is
    ever noticed late. With no measurements yet, floor is 0 and it watches closely
    throughout."""
    start = time.monotonic()
    end = start + timeout
    suspicious = None
    said, last = 0.0, None
    while time.monotonic() < end:
        end += check_stop()                       # a pause doesn't count against the table
        t0 = time.perf_counter()
        b = bet.read_board_stable()
        if on_read:
            on_read(b, (time.perf_counter() - t0) * 1000)
        waited = time.monotonic() - start
        if waited > 30 and waited - said > 30:               # say what we're looking at
            said = waited
            if b:
                log.info("Still on game %d after %.0f s (bar reads fine: %s). The table looks "
                         "stuck or very slow.", game_no, waited, fmt_board(b))
            else:
                log.info("Can't read the scoreboard bar (%.0f s). Something may be covering it, "
                         "the page may have reloaded, or you may have been logged out.", waited)
        last = b or last
        if b:
            if total(b) < total(prev):                       # counters went back → new table
                return b
            if b["game"] != game_no:
                if b["game"] == game_no + 1 or b["game"] == suspicious:
                    return b
                log.warning("Game number jumped %d → %d — re-checking …", game_no, b["game"])
                suspicious = b["game"]
        time.sleep(poll_step(time.monotonic() - start, floor, quiet, fast))
    return None


def detect_winner(prev: Board, cur: Board):
    """Compare counters with the previous round's.
    → (winner, pairs, board, reset). reset=True when the counters went back
    (new table); then winner is set only if the new table already has 1 result."""
    end = time.monotonic() + tuning.COUNT_WAIT
    while True:
        if total(cur) < total(prev):
            if total(cur) == 1:
                return (next(k for k in SIDES if cur[k] == 1),
                        [k for k in tuning.PAIRS if cur[k] > 0], cur, True)
            return None, [], cur, True
        diff = {k: cur[k] - prev[k] for k in SIDES}
        if any(diff.values()):
            pairs = [k for k in tuning.PAIRS if cur[k] > prev[k]]
            up = [k for k, d in diff.items() if d == 1]
            if len(up) == 1 and all(d == 0 for k, d in diff.items() if k != up[0]):
                return up[0], pairs, cur, False
            log.warning("Counters changed unexpectedly: %s → %s (missed round or misread)",
                        fmt_board(prev), fmt_board(cur))
            return None, [], cur, False
        if time.monotonic() > end:
            log.warning("Counters didn't change (%s) — raise tuning.COUNT_WAIT?", fmt_board(cur))
            return None, [], cur, False
        time.sleep(0.1)
        check_stop()
        cur = bet.read_board_stable() or cur


def wait_for_score(expected: float | None) -> float | None:
    """Live: read the score, waiting (up to tuning.SCORE_WAIT) until it shows `expected`."""
    end = time.monotonic() + tuning.SCORE_WAIT
    s = None
    while time.monotonic() < end:
        check_stop()
        s = bet.read_number_stable("score", timeout=1.0)
        if s is not None and (expected is None or abs(s - expected) < 0.01):
            return s
        time.sleep(0.1)
    return s


# ---------------------------------------------------------------------------
# Joining a table that already has results
# ---------------------------------------------------------------------------

LETTERS = {"p": "player", "b": "banker", "t": "tie"}


def parse_road(text: str) -> list[str]:
    """'B P B', 'bpb', 'B,P,T' → ['banker', 'player', 'banker'] (oldest first)."""
    road = []
    for ch in text.lower():
        if ch in LETTERS:
            road.append(LETTERS[ch])
        elif ch.isalpha():
            raise ValueError(f"'{ch}' isn't P, B or T")
    return road


def road_and_board(board: Board, tries: int = tuning.ROAD_TRIES) -> tuple[list[str] | None, Board]:
    """Read the bead road (the grid of results) and check it against the scoreboard
    counters. Returns the whole table so far, or None if there's no road region.

    One attempt reads the road, the counters, then the road again. Accepted only when
    both road reads agree (so no result landed in the middle) and the totals match the
    counters (so the region was read right). A result landing mid-read, or one noisy
    read, costs an attempt, not the table — on a table with 30 results already down,
    throwing them away means the strategy sits out hands it could have bet.

    Returns the road AND the counters it agrees with, because a result can land while
    all this is going on and then the road is a hand ahead of the counters the caller
    started with. Handing back a road for one moment and leaving the caller on another
    puts the last result into the road twice, and every window the strategy looks at
    is wrong from then on."""
    said = False
    for attempt in range(1, max(1, tries) + 1):
        try:
            first = bet.read_road()
            if first is None:
                return None, board                    # no 'road' region set up
            time.sleep(tuning.ROAD_GAP)
            mid = bet.read_board_stable() or board     # counters from between the reads
            second = bet.read_road()
        except Exception as e:
            log.warning("Couldn't read the road: %s", e)
            return None, board
        if second != first:
            if not said:                              # one line, however many attempts
                log.info("The road changed while reading it (a result just came in?) — "
                         "reading it again.")
                said = True
            continue
        want = {k: mid[k] for k in SIDES}
        got = {k: first.count(k) for k in SIDES}
        if got == want:
            if attempt > 1:
                log.info("Read the road cleanly on attempt %d.", attempt)
            if total(mid) != total(board):
                log.info("A result landed while the road was being read — joining on "
                         "%s, which is what the road shows.", fmt_board(mid))
            return first, mid
        log.info("Attempt %d: the road shows P%d B%d T%d but the counters say P%d B%d T%d.",
                 attempt, got["player"], got["banker"], got["tie"],
                 want["player"], want["banker"], want["tie"])
        short = sum(want.values()) - sum(got.values())
        if all(got[k] <= want[k] for k in SIDES) and short > 0:
            log.warning("The road is %d result%s short of the counters every time. That is "
                        "what a region drawn too small looks like — the grid scrolls, and "
                        "the box is only catching part of it. Interface tab → the 'road' "
                        "region → Re-draw it around the whole grid.",
                        short, "" if short == 1 else "s")
            return None, board
    log.warning("Couldn't get a clean read of the road in %d attempts — carrying on without "
                "it, so the strategy waits for results of its own. Check the region with: "
                "python bet.py --read-road", tries)
    return None, board


def road_from_screen(board: Board, tries: int = tuning.ROAD_TRIES) -> list[str] | None:
    """Just the road, for callers that only want to look at the results."""
    return road_and_board(board, tries)[0]


def no_road_question(board: Board, need: int = 3) -> list[str]:
    """Setup option off: don't ask — the strategy waits for results it sees itself."""
    return []


def ask_road(board: Board, need: int = 3) -> list[str]:
    """The counters give totals, not order. Ask for the last results."""
    if total(board) < max(1, need) or not sys.stdin.isatty():
        return []
    print(f"\n  This table already has {total(board)} results ({fmt_board(board)}),")
    print("  but the counters don't show their ORDER. Type the last results you see")
    print("  on the table, oldest → newest (e.g.  B P B  or  bbt p b),")
    while True:
        text = input("  or press Enter to watch a few rounds first: ").strip()
        if not text:
            return []
        try:
            return parse_road(text)
        except ValueError as e:
            print(f"  ✗ {e} — use P, B and T only.")
