#!/bin/bash
# Double-click to check this Mac can run the bot: permissions, pictures, the pointer.
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
    echo "The bot isn't set up yet: run  sh setup_mac.sh  in this folder first."
else
    .venv/bin/python -m baccarat.screen --doctor
fi
read -r -p "Press Return to close."
