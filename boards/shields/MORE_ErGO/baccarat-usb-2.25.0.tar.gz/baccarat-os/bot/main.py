"""main.py — kept so the commands you already know keep working.

Everything moved into the baccarat package. `python -m baccarat` is the same
program with the same arguments; this file forwards to it, and `import main`
still answers to the old names.

Where things went:

    baccarat/play/        playing a table: the loop, timing, money, navigation
    baccarat/web/         the dashboard and its API
    baccarat/setup.py     reading the Setup form
    baccarat/cli.py       the command line
"""

import sys

from baccarat.cli import *                        # noqa: F401,F403
from baccarat.consistency import *                # noqa: F401,F403
from baccarat.play.actions import *               # noqa: F401,F403
from baccarat.play.pace import *                  # noqa: F401,F403
from baccarat.play.player import Player           # noqa: F401
from baccarat.play.reading import *               # noqa: F401,F403
from baccarat.play.stop import *                  # noqa: F401,F403
from baccarat.play.tuning import *                # noqa: F401,F403
from baccarat.setup import *                      # noqa: F401,F403
from baccarat.store.settings import *             # noqa: F401,F403
from baccarat.util.clock import *                 # noqa: F401,F403
from baccarat.util.show import *                  # noqa: F401,F403
from baccarat.web.api import *                    # noqa: F401,F403
from baccarat import cli as _cli

if __name__ == "__main__":
    sys.exit(_cli.main())
