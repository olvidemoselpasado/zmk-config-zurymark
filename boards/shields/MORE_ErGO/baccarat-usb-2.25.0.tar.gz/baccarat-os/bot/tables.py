"""tables.py — kept so existing imports keep working. Now baccarat/store/history.py."""

import sys

import baccarat.store.history

sys.modules[__name__] = baccarat.store.history
