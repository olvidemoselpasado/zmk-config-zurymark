# The bot as a system service, under its own user -- the LOCKED bot: its set-up and
# its casino login live on the server, never on the stick. At boot it downloads them
# (once this stick has been approved on the server's page), keeps them in RAM, and
# sends back whatever is changed on its dashboard. It reaches kiosk's screen only
# through the doors kiosk's session opens for it (see kiosk-session.sh), and the
# network only to the stick itself and the server.
#
# The stick keeps two things of its own, made at its first boot, readable by root
# only: its id, and its secret key -- which it signs every call to the server with, so
# no other computer can pass itself off as it. The key reaches the bot as a systemd
# credential: in its own private folder, for this service alone.
{ pkgs, lib, settings, ... }:
let
  # the server: the one address on the network the bot may reach
  given = settings.server or "";
  server = if given == "" || lib.hasInfix "://" given then given else "http://${given}";
  hostPort = lib.last (lib.splitString "://" server);
  serverIp = lib.head (lib.splitString ":" (lib.head (lib.splitString "/" hostPort)));
  bot = pkgs.callPackage ./bot-package.nix { };
  envFile = "/run/baccarat-display/env";
  # waits for kiosk's screen, runs the bot on it, and starts it again on a new screen
  # (Hyprland restarted: a new instance, new sockets)
  runner = pkgs.writeShellScript "baccarat-run" ''
    set -u
    while true; do
      while [ ! -s ${envFile} ]; do sleep 1; done
      seen=$(${pkgs.coreutils}/bin/sha1sum < ${envFile})
      set -a; . ${envFile}; set +a
      ${lib.getExe bot} &
      pid=$!
      while kill -0 "$pid" 2>/dev/null; do
        sleep 2
        now=$(${pkgs.coreutils}/bin/sha1sum < ${envFile} 2>/dev/null || true)
        if [ "$now" != "$seen" ]; then
          echo "the screen changed (Hyprland restarted) — starting the bot on the new one"
          kill "$pid"; wait "$pid"; break
        fi
      done
      wait "$pid" 2>/dev/null
      sleep 2
    done
  '';
in {
  # fixed numbers, so files handed over from another computer belong to it
  users.groups.baccarat.gid = 950;
  users.users.baccarat = {
    uid = 950;
    isSystemUser = true;
    group = "baccarat";
    extraGroups = [ "ydotool" ];       # the mouse: ydotoold's socket, nothing more
    home = "/var/lib/baccarat";
  };
  programs.ydotool.enable = true;      # ydotoold as a service: no more `sudo ydotoold`

  # (where kiosk tells the bot about its screen, /run/baccarat-display, is made in kiosk.nix)

  # Before the bot: its id and key (made once, kept on the stick), and -- only for a
  # stick made with --data -- a first set-up to start from until the server has one.
  systemd.services.baccarat-seed = {
    description = "Give the bot the data it starts from";
    wantedBy = [ "multi-user.target" ];
    before = [ "baccarat.service" ];
    serviceConfig.Type = "oneshot";
    script = ''
      install -d -m 0700 -o 950 -g 950 /var/lib/baccarat
      seed=/nix/var/baccarat-os/seed
      if [ -d "$seed" ] && [ ! -e /var/lib/baccarat/data ]; then
        cp -a "$seed" /var/lib/baccarat/data
        echo "the bot starts from the copy made with the stick ($(du -sh /var/lib/baccarat/data | cut -f1))"
      else
        echo "the bot starts empty"
      fi
      # this stick's own id, for the report server: made at its first boot, kept on
      # the stick, so it is the same bot at every boot (and every stick a different one)
      id=/nix/var/baccarat-os/bot-id
      if [ ! -s "$id" ]; then
        install -d -m 0700 /nix/var/baccarat-os
        (umask 077; echo "usb-$(tr -d - < /proc/sys/kernel/random/uuid)" > "$id")
      fi
      key=/nix/var/baccarat-os/bot-key
      if [ ! -s "$key" ]; then
        (umask 077; head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n' > "$key")
        echo "this stick made itself its key (it shows its code on the screen until approved)"
      fi
      install -d -m 0700 /var/lib/baccarat/data
      cp "$id" /var/lib/baccarat/data/bot_id
      chown -R 950:950 /var/lib/baccarat/data
    '';
  };

  systemd.services.baccarat = {
    description = "Baccarat bot (dashboard on http://127.0.0.1:8765)";
    wantedBy = [ "multi-user.target" ];
    after = [ "ydotoold.service" "systemd-tmpfiles-setup.service" "baccarat-seed.service" ];
    wants = [ "ydotoold.service" "baccarat-seed.service" ];
    environment = {
      BACCARAT_DATA = "/var/lib/baccarat/data";
      BACCARAT_OS = "usb";
      BACCARAT_SERVER = if server == "" then "off" else server;
      BACCARAT_LOCKED = if server == "" then "0" else "1";
      YDOTOOL_SOCKET = "/run/ydotoold/socket";
      HOME = "/var/lib/baccarat";
    } // lib.optionalAttrs ((settings.serverCa or null) != null) {
      BACCARAT_SERVER_CA = "${settings.serverCa}";
    };
    serviceConfig = {
      # its key: in $CREDENTIALS_DIRECTORY/bot-key, readable by this service alone
      LoadCredential = [ "bot-key:/nix/var/baccarat-os/bot-key" ];
      User = "baccarat";
      Group = "baccarat";
      ExecStart = runner;
      Restart = "always";
      RestartSec = 3;
      StateDirectory = "baccarat";
      StateDirectoryMode = "0700";
      UMask = "0077";
      # the bot needs no internet at all: only the dashboard, on the stick itself, and
      # the report server
      IPAddressAllow = [ "localhost" ] ++ lib.optional (serverIp != "") serverIp;
      IPAddressDeny = "any";
      RestrictAddressFamilies = [ "AF_UNIX" "AF_INET" "AF_INET6" ];
      PrivateTmp = true;
      NoNewPrivileges = true;
      ProtectSystem = "strict";
      ProtectKernelTunables = true;
      ProtectKernelModules = true;
      ProtectKernelLogs = true;
      ProtectControlGroups = true;
      ProtectClock = true;
      ProtectHostname = true;
      RestrictSUIDSGID = true;
      RestrictRealtime = true;
      RestrictNamespaces = true;
      LockPersonality = true;
      CapabilityBoundingSet = "";
      SystemCallArchitectures = "native";
    };
  };
}
