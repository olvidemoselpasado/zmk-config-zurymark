# How the stick gets new versions -- of the bot, the browser, everything.
#
# From the server (the usual way, once `make-usb.sh publish` has been run once):
#   You publish from your computer: it builds the new system, signs it with a key that
#   never leaves your computer, and puts what is new on the server. Every stick hears of
#   it within ~30 s (the server says so in its answer to the bot's report) and starts
#   fetching at once -- a few sticks at a time, as the server lets them -- and looks by
#   itself every ~10 minutes as well. It fetches only what it lacks, refuses anything
#   not signed with that key (update-key.pub, in this folder and so in every stick), and
#   switches to it while no session is running: a session in play finishes the run in
#   progress, stops at the base bet, and carries on by itself after. Nothing to unplug.
#   The boot menu keeps the last 5 systems, to go back to if one ever goes wrong.
#
# From the internet (updates = "internet" in settings.nix, or before the first
# publish): every day the stick fetches the newest NixOS packages itself and builds
# them, for the next start.
{ self, settings, config, pkgs, lib, ... }:
let
  recipe = "/nix/var/baccarat-os/flake";        # on the stick: / is RAM
  keyFile = ../update-key.pub;
  hasKey = builtins.pathExists keyFile;
  given = settings.server or "";
  server = if given == "" || lib.hasInfix "://" given then given else "http://${given}";
  fromServer = (settings.updates or "server") == "server" && server != "" && hasKey;
  ca = if (settings.serverCa or null) != null then "${settings.serverCa}" else "";
  # this system's own version (the bot's), kept in it: an update never goes backwards
  version = (pkgs.callPackage ./bot-package.nix { }).version;

  updater = pkgs.writeShellScript "baccarat-update" ''
    set -euo pipefail
    export PATH=${lib.makeBinPath (with pkgs; [ coreutils curl jq openssl gawk gnused config.nix.package ])}
    server=${lib.escapeShellArg server}
    ca=${lib.escapeShellArg ca}
    host=$(printf '%s' "$server" | sed -E 's#^[a-z]+://##; s#[:/].*##')
    opts=(-fsS --max-time 30)
    [ -n "$ca" ] && opts+=(--cacert "$ca")
    version="?"

    # Where it is, for the bot's dashboard (a progress bar, Start held back while it
    # installs) and through it for the server's page. "at" is a heartbeat: a status
    # nobody has refreshed for a minute is stale, and holds nothing back.
    sdir=/run/baccarat-update-status
    install -d -m 0755 "$sdir"
    status() {   # state [done total [error]]
      jq -n --arg s "$1" --arg v "$version" --argjson d "''${2:-0}" --argjson t "''${3:-0}" \
        --arg e "''${4:-}" --argjson at "$(date +%s)" \
        '{state: $s, version: $v, done: $d, total: $t, error: $e, at: $at}' > "$sdir/status.json.new"
      chmod 0644 "$sdir/status.json.new"
      mv -f "$sdir/status.json.new" "$sdir/status.json"
    }
    running() {
      [ "$(curl -fs --max-time 5 http://127.0.0.1:8765/api/state | jq -r '.running // false' 2>/dev/null)" = true ]
    }

    # who it is: this stick's id, and a token only its key can make
    id=$(cat /nix/var/baccarat-os/bot-id)
    key=$(cat /nix/var/baccarat-os/bot-key)
    tok=$(printf cache | openssl dgst -sha256 -mac HMAC -macopt "hexkey:$key" | awk '{print $NF}')
    install -d -m 0700 /run/baccarat-update
    netrc=/run/baccarat-update/netrc
    (umask 077; printf 'machine %s login %s password %s\n' "$host" "$id" "$tok" > "$netrc")

    # The release, and whether this stick may download it now: the server lets a few
    # sticks at a time ("go"), so a thousand of them never swamp it. One told to wait
    # is woken again by the bot within a minute (it hears of the release every ~30 s).
    rel=$(curl "''${opts[@]}" --netrc-file "$netrc" "$server/v1/release") ||
      { echo "the server can't be reached"; exit 0; }
    want=$(printf '%s' "$rel" | jq -r '.system // empty')
    version=$(printf '%s' "$rel" | jq -r '.version // "?"')
    go=$(printf '%s' "$rel" | jq -r 'if has("go") then .go else true end')
    case "$want" in
      /nix/store/*-nixos-system-*) ;;
      *) echo "no update published"; exit 0 ;;
    esac
    cur=$(readlink -f /run/current-system)
    staged=$(readlink -f /nix/var/nix/profiles/system)
    if [ "$want" = "$cur" ]; then
      status current
      exit 0
    fi

    # Never backwards: a stick put on a newer version by hand (make-usb.sh update) keeps
    # it, whatever older release the server still has. The same version built again is
    # taken only if it was published after this stick got its own (a republish, e.g.
    # with the newest browser) -- not an older build of it.
    mine=$(cat "$cur/etc/baccarat-os/version" 2>/dev/null || true)
    newer() { [ "$1" != "$2" ] && [ "$(printf '%s\n%s\n' "$1" "$2" | sort -V | tail -n 1)" = "$1" ]; }
    if [ -n "$mine" ] && [ "$version" != "?" ]; then
      if newer "$mine" "$version"; then
        echo "the server's release ($version) is older than this stick ($mine): staying on $mine"
        version=$mine; status current
        exit 0
      fi
      if [ "$mine" = "$version" ]; then
        published=$(printf '%s' "$rel" | jq -r '.at // 0 | floor')
        since=0
        for l in /nix/var/nix/profiles/system-*-link; do
          [ "$(readlink -f "$l")" = "$cur" ] || continue
          t=$(stat -c %Y "$l"); [ "$t" -gt "$since" ] && since=$t
        done
        if [ "$since" -gt 0 ] && [ "$published" -le "$since" ]; then
          echo "the server's $version was published before this stick got its own $version: keeping this one"
          status current
          exit 0
        fi
      fi
    fi

    if [ "$want" != "$staged" ]; then
      if [ "$go" != true ]; then
        echo "update $version is out; the server has no download slot free yet — trying again shortly"
        status queued
        exit 0
      fi
      extra=(--option netrc-file "$netrc" --option connect-timeout 20)
      [ -n "$ca" ] && extra+=(--option ssl-cert-file "$ca")

      # what this stick lacks of it, and how much that is to download
      status downloading 0 0
      declare -A size=()
      paths=()
      while IFS=$'\t' read -r p n; do
        [ -n "$p" ] || continue
        size[$p]=$n
        paths+=("$p")
      done < <(nix path-info -r --json --store "$server/cache" "$want" "''${extra[@]}" 2>/dev/null |
        jq -r 'if type == "array" then .[] | [.path, (.downloadSize // .narSize // 0)]
               else to_entries[] | [.key, (.value.downloadSize // .value.narSize // 0)] end | @tsv' || true)
      missing=()
      [ "''${#paths[@]}" -gt 0 ] && mapfile -t missing < <(nix-store --check-validity --print-invalid "''${paths[@]}" 2>/dev/null)
      total=0
      for p in "''${missing[@]}"; do total=$((total + ''${size[$p]:-0})); done
      echo "fetching update $version: ''${#missing[@]} new package(s), $((total / 1048576)) MB"
      status downloading 0 "$total"

      # only what is missing comes; anything not signed with update-key.pub is refused
      nix copy --from "$server/cache" "$want" "''${extra[@]}" &
      cp=$!
      while kill -0 "$cp" 2>/dev/null; do
        sleep 2
        left=0
        if [ "''${#missing[@]}" -gt 0 ]; then
          while read -r p; do left=$((left + ''${size[$p]:-0})); done \
            < <(nix-store --check-validity --print-invalid "''${missing[@]}" 2>/dev/null)
        fi
        status downloading $((total - left)) "$total"
      done
      if ! wait "$cp"; then
        status failed 0 "$total" "the download broke off — it is tried again in a few minutes"
        exit 1
      fi
      nix-env -p /nix/var/nix/profiles/system --set "$want"
      "$want/bin/switch-to-configuration" boot
      staged=$want
      echo "update $version is on the stick"
    fi

    # Installed only while no session runs. A running session hears "waiting" and plays
    # out the run in progress, stops at the base bet, and carries on by itself once this
    # is done (the bot's web/resume.py); an older bot just runs to its end. Then
    # "installing" holds back Start, and after a moment for a Start pressed just before
    # to land, it looks once more.
    while true; do
      while running; do status waiting; sleep 5; done
      status installing
      sleep 3
      running || break
    done
    echo "switching to update $version now (no session running)"
    "$staged/bin/switch-to-configuration" switch || echo "it will be used from the next start"
    status "done"
  '';
in {
  nix.settings.experimental-features = [ "nix-command" "flakes" ];
  # updates are signed on your computer: this stick takes only those
  nix.settings.extra-trusted-public-keys = lib.optional hasKey (lib.removeSuffix "\n" (builtins.readFile keyFile));

  environment.etc."baccarat-os/version".text = version;

  systemd.services.baccarat-update = lib.mkIf fromServer {
    description = "Fetch the update published on the server, and use it when no session runs";
    after = [ "network-online.target" "baccarat-seed.service" ];
    wants = [ "network-online.target" ];
    # it switches the system itself: a switch must not stop it halfway
    restartIfChanged = false;
    serviceConfig = {
      Type = "oneshot";
      ExecStart = updater;
      # downloads beside a session in play: the bot always comes first
      Nice = 19;
      IOSchedulingClass = "idle";
      CPUSchedulingPolicy = "idle";
    };
  };
  # Woken at once by the bot when the server mentions a release this stick isn't on
  # (web/updatestatus.py, poke): the bot may write in this one folder, nothing else.
  systemd.tmpfiles.rules = lib.mkIf fromServer [ "d /run/baccarat-update-poke 0750 baccarat baccarat -" ];
  systemd.paths.baccarat-update = lib.mkIf fromServer {
    wantedBy = [ "multi-user.target" ];
    pathConfig = {
      PathChanged = "/run/baccarat-update-poke";
      Unit = "baccarat-update.service";
      TriggerLimitIntervalSec = "30s";
      TriggerLimitBurst = 4;
    };
  };
  systemd.services.baccarat.serviceConfig.ReadWritePaths = lib.mkIf fromServer [ "-/run/baccarat-update-poke" ];
  systemd.timers.baccarat-update = lib.mkIf fromServer {
    wantedBy = [ "timers.target" ];
    timerConfig = {
      OnBootSec = "2min";
      OnUnitActiveSec = "10min";
      # a thousand sticks don't all ask in the same second
      RandomizedDelaySec = "5min";
    };
  };

  # From the internet instead: the update needs this system's own recipe (this flake)
  # on the stick, where it can move its lock file on.
  systemd.services.baccarat-os-recipe = lib.mkIf (!fromServer) {
    description = "Keep this system's own recipe on the stick, for the daily update";
    wantedBy = [ "multi-user.target" ];
    before = [ "nixos-upgrade.service" ];
    serviceConfig.Type = "oneshot";
    script = ''
      mkdir -p /nix/var/baccarat-os
      stamp=/nix/var/baccarat-os/recipe.from
      if [ "$(cat "$stamp" 2>/dev/null)" != "${self}" ]; then
        rm -rf ${recipe}.new
        cp -r ${self} ${recipe}.new
        chmod -R u+w ${recipe}.new
        rm -rf ${recipe}
        mv ${recipe}.new ${recipe}
        printf '%s' "${self}" > "$stamp"
      fi
    '';
  };
  system.autoUpgrade = {
    enable = !fromServer;
    flake = "path:${recipe}#usb";
    # newest packages of the same stable release: security fixes, a new browser
    flags = [ "--update-input" "nixpkgs" "--print-build-logs" ];
    upgrade = false;
    operation = "boot";                # in effect from the next boot
    allowReboot = false;
    dates = settings.updateTime;
    randomizedDelaySec = "30min";
    persistent = true;                 # off at that hour? then at the next boot
  };

  # old systems and downloads cleared away, so the stick never fills up
  nix.gc = { automatic = true; dates = "weekly"; options = "--delete-older-than 14d"; };
  nix.optimise.automatic = true;
}
