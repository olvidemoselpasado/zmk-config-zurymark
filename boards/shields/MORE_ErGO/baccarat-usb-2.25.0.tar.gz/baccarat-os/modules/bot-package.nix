# The bot, from ../bot, as a read-only package: what the service runs.
{ lib, stdenvNoCC, python3, makeWrapper, grim, slurp, wtype, ydotool, hyprland, procps }:
let
  python = python3.withPackages (ps: with ps; [ numpy opencv4 psutil ]);
in
stdenvNoCC.mkDerivation {
  pname = "baccarat-bot";
  version =
    let line = lib.findFirst (l: lib.hasPrefix "__version__" l) ''__version__ = "0"''
      (lib.splitString "\n" (builtins.readFile ../bot/baccarat/__init__.py));
    in builtins.head (builtins.match ''__version__ = "([^"]+)".*'' line);
  # only the program: not your data, the tests, the updater or the Mac files
  src = lib.cleanSourceWith {
    src = ../bot;
    filter = path: type:
      let rel = lib.removePrefix (toString ../bot + "/") (toString path); in
      !(lib.hasPrefix "data" rel || lib.hasPrefix "tests" rel || lib.hasInfix "__pycache__" rel
        || lib.elem rel [ "update.py" "setup_mac.sh" "requirements-mac.txt" "Start bot.command"
                          "Check this Mac.command" "pytest.ini" "ruff.toml" ]);
  };
  nativeBuildInputs = [ makeWrapper ];
  dontBuild = true;
  installPhase = ''
    mkdir -p $out/share/baccarat-bot $out/bin
    cp -r . $out/share/baccarat-bot/
    makeWrapper ${python}/bin/python3 $out/bin/baccarat-bot \
      --add-flags "$out/share/baccarat-bot/main.py --no-open" \
      --set PYTHONDONTWRITEBYTECODE 1 \
      --prefix PATH : ${lib.makeBinPath [ grim slurp wtype ydotool hyprland procps ]}
  '';
  meta.mainProgram = "baccarat-bot";
}
