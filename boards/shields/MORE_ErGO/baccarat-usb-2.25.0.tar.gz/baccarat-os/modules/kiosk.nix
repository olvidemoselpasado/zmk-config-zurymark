# kiosk: logs in by itself into Hyprland with two windows -- the dashboard and the
# game -- and that is all it can reach. No password, no shell, no other program.
{ config, pkgs, lib, settings, ... }:
let
  hyprland = config.programs.hyprland.package;
  firefox = config.programs.firefox.package;
  session = pkgs.writeShellScript "kiosk-session" (lib.replaceStrings
    [ "@SETFACL@" "@FIREFOX@" "@CURL@" "@HYPRCTL@" "@JQ@" "@SYSTEMDCAT@" "@GAME_URL@" ]
    [ "${pkgs.acl}/bin/setfacl" "${firefox}/bin/firefox" "${pkgs.curl}/bin/curl"
      "${hyprland}/bin/hyprctl" "${lib.getExe pkgs.jq}" "${pkgs.systemd}/bin/systemd-cat" (if settings.gameUrl == "" then "about:blank" else settings.gameUrl) ]
    (builtins.readFile ../kiosk-session.sh));
  hyprConf = pkgs.writeText "hyprland.lua" (lib.replaceStrings
    [ "@MODE@" "@SCALE@" "@KB@" "@SESSION@" ]
    [ settings.monitorMode settings.monitorScale settings.keyboardLayout "${session}" ]
    (builtins.readFile ../hyprland.lua));
  # the config is passed on the command line, from the read-only store: nothing kiosk
  # could write (a download, a saved page) can ever become its Hyprland config
  start = "${hyprland}/bin/start-hyprland -- --config ${hyprConf}";
in {
  users.users.kiosk = {
    isNormalUser = true;
    uid = 1000;
    createHome = false;
    home = "/home/kiosk";
    hashedPassword = "!";              # nobody logs in as kiosk: it is logged in
    extraGroups = [ "video" "audio" ];
  };

  # Its home itself belongs to root: kiosk can't put a file there (no ~/.profile, no
  # ~/.bashrc). The folders programs keep their settings and caches in are kiosk's --
  # the browser, the graphics drivers and GTK need to write there, and nothing kiosk
  # writes can change how the screen starts (Hyprland's config comes from the store).
  systemd.tmpfiles.rules = [
    "d /home/kiosk 0755 root root -"
    "d /home/kiosk/.config 0700 kiosk users -"
    "d /home/kiosk/.local 0700 kiosk users -"
    "d /home/kiosk/.mozilla 0700 kiosk users -"
    "d /home/kiosk/.cache 0700 kiosk users -"
    "d /home/kiosk/Downloads 0700 kiosk users -"
    # where kiosk tells the bot about its screen: setgid, so what it writes is baccarat's to read
    "d /run/baccarat-display 2750 kiosk baccarat -"
  ];

  programs.hyprland.enable = true;
  services.greetd = {
    enable = true;
    settings = {
      initial_session = { user = "kiosk"; command = start; };
      # if the screen ever stops, straight back in -- there is no login screen to land on
      default_session = { user = "kiosk"; command = start; };
    };
  };

  # The browser, and what it is not allowed to do. Updates come with the system (daily),
  # never from inside the browser.
  programs.firefox = {
    enable = true;
    policies = {
      DisableAppUpdate = true;
      DisableSystemAddonUpdate = true;
      DisableDeveloperTools = true;
      BlockAboutConfig = true;
      BlockAboutProfiles = true;
      BlockAboutSupport = true;
      DisableProfileImport = true;
      DisableFirefoxAccounts = true;
      DisableFirefoxStudies = true;
      DisableTelemetry = true;
      DisablePocket = true;
      DontCheckDefaultBrowser = true;
      NoDefaultBookmarks = true;
      OverrideFirstRunPage = "";
      OverridePostUpdatePage = "";
      PrintingEnabled = false;
      # no add-ons: nothing can be installed into the browser
      ExtensionSettings."*".installation_mode = "blocked";
      # no reading files off the stick
      WebsiteFilter.Block = [ "file:///*" ];
      # downloads go to one folder, without asking where (so never anywhere else)
      PromptForDownloadLocation = false;
      DownloadDirectory = "/home/kiosk/Downloads";
      # the game's stream and the dashboard's alarm play without a click; nothing asks
      # for notifications, location, camera or microphone (a prompt covers the screen)
      Permissions = {
        Autoplay = { Default = "allow-audio-video"; Locked = true; };
        Notifications = { BlockNewRequests = true; Locked = true; };
        Location = { BlockNewRequests = true; Locked = true; };
        Camera = { BlockNewRequests = true; Locked = true; };
        Microphone = { BlockNewRequests = true; Locked = true; };
        VirtualReality = { BlockNewRequests = true; Locked = true; };
      };
      # no "save this password?", no autofill, no "translate this page?": every one of
      # them is a bar or a box over the game, and the clicks are points on the screen
      PasswordManagerEnabled = false;
      OfferToSaveLogins = false;
      AutofillAddressEnabled = false;
      AutofillCreditCardEnabled = false;
      DisableFormHistory = true;
      TranslateEnabled = false;
      UserMessaging = { WhatsNew = false; ExtensionRecommendations = false;
                        FeatureRecommendations = false; SkipOnboarding = true; MoreFromMozilla = false; };
    };
    preferences = {
      "media.ffmpeg.vaapi.enabled" = true;          # the stream decoded by the graphics chip, where it can
      "browser.tabs.crashReporting.sendReport" = false;
      # nothing that pops up over the page or pushes it down: the clicks are points on
      # the screen, recorded with the page where it is
      "browser.translations.enable" = false;
      "browser.translations.automaticallyPopup" = false;
      "signon.rememberSignons" = false;
      "signon.autofillForms" = false;
      "signon.generation.enabled" = false;
      "signon.firefoxRelay.feature" = "disabled";
      "extensions.formautofill.addresses.enabled" = false;
      "extensions.formautofill.creditCards.enabled" = false;
      "privacy.popups.showBrowserMessage" = false;          # the "pop-up blocked" bar
      "dom.disable_beforeunload" = true;                    # "leave this page?" boxes
      "dom.webnotifications.enabled" = false;
      "geo.enabled" = false;
      "browser.tabs.warnOnClose" = false;
      "browser.tabs.warnOnCloseOtherTabs" = false;
      "browser.warnOnQuit" = false;
      "full-screen-api.warning.timeout" = 0;
      "browser.toolbars.bookmarks.visibility" = "never";
      "browser.download.alwaysOpenPanel" = false;
      "media.videocontrols.picture-in-picture.video-toggle.enabled" = false;   # the PiP button over videos
      "browser.aboutwelcome.enabled" = false;
      # A page that opens a new window (a casino's game, a pop-up) gets a new TAB in
      # the same window instead, as LibreWolf does: no window jumping over the screen
      # or splitting it, and the game stays in the window the coordinates were
      # recorded in.
      "browser.link.open_newwindow" = 3;                 # links asking for a window: a tab
      "browser.link.open_newwindow.restriction" = 0;     # … even with a size or position given
      "browser.link.open_newwindow.override.external" = 3;
      "browser.sessionstore.resume_from_crash" = false;   # always the same two windows
      "browser.startup.page" = 0;
      "browser.shell.checkDefaultBrowser" = false;
      "browser.cache.disk.enable" = false;          # cache in memory: fewer writes to the stick
      "browser.cache.memory.enable" = true;
    };
    preferencesStatus = "locked";
  };
}
