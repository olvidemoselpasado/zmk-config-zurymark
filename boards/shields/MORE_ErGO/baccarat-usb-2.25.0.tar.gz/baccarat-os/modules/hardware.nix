# Boots on any 64-bit PC (and Intel Macs): nothing here is tied to one machine.
{ pkgs, lib, settings, ... }: {
  system.stateVersion = "26.05";
  networking.hostName = "baccarat";
  time.timeZone = settings.timeZone;

  boot.loader.systemd-boot = {
    enable = true;
    editor = false;                    # nobody edits the kernel command line at boot
    configurationLimit = 5;            # the last few systems, to go back to after a bad update
  };
  boot.loader.timeout = 2;
  # never write the computer's own boot entries: the stick boots from its fallback
  # path (EFI/BOOT/BOOTX64.EFI) on whatever machine it is plugged into
  boot.loader.efi.canTouchEfiVariables = false;

  boot.initrd.systemd.enable = true;
  boot.initrd.availableKernelModules = [
    "xhci_pci" "ehci_pci" "ahci" "nvme" "usb_storage" "uas" "sd_mod" "sdhci_pci"
    "rtsx_pci_sdmmc" "thunderbolt" "hid_generic" "usbhid"
  ];
  boot.kernelPackages = pkgs.linuxPackages;          # the long-term kernel
  boot.kernelParams = [ "quiet" "loglevel=3" ];

  hardware.enableRedistributableFirmware = true;     # Wi-Fi and graphics firmware
  hardware.cpu.intel.updateMicrocode = true;
  hardware.cpu.amd.updateMicrocode = true;
  hardware.graphics = {
    enable = true;
    # hardware video decoding for the game's stream: Intel (new and old); AMD comes with Mesa
    extraPackages = with pkgs; [ intel-media-driver intel-vaapi-driver ];
  };

  networking.networkmanager.enable = true;
  # Wi-Fi, from a file only root can read, on the system partition (make-usb.sh --wifi
  # writes it). Ethernet just works.
  networking.networkmanager.ensureProfiles = {
    environmentFiles = [ "/nix/var/baccarat-os/wifi.env" ];
    profiles.wifi = {
      connection = { id = "wifi"; type = "wifi"; autoconnect = true; };
      wifi = { ssid = "$WIFI_SSID"; mode = "infrastructure"; };
      wifi-security = { key-mgmt = "wpa-psk"; psk = "$WIFI_PSK"; };
      ipv4.method = "auto";
      ipv6.method = "auto";
    };
  };
  systemd.tmpfiles.rules = [
    "d /nix/var/baccarat-os 0700 root root -"
    "f /nix/var/baccarat-os/wifi.env 0600 root root -"
  ];

  # light: nothing that isn't needed to show the browser and run the bot
  documentation.enable = false;
  environment.defaultPackages = [ ];
  programs.nano.enable = false;
  programs.command-not-found.enable = false;
  fonts.enableDefaultPackages = false;
  fonts.packages = with pkgs; [ dejavu_fonts liberation_ttf noto-fonts-color-emoji ];

  services.pipewire = { enable = true; pulse.enable = true; };      # the alarm's sound

  # speed: the stick holds only the system, read at boot; the rest is in RAM already
  zramSwap.enable = true;
  powerManagement.cpuFreqGovernor = "performance";
  services.journald.extraConfig = "SystemMaxUse=200M";
  # a laptop lid or an idle machine must not stop a session
  services.logind.settings.Login = {
    HandleLidSwitch = "ignore";
    HandleLidSwitchExternalPower = "ignore";
    IdleAction = "ignore";
    NAutoVTs = 0;                      # no text consoles to switch to
    ReserveVT = 0;
  };
  systemd.sleep.settings.Sleep = {
    AllowSuspend = "no";
    AllowHibernation = "no";
    AllowHybridSleep = "no";
    AllowSuspendThenHibernate = "no";
  };
}
