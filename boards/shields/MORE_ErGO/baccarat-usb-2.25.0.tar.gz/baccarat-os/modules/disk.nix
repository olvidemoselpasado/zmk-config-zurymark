# The stick: a boot partition, and one partition for the system (/nix) -- nothing
# else is ever written to it. Everything that is not the system lives in RAM: the
# bot's data, the browser's profile and cookies, the logs. Power off, and it is gone;
# every boot starts clean. (Later the bot's data comes from, and goes back to, the
# server.)
{ lib, settings, ... }: {
  # make-usb.sh builds the stick as an image in a small VM on your computer, then
  # writes only the used part of it: one long write, instead of many small ones
  disko.memSize = 4096;
  disko.devices = {
    disk.main = {
      type = "disk";
      imageSize = settings.imageSize;
      device = lib.mkDefault "/dev/sda";     # only used to make the stick: make-usb.sh gives the real one
      content = {
        type = "gpt";
        partitions = {
          ESP = {
            size = "1G";
            type = "EF00";
            content = {
              type = "filesystem";
              format = "vfat";
              mountpoint = "/boot";
              mountOptions = [ "umask=0077" ];
            };
          };
          nix = {
            size = "100%";
            content = {
              type = "filesystem";
              format = "ext4";
              mountpoint = "/nix";
              # a read must not become a write: the stick is the slow part
              mountOptions = [ "noatime" "commit=60" ];
            };
          };
        };
      };
    };
    # the whole of / is RAM
    nodev."/" = {
      fsType = "tmpfs";
      mountOptions = [ "size=3G" "mode=755" ];
    };
  };
}
