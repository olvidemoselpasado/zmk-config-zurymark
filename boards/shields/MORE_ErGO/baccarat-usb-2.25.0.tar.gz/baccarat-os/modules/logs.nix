# While testing (keepLogs in settings.nix): the log of each boot is copied onto the
# stick's system partition -- every 2 minutes, and once more at power-off -- so it
# survives the RAM root. `sudo ./make-usb.sh logs /dev/sdX` brings them back.
#
# Two files per boot, the last 5 boots kept, readable by root only:
#   <boot time>.short.log   the computer, its graphics, warnings and errors, and
#                           everything the browser and the screen said -- paste this one
#   <boot time>.log         everything
# No passwords are in them (the bot never logs its login; Wi-Fi keys aren't logged),
# but anyone holding the stick could read them: turn keepLogs off once it all works.
{ pkgs, lib, settings, ... }:
let
  dir = "/nix/var/baccarat-os/logs";
  save = pkgs.writeShellScript "baccarat-save-logs" ''
    set -u
    export PATH=${lib.makeBinPath (with pkgs; [ coreutils systemd pciutils procps gnugrep findutils ])}
    install -d -m 0700 ${dir}
    boot=$(uptime -s | tr ' :' '_-')          # when this boot started: one name per boot
    f=${dir}/$boot
    {
      echo "== saved $(date '+%F %T'), up $(uptime -p)"
      echo "== system: $(basename "$(readlink -f /run/current-system)")"
      echo "== computer: $(cat /sys/class/dmi/id/sys_vendor /sys/class/dmi/id/product_name 2>/dev/null | tr '\n' ' ')"
      echo "== kernel: $(uname -r)"
      echo "== graphics:"; lspci -nnk | grep -A3 -Ei 'vga|3d|display'
      echo "== memory:"; free -m
      echo "== disk:"; df -h / /nix
    } > "$f.head" 2>&1
    { cat "$f.head"
      echo "== warnings and errors:"
      journalctl -b --no-pager -o short-precise -p warning
      echo "== the browser and the screen (last 400 lines):"
      journalctl -b --no-pager -o short-precise -t kiosk -t firefox -t greetd -n 400
    } > "$f.short.log.new" 2>&1
    { cat "$f.head"; echo "== everything:"; journalctl -b --no-pager -o short-precise
    } > "$f.log.new" 2>&1
    mv -f "$f.short.log.new" "$f.short.log"
    mv -f "$f.log.new" "$f.log"
    rm -f "$f.head"
    # the last 5 boots
    ls -1t ${dir}/*.short.log | tail -n +6 | while read -r old; do
      rm -f "$old" "''${old%.short.log}.log"
    done
    sync -f ${dir}
  '';
in lib.mkIf (settings.keepLogs or true) {
  systemd.services.baccarat-logs = {
    description = "Copy this boot's log onto the stick";
    serviceConfig = { Type = "oneshot"; ExecStart = save; };
  };
  systemd.timers.baccarat-logs = {
    wantedBy = [ "timers.target" ];
    timerConfig = { OnBootSec = "40s"; OnUnitActiveSec = "2min"; AccuracySec = "10s"; };
  };
  # once more at power-off, after the bot and the screen have stopped and while the
  # stick is still mounted
  systemd.services.baccarat-logs-at-stop = {
    description = "Copy this boot's log onto the stick at power-off";
    wantedBy = [ "multi-user.target" ];
    after = [ "local-fs.target" "systemd-journald.service" ];
    before = [ "baccarat.service" "display-manager.service" ];
    serviceConfig = {
      Type = "oneshot";
      RemainAfterExit = true;
      ExecStart = "${pkgs.coreutils}/bin/true";
      ExecStop = save;
    };
  };
}
