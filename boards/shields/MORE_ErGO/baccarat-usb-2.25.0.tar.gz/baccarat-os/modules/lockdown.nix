# Who can do what. Two people live on the stick, and neither is root:
#
#   kiosk     logs in by itself and sees the screen: the game and the dashboard,
#             in the browser. No password, no shell, no terminal, no other program.
#   baccarat  runs the bot, as a system service. Its folder (/var/lib/baccarat: the
#             recordings, the tables, the login for the casino) is its own, mode 0700:
#             kiosk cannot read a byte of it. It may draw on kiosk's screen and send it
#             clicks -- that is the whole of its job -- and nothing else.
#
# There is no administrator account at all: the stick is changed by rebuilding it
# from this flake on another computer (make-usb.sh --update).
{ lib, ... }: {
  users.mutableUsers = false;
  users.users.root.hashedPassword = "!";             # no root login, ever
  # on purpose: nobody can log in with a password. The stick is changed only by
  # rebuilding it from another computer (make-usb.sh --update), never from inside it.
  users.allowNoPasswordLogin = true;
  security.sudo.enable = false;
  # only root may ask the Nix daemon for anything (the daily update runs as root)
  nix.settings.allowed-users = [ "root" ];
  nix.settings.trusted-users = [ "root" ];

  # no text consoles: nothing to switch to, nothing to log in on
  systemd.services."getty@tty1".enable = false;
  systemd.services."autovt@".enable = false;
  console.enable = true;                              # the boot messages, and the passphrase
  # no emergency shell when something fails at boot, no magic SysRq keys
  boot.initrd.systemd.emergencyAccess = false;
  systemd.enableEmergencyMode = false;
  boot.kernel.sysctl."kernel.sysrq" = 0;
  # nothing comes in from the network; the dashboard only listens on the stick itself
  networking.firewall.enable = true;
  services.openssh.enable = lib.mkForce false;
  # one user cannot see another's processes' details beyond the basics
  boot.kernel.sysctl."kernel.dmesg_restrict" = 1;
}
