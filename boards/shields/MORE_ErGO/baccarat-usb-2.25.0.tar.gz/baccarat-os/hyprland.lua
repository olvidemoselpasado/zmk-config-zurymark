-- The kiosk's screen: two windows, nothing else -- the dashboard on the left third,
-- the game on the rest. No key does anything here but type into the browser -- no
-- launcher, no terminal -- except two:
--   Super + right click, dragged   resizes (then "Save its width" on the dashboard)
--   Super + C                      closes a window: it comes back, fresh, in its place
-- @MODE@, @SCALE@, @KB@ and @SESSION@ are filled in from settings.nix.

hl.monitor({ output = "", mode = "@MODE@", position = "auto", scale = "@SCALE@" })

hl.config({
    general = {
        gaps_in = 0, gaps_out = 0, border_size = 1,
        layout = "dwindle", resize_on_border = false, allow_tearing = false,
    },
    decoration = { rounding = 0, shadow = { enabled = false }, blur = { enabled = false } },
    -- no animations: a window that moves while a click is on its way is a missed bet
    animations = { enabled = false },
    -- a new window always goes to the right, so the order things open in is the layout:
    -- the dashboard first (left), the game second (right)
    -- the first window keeps 2/3 of the default ratio (1.0 = halves): the dashboard,
    -- opened first, gets a third of the screen, the game two thirds
    dwindle = { preserve_split = true, force_split = 2, default_split_ratio = 0.66667 },
    misc = {
        disable_hyprland_logo = true, disable_splash_rendering = true,
        force_default_wallpaper = 0, disable_watchdog_warning = true,
        disable_autoreload = true,
        mouse_move_enables_dpms = true, key_press_enables_dpms = true,
    },
    input = {
        kb_layout = "@KB@",
        -- srvrkeys:none takes Ctrl+Alt+F1…F12 away: no switching to a text console
        kb_options = "srvrkeys:none",
        follow_mouse = 1,
    },
    ecosystem = { no_update_news = true, no_donation_nag = true },
})

-- Super + right mouse button, dragged: the split between the two windows moves.
-- (Only resizing: dragging a window to move it would swap the two, and the recorded
-- clicks would land on the wrong one.)
hl.bind("SUPER + mouse:273", hl.dsp.window.resize(), { mouse = true })

-- Super + C: close the focused window. If it was the dashboard or the game,
-- kiosk-session.sh opens it again, fresh, in its place a few seconds later; anything
-- else (a casino pop-up) just goes.
hl.bind("SUPER + C", hl.dsp.window.close())

hl.on("hyprland.start", function ()
    hl.exec_cmd("@SESSION@")
end)
