"""The locked stick's cryptography, in one small file shared by the three places that
need it: the build tool (make-usb.sh → build_lock.py), the boot bootstrap (unlock.py),
and — for verifying signatures only — the report server.

The idea, plainly:
  - The bot's Python is shipped ENCRYPTED on the stick (AES-256-GCM). The key that
    decrypts it is NOT on the stick: it lives on the server.
  - Each stick has its own signing keypair (Ed25519), made when the stick is flashed.
    The private key is on the stick (root-only); the public key and the code key are
    registered with the server at flash time.
  - At boot the stick signs a fresh timestamp with its private key and asks the server
    for the code key. The server checks the signature against the public key it has for
    that stick, checks the stick isn't revoked, and hands back the code key. The stick
    decrypts the bot into RAM and runs it.

What this is good for, and what it is not:
  - Good: someone who copies the stick's files can't read the bot's code (it is
    ciphertext), and you can REVOKE a stick on the server so it can't decrypt on its
    next boot — a kill switch.
  - Not: it can't stop someone who fully controls a running stick with network access,
    because the code is decrypted in RAM and the key comes over the wire. That needs a
    hardware root of trust (TPM/measured boot), which can be added later.

Only the Python package `cryptography` is used (it is in nixpkgs and well vetted).
"""

from __future__ import annotations

import time

from cryptography.exceptions import InvalidSignature, InvalidTag
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey, Ed25519PublicKey)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

CLOCK_SLOP = 300          # s: how far a signed timestamp may be from the server's clock
NONCE = 12                # AES-GCM nonce bytes, prepended to the ciphertext


# -- identity: an Ed25519 keypair per stick ------------------------------------------
def gen_identity() -> tuple[str, str]:
    """A new signing keypair. → (private key hex, public key hex)."""
    priv = Ed25519PrivateKey.generate()
    priv_hex = priv.private_bytes_raw().hex()
    pub_hex = priv.public_key().public_bytes_raw().hex()
    return priv_hex, pub_hex


def public_of(priv_hex: str) -> str:
    priv = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(priv_hex))
    return priv.public_key().public_bytes_raw().hex()


def sign(priv_hex: str, message: bytes) -> str:
    priv = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(priv_hex))
    return priv.sign(message).hex()


def verify(pub_hex: str, message: bytes, sig_hex: str) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub_hex)).verify(
            bytes.fromhex(sig_hex), message)
        return True
    except (InvalidSignature, ValueError):
        return False


# -- the request a stick signs to prove who it is ------------------------------------
def canonical(action: str, stick_id: str, ts: int, extra: str = "") -> bytes:
    """The exact bytes that get signed, so both sides form them the same way."""
    return f"baccarat-lock|{action}|{stick_id}|{ts}|{extra}".encode()


def fresh(ts: int, now: float | None = None) -> bool:
    """A signed timestamp is only accepted near the server's own clock (anti-replay)."""
    return abs((now if now is not None else time.time()) - ts) <= CLOCK_SLOP


# -- the bot's code, encrypted at rest -----------------------------------------------
def gen_code_key() -> str:
    """A fresh 256-bit key, as hex: what encrypts (and decrypts) one stick's code."""
    return AESGCM.generate_key(256).hex()


def encrypt(code_key_hex: str, plaintext: bytes) -> bytes:
    import os
    nonce = os.urandom(NONCE)
    ct = AESGCM(bytes.fromhex(code_key_hex)).encrypt(nonce, plaintext, b"baccarat-bot")
    return nonce + ct


def decrypt(code_key_hex: str, blob: bytes) -> bytes:
    nonce, ct = blob[:NONCE], blob[NONCE:]
    try:
        return AESGCM(bytes.fromhex(code_key_hex)).decrypt(nonce, ct, b"baccarat-bot")
    except InvalidTag as e:
        raise ValueError("the code key is wrong, or the encrypted bot was tampered with") from e
