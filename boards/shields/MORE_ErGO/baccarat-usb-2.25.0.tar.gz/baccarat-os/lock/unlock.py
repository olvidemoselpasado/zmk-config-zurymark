"""Boot time (a systemd service on the locked stick, before the bot starts): ask the
server for this stick's code key, decrypt the bot into RAM.

  python3 unlock.py --key /nix/var/baccarat-os/lock/stick.key \
                    --enc /nix/var/baccarat-os/lock/bot.enc \
                    --id-file /nix/var/baccarat-os/lock/stick.id \
                    --server https://192.168.0.2:4444 --out /run/baccarat-code

Exit 0: the bot's code is in --out (a tmpfs). Any other exit: it is not, and the bot
must not start. The server returns the key only if this stick's signature checks out
and the stick has not been revoked, so a revoked or unknown stick simply can't boot the
bot.
"""

from __future__ import annotations

import argparse
import json
import shutil
import ssl
import sys
import tarfile
import time
import urllib.error
import urllib.request
from pathlib import Path

import locklib


def ask_for_key(server: str, stick_id: str, priv: str, insecure: bool) -> str:
    ts = int(time.time())
    sig = locklib.sign(priv, locklib.canonical("unlock", stick_id, ts))
    body = json.dumps({"stick_id": stick_id, "ts": ts, "sig": sig}).encode()
    req = urllib.request.Request(server.rstrip("/") + "/v1/unlock", data=body, method="POST",
                                 headers={"Content-Type": "application/json"})
    ctx = ssl._create_unverified_context() if insecure else None
    with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
        reply = json.loads(r.read() or b"{}")
    key = reply.get("code_key")
    if not key:
        raise SystemExit(f"the server would not unlock this stick: {reply.get('error', reply)}")
    return key


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--key", required=True, type=Path)
    ap.add_argument("--enc", required=True, type=Path)
    ap.add_argument("--id-file", required=True, type=Path)
    ap.add_argument("--server", required=True)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--insecure", action="store_true")
    ap.add_argument("--tries", type=int, default=30, help="the network may not be up yet")
    args = ap.parse_args()

    priv = args.key.read_text().strip()
    stick_id = args.id_file.read_text().strip()

    last = ""
    for i in range(args.tries):
        try:
            code_key = ask_for_key(args.server, stick_id, priv, args.insecure)
            break
        except SystemExit:
            raise                                  # the server refused: do not keep trying
        except (urllib.error.URLError, OSError, ValueError) as e:
            last = str(getattr(e, "reason", e))
            print(f"waiting for the server ({last})… {i + 1}/{args.tries}", file=sys.stderr)
            time.sleep(4)
    else:
        raise SystemExit(f"could not reach the server to unlock: {last}")

    plain = locklib.decrypt(code_key, args.enc.read_bytes())
    if args.out.exists():
        shutil.rmtree(args.out)
    args.out.mkdir(parents=True)
    with tarfile.open(fileobj=__import__("io").BytesIO(plain), mode="r:gz") as tar:
        _safe_extract(tar, args.out)
    print(f"the bot was unlocked into {args.out}")
    return 0


def _safe_extract(tar: tarfile.TarFile, dest: Path) -> None:
    dest = dest.resolve()
    for m in tar.getmembers():
        target = (dest / m.name).resolve()
        if not str(target).startswith(str(dest)):
            raise SystemExit(f"refusing a path outside {dest}: {m.name}")
    tar.extractall(dest)                            # noqa: S202 — members checked above


if __name__ == "__main__":
    sys.exit(main())
