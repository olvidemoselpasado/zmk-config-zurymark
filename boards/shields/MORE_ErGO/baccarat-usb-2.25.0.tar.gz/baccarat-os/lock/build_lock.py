"""Build time (called by make-usb.sh for a locked stick): make this stick's keys,
encrypt the bot's code, and register the stick with the server.

  python3 build_lock.py --source ../bot --out OUT --server https://192.168.0.2:4444 \
                        --enroll-key SECRET

Writes into OUT:
  bot.enc        the bot's Python, encrypted (AES-256-GCM) — this goes on the stick
  stick.key      this stick's private key (0600) — this goes on the stick
  stick.id       this stick's id

And registers {stick id, public key, code key} with the server, so the stick can ask
for the code key at boot. The plaintext code key is never written to OUT or the stick.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import ssl
import sys
import tarfile
import urllib.request
from pathlib import Path

import locklib

SKIP = {"data", "tests", "__pycache__", ".git"}


def pack_source(src: Path) -> bytes:
    """A .tar.gz of the bot package, without data, tests or caches."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for p in sorted(src.rglob("*")):
            rel = p.relative_to(src)
            if any(part in SKIP or part.endswith(".pyc") for part in rel.parts):
                continue
            if p.is_file():
                tar.add(p, arcname=str(rel))
    return buf.getvalue()


def enroll(server: str, enroll_key: str, stick_id: str, pub: str, code_key: str,
           insecure: bool) -> None:
    body = json.dumps({"stick_id": stick_id, "public_key": pub, "code_key": code_key}).encode()
    req = urllib.request.Request(server.rstrip("/") + "/v1/enroll", data=body, method="POST",
                                 headers={"Content-Type": "application/json",
                                          "X-Enroll-Key": enroll_key})
    ctx = ssl._create_unverified_context() if insecure else None
    with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
        reply = json.loads(r.read() or b"{}")
    if not reply.get("ok"):
        raise SystemExit(f"the server did not accept the enrolment: {reply}")


def main() -> None:
    ap = argparse.ArgumentParser(description="Encrypt the bot and register a locked stick.")
    ap.add_argument("--source", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--server", required=True)
    ap.add_argument("--enroll-key", required=True)
    ap.add_argument("--insecure", action="store_true",
                    help="skip HTTPS certificate checking (self-signed server)")
    args = ap.parse_args()

    if not (args.source / "baccarat").is_dir():
        raise SystemExit(f"{args.source} is not the bot (no baccarat/ inside).")
    args.out.mkdir(parents=True, exist_ok=True)

    priv, pub = locklib.gen_identity()
    code_key = locklib.gen_code_key()
    stick_id = "usb-" + hashlib.sha256(bytes.fromhex(pub)).hexdigest()[:24]

    plain = pack_source(args.source)
    (args.out / "bot.enc").write_bytes(locklib.encrypt(code_key, plain))
    key_file = args.out / "stick.key"
    key_file.write_text(priv + "\n")
    os.chmod(key_file, 0o600)
    (args.out / "stick.id").write_text(stick_id + "\n")

    enroll(args.server, args.enroll_key, stick_id, pub, code_key, args.insecure)
    print(stick_id)


if __name__ == "__main__":
    main()
