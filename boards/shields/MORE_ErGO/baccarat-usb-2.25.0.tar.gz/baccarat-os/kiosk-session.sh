# shellcheck shell=bash
# Runs as kiosk when the screen comes up (Hyprland starts it). Opens the doors the
# bot needs into this screen -- and only those -- then the two windows.
# @SETFACL@ @FIREFOX@ @CURL@ @HYPRCTL@ @JQ@ @SYSTEMDCAT@ @GAME_URL@ are filled in by kiosk.nix.
set -u
rt="$XDG_RUNTIME_DIR"
sig="$HYPRLAND_INSTANCE_SIGNATURE"
wl="$WAYLAND_DISPLAY"
dash="http://127.0.0.1:8765"

say() { printf '%s\n' "$*" | @SYSTEMDCAT@ -t kiosk; }

# The bot (user baccarat) may draw on nothing and read nothing of kiosk's -- except:
# the Wayland socket (to take screenshots and type) and Hyprland's two sockets (to
# move the pointer and size the game window). Directories: pass through, not list.
for _ in $(seq 1 50); do [ -S "$rt/hypr/$sig/.socket.sock" ] && break; sleep 0.1; done
@SETFACL@ -m u:baccarat:x "$rt" "$rt/hypr" "$rt/hypr/$sig"
@SETFACL@ -m u:baccarat:rw "$rt/$wl"
for s in "$rt/hypr/$sig"/.socket*.sock; do @SETFACL@ -m u:baccarat:rw "$s"; done

# tell the bot where this screen is (it is waiting for exactly this file)
umask 027
printf 'XDG_RUNTIME_DIR=%s\nWAYLAND_DISPLAY=%s\nHYPRLAND_INSTANCE_SIGNATURE=%s\n' \
  "$rt" "$wl" "$sig" > /run/baccarat-display/env.new
mv -f /run/baccarat-display/env.new /run/baccarat-display/env
umask 077

# the dashboard answers once the bot has seen the screen
for _ in $(seq 1 90); do @CURL@ -fs -o /dev/null "$dash" && break; sleep 1; done

# --- the browser ----------------------------------------------------------------------
# Everything Firefox says goes to the system log (make-usb.sh logs brings it back to
# another computer). Every crash of one of its parts is noted, with the time.
crashes="$rt/firefox-crashes"; : > "$crashes"
watch_output() {
  while IFS= read -r line; do
    printf '%s\n' "$line"
    case "$line" in
      *"exited on signal 9"*|*"exited on signal 15"*) ;;      # closed on purpose
      *"exited on signal"*) date +%s >> "$crashes" ;;          # a part of it crashed
    esac
  done | @SYSTEMDCAT@ -t firefox
}

# If it crashes again and again on this computer, it is started again with one more
# thing turned off each time, from the most likely culprit to the least:
level=0
LEVELS=("normal"
        "graphics drawn without the graphics chip"
        "… and without Firefox's sandboxes"
        "… and through XWayland instead of Wayland")
fx_env() {
  echo MOZ_CRASHREPORTER_DISABLE=1          # no 'Firefox crashed' box: it is restarted here
  if [ "$level" -ge 1 ]; then echo LIBGL_ALWAYS_SOFTWARE=1; echo LIBVA_DRIVER_NAME=none; fi
  if [ "$level" -ge 2 ]; then
    echo MOZ_DISABLE_CONTENT_SANDBOX=1; echo MOZ_DISABLE_RDD_SANDBOX=1
    echo MOZ_DISABLE_GPU_SANDBOX=1; echo MOZ_DISABLE_SOCKET_PROCESS_SANDBOX=1
    echo MOZ_DISABLE_UTILITY_SANDBOX=1
  fi
  if [ "$level" -ge 3 ]; then echo MOZ_ENABLE_WAYLAND=0; fi
}
browser() {
  local e; mapfile -t e < <(fx_env)
  env "${e[@]}" @FIREFOX@ "$@" > >(watch_output) 2>&1 &
}

# The browser's windows, one line each: "dash <address>" or "game <address>". The
# dashboard is the window it was opened in (its address, kept from the moment it was
# opened) -- or, before that is known, the one with its page's name in the title. Not
# the title alone: a page that blinks "⚠ BET NOT ACCEPTED" in its title must not look
# like a closed dashboard, or a second one gets opened over the game.
DASH_TITLE="Baccarat control"
dash_addr=""
# shellcheck disable=SC2016  # $t and $a are jq's, not the shell's
browser_windows() {
  @HYPRCTL@ clients -j 2>/dev/null | @JQ@ -r --arg t "$DASH_TITLE" --arg a "$dash_addr" '.[]
    | select(.class == "firefox" or .class == "org.mozilla.firefox")
    | (if (.address == $a or ($a == "" and (.title | contains($t)))) then "dash" else "game" end)
      + " " + .address' 2>/dev/null
}
addresses() { browser_windows | while read -r _ a; do echo "$a"; done; }
# the address of a window that wasn't there before (given: the addresses before)
new_window() {
  local before=$1 a
  for _ in $(seq 1 30); do
    for a in $(addresses); do
      case " $before " in *" $a "*) ;; *) echo "$a"; return 0 ;; esac
    done
    sleep 1
  done
  return 1
}
windows() { browser_windows | grep -c .; }
count() { browser_windows | grep -c "^$1 "; }
fx=""
# The game's page: the one set on the dashboard (Interface → the game's page; it is part
# of the bot's configuration, from the server), else settings.nix's gameUrl, else a blank
# window. Asked each time the window opens -- the bot answers once its configuration is
# in (a new stick: once it has been approved on the server's page).
game_url() {
  local got="" url=""
  for _ in $(seq 1 900); do
    got=$(@CURL@ -fs "$dash/api/game-url") &&
      [ "$(printf '%s' "$got" | @JQ@ -r '.ready' 2>/dev/null)" = true ] && break
    sleep 2
  done
  url=$(printf '%s' "$got" | @JQ@ -r '.url // ""' 2>/dev/null)
  printf '%s' "${url:-@GAME_URL@}"
}
open_both() {
  # the dashboard first, on the left third; the game second, on the rest -- the
  # layout the recorded coordinates were made with
  dash_addr=""
  local before
  before=$(addresses | tr '\n' ' ')
  browser --new-window "$dash"; fx=$!
  dash_addr=$(new_window "$before") || dash_addr=""
  browser --new-window "$(game_url)"
}
# Closed with Super+C (or by the page): back in its place. A new window always opens
# on the right, which is the game's place; the dashboard is then swapped to the left.
reopen_game() {
  say "the game's window was closed — opening it again"
  browser --new-window "$(game_url)"
}
reopen_dashboard() {
  local before addr
  say "the dashboard's window was closed — opening it again"
  before=$(addresses | tr '\n' ' ')
  browser --new-window "$dash"
  addr=$(new_window "$before") || return 0
  dash_addr=$addr
  @HYPRCTL@ dispatch \
    "hl.dsp.window.swap({ direction = \"left\", window = \"address:$addr\" })" >/dev/null
}
stop_browser() {
  [ -n "$fx" ] || return 0
  kill "$fx" 2>/dev/null
  for _ in $(seq 1 10); do kill -0 "$fx" 2>/dev/null || break; sleep 1; done
  kill -9 "$fx" 2>/dev/null
  for _ in $(seq 1 10); do [ "$(windows)" -eq 0 ] && break; sleep 1; done
}
# two crashes within two minutes: one step down
step_down() {
  local since n=0 t
  since=$(( $(date +%s) - 120 ))
  while read -r t; do [ "$t" -gt "$since" ] && n=$((n + 1)); done < "$crashes"
  [ "$n" -ge 2 ] && [ "$level" -lt $(( ${#LEVELS[@]} - 1 )) ] || return 1
  level=$((level + 1)); : > "$crashes"
  say "Firefox crashed $n times in two minutes — starting it again: ${LEVELS[$level]}"
}

say "screen up — opening the browser (${LEVELS[$level]})"
open_both

# Whatever was closed comes back in its place: the browser altogether, or one of the
# two windows. (Looked at twice, 3 s apart: a page that is loading has no title yet.)
while sleep 5; do
  if [ "$(windows)" -eq 0 ]; then
    sleep 3
    [ "$(windows)" -eq 0 ] || continue
    if ! kill -0 "$fx" 2>/dev/null; then
      say "Firefox stopped"; date +%s >> "$crashes"
    fi
    step_down || true
    stop_browser; open_both
  elif step_down; then
    stop_browser; open_both
  elif [ "$(count dash)" -eq 0 ] || [ "$(count game)" -eq 0 ]; then
    sleep 3
    [ "$(count game)" -eq 0 ] && reopen_game
    [ "$(count dash)" -eq 0 ] && reopen_dashboard
  fi
done
