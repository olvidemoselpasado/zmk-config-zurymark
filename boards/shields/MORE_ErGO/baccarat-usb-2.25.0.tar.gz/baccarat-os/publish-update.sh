#!/usr/bin/env bash
# Upload what is new of an update to the server, then make it the release every stick
# moves to. Called by `make-usb.sh publish`; it can be run by itself too:
#
#   publish-update.sh SERVER CACHE_DIR SYSTEM VERSION
#
# CACHE_DIR is what `nix copy --to file://…` wrote (signed with your key). Only the
# files the server doesn't have yet are sent: the first time that is the whole system
# (a few GB, once), after that only what changed (a new bot: a few MB).
# The server page's password: $BACCARAT_ADMIN_PASSWORD, else it is asked for.
set -euo pipefail
server=${1%/}; cache=$2; system=$3; version=$4

if [ -z "${BACCARAT_ADMIN_PASSWORD:-}" ]; then
  read -r -s -p "The server page's password (user admin): " BACCARAT_ADMIN_PASSWORD; echo
fi
auth=(-u "admin:$BACCARAT_ADMIN_PASSWORD")
CURL=(curl -fsS --retry 3 --retry-delay 2)
[ -n "${BACCARAT_SERVER_CA:-}" ] && CURL+=(--cacert "$BACCARAT_SERVER_CA")

cd "$cache"
mapfile -t files < <(find . -type f ! -name '*.part*' -printf '%P\n' | sort)
missing=$(printf '%s\n' "${files[@]}" | jq -R . | jq -s '{names: .}' |
  "${CURL[@]}" "${auth[@]}" -H 'Content-Type: application/json' --data-binary @- \
    "$server/admin/cache/have" | jq -r '.missing[]')

# the packages first, then what describes them, then the store's own header: what
# describes a package never points at one that isn't there yet
n=0; bytes=0; todo=$(printf '%s\n' "$missing" | grep -c . || true)
for pass in 'nar/*' '*.ls' '*.narinfo' 'nix-cache-info'; do
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    # shellcheck disable=SC2254   # $pass is a pattern on purpose
    case "$f" in $pass) ;; *) continue ;; esac
    "${CURL[@]}" "${auth[@]}" -T "$f" "$server/admin/cache/$f" >/dev/null
    n=$((n + 1)); bytes=$((bytes + $(stat -c %s "$f")))
    printf '\r  uploaded %d of %d files (%d MB)' "$n" "$todo" $((bytes / 1048576))
  done <<< "$missing"
done
[ "$n" -gt 0 ] && echo

jq -n --arg s "$system" --arg v "$version" '{system: $s, version: $v}' |
  "${CURL[@]}" "${auth[@]}" -H 'Content-Type: application/json' --data-binary @- \
    "$server/admin/release" >/dev/null
echo "  release: $version — $n new file(s), $((bytes / 1048576)) MB sent"
